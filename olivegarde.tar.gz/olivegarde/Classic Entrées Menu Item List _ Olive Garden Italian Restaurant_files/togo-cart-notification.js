var viewCheckoutText, viewCartText, itemAddedInfo;
$(document).ready(function () {	
	viewCheckoutText = $('#viewCheckoutText').val();
	viewCartText = $('#viewCartText').val();
	itemAddedInfo = $('#itemAddedInfo').val();
});

function viewCartDetailMobile() {
	$height = $(window).height();
	var headerheight = $('header').height();
	$('#drawer-panel').addClass('opendrawer-panel');
	$('#body-overlay').show();
	$('.drawer-container').css({ 'top': '-' + headerheight + 'px', 'height': 'calc(100vh)' });
	$('body').css({ 'overflow': 'auto' });
	callOrderDetail();
}
function viewCartDetail() {
	$('#addCart-popup').hide();
	if ($('#notificationViewCartSliderEnabled').val() === 'true') {

		$height = $(window).height();
		var headerheight = $('header').height();
		$('#drawer-panel').addClass('opendrawer-panel');
		$('#body-overlay').show();
		$('.drawer-container').css({ 'top': '-' + headerheight + 'px', 'height': 'calc(100vh)' });
		$('body').css({ 'overflow': 'auto' });
		callOrderDetail();
	} else {
		window.location.href = URLPrefixLocale('/cart');
	}
	//spanish coupon rewards header height 
	/*if($('#rewards-tab a').text().length > 20 ){
	    var rewardsHeight = $('#rewards-tab').height();
        $('#coupon-tab a').css('height',rewardsHeight);
    }*/
	$('body').addClass('cart-slider-open');
	
	if($('#cartSliderCrossSellEnabled').val()==='true') {
		cart_slider_related_products();
	}
}

function viewCheckoutDetail() {
	/*$('#addCart-popup').hide();
	if ($('#notificationDirectCheckoutEnabled').val() === 'true') {
		var uri = '/web-api/order/moveToPurchase';
		var data = {togoNewFlow: true};
		apiCall(uri, 'POST', data, function (response) {
			if (response.successResponse) {
				window.location.href = URLPrefixLocale('/commerce/checkout');
			}else{
				if(response.errorResponse && response.errorResponse.fault
						&& response.errorResponse.fault.faultDescription){
						$('#moveToPurchaseErrorModal').modal('show');
						$('#checkoutErrorMsg').removeClass('hidden');
						$('#checkoutErrorMsg').html(response.errorResponse.fault.faultDescription);
				}
			}

		}, null);
	} else {
		window.location.href = URLPrefixLocale('/cart');
	}*/
	var minDeliveryAmtThreshold = parseInt($('#minDeliveryAmtThreshold').val());
	$('#addCart-popup').hide();
	if ($('#notificationDirectCheckoutEnabled').val() === 'true') {
		if ($('#orderTypeValue').val() !== undefined && $('#orderTypeValue').val() !== '2') {
				checkoutCall();
		} else {
			if ($('#cateringTotal').val() > minDeliveryAmtThreshold) {
				checkoutCall();
			} else {
				handleCateringItems();
			}
		 }
	} else {
		window.location.href = '/cart';
	}
}

function cartDetails(itemCount, isDesktop) {
	callOrderDetail();
	if (isDesktop) {
		$('#drawer-openmenu').append('<span class="order_num">' + itemCount + '</span>');
	} else {
		$('.dar-cart-count').show();
		$('.dar-cart-count').html(itemCount + '');
	}
	$.ajax({
		url: URLPrefixLocale('/browse/gadgets/togo-cart-notification.jsp'),
		success: function (response1) {
			var stored_cartItems = JSON.parse(sessionStorage.getItem('CartItems'));
			$("#addCart-popup").html(response1);
			$('#item-added-info').html($('#itemAddedCartText').val());
			getNotificationDetails(stored_cartItems);
			if ($('#notificationDirectCheckoutEnabled').val() === 'true') {
				$('#view-checkout').html($('#viewCheckoutText').val());
			}
			viewCartText = $('#viewCartText').val();
			$('#view-cart').html($('#viewCartText').val());
		}
	});
}
function updateURL() {
	if (window.location.search && (window.location.search.indexOf('notifyCart') != -1
		|| window.location.search.indexOf('reordered') != -1
		|| (window.location.pathname && window.location.pathname.indexOf('menu-listing') != -1
			&& window.location.search.indexOf('_requestid') != -1))) {
		var newUrl = refineUrl();
		window.history.pushState("object or string", "Title", newUrl);
	}

	function refineUrl() {
		var url = window.location.href;
		var value = url = url.slice(0, url.indexOf('?'));
		value = value.replace('@System.Web.Configuration.WebConfigurationManager.AppSettings["BaseURL"]', '');
		return value;
	}
}
function getNotificationDetails(response) {
	updateURL();
	var resdata = response.successResponse.order.commerceItems;
	var orderNotificationDetails = document.getElementById("notificationDetails-template").innerHTML;
	var orderNotificationDetailsTemplate = Handlebars.compile(orderNotificationDetails);
	var dataCount = reordered ? reorderedCount : 1;
	var data = '';
	if (dataCount) {
		if (dataCount == 1) {
			data = orderNotificationDetailsTemplate(resdata[resdata.length - 1]);
		}
		$("#renderedNotificationDetails").html(data);
		if (dataCount > 1) {
			$('#item-added-info').html(itemAddedInfo);
		}
		$("#addCart-popup").show();
		$('#addCart-popup').delay(5000).fadeOut(1000);
	}
}

function cartClose() {
	$("#addCart-popup").stop().fadeOut(1000);
}