/**
 * Generic method to be used for calling an ATG FormHandler
 * asynchronously using AJAX
 *
 * @param obj -
 *            The input DOM object
 * @param extraParams(optional) -
 *            Additional query string to be passed if necessary
 * @param successMethod -
 *            reference of the success callback function to be
 *            called on AJAX success
 * @param form(optional) -
 * 			 pass the form here if form is not enclosing the
 * 			input DOM object
 *
*/

/* Gift cart js function is replaced in customerservice.js*/
function doAJAX(inputObj, extraParams, successMethod, form) {

	var parentForm = form;
	// if form object is not passed, then use closet form
	if (parentForm == undefined) {
		parentForm = inputObj.closest("form");
	}
	// serialize the data in the form
	var data = parentForm.serialize();
	
	var url = parentForm.attr("action");




	if (extraParams != null) {
		data = data + extraParams;
	}
	// disabling the inputs for the duration of the ajax request
	$("input, button, a, span").prop("disabled", true);

	// fire off the request to the url
	request = $.ajax({
		url : url,
		type : "post",
		data : data
	});

	// callback handler that will be called on success
	request.done(function(response, textStatus, jqXHR) {
		/**
		 * response - HTML String output of the AJAX call parentForm - the form
		 * inputObj - The input element bound to the event jqXHR -
		 * XMLHttpRequest object
		 */
		successMethod(response, parentForm, inputObj, jqXHR);
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console
				.error("The following error occured: " + textStatus,
						errorThrown);
	});

	// callback handler that will be called regardless
	// if the request failed or succeeded
	request.always(function() {		
		$("input, button, a, span").prop("disabled", false);
	});

}

/**
 * Generic method to be used for calling an ATG FormHandler
 * asynchronously using AJAX without disabling the input fields.
 *
 * @param obj -
 *            The input DOM object
 * @param extraParams(optional) -
 *            Additional query string to be passed if necessary
 * @param successMethod -
 *            reference of the success callback function to be
 *            called on AJAX success
 * @param form(optional) -
 * 			 pass the form here if form is not enclosing the
 * 			input DOM object
 *
 */
function doAJAXEnableInputs(inputObj, extraParams, successMethod, form) {

	var parentForm = form;

	//if form object is not passed, then use closest form
	if(parentForm == undefined) {
		parentForm = inputObj.closest("form");
	}
	//select input elements in the form
	var formElements = parentForm.find("input, select, textarea");
	// serialize the data in the form
	var data = formElements.serialize();
	var url = parentForm.attr("action");

	if (extraParams != null) {
		data = data + extraParams;
	}

	// fire off the request to the url
	request = $.ajax({
		url : url,
		type : "post",
		data : data
	});

	// callback handler that will be called on success
	request.done(function(response, textStatus, jqXHR) {
		/**
		 * response - HTML String output of the AJAX call
		 * parentForm - the form
		 * inputObj - The input element bound to the event
		 * jqXHR - XMLHttpRequest object
		 */
		successMethod(response, parentForm, inputObj, jqXHR);
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
}

function scrolloverlay(getID){
	getID.animate({paddingTop:"0px"}, function(){
		var getscrolltop = parseInt($(window).scrollTop());
		$(window).scrollTop(getscrolltop-2000);
	});
}

jQuery(document).ready(
		function() {
			var emailSignupCookieValidDays = Number($.trim($('#emailSignupCookieResetTime').val()));
			var emailSignupCounterForSession = Number($.trim($('#emailSignupSessionCounter').val()));
			/*
             * start : opt-in select default
             */
             var hostname = window.location.hostname;
             var pathname = window.location.pathname;
             if(hostname.indexOf('olivegarden.com') > -1 && pathname.indexOf('customer-service/registration') > -1){
                   $("#primaryOptin_reg").find('#offers').attr('checked', true);
                   $('#primaryOptin_reg').css('background-position', '0% -24px');
             }
             /*
             * End : opt-in select default
             */
			/*pasta pass enhancement start*/
			$(".contact_bd").find(".error_msg").each(function(){
                if( $(this).text() !== "Please select reason for contact."){
                    $(".contact_bd").find(".radio_new").each(function(){
                       if($(this).next("label").text() === sessionStorage.getItem("radioToremember")){
                           $(this).addClass("radio_checked");
						   $("#ppCntReason").val("false");
                       }
                        
                    });
                   
                }
            });
			if(window.location.pathname.indexOf("/contact-us/confirmation")>-1 ||( window.location.pathname.indexOf("/contact-us") >-1 && window.location.pathname.indexOf("specials/never-ending-pasta-pass/contact-us") === -1 )){
			    sessionStorage.removeItem("radioToremember");
			}
			/*pasta pass enhancement end*/
			
			 var hostname = window.location.hostname;
             var pathname = window.location.pathname;
			 var restcookie = $.cookie('DRIREST');
			 if(restcookie){
				var restid= restcookie.split('@@')[0];
				var restlist = ['700928','701019','701020','701012','701013','701014','701016','701015','701017','3900002','3900003','3900004','3900005','3900006'];
				var restexists =(restlist.indexOf(restid));

				if(pathname.indexOf('/commerce/checkout') > -1 && restexists != -1){
					//469724696 fix to hide payonline for CA restaurants. The class changed due to ToGO redesign launch
					// hide pay online radio
					$('#pay_online').parent().parent().parent().hide();

			        // hide We accept text
					$('span.grey_text_recipe1.txtbold:last').parent().hide();
					// check payinrestaurnt radio
					$('#pay_in_rest').attr('checked', true);
					$('#pay_in_rest').click();
				}
			}

             /*
             * start : avoid multiple clicks fix


             var count= 0;
             $(".capitalize").click(function(e) {
            	 count++;
            	 if(count>1){
            		 //e.preventDefault();
            	 }
             });


             * End : avoid multiple clicks fix
             		*/

			/** function to show sign up overlay */

			function showEmailSignupOverlay(isLoyaltyEnabled) {
				var email_cookie = $.cookie("email_signup_cookie");
				var loyalty_cookie = $.cookie("LOYALTY_ACCOUNT_ID");
				var cookieFlag = false;
				var cookieEnabled = navigator.cookieEnabled;
				var emailSignupCounterPerSession = $.cookie("emailSignupCounterPerSession");
				if(!emailSignupCounterPerSession){
					$.cookie("emailSignupCounterPerSession",1,{path: "/"});
					emailSignupCounterPerSession = 1;
				}else{
					emailSignupCounterPerSession = Number(emailSignupCounterPerSession);
				}
				if(email_cookie !=null && email_cookie != undefined) {
					cookieFlag = true;
					var cookieValues = email_cookie.split(":");
					var cookie_counter = cookieValues[0];
					var cookieCheckFlag = cookieValues[1];
				}
				var emailSignupCounter=new Number($("#emailSignupCounter").val());

				if(cookieEnabled && (emailSignupCounterPerSession <= emailSignupCounterForSession) && (emailSignupCounter > 0 || (emailSignupCounter != null && emailSignupCounter != ""))) {

					if(cookieFlag == false || (cookieFlag && cookie_counter <= emailSignupCounter && cookieCheckFlag != "true")) {
						 var emailsignup_url=$("#crm-popup").text().trim();
						 if(emailsignup_url == "" || emailsignup_url == null || emailsignup_url == undefined){
							var emailsignup_url=$("#emailSignup").val(); 
						 }
						 if((isLoyaltyEnabled !=null && isLoyaltyEnabled != undefined && isLoyaltyEnabled == "true") && (loyalty_cookie == null || loyalty_cookie == undefined))
						 {
							 var emailsignup_interstitial_url=$("#emailSignUpInterstitialOverlayUrl").val();
							 var emailsignup_url=emailsignup_interstitial_url;
							 if(location.protocol == "https:"){
								emailsignup_url = "/customer-service"+emailsignup_url;
							 }
						 }
					       var request = $.ajax({
					              url : emailsignup_url,
					              cache : false
					       });

					       request.done(function(response, textStatus, jqXHR) {
								  $.cookie("emailSignupCounterPerSession",(emailSignupCounterPerSession+1),{path: "/"});
					    	      if((isLoyaltyEnabled !=null && isLoyaltyEnabled != undefined && isLoyaltyEnabled == "true") && (loyalty_cookie == null || loyalty_cookie == undefined))
					    		  {
					    	      var modalDiv = $($.parseHTML(response)).filter("#loyaltyEnrollmentSignupOverlayInModal");
					    		  }
					    	   	  else
					    	   	  {
					    	   		var modalDiv = $($.parseHTML(response)).filter("#emailSignUpModal");
					    	   	  }
								  /*** optin fix on home interstitial overlay starts*/


								  modalDiv.find(".checkbox_d").dgStyle();


								  modalDiv.find('#join_checkbox,#globalOptin_reg').on('click', function(e) {
											var a=modalDiv.find(this).css('background-position');
											if(a=='0% 0px'){$('.opt_in_darden_checkin .checkbox_d.cd_check').css('background-position','left 0px').data('checked',false).find(":checkbox").removeAttr('checked');}
											else{modalDiv.find('.opt_in_darden_checkin .checkbox_d.cd_check').css('background-position','left -24px').data('checked', true).find(":checkbox").attr('checked', true).prop('checked',true);}
											//event.preventDefault();
									});

									modalDiv.find('.opt_in_darden_checkin .checkbox_d.cd_check').on('click', function(e) {
									var innerCheckbox=modalDiv.find(this).css('background-position');
											if(innerCheckbox=='0% -24px'){
												modalDiv.find('#join_checkbox,#globalOptin_reg').css('background-position','left -24px').data('checked',true).find(":checkbox").attr('checked', true).prop('checked',true);
												}

											else{
												modalDiv.find('#join_checkbox,#globalOptin_reg').css('background-position','left 0px').data('checked',false).find(":checkbox").removeAttr('checked');
												var inputs = modalDiv.find(".opt_in_darden_checkin .checkbox_d.cd_check");
												for(var i = 0; i < inputs.length; i++){
													var inputbg=modalDiv.find(inputs[i]).css('background-position');
													if(inputbg=='0% -24px'){
													modalDiv.find('#join_checkbox,#globalOptin_reg').css('background-position','left -24px').data('checked',true).find(":checkbox").attr('checked', true).prop('checked',true);
														}
													}
												}
									});
								  /*** optin fix on home interstitial overlay ends*/
					              modalDiv.find(".styled-select select, .styled-select-red select").each(function() {
					                     $(this).wrap("<span class='select-wrapper'></span>");
					                     $(this).after("<span class='holder'></span>");
					                     var firstOption = $(this).find("option:first").text();
					                     $(this).next(".holder").text(firstOption);
					                     });
					              scrolloverlay(modalDiv);

					              modalDiv.modal();
									if($("#dtmenabled").val()=="true")
									{
										// on display of modal Added for welcome popup
										  let modalData = {
											 "modalName":"welcome eclub signup",
											 "modalIntent":"welcome user signup",
											 "modalContent":"welcome eclub signup form"
										   }
											AU.dispatchEvent('AnalyticsEvent','DisplayModal',modalData);
										// DTM eclub event END
									}

					              if($.cookie('email_signup_cookie') == null) {
					            	  var count = 1;
					            	  var cookie_value=++count+":"+false;
									  var expireOn = $.cookie('email_signup_cookie', cookie_value, { expires: emailSignupCookieValidDays, path: "/"});
									  expireOn = expireOn.match(/expires=(.+); path/);
									  expireOn = expireOn[1];
									  $.cookie('email_signup_cookie_expire', expireOn, { expires: emailSignupCookieValidDays, path: "/"});
					    	        }
					              else{
					            	  if(cookie_counter <= emailSignupCounter){
					            			cookie_value = ++cookie_counter+":"+cookieCheckFlag;
					            			$.cookie('email_signup_cookie', cookie_value, { expires: getCrmCookieExpireDate(), path: "/"});
					            		}
					              }
					       });


					       // callback handler that will be called on failure
					       request.fail(function(jqXHR, textStatus, errorThrown) {
					              // log the error to the console
					              console.error("The following error occured: " + textStatus,
					                                         errorThrown);
					       });


					}
				}



			}
			/**
			 * AJAX call to invoke handleSavePartySize
			 */
			$(document).on("click", "#savePartySize", function() {
				/** Omniture tracking start **/
				//dtm flag check
				if($("#dtmenabled").val()=="false")
				{
				var linktext = $("#catDeliveryPartySize").val();
				s.linkTrackVars="eVar83";
				s.eVar83=linktext;
				s.tl($(this),'o','save party size');
				}
					/** Omniture tracking end **/
				var form = $(this).closest("form");
				doAJAX($(this), null, successUpdatePartySize);
				// preventing the page from being refreshed
				return false;

			});

			/*get CRM Popup cookie expire date*/
			function getCrmCookieExpireDate(){
				var expireOn = $.cookie("email_signup_cookie_expire");
				if(expireOn){
					expireOn = new Date(expireOn);
				}else{					
					expireOn = $.cookie('email_signup_cookie_expire', "", { expires: emailSignupCookieValidDays, path: "/"});
					expireOn = expireOn.match(/expires=(.+); path/);
					expireOn = expireOn[1];
					$.cookie('email_signup_cookie_expire', expireOn, { expires: emailSignupCookieValidDays, path: "/"});
					expireOn = new Date(expireOn);
				}
				return expireOn;
			}

			function successUpdatePartySize(response, form, inputObj) {
				var partySize = $(response).filter("#deliveryPartySize");
				var estCost = $(response).filter("#estCostPerPerson");
				$('#deliveryPartySize').empty();
				$("#deliveryPartySize").html(partySize.html());
				$('#estCostPerPerson').text(estCost.text());
				$('#est_delivery_cost').text(estCost.text());
				$('#editPartySize').show();
		    	$('#savePartySize').hide();
			}
			/**
			 * AJAX call to invoke handleProcessEclub for Join E-club Step2
			 */
			$(document).on("click", "#save_email_button", function() {
				var form = $(this).closest("form");

				//Defect fix - 13003 : starts
				if(!Modernizr.input.placeholder) {
					$(this).parents('form').find('[placeholder]').each( function() {
						var input = $(this);
						if (input.val() == input.attr('placeholder')) {
							input.val('');
						}
					});
				}
				//Defect fix - 13003 : ends

				doAJAX($(this), null, successEmailSignupCall);
				// preventing the page from being refreshed
				return false;
			});

			/**
			 * Success callback method for Join E-club Step 2
			 */
			function successEmailSignupCall(response, form, inputObj) {
				/*Update cookie flag as true*/
				var email_cookie = $.cookie("email_signup_cookie");
				if(email_cookie !=null && email_cookie != undefined) {
					var cookieValues = email_cookie.split(":");
					var cookie_counter = cookieValues[0];
					var cookieCheckFlag = cookieValues[1];
					var cookie_value=cookie_counter+":"+true;
					$.cookie('email_signup_cookie', cookie_value, { expires: getCrmCookieExpireDate(), path: "/"});
				}
				var errorDiv = $(response).find("#error_msg");
				form.find('#zip_errorDiv').empty();
				form.find("#error_msg").html(errorDiv.html());

				if (!$.trim((errorDiv.html()))) {
					// DTM eclub event START
					if($("#dtmenabled").val()=="true")
					{
					dtmEvent("eclubComplete","eclub");
					}
					// DTM eclub event END
					$("#error_msg").empty();
						var zipField = form.find("#zipcode_step2").val();
						var zipCode_Country = form.find("#zipCode_Country").val();
						$('#myModal').modal('hide');

							form.find('#zip_errorDiv').empty();
							var zipSearchEclubUrl = $("#emailZipSearchUrl").val();
							if(zipField != null && zipField != undefined && zipField != '') {
								form.find('#error_msg').empty();
									if(zipCode_Country=='US') {
										if(zipField.length == 5) {
											findZipCode(zipField,zipSearchEclubUrl,zipCode_Country,form,response);
										}
									}
									if(zipCode_Country=='CA') {
										if(zipField.length <= 6) {
											findZipCode(zipField,zipSearchEclubUrl,zipCode_Country,form,response);
										}
									}
							}

				}else
				{
					scrolloverlay($("#myModal"));
				}
			}

			$(document).on("click", "#hasAccount", function() {
				$("#myModal").modal('hide');
				$("#myModal").remove();

				var email_cookie_check = $.cookie("email_signup_cookie");
				if(email_cookie_check !=null && email_cookie_check != undefined) {
					var cookieVals = email_cookie_check.split(":");

					var cookie_new_val=cookieVals[0]+":"+true;
	  	            $.cookie('email_signup_cookie', cookie_new_val, { expires: getCrmCookieExpireDate(), path: "/"});
				}

			});
			/**************start of code change for magic ticket 469098289****************/
					/*
						var EclubPageUrl =  $("#joinclubPage").val();
												 if ( EclubPageUrl != undefined && EclubPageUrl != '' ) {
													 s.events='event3';
													 s.tl($(this), 'o', 'Eclub Step1 SignUp');
						 }
						 */
			/***************end of code change for magic ticket 469098289 ****************/

			/** refresh header links on page load **/
			if ($("#header-links").length > 0) {
				var url = $("#header-links").attr('data-url');
				refreshHeaderLinks(url);
			}

			function refreshHeaderLinks(url) {
				var MasterTmsUdo;
				var headerLinks = $("#header-links");
				var join_wait_list_details;
				var data = {};
					if (window.location.protocol == "https:") {
						url = $("#ajaxServletURL").val();
						data.AJAX_FUNCTION = "headerLinks";
					}

			    data.fromPage = location.pathname;
			    // added by Jaydeep for DTM event Start
				if(location.pathname.indexOf("/customer-service/join/") != -1){
					var showConfirmation = getParameterByName("showConfirmation");
					if(showConfirmation && showConfirmation ==="true"){
						data.showConfirmation="true";
					}
				}
				// added by  Jaydeep for DTM event END
				if(location.pathname.indexOf("/commerce/order-confirmation") != -1 || location.pathname.indexOf("/purchase/gift-card-order-confirmation") != -1){
				data.ANC=getParameterByName("ANC");
				data._requestid=getParameterByName("_requestid");
				}
				// Change for Enhancement : Location update from sitemap - starts here [xsdamm1]
				var isLocationDetailsPage = $('#isLocationDetails').val();
				if(isLocationDetailsPage != undefined && isLocationDetailsPage != null && isLocationDetailsPage == 'true'){

					var currentUrl = location.pathname;
				    var splitUrl = currentUrl.split("/");
					
				    if(location.pathname.indexOf("/es/locations/") > -1){
				    var restnum = splitUrl[6];
				    }
				    else{
				    var restnum = splitUrl[5];
				    }

					if(restnum != undefined && restnum != null){
						var locationCookie = $.cookie("DRIREST");
						if(locationCookie){
							locationCookie = locationCookie.replace(/\*/g,',');
					        var locValues = locationCookie.split("@@");
					        if(locValues.length > 0){
					        	if(locValues[11] != restnum){
					        		data.changeCurrentLocation = 'true';
					        		data.restNum = restnum;
					        	}
					        }
						}
						else{
							data.changeCurrentLocation = 'true';
							data.restNum = restnum;
						}
					}
				}
				// Change for Enhancement : Location update from sitemap - ends here [xsdamm1]

				// Change for restCatering starts
				var locnCookie = $.cookie("DRIREST");
				if(locnCookie){
					locnCookie = locnCookie.replace(/\*/g,',');
					var locValues = locnCookie.split("@@");
					var restId=locValues[0];
					data.restId = restId;
					var dataPageURL = location.pathname;
					if ($("#joinWaitListDetails").length > 0) {
						join_wait_list_details = $("#joinWaitListDetails");
						data.dataPageURL = dataPageURL;
				}
				}

				var isLocDetails=$("#isLocationDetails").val();
				var dataPageURL = location.pathname;
				var restID='' ;
				var locDetailsReqURI='' ;
				var location_wait_list_details='';
				if ( isLocDetails == "true") {
					restID = $("#locationWaitlistDetails").attr('data-rest-id');
					locDetailsReqURI = $("#locationWaitlistDetails").attr('base-url');
					data.restID = restID;
					data.locDetailsReqURI = locDetailsReqURI;
				}
				//Change for restCatering ends

				// gpodma1
				var location_popup_holiday_message='';
				if ($("#idHolidayMessage-location-popup").length > 0) {
					// Make sure the #idHolidayMessage-location-popup exists in
					//    xmgr.html#pages/desktop/us/en_US/olivegarden/global-header
					location_popup_holiday_message=$("#idHolidayMessage-location-popup");
				}
				// gpodma1

				$.ajaxSetup({
					cache : false
				});
				
				//Check if url contains restaurant parameter to change location - start
				var setRestaurantParamPresent = false;
				var restFromUrl = getUrlParameter("setRestaurant");
				if (restFromUrl != undefined && restFromUrl != ''){
						setRestaurantParamPresent = true;	
						url = url + "?setRestaurant="+restFromUrl;
				}
				//Check if url contains restaurant parameter to change location - end
				
				
				
				$.get(url, data,  function(response) {
					var pageURL = location.pathname;
					var securityStatus = $(response).find("#security_status").val();
					var isLoyaltyEnabled = $(response).find("#loyaltyEnabled").val();
					var loyalty_cookie = $.cookie("LOYALTY_ACCOUNT_ID");
					if(securityStatus < 4){
						/*if((location.pathname.indexOf("/home") == 0)||(location.pathname.indexOf("/es/pagina-de-inicio") == 0)){
								showEmailSignupOverlay(isLoyaltyEnabled);
						}*/
						if(($('#crm-popup').length > 0) || (location.pathname.indexOf("/es/pagina-de-inicio") == 0)){
							showEmailSignupOverlay(isLoyaltyEnabled);
						}else if((isLoyaltyEnabled !=null && isLoyaltyEnabled != undefined && isLoyaltyEnabled == "true") && (loyalty_cookie == null || loyalty_cookie == undefined)){
							showEmailSignupOverlay(isLoyaltyEnabled);
						}
					}
					// added for DTM by Jaydeep START
					if($("#dtmenabled").val()=="true") {
						var digitalDataAjx;
						if($(response).filter("#datalayer_jason").html()){
								digitalDataAjx= JSON.parse($(response).filter("#datalayer_jason").html());
							}
						// update ajax response in existing digitalData obj
						if(digitalDataAjx && window.digitalData){
							// added for dtm event Jaydeep
							if(digitalDataAjx.event && digitalDataAjx.event.length > 0 &&
							location.pathname.indexOf("/customer-service/favorite-locations") == -1 &&
							digitalDataAjx.event[0].eventInfo.eventName == "addLocationToFavorites"){
							delete digitalDataAjx.event;
							digitalDataAjx.event = digitalDataAjx.event || [];
							}else{
								window.digitalData = digitalDataAjx;
								// eclubComplete event check
								if(window.sessionStorage && location.pathname.indexOf("/reservations/reservation-confirmation") != -1 ||
										location.pathname.indexOf("/private-dining/confirmation") != -1 ||
										location.pathname.indexOf("/private-dining/national-accounts/thank-you") != -1 || location.pathname.indexOf("/customer-service/communication-preferences") != -1){
									if(sessionStorage.getItem("eclubChecked")
										&& sessionStorage.getItem("eclubChecked") != null
										&& sessionStorage.getItem("eclubChecked")=== "true"){
										sessionStorage.removeItem("eclubChecked");
										dtmEvent("eclubComplete","eclub");
									}
								}
								// eclubComplete event end
								if($(response).filter("#datalayer_event").html()){
								var eventNameDL = $(response).filter("#datalayer_event").html();
								if(eventNameDL !== "pageDataResponse"){
								sendCustomEvent($(response).filter("#datalayer_event").html());
								}
								}
							}
							sendCustomEvent("pageDataResponse");
						}
					}
					// added for DTM by Jaydeep END
					headerLinks.replaceWith(response);
					var locnCookie = $.cookie("DRIREST");
					if(locnCookie){
					if ($("#joinWaitListDetails").length > 0) {
						join_wait_list_details = $("#joinWaitListDetails");
						join_wait_list_details.html($(response).filter('#waitListInfo').html());
						}
					if ($("#locationWaitlistDetails").length > 0) {
						location_wait_list_details = $("#locationWaitlistDetails");
						location_wait_list_details.html($(response).filter('#location-webahead-info-reload').html());
					}
					// gpodma1
					if ($("#idHolidayMessage-location-popup-fromHeaderLinks").length > 0 && location_popup_holiday_message.length > 0) {
						location_popup_holiday_message.html($(response).filter('#idHolidayMessage-location-popup-fromHeaderLinks').html());
					}
					// gpodma1
					}
					//check if the abandon cart needs to be displayed when gc order is present

					if(window.location.pathname.indexOf("/togo")>-1 ||window.location.pathname.indexOf("/tmi")>-1){
						showProgressBar();
						updateOrderSummaryInfo();
					}

					//show change restaurant overlay if locationMismatch is true
					var locationMismatch = $('#locationMismatch').val();
					var orderType= new Number($("#orderType").val());
					var enableSettings = $('#expressSettingsEnabled').val();
					var locationUrl = window.location.href;
					if(enableSettings == 'true'  && !(window.location.href.indexOf('enrollConfirmed') > -1 && window.location.href.indexOf('/customer-service/my-rewards') > -1)) {
						var restcookie = $.cookie('DRIREST');
						 if(restcookie){
							var restid= restcookie.split('@@')[0];
							var restlist = ['700928','701019','701020','701012','701013','701014','701016','701015','701017','3900002','3900003','3900004','3900005','3900006'];
							var restexists =(restlist.indexOf(restid));

							if(restexists == -1){
								var redirectUrlValue = $('#redirectUrlValue').val();
								var data = {};
								var overlayURL = $('#expressSettingsEnabled').attr('data-url');
								if (window.location.protocol == "https:") {
									overlayURL = $("#ajaxServletURL").val();
									data.AJAX_FUNCTION = "enableExpressSetting";
								}
								$.get(overlayURL, data, function(overlayHTML) {
									var modalDiv = $(overlayHTML).filter("#myModalEnableExpressSettings");
									var successUrl = modalDiv.find('#expSuccessUrl').val();
									successUrl = successUrl+"?returnPage="+redirectUrlValue;
									modalDiv.find('#expSuccessUrl').each(function() {
		  							  $(this).attr('value', successUrl);

		  			                     });
									modalDiv.find('#setReturnUrl').each(function() {
			  							  $(this).attr('value', successUrl);

			  			                     });
									modalDiv.modal();
							setTimeout( function()
							{
								modalDiv.find('.container-fluid.mobalbox').focus();
							},10)

									});
							}
						}
					}else if(locationMismatch == 'true'  && !((location.pathname.indexOf("/purchase") == 0)||(location.pathname.indexOf("/commerce/checkout-payment-method") == 0))) {
						var data = {};
						var overlayURL = $('#locationMismatch').attr('data-url');
						if (window.location.protocol == "https:") {
							overlayURL = $("#ajaxServletURL").val();
							data.AJAX_FUNCTION = "changeCurrentRestaurant";
						}
						$.get(overlayURL, data, function(overlayHTML) {
							var modalDiv = $(overlayHTML).filter("#myModalRestaurantChange");
							modalDiv.modal();
						});
					}
					// Change for Enhancement : Location update from sitemap - starts here [xsdamm1]
					var locDetCookieVal = $("#locDetCookieVal").val();
					if(locDetCookieVal != '' && locDetCookieVal != null){
						locDetCookieVal = locDetCookieVal.replace(/#/g,'"');
						setLocationCookie(locDetCookieVal);
						setLocationHeader();
					}
					// Change for Enhancement : Location update from sitemap - ends here [xsdamm1]

					// Change for restCatering starts
					var displayCateringLink =$(response).filter('#displayCateringLink').val();
					var isDetectedLatLong =$(response).filter('#isDetectedLatLong').val();
					if(isDetectedLatLong != null && isDetectedLatLong == 'true'){
					$('span#find-locn-nearme-hidden-header').show();
					}

					if(displayCateringLink != null && displayCateringLink == 'true'){

						$('span#selected-cateing').show();
					}
					if(displayCateringLink!= null &&displayCateringLink == 'false')
					{
					$('span#selected-cateing').hide();
					}
					// Change for restCatering ends
                   $('a.capitalize.trackContent.come-on-in').contents().unwrap();
                   
                   if(setRestaurantParamPresent){
                	   setLocationHeader();
                   }
				   var isOnlineTogoEnabledValue =  $('#isOnlineTogoEnabled').val();
				   var inRestTogoEnabled =  $("#inRestTogoEnabled").val();
				   var franchiseLocPhone =  $('#togoFranchisePhoneNo').val();
				   
				   // messages
				   var togoText =$("#togoText").val();
				   var onlineTogoText =$("#onlineTogoText").val();	
				   var inrestTogoText =$("#inrestTogoText").val();
				   var togoOffText =$("#togoOffText").val();	
				   
				   if(typeof inRestTogoEnabled == 'undefined'){
					   inRestTogoEnabled= false;
				   }else{
					   if(inRestTogoEnabled === "true"){
						   inRestTogoEnabled = true;
					   }else{
						   inRestTogoEnabled= false;
					   }
				   }
				   if(typeof isOnlineTogoEnabledValue == 'undefined'){
					   isOnlineTogoEnabledValue= false;
				   }else{
					   if(isOnlineTogoEnabledValue === "true" || isOnlineTogoEnabledValue == "" || isOnlineTogoEnabledValue == null){
						   isOnlineTogoEnabledValue = true;
					   }else{
						   isOnlineTogoEnabledValue= false;
					   }
				   }
				   
						
						if(!isOnlineTogoEnabledValue && inRestTogoEnabled){
								if (window.location.href.indexOf('/es') > -1) {
								$("#\\/es\\/order-online").html("ToGo");
								$("#\\/es\\/order-online").attr("onclick","showFranchiseModal();");
								$("#\\/es\\/order-online").attr("id","franchiseMenuHeading");
								$(".franchise_cartalert").attr("style","margin-left:32px");							
								$(".franchise-loc-detail").css("margin-left","15px");
								$("#franchiseMenuHeading").attr("style","display: none;");
								}
								else {
								$("#\\/order-online").html("ToGo");				    
                       $("#\\/order-online").attr("onclick","showFranchiseModal();");
                       $("#\\/order-online").attr("id","franchiseMenuHeading");
								$("#franchiseMenuHeading").attr("style","visibility: hidden;");
								}

								//$(".franchiseOverlay").html(inrestTogoText);
								
					   $("#franchise_restphno").html(franchiseLocPhone); 
						$(".franchiseOverlay").removeClass("primary-btn");
						$(".franchiseOverlay").removeAttr("href");
								$(".franchiseOverlay").attr("style","text-decoration:none;display:none;");
						$("#franchiseLocOverlay").removeAttr("href");
                   }
						else if (!isOnlineTogoEnabledValue && !inRestTogoEnabled){
								if (window.location.href.indexOf('/es') > -1) {
								$("#\\/es\\/order-online").html("ToGo");
								$("#\\/es\\/order-online").attr("onclick","showFranchiseModal();");
								$("#\\/es\\/order-online").attr("id","franchiseMenuHeading");
								$(".franchise_cartalert").attr("style","margin-left:32px");							
								$(".franchise-loc-detail").css("margin-left","15px");
								$("#franchiseMenuHeading").attr("style","display: none;");
								}
								else {
								$("#\\/order-online").html("ToGo");				    
								$("#\\/order-online").attr("onclick","showFranchiseModal();");
								$("#\\/order-online").attr("id","franchiseMenuHeading");
								$("#franchiseMenuHeading").attr("style","visibility: hidden;");
								}

								//$(".franchiseOverlay").html(togoOffText);
								
								$("#franchise_restphno").html(franchiseLocPhone); 
								$(".franchiseOverlay").removeClass("primary-btn");					
								$(".franchiseOverlay").removeAttr("href");
								$(".franchiseOverlay").attr("style","text-decoration:none;display:none;");
								$("#franchiseLocOverlay").removeAttr("href");
						}
						
						
					
				});
			}
			var loggedinCookie = $.cookie("DRI_LOGGED_IN");
			if ($("#favorite_link_location_detail").length > 0) {
				var favorite_link_location = $("#favorite_link_location_detail");
				var favorite_link_location_detail_url = $("#favorite_link_location_detail_url");
				var url = favorite_link_location_detail_url.attr('data-url');
				var restId = favorite_link_location.attr('data-restId');
				var directUrl = $("#favorite_location_redirectUrl").val();
				var data = { restaurantId : restId , redirectUrl : directUrl};
				$.ajaxSetup({
					cache : false
				});
				$.get(url, data,  function(response) {
					favorite_link_location.replaceWith(response);
				});
			}
			/************************ REORDER FUNCTIONALITY -- START **********************************/

			/**
			 * This Function is called when 'Add to Reorder'
			 * button is clicked from ToGo orders page *
			 */
			$(document).on("click", "#reorder_addtocart,#delivery_reorder_addtocart", function() {
            	  if(window.location.pathname.indexOf('/es/')>-1){
            	    window.location.replace('/es/reorder');
            	  }	
            	  else {
            	     window.location.replace('/reorder'); 
            	  }
			});




			/**
			 * This Function is called when 'Continue'
			 * button is clicked from Reorder Error States Overlay *
			 */
			$(document).on("click", "#reorder-continue", function() {
				var orderIdForReorder = $(this).attr('data-order-id');
				var url = $(this).attr('data-url');
				var itemIdsForContinue = $("#itemIdsForContinue");
				var itemIdsForReorder = $.trim($("#itemIdsForReorder").val());
				var data = {orderIdForReorder : orderIdForReorder, itemIdsForReorder : itemIdsForReorder};
				if (itemIdsForContinue.length > 0) {
					var validItemIds = $.trim(itemIdsForContinue.val());
					data.validItemIds = validItemIds;
				}
				if (location.pathname
						.indexOf("location-confirmation") != -1 || location.pathname
						.indexOf("pick-date-and-time") != -1 ) {
					var requestedPickupDate = $.trim($("#requestedPickupDate").val());
					var requestedPickupTime = $.trim($("#requestedPickupTime").val());
					var selectedMenuType= $.trim($("#selectedMenuType").val());
					data.selectedMenuType= selectedMenuType;
					data.requestedPickupDate = requestedPickupDate;
					data.requestedPickupTime = requestedPickupTime;
					var ajaxurl = "reOrderStates";
					data.AJAX_FUNCTION = ajaxurl;
					url = $("#ajaxServletURL").val();
				}

				request = $.ajax({
					url: url,
					type: "get",
					cache: false,
					data : data
				});

				request.done(function (response, textStatus, jqXHR){
					if (location.pathname
							.indexOf("location-confirmation") == -1 ||
							location.pathname
						.indexOf("pick-date-and-time") == -1) {
						successReorder(response);
					} else {
						successReorderFromPickUpPage(response);
					}
				});
			});

			/**
			 * This Function is called when 'Change'
			 * button is clicked from Reorder Error States Overlay *
			 */
			$(document).on("click", "#reorder-pickup-change", function() {
				var orderIdForReorder = $(this).attr('data-order-id');
				var url = $(this).attr('data-url');
				var itemIdsForReorder = $.trim($("#itemIdsForReorder").val());
				var requestedPickupDate = $.trim($("#date_picker_reorder").val());
				var requestedPickupTime = $.trim($("#reorder_pickup_time").val());
				var selectedMenuType= $.trim($("#selectedMenuType").val());
				var data = {
							orderIdForReorder : orderIdForReorder,
							itemIdsForReorder : itemIdsForReorder,
							requestedPickupDate : requestedPickupDate,
							requestedPickupTime : requestedPickupTime,
							selectedMenuType : selectedMenuType
							}

				if (location.pathname
						.indexOf("location-confirmation") != -1 ||
						location.pathname
						.indexOf("pick-date-and-time") != -1) {
					url = $("#ajaxServletURL").val();
					var ajaxurl = "reOrderStates";
					data.AJAX_FUNCTION = ajaxurl;
				}
				request = $.ajax({
					url: url,
					type: "get",
					cache: false,
					data : data
				});
				request.done(function (response, textStatus, jqXHR){
						if (location.pathname
						.indexOf("pick-date-and-time") == -1) {
							successReorder(response);
						} else {
							successReorderFromPickUpPage(response);
						}
				});
			});

			/**
			 * This Function is called when 'Continue' button is clicked from
			 * Location Confirmation page when the guest lands on this page
			 * after clicking on 'add to order'.
			 */
			$(document).on("click", "#reorder_pickup_continue", function() {

				var orderIdForReorder = $(this).attr('data-order-id');
				var url = $(this).attr('data-url');
				var requestedPickupDate = $.trim($("#requestedPickupDate").val());
				var requestedPickupTime = $.trim($("#requestedPickupTime").val());
				var selectedMenuType= $.trim($("#selectedMenuType").val());
				var ajaxurl = $.trim($("#ajaxurl").val());
				if(!requestedPickupDate) {
					alert("Please select pick up date");
					return false;
				}
				if(!requestedPickupTime) {
					alert("Please select a timeslot from available timeslots");
					return false;
				}
				request = $.ajax({
					url: url,
					type: "get",
					cache: false,
					data : {
								orderIdForReorder : orderIdForReorder,
								requestedPickupDate : requestedPickupDate,
								requestedPickupTime : requestedPickupTime,
								selectedMenuType : selectedMenuType,
								AJAX_FUNCTION : ajaxurl
							}
				});
				request.done(function (response, textStatus, jqXHR){
					successReorderFromPickUpPage(response);
				});
			});

			/**
			 * success Function for Reorder from TOGO orders page
			 */
			function successReorder(data) {
				$("#reorderErrorStates").modal('hide');
				$("#reorderErrorStates").remove();

					var callHandleReorder = $(data).find("#callHandleReorder");

					var noItems = $(data).find("#noItems");
						if ($.trim(noItems.val()) == "true") {
							$("#reorderErrorStates").modal('hide');
						} else if ($.trim(callHandleReorder.val()) == "true") {
							var formObj = $(data).find("form#reorder");
							$("body").append(formObj);
							formObj.submit();
						} else {
							var reorderErrorModal = $(data).filter("#reorderErrorStates");
							scrolloverlay($("#reorderErrorStates")) ;
							reorderErrorModal.modal();
							reorderErrorModal.find(".styled-select selectmenu-layoutform").each(function() {
							$(this).wrap("<span class='select-wrapper'></span>");
							$(this).after("<span class='holder'></span>");
							var firstOption = $(this).find("option:first").text();
							$(this).next(".holder").text(firstOption);
							});
							var datePicker = reorderErrorModal.find("#reorder_pickup_time");
							if (datePicker.length > 0) {
								var pickupTimeSelectBox = reorderErrorModal.find("#reorder_pickup_time");
								var intervalInMins = reorderErrorModal.find('#intervalInMinsReorder').val();
								var pickupDate = reorderErrorModal.find("#date_picker_reorder").val();
								populatePickUpTimeBox(pickupTimeSelectBox, intervalInMins, pickupDate);

								loadDatePicker(reorderErrorModal.find("#date_picker_reorder"));
							}
							$(window).scrollTop(0);
						}
			}

			/**
			 * success Function for Reorder when guest is redirected to pick up
			 * time page.
			 */
			function successReorderFromPickUpPage(data) {
				$("#reorderErrorStates").modal('hide');
				$("#reorderErrorStates").remove();
				if(!!($.trim($("#requestedPickupDate").val()) && $.trim($("#requestedPickupTime").val()))) {
					$("#requestedPickupDate").val($(data).find("#reorder_reqPickupDate").val());
					$("#requestedPickupTime").val($(data).find("#reorder_reqPickupTime").val());
					$("#selectedMenuType").val($(data).find("#selectedMenuType").val());
				}

				$("#pickup_validItemIds").val($(data).find("#itemIdsForReorder").val());
					var callHandleReorder = $(data).find("#callHandleReorder");
					var noItems = $(data).find("#noItems");
					if($.trim(noItems.val()) == "true") {
						location.reload();
					} else if ($.trim(callHandleReorder.val()) == "true") {
							$("form#form-pick-up-time").submit();
						} else {
							var reorderErrorModal = $(data).filter("#reorderErrorStates");
							reorderErrorModal.modal();
				reorderErrorModal.find(".styled-select selectmenu-layoutform").each(function() {
				$(this).wrap("<span class='select-wrapper'></span>");
				$(this).after("<span class='holder'></span>");
				var firstOption = $(this).find("option:first").text();
				$(this).next(".holder").text(firstOption);
				});
							var datePicker = reorderErrorModal.find("#reorder_pickup_time");
							if (datePicker.length > 0) {
								var pickupTimeSelectBox = reorderErrorModal.find("#reorder_pickup_time");
								var intervalInMins = reorderErrorModal.find('#intervalInMinsReorder').val();
								var pickupDate = reorderErrorModal.find("#date_picker_reorder").val();
								populatePickUpTimeBox(pickupTimeSelectBox, intervalInMins, pickupDate);
								loadDatePicker(reorderErrorModal.find("#date_picker_reorder"));
							}
							$(window).scrollTop(0);
						}
			}

			/************************ REORDER FUNCTIONALITY -- END **********************************/

			/**
			 * Function to Load the datepicker on AJAX loaded overlay.
			 */
			function loadDatePicker(datePickerInput){
				var imagePrefix = $('#media').val();
				datePickerInput.datepicker({
					showOn: "both",
					buttonImage: imagePrefix + "/calendar-icon.png",
					buttonImageOnly: true,
					buttonText: "Calendar",
					showOtherMonths: true,
					showButtonPanel: true,
					minDate: 0,
					maxDate: 11
				});
			}

			/**
			 * Function to populate the pickuptime dropdown box on overlay.
			 */
			function populatePickUpTimeBox(pickupTimeSelectBox, intervalInMins, pickupDate) {
				var url = pickupTimeSelectBox.attr('data-url');
				var data = {};
				if (window.location.protocol == "https:") {
					url = $("#ajaxServletURL").val();
					data = { AJAX_FUNCTION : "restTimings" };
				}
				data.pickupDate = pickupDate;
				request = $.ajax({
					url: url,
					type: "get",
					cache: false,
					data: data
				});
				request.done(function (response, textStatus, jqXHR){
					var $response = $(response);
					var lunchSlots = $response.filter('#lunchTimings').text();
					var array = lunchSlots.split("#");
					lunchStartTime = array[0];
					lunchFirstSlot = array[1];
					lunchEndTime = array[2];
					if (lunchStartTime != null && lunchEndTime != null
							&& lunchFirstSlot != null) {
						populatePickUpTimeDropDown(pickupTimeSelectBox, lunchFirstSlot, lunchEndTime, intervalInMins);
					}
					var dinnerSlots = $response.filter('#dinnerTimings').text();
					var array = dinnerSlots.split("#");
					dinnerStartTime = array[0];
					dinnerFirstSlot = array[1];
					dinnerEndTime = array[2];
					if (dinnerStartTime != null && dinnerEndTime != null
							&& dinnerFirstSlot != null) {
						populatePickUpTimeDropDown(pickupTimeSelectBox, dinnerFirstSlot, dinnerEndTime, intervalInMins);
					}
				});
			}

			/**
			 * Function to populate the pickuptime dropdown box on overlay.
			 */
			function populatePickUpTimeDropDown(pickUpTimeSelectBox, firstTimeSlot, endTime, intervalInMins){

				if (pickUpTimeSelectBox == null || pickUpTimeSelectBox.length < 1)
					return;
				var startTime = Date.parseExact(firstTimeSlot, "HH:mm");
				var endTime = Date.parseExact(endTime, "HH:mm:ss");
				var startHour = startTime.toString("HH");
				var endHour = endTime.toString("HH");

				var NumOfHours = endHour - startHour;
				var slotsPerHour = 60 / intervalInMins;
				var NumberOfSlots = NumOfHours * slotsPerHour;
				for ( var r = 0; r < NumberOfSlots; r++) {
					if ((startTime.compareTo(endTime) == -1)) {
						var startTimeString = startTime.toString("hh:mm tt");
						startTime = startTime.addMinutes(intervalInMins);
					}

					pickUpTimeSelectBox.append($('<option></option>').val($.trim(startTimeString)).html($.trim(startTimeString)));

				}
				$(pickUpTimeSelectBox).wrap("<span class='select-wrapper'></span>");
				var selectText=$(pickUpTimeSelectBox).find("option:first").val();
				$(pickUpTimeSelectBox).after("<span class='holder'>"+selectText+"</span>");
				$(".holder").css("color","#555555");
			}


	/**
	 * Allow only numbers for phone number field
	 */
		$(document).on('keypress change', '#phone-ctn, #phoneExt,#loyaltyMemberPhone', function(e) {
			if (e.which > 31 && (e.which < 48 || e.which > 57)) {
				e.preventDefault();
			}
		});

		/** Method for formatting phone number to (###) ###-#### format **/
		$(document).on('keypress','#phone-ctn,#loyaltyMemberPhone', function(e)
			    {
			        var l=$(this).val().length;
			        var text = $(this).val();
			        var isNumber = (e.which > 47 && e.which < 58) || (e.which > 95 && e.which < 106);
			        if(isNumber) {
				        if (l<=4) {
				        	for(var i=0;i<=l;i++){

				        		var codeA = text.charCodeAt(i);
				        		if(codeA > 31 && (codeA < 48 || codeA > 57))
				        			{
				        			 $(this).val(text.replace(/(\d{3})\)?/g,'$1)'));
				        			 return true;
				        			}

				        	}
							/** alm 7526 change start  **/
				        	$(this).val(text.replace(/(\d{3})\)?/g,'($1) '));
				        	return true;
							/** alm 7526 change end **/
				        }
				        if (l==9){
				            $(this).val(text.replace(text, text +'-'));
				            return true;
				        }
			        }
			    });


	// call format phone number on focus out
	$(document).on('focusout','#phone-ctn', formatPhoneNumber);
	$(document).on('focusout','#loyaltyMemberPhone', formatPhoneNumber4);
	// call format phone number on page load.
	if ($('#phone-ctn').length > 0 ) {
		formatPhoneNumber();
	}
	if ($('#loyaltyMemberPhone').length > 0 ) {
		formatPhoneNumber4();
	}
	/** function for formatting phone number to (###) ###-#### format **/
	/*function formatPhoneNumber(input) {
		var input = $('#phone-ctn');
		var numsOnly = input.val().replace(/\D/g, '');
		if (numsOnly.length >= 10) {
			input.val(input.val().replace(/\D/g, ''));
		}
		input.val(input.val().replace(/(\d{3})(\d{3})(\d{4})/,'($1) $2-$3'));
		if (input.val().length > 14) {
			input.val(input.val().slice(0, 14));
		}
	}*/

	function formatPhoneNumber(input) {
		var input = $('#phone-ctn');
		var numsOnly = input.val().replace(/\D/g, '');
		if (numsOnly.length >= 10) {
			input.val(input.val().replace(/\D/g, ''));
	}
		input.val(input.val().replace(/(\d{3})(\d{3})(\d{4})/,'($1) $2-$3'));
		if (input.val().length > 14) {
			input.val(input.val().slice(0, 20));
		}
	}

	function formatPhoneNumber4(input) {
		var input = $('#loyaltyMemberPhone');
		var numsOnly = input.val().replace(/\D/g, '');
		if (numsOnly.length >= 10) {
			input.val(input.val().replace(/\D/g, ''));
	}
		input.val(input.val().replace(/(\d{3})(\d{3})(\d{4})/,'($1) $2-$3'));
		if (input.val().length > 14) {
			input.val(input.val().slice(0, 13));
		}
	}


	//call monthYearChanged if month/year dropdown is changed.
    $(document).on("change", "#dobMonth, #dobYear", monthYearChanged);

    /**
	 * Function to populate the days dropdown box based on the the month and
	 * year. This also takes leap years into account.
	 */
    function monthYearChanged() {
        var days = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        var enclosingDiv = $(this).closest('div.row');
        var dayDiv = enclosingDiv.find('#dobDay');
        var monthDiv = enclosingDiv.find('#dobMonth');
        var yearDiv = enclosingDiv.find('#dobYear');
        var month = monthDiv.val() - 1, year = +yearDiv.val();
        var diff;

        // Check for leap year if Feb
        if (month == 1 && new Date(year, month, 29).getMonth() == 1) days[1]++;

        // Add/Remove options
        diff = dayDiv.find('option').length - (days[month] + 1);
        if (diff > 0) { // Remove
           dayDiv.find('option').slice(days[month] + 1).remove();
        } else if (diff < 0) { // Add
            for (var i = dayDiv.find('option').length; i <= days[month]; i++) {
                $('<option>').attr('value', i).text(i).appendTo(dayDiv);
            }
        }
    }

	/**
	 * Omniture tracking for registration
	 * **/
    if($("#dtmenabled").val()=="false")
    	{
	$("#register").click(function() {
		var form  = $(this).closest('form');
		var globalOptin = form.find("#primaryOptin_reg").data('checked');
		var primaryOptin = form.find("#globalOptin_reg").data('checked');

		if ($.trim(globalOptin) == 'true' || $.trim(primaryOptin)  =='true') {
				/** Omniture tracking -- START **/
				s.linkTrackVars='eVar7,eVar10,events';
				s.linkTrackEvents='event3';
				s.events='event3';
				s.eVar10= 'Account';

				if ($.trim(globalOptin) == 'true') {
						s.eVar7 = 'Global opt-in';
				} else {
						s.eVar7 = 'Concept opt-in';
				}

				s.tl($(this), 'o', 'Account Registration');
				/** Omniture tracking -- END **/
		}
	});
    	}

	/**
	 * Omniture Tracking for Account Subscriptions on page load.
	 */
    if($("#dtmenabled").val()=="false")
    	{
	if($("#unsubscriptiondata").length > 0) {
		var unsubdata = $("#unsubscriptiondata").val();
		if(unsubdata != '') {
		var splitArray = $.trim(unsubdata).split(':');
		s.linkTrackVars='eVar7,eVar10,eVar63,events';
		$.each( splitArray, function( key, value ) {
			s.events = 'event37';
			s.eVar7 = 'Concept';
			s.eVar10 = 'Account unsubscribe from Manage Subscriptions';
			s.eVar63 =  value;
			s.pageName = 'Un-Subscription-Manage Subscriptions'
			s.tl($(this), 'o', 'Account un-Subscriptions Save');
		});
	}
	}
	/**
	 * Omniture Tracking for Account Subscriptions on page load.
	 */
	if($("#subscriptiondata").length > 0) {
		var unsubdata = $("#subscriptiondata").val();
		if(unsubdata != '') {
		var splitArray = $.trim(unsubdata).split(':');
		s.linkTrackVars='eVar7,eVar10,events';
		$.each( splitArray, function( key, value ) {
			s.events = 'event7';
			s.eVar7 = 'Concept';
			s.eVar10 = 'Account subscribe from Manage Subscription';
			s.pageName = 'Subscription-Manage Subscriptions'
			s.tl($(this), 'o', 'Account Subscriptions Save');
		});
	}
	}
    	}
/**
	 * Common method in Manage profile page to make the fields editable.
	 * The anchor tag or any DOM object used for toggling should have an id
	 * attribute set which contains "-toggle".
	 * Please ensure that the following data attributes are set in the anchor tag:
	 * 		data-url : this should contain the url for the AJAX call.
	 * 		data-div : this should contain the id of the div to be refreshed.
	 * 		data-param(optional) : this attribute maybe used if any parameter has to
	 * 							   passed to the AJAX call.
	 */
	$(document).on("click", "a[id*='-toggle']", function() {
		var $this = $(this);
		var url = $this.attr('data-url');
		var divToRefresh = $($this.attr('data-div'));
		var param = $this.attr('data-param');
		$.ajaxSetup({ cache: false });
		$.get(url, { param : param }, function(data) {
			divToRefresh.replaceWith(data);
			var formDivId = "#"+$(data).first().attr('id');
			$(formDivId).find(".styled-select select, .styled-select-red select").each(function() {
	    	$(this).wrap("<span class='select-wrapper'></span>");
	    	$(this).after("<span class='holder'></span>");
			var selectedOption = $(this).find("option:selected").text();
			$(this).next(".holder").text(selectedOption);
			});

			//to hide toggle-data divs
			if($("#show").length > 0) {
				$("#show").css("background-position","0 -24px");
				$("div.toggle-data").hide();
			}

			// format phoneNumber if exists
			if ($('#phone-ctn').length > 0 ) {
				formatPhoneNumber($('#phone-ctn'));
			}
			// format phoneNumber if exists
			if ($('#loyaltyMemberPhone').length > 0 ) {
				formatPhoneNumber4($('#loyaltyMemberPhone'));
			}

			//calling dgStyle() function manually for the checkbox to work normally
			// as in a normal page load
			if ($(".checkbox_d").length > 0) {
				$(".checkbox_d").dgStyle();
			}
		});

		return false;
	});

	/**
		 * for redirection of close button in joineclubstep4 overlay
		 */
		$(document).on("click", "#myModal_overlayCloseButton", function() {
			
			/*REQ504763/WO286724 Desktop Join Pages Post Submission Issue*/
			if(location.href.indexOf('/customer-service/joineclub-step1')>-1){
    
                var IndexOF = window.location.href.indexOf("/customer-service");
                var redirectURL = window.location.href.slice(0,IndexOF)
                if(window.location.href.indexOf('.com/es/') > -1) {
                   redirectURL += "/pagina-de-inicio" 
                } else {
                    redirectURL += "/home"
                }
                window.location.href = redirectURL;
            }
			
			
			
			var div=document.getElementById('step4');
			var url=div.getAttribute("data-url");
			var name=div.getAttribute("data-name");
			if(name=='step4')
				{
				 window.location.href =url;
			}

	});

	/**
	 * Fix ALM # 4046
	 * Redirect to skus according to serving size
	 */
	$(document).on('change','#servingsize', function() {
			var productId=$( "#productId" ).val();
			var skuId=this.value;
			var productdisplayName=$( "#productdisplayName" ).val();
			var recipeURL = $('#baseURL').val()+"/"+productdisplayName+"/"+productId;
			recipeURL = recipeURL.replace(/[^a-zA-Z0-9/]/g,'-');
			recipeURL = recipeURL.toLowerCase();
			recipeURL = recipeURL + "?skuId="+skuId;

			$.ajaxSetup({
				cache : false
			});

			var recipeDetails = $("#recipe-details");
			var recipieIngredients = $("#collapse11");
			var recipieProcedure = $("#collapse12");

			$.get(recipeURL, function(response) {
				recipeDetails.html($(response).find("#recipe-details").html());
				recipieIngredients.html($(response).find("#collapse11").html());
				recipieProcedure.html($(response).find("#collapse12").html());
			});

	});
	/**
	 * AJAX call for Edit Name functionality
	 */
	$(document).on("click", "#edit-name-save-btn", function() {
		doAJAX($(this), null, successEditName);
		return false;
	});

	/**
	 * success method for Edit Name ajax call.
	 */
	function successEditName(successHTML, form) {
		var errorDiv = $($.parseHTML(successHTML)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#editName").replaceWith(successHTML);
		}
	}


	/**
	 * AJAX call for Edit dob functionality
	 */
	$(document).on("click", "#edit-dob-save-btn", function() {
		doAJAX($(this), null, successEditDOB);
		return false;
	});

	/**
	 * success method for Edit dob ajax call.
	 */
	function successEditDOB(successHTML, form) {
		var errorDiv = $($.parseHTML(successHTML)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#editDOB").replaceWith(successHTML);
		}
		else
		{
		form.find(".styled-select select").each(function() {
			var selectedOption = $(this).find("option:selected").text();
	    					$(this).next(".holder").text(selectedOption);
			});
		}
	}



	/**
	 * AJAX call for add phone functionality
	 */
	$(document).on("click", "#add-phone-btn", function() {
		doAJAX($(this), null, successAddPhone);
		return false;
	});

	/**
	 * success method for Add Phone Ajax call.
	 */
	function successAddPhone(successHTML, form) {
		var errorDiv = $($.parseHTML(successHTML)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#addPhone").replaceWith(successHTML);
		}
	}

	/**
	 * AJAX call for edit phone functionality
	 */
	$(document).on("click", "#edit-phone-btn", function() {
		var pType = $("#phoneType").val();
		doAJAX($(this), null, successEditPhone);
		if($("#dtmenabled").val()=="false")
			{
		/** Omniture tracking R4.2 -- START **/
		s.linkTrackVars='eVar70,prop49,events';
		s.linkTrackEvents='event75';
		s.events='event75';
		if ($.trim(pType) != '') {
			var pType2 = $.trim(pType);
		}
       var linkname=s.eVar70=s.prop49=s.pageName +' '+'Edit Phone Number'+' '+pType2;
		s.tl($(this), 'o', linkname);
		/** Omniture tracking R4.2 -- END **/
			}
		return false;
	});

	/**
	 * success method for Edit Phone Ajax call.
	 */
	function successEditPhone(successHTML, form) {
		var errorDiv = $($.parseHTML(successHTML)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#editPhone").replaceWith(successHTML);
		}
	}

	/**
	 * Remove Phone Functionality
	 */
	$(document).on("click", "a[id*='phone-remove']", function() {
		var inputObj = $(this);
		var removalId = inputObj.attr('data-id');
		var removeModalURL = inputObj.attr('data-modal-url');
		var defaultPhoneId = inputObj.attr('data-default-phone');
		var numOfPhones = inputObj.attr('data-size');
		var defaultPhone;
		if ($.trim(numOfPhones) != 1 && ($.trim(removalId) == $.trim(defaultPhoneId))) {
			defaultPhone = 'true';
		}
		$.ajaxSetup({ cache: false });
		$.get(removeModalURL, { defaultPhone : defaultPhone },  function(data){
		$("#removePhoneModal").remove();
		var removeModal = $($.parseHTML(data)).filter("#removePhoneModal");
		scrolloverlay(removeModal);
		removeModal.modal();
		removeModal.find("#removalPhoneId").val(removalId);
		});

		return false;
	});


	/**
	 * AJAX call for Remove Phone function.
	 */
	$(document).on("click", "#remove-phone-confirm", function() {
		var pRemove = $("#remove_phone_type").val();
		doAJAX($(this), null, successRemovePhone);
		if($("#dtmenabled").val()=="false")
			{
		/** Omniture tracking R4.2 -- START **/
		s.linkTrackVars='eVar70,prop49,events';
		s.linkTrackEvents='event75';
		s.events='event75';
		if ($.trim(pRemove) != '') {
			var pRemove2 = $.trim(pRemove);
		}
		var linkname=s.eVar70=s.prop49=s.pageName +' '+'Remove Phone Number '+' '+pRemove2;
		s.tl($(this), 'o',linkname);
		/** Omniture tracking R4.2 -- END **/
			}
		$("#removePhoneModal").modal('hide');
		$("#removePhoneModal").remove();
		return false;
	});

	/**
	 * success method for Remove phone ajax call.
	 */
	function successRemovePhone(successHTML, form) {
		var errorDiv = $($.parseHTML(successHTML)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#edit-phone").replaceWith(successHTML);
		}
	}

	/**
	 * AJAX call for edit password
	 */
	$(document).on("click", "#password-save-button", function() {
		doAJAX($(this), null, successEditPassword);
		return false;
	});

	/**
	 * success method for Edit Password ajax call.
	 */
	function successEditPassword(response, form) {
		var errorDiv = $($.parseHTML(response)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#editPassword").replaceWith(response);
		}
	}

	/**
	 * AJAX call for Edit challenge question
	 */
	$(document).on("click", "#edit-question-button", function() {
		doAJAX($(this), null, successEditQuestion);
		return false;
	});

	/**
	 * success method for Edit challenge question ajax call.
	 */
	function successEditQuestion(response, form){
		var errorDiv = $($.parseHTML(response)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#editQuestion").replaceWith(response);
		}
	}


	/**
	 * AJAX call for remove phone functionality
	 */
	$(document).on("change", "#edit-phone input[type='radio']", function(){
	doAJAX($(this), null, successDefaultPhone);
	});

	function successDefaultPhone(successHTML, form) {
		var errorDiv = $($.parseHTML(successHTML)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#edit-phone").replaceWith(successHTML);
		}
	var rdbtns = document.getElementsByName('num');
	var phnType = document.getElementsByName('remove_phone_type');
	len = phnType.length;
	rlen = rdbtns.length;
	var ptypeVal="";
	var ptypeVal2="";
	for (var i=0; i<len; i++) {
        if ( rdbtns[i].checked ) {
			 ptypeVal= phnType[i].value;
			 break;
        }
		}
	if($("#dtmenabled").val()=="false")
		{
	    /** Omniture tracking R4.2-- START **/
		s.linkTrackVars='eVar70,prop49,events';
		s.linkTrackEvents='event75';
		s.events='event75';
		if ($.trim(ptypeVal) != '') {
			ptypeVal2 = $.trim(ptypeVal);
		}
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'Change Default Phone Preference To'+' '+ptypeVal2;
		s.tl($(this), 'o',linkname);
		/** Omniture tracking R4.2-- END **/
		}
	}
	/**
	 * AJAX call to invoke handleChangeEmailAddress
	 */
	$(document).on("click", "#edit_email_btn", function() {


		var globalOptin = $("#globalCheck").data('checked');
		var primaryOptin = $("#primaryOptin").data('checked');
		if ($.trim(globalOptin) == 'true' || $.trim(primaryOptin)  =='true') {
			if($("#dtmenabled").val()=="false")
				{
				/** Omniture tracking -- START **/
				s.linkTrackVars='eVar7,eVar10,events';
				s.linkTrackEvents='event3';
				s.events='event3';
				s.eVar10= 'Account';

				if ($.trim(globalOptin) == 'true') {
						s.eVar7 = 'Global opt-in';
				} else {
						s.eVar7 = 'Concept opt-in';
				}

				s.tl($(this), 'o', 'Edit Email Save');
				/** Omniture tracking -- END **/
				}
		}
		doAJAX($(this), null,successEditEmail);
		// preventing the page from being refreshed
		return false;
	});
	/**
	 * Success callback method for ChangeEmailAddress
	 */
	function successEditEmail(response, form) {
		var errorDiv = $($.parseHTML(response)).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {

			var globalOptin = form.find("#globalCheck").data('checked');
			var primaryOptin = form.find("#primaryOptin").data('checked');
			if ($.trim(globalOptin) == 'true' || $.trim(primaryOptin)  =='true') {
				if($("#dtmenabled").val()=="false")
					{
					/** Omniture tracking -- START **/
					clearOmnitureVars();
					s.events='event7';
					s.eVar10= 'Account';

					if ($.trim(globalOptin) == 'true') {
							s.eVar7 = 'Global opt-in';
					} else {
							s.eVar7 = 'Concept opt-in';
					}
					s.pageName = 'Edit Email Success';
					void(s.t());
					/** Omniture tracking -- END **/
					}
			}

			$("#editEmail").replaceWith(response);
		}

	}

	/** show step2 overlay if #loadStep2Overlay input is set to true  **/
	if ($("#eclub_emailid").length ) {
		var showStep2Overlay = $("#loadStep2Overlay");
		if($.trim(showStep2Overlay.val()) == 'true') {
			loadStep2Overlay(showStep2Overlay);
		}

	}
	/** function to show step2overlay **/
	function loadStep2Overlay(inputObj) {
		var url = inputObj.attr('data-url');
		$.ajaxSetup({ cache: false });
		var profileItemId = $("#profileItemId").val();
		var globallyOptedInStep1 = $("#globallyOptedInStep1").val();
		var signupfromPage = $("#signupfromPage").val();
		$.get(url, {profileItemId : profileItemId,
					globallyOptedInStep1: globallyOptedInStep1,
					signupfromPage : signupfromPage},  function(data){
			var modalDiv = $(data).filter("#myModal");
			modalDiv.find(".styled-select select, .styled-select-red select").each(function() {
				$(this).wrap("<span class='select-wrapper'></span>");
				$(this).after("<span class='holder'></span>");
				var firstOption = $(this).find("option:first").text();
				$(this).next(".holder").text(firstOption);
				});
			scrolloverlay(modalDiv);
			modalDiv.attr('style','top: 0% !important');
			modalDiv.modal();
			modalDiv.find(".checkbox_d").dgStyle();
			dtmEvent("eclubComplete","eclub");
		});
	}

	/**
	 * Script to append current page on click of learn more button
	 */
	$('#learn_more').click(function() {
		var href = $(this).attr('href');
		var currentPage = location.pathname;
		$(this).attr('href', href.concat('?fromPage=').concat(currentPage));
	});

	/**
	 * AJAX call to invoke handleProcessEclub for Join E-club Step1
	 *
	 * This function will be called when either of the below to links
	 * are clicked:
	 * 1. form#signup_footer #signUp - Join button in the footer
	 * 2. form#joinEclub #signUp - Sign up button in Join E-club page.
	 * 3. #subscribeoffers - subscribe button for guests in order-confirmation page
	 */

	$("form#joinEclub #signUp, #subscribeoffers, #joineclubcontactus").click(
			function() {

				var inputObj = $(this);
				//prevent duplicate clicks
				if($(this).prop('disabled')) {
					return false;
				}
				var form =  $("#signup_footer_form");
				form.attr('action', location.href);
				var globalOptin = form.find(".checkbox_d").data('checked');
				form.find("#globalOptinStep1").val(false);
				if (globalOptin) {
					form.find("#globalOptinStep1").val(true);
				}
				if($("#dtmenabled").val()=="false")
					{
				/** Omniture tracking -- START **/
				s.linkTrackVars='eVar7,eVar10,events';
				s.linkTrackEvents='event3';
				s.events='event3';
				s.eVar10= 'Eclub';

				if ($.trim(globalOptin) == "true") {
						s.eVar7 = 'Global opt-in';
				} else {
						s.eVar7 = 'Concept opt-in';
				}

				s.tl($(this), 'o', 'Eclub Step1 SignUp');
				/** Omniture tracking -- END **/
					}
				doAJAX(inputObj, null, successStep1Call);

				// preventing the page from being refreshed
				return false;
			});

	// Join Eclub Footer
	$('#join_footer').click(function(){
				var inputObj = $(this);
				var id = inputObj.attr('id');
		if(inputObj.prop('disabled')) {
			return false;
		}
		var form =  $("#signup_footer_form");
		form.attr('action', location.href);
		var globalOptin = $("#global_optin_chk").attr('checked');
		form.find("#globalOptinStep1").val(false);
		if (globalOptin == 'checked') {
			$('#global_opt_in_footer').val('G');
			form.find("#globalOptinStep1").val(true);
		}

					if ($("#security_status").length > 0) {
						var loggedin=$("#security_status").val();

						if(loggedin == '2' || loggedin == '3' || loggedin == '4' || loggedin == '5') {
							if($("#dtmenabled").val()=="false")
								{
						/** Omniture tracking -- START **/
								s.linkTrackVars='eVar7,eVar10,events';
								s.linkTrackEvents='event3';
								s.events='event3';
								s.eVar10= 'EClub Landing Page Sign-up';

								if ($.trim(globalOptin) == "true") {
										s.eVar7 = 'Global opt-in';
								} else {
										s.eVar7 = 'Concept opt-in';
								}

								s.tl($(this), 'o', 'Eclub Step1 SignUp');
								/** Omniture tracking -- END **/
								}
							}
						}
					var Language = $("#language").val();
			 		var Brand = $("#brand").val();
					$.ajaxSetup({ cache: false });
					form.find("#eclubFromPage").val(location.href);
					var email = $("#emailid_footer").val();
					var optins = $("#showpassword").val();
					$("#emailid_footer_form").val(email);
					var staticoptins = [];
					var staticoptins=["general-longhorn-logo", "general-seasons-logo", "general-capital-logo"];

					var og_opt_in = $("#global_optin_og").attr('checked');
					var lh_opt_in = $("#global_optin_lh").attr('checked');
					var bb_opt_in = $("#global_optin_bb").attr('checked');
					var cg_opt_in = $("#global_optin_cg").attr('checked');
					var ev_opt_in = $("#global_optin_ev").attr('checked');
					var s52_opt_in = $("#global_optin_52").attr('checked'); /** changed variable name by sathya */
					var yh_opt_in = $("#global_optin_yh").attr('checked');
					var cs_opt_in = $("#global_optin_cs").attr('checked');
					var selected_opt_ins = [];
					if (og_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_og").attr('value'));
					}
					if (lh_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_lh").attr('value'));
					}
					if (bb_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_bb").attr('value'));
					}
					if (cg_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_cg").attr('value'));
					}
					if (ev_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_ev").attr('value'));
					}
					if (s52_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_52").attr('value'));
					}
					if (yh_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_yh").attr('value'));
					}
					if (cs_opt_in == 'checked') {
						selected_opt_ins.push($("#global_optin_cs").attr('value'));
					}
					console.log("The selected optins:"+selected_opt_ins);

					if(selected_opt_ins && selected_opt_ins.length > 0){
						$("#all_brand_opt_ins").val(selected_opt_ins);
					}

					var data = {email : email};
					var url = inputObj.attr('data-guesttype-url');
					if (window.location.protocol == "https:") {
						url = $("#ajaxServletURL").val();
						data.AJAX_FUNCTION = "checkGuestType";
					}
					$.get(url, data,  function(response){
						successStep1Footer(response, inputObj, form);
					});

		return false;

			});

	/*
	Custom JS to overwrite functions in customerservice.js - supplied by DP - Start - WO48953
	*/

    $('#join_header_submit').click(function(){
        
        var inputObj = $('#join_header_submit'),
            email = $("#emailid_header").val(),
            suSource = $("#signup_header #signupSource").val();
        
        var frmHeader =  $("#signup_header"),
            submitForm = $("#signup_footer_form"); // this is the form we actually submit!
            
            frmHeader.attr('action', location.href);
           
        // hotswap in new form email id
        submitForm.find("#emailid_footer_form").val(email);
        submitForm.find("#signupSource").val(suSource);
        submitForm.find("#processEclubErrorURL").val("/home");  //this works
        submitForm.find("#processEclubSuccessURL").val("/customer-service/joineclub-step1");
        submitForm.find("#signupThankYouURL").val("/home");
        submitForm.find("#globalOptinStep1").val(false);
        
        // prep the AJAX request for checkGuestType
        $.ajaxSetup({ cache: false });
        var url = $("#ajaxServletURL").val();
        var data = {
            email : email,
            AJAX_FUNCTION : "checkGuestType"
        };

        // check for valid submission
        $.get(url, data, function(response){
            successStep1Slider(response, inputObj, submitForm);
        });

        return true;
      });


    /**
     * successStep1Footer -- from customerservice.js
     * @param  {Object} response Data response from ajax query
     * @param  {Object} inputObj trigger element that set off the click
     * @param  {Object} form     the form element that is to be submitted
     * @return {Boolean}         true on success
     */
    function successStep1Slider(response, inputObj, frmSubmit) {
        

        var errorMsg = $(response).filter("#errorMsg");
        var emessage = errorMsg.html();
            emessage = $.trim(emessage);
			
		// thank you modal HTML
		var thankYouModalHTML = '<span style="display:none;" id="showThankYouOverlay">true</span><div id="myModal" class="modal hide fade eclubconfirmation" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">'+
                        '<div class="container-fluid mobalbox">'+
                        '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">'+
                        '<img src="https://media.olivegarden.com/images/site/close-btn.png" title="Close Icon" alt="Close Icon" /></button>'+
                        '<h3 class="myModalLabel2">THANK YOU FOR SIGNING UP!</h3>'+
                        '<p>You will receive a confirmation email shortly.</p>'+
                        '<hr /></div></div>';

        // make errs visible
        $("#signup_header #error_msg").html(errorMsg.html());

        // if we didnt get any errors
        if (!emessage){
            $("#signup_header #error_msg").empty();

           	var showThankYouOverlay = $(response).filter("#showThankYouOverlay"); //WO181051- DP Enhancement - eClub Duplicate Signup
            var alreadySubscribed = $(response).filter("#alreadySubscribed");	  //WO181051- DP Enhancement - eClub Duplicate Signup
            
            if ("true" == showThankYouOverlay.html()) {
                if (window.location.protocol == "https:") {
                var thankYouURL = $("#ajaxServletURL").val().concat("?AJAX_FUNCTION=eclubThankYou");
                    frmSubmit.find("#signupThankYouURL").val(thankYouURL);
                }

                //trigger DTM events
                dtmEvent("eclubComplete","eclub");
                adobe.target.trackEvent({
                    "mbox": "mboxClickTrack",
                    "params": {
                        "signup": "header"
                    }
                });

                $.get(thankYouURL , function(overlayHTML){
                    loadEclubOverlaySlider(overlayHTML)
                });
                frmSubmit.submit();
            
            }else if("true" == alreadySubscribed.html()){
                var alreadySubscribedURL = $('#alreadySubscribedURL').val();

                $.get(alreadySubscribedURL , function(overlayHTML){
                    loadEclubOverlaySlider(overlayHTML)
                });

            }else{
                frmSubmit.submit();
            }

            //cleanup
            $("#emailid_header").val('');

        }else{
            // we encountered an error
            _dri.h.reportBugsnag({"Extra":
                            { "experience":"B",
                              "section":"successStep1Slider"}
                            },
                            { "title":"eClub Submission Error",
                              "message":emessage
                        });
        }
    }


    
    function loadEclubOverlaySlider(modalHTML){
        $("#myModal").remove();

        var modalDiv = $(modalHTML).filter("#myModal");
                
        var zipSearchEclubUrl = $("#zipSearchUrl").val();
        
        modalDiv.find(".styled-select select, .styled-select-red select").each(
            function() {
                $(this).wrap("<span class='select-wrapper'></span>");
                $(this).after("<span class='holder'></span>");
                var firstOption = $(this).find("option:first").text();
                $(this).next(".holder").text(firstOption);
            }
        );

        modalDiv.attr('style','top: 0% !important');
        scrolloverlay(modalDiv);
        
        modalDiv.modal();
        //calling dgStyle() function manually for the checkbox to work normally
        // as in a normal page load
        if(modalDiv.find(".checkbox_d").length > 0){
            modalDiv.find(".checkbox_d").dgStyle();
        }
        
        //Added for ALM#1757, to prepopulate city state in step3
        var zipField = $(modalHTML).find('#eclub_zip');
        if(zipField && zipField.val() && zipField.val() != '') {
            findCityState(zipField,zipSearchEclubUrl);
        }
    }


	/*
	Custom JS to overwrite functions in customerservice.js - supplied by DP - End - WO48953
	*/
	
	
	/**
	 * Success callback method for Join E-club Step 1
	 */
	function successStep1Footer(response, inputObj, form) {
		var errorMsg = $(response).filter("#errorMsg");
		$("#signup_footer #error_msg").html(errorMsg.html());
		if (!$.trim((errorMsg.html()))) {
			$("#signup_footer #error_msg").empty();
			var showThankYouOverlay = $(response).filter(
					"#showThankYouOverlay");
			var alreadySubscribed = $(response).filter(
			"#alreadySubscribed");
			if ("true" == showThankYouOverlay.html()) {
				if (window.location.protocol == "https:") {
				var thankYouURL = $("#ajaxServletURL").val().concat("?AJAX_FUNCTION=eclubThankYou");
					form.find("#signupThankYouURL").val(
							thankYouURL);
				}
				doAJAX(inputObj, null, loadEclubOverlay, form);
			}else if("true" == alreadySubscribed.html()){
				var alreadySubscribedURL = $('#ajax_alreadySubscribed').val();
				if (window.location.protocol == "https:") {
					alreadySubscribedURL = $('#alreadySubscribedURL').val();
				}
				$.get(alreadySubscribedURL , function(overlayHTML){
					loadEclubOverlay(overlayHTML)
	    		});
				}else{
				form.submit();
			}
			$("#emailid_footer").val('');
			$("#global_optin_chk").prop('checked', false);
			$("#global_optin_chk").attr('checked', false);
			$('#join_checkbox').data("checked",false).css({backgroundPosition:"left 0"})
		}
	}


	function successStep1Call(response, form, inputObj) {
		/** Omniture tracking start **/
		//dtm flag check
	    if($("#dtmenabled").val()=="false")
		{
		s.linkTrackVars='prop31';
		s.prop31 = "Subscribe Darden Family:Yes";
		s.tl($(this), 'o', 'Subscribe Darden Family');
		}
	   /** Omniture tracking start **/
		// console.log($.trim(response));
		var errorDiv = $(response).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			dtmEvent("eclubComplete","eclub");
			//if no form errors show overlay
			$("#error_msg").empty();
			loadEclubOverlay(response);
		}
	}
	/**
	 * AJAX call to display learn more overlay.
	 */
	$(document).on("click", "#optin , #global-Optin, #global-Optin-reg", function() {
		scrolloverlay($("#signupBenefitsModal"));
		$("#signupBenefitsModal").attr('style','top: 0% !important');
				$("#signupBenefitsModal").modal();
		return false;
	});

	/** Omniture tracking for Eclub step2 cancel**/
	if($("#dtmenabled").val()=="false")
		{
	$(document).on("click", "#cancel-eclub-step2", function() {
		s.linkTrackVars='eVar7,eVar10,events';
		s.linkTrackEvents='event7';
		s.events='event7';
		s.eVar10= 'Eclub';

		if ($.trim($("#globalOptin").val()) == "true") {
				s.eVar7 = 'Global opt-in';
		} else {
				s.eVar7 = 'Concept opt-in';
		}

		s.tl($(this), 'o', 'Eclub step2 cancel');
	});
		}

	/**
	 * AJAX call to invoke handleProcessEclub for Join E-club Step2
	 */
	$(document).on("click", "#save_button", function() {
		var form = $(this).closest("form");
		var globalOptin = form.find(".checkbox_d").data('checked');
		//do omniture tracking only if Global checkbox was checked.
		if ($.trim(globalOptin) == 'true') {
			if($("#dtmenabled").val()=="false")
				{
			/** Omniture tracking -- START **/
			s.linkTrackVars='eVar7,eVar10,events';
			s.linkTrackEvents='event3';
			s.events='event3';
			s.eVar10= 'Eclub';
			s.eVar7 = 'Global opt-in';
			s.tl($(this), 'o', 'Eclub step2 Save');
			/** Omniture tracking -- END **/
				}
		}
		doAJAX($(this), null, successStep2Call);

		// preventing the page from being refreshed
		return false;
	});

	/**
	 * Success callback method for Join E-club Step 2
	 */
	function successStep2Call(response, form, inputObj) {
		var errorDiv = $(response).find("#error_msg");

		form.find("#error_msg").html(errorDiv.html());

		if (!$.trim((errorDiv.html()))) {
			$("#error_msg").empty();
			$('#myModal').modal('hide');
			if($("#dtmenabled").val()=="false")
				{
				/** Omniture tracking for create account page view -- START **/
			    clearOmnitureVars();
		    s.events='event7,event104';
			s.eVar10= 'EClub Landing Page Sign-up';
			s.eVar7 = 'Concept opt-in';
			/*if($.trim(form.find("#global").val()) == 'G') {
					s.eVar7 = 'Global opt-in';
			}*/
			if($("#globalOptinStep1").val()== 'true') {
				s.eVar7 = 'Global opt-in';
				}
				s.pageName = 'Eclub Step3 Page';
				void(s.t());
				/** Omniture tracking -- END **/
				}
			dtmEvent("eclubMoreInfo","eclub");
			loadEclubOverlay(response);

		}else
		{
		scrolloverlay($("#myModal"));
		}
	}


	//Start :ToGo redesign Progress Bar AJAX call.
	function showProgressBar(){
		var progressBarUrl = $('#progressbar-ajax-url').val();
		var currentURL=window.location + "";
		var orderTypeValue=$("#orderTypeValue").val();
		var orderType=$("#orderType").val();

		var data = {};
		if(orderType == 2)
		{
			progressBarUrl=$('#deliveryProgressbar-ajax').val();
			data.AJAX_FUNCTION = "deliveryProgressBar";
		}else{
			data.AJAX_FUNCTION = "progressBar";
		}

		if (window.location.protocol == "https:") {
			progressBarUrl = $("#ajaxServletURL").val();
		}
		data.fromPage = location.pathname;
		data.URL = window.location.pathname;

		if(typeof progressBarUrl != "undefined"){
			request = $.ajax({
		        url: progressBarUrl,
		        type: "post",
		        data: data,
		        cache : false
		    });
		    request.done(function (response, textStatus, jqXHR){
		    	$("#progressBar").html(response);
				if($("#restName").length)
				{
				var str=$("#restName").html();
				if(str.length>21)
				{
				$("#restName").attr("title",str);
				var res = str.substring(1, 25);
				$("#restName").html(res+"..")
				}
				}
		    });
		    request.fail(function (jqXHR, textStatus, errorThrown){
		 		// log the error to the console
		 		console.error("The following error occured: "+ textStatus, errorThrown);
		 	});
		}
	}

	function updateOrderSummaryInfo(){
		var orderSummaryURL = '/cartridges/order-summary/order-summary.jsp';
		var lang = $('#language').val();

		if('es' == lang){
			orderSummaryURL = '/es'+orderSummaryURL;
		}
		var data = {};
		request = $.ajax({
	        url: orderSummaryURL,
	        type: "post",
	        data: data,
	        cache : false
	    });
	    request.done(function (response, textStatus, jqXHR){
	    	//$('div[class="place-order mar-lft-2"]').html($(response).filter('div[class="place-order mar-lft-2"]').html());
	    	$('div[class="pick-up mar-lft-2"]').html($(response).filter('div[class="pick-up mar-lft-2"]').html());
			if($(".coupon-price-box") && $(".coupon-price-box").size() > 0){
		if($(".coupon-price-box") && $(".coupon-price-box").html() && location.pathname.indexOf("/togo/") != -1) {
			$(".coupon-heading.txtbold").hide();
			$(".coupon-label").hide();
			$("#couponCode").hide();
			$("#apply_coupon_btn").hide();
			$(".coupon-chk-out-bg.primary-btn.pull-right.item-null").hide();
		}
	}
	    });
	    request.fail(function (jqXHR, textStatus, errorThrown){
	 		// log the error to the console
	 		console.error("The following error occured: "+ textStatus, errorThrown);
	 	});
	}

	/**
	 * Function used for to validate the zip code provided based on country.
	 */
	function findZipCode(zipField,zipSearchUrl,zipCode_Country,form,response) {
		var thankyou_resp = response;
		if(zipField.trim() == "")
			return;
		var jsonData = {"atg-rest-class-type": "com.darden.commerce.address.ZipSearchLookupRequest"};
		jsonData.zipCode = zipField;
		jsonData.country = zipCode_Country;
		var request = $.ajax({
						cache: false,
						timeout: 5000,
						type: "POST",
						async: true,
						data: {requestData : JSON.stringify(jsonData)}, //Creates JSON query string.
						dataType: "json",
						url:zipSearchUrl
					})
		request.done(function (res) {
			if(res.errorMessage == null){
				form.find('#zip_errorDiv').empty();
				$("#emailSignUpModal").modal('hide');
				loadEclubThankyouOverlay(thankyou_resp);
			}
			else{
				form.find("#zip_errorDiv").text(res.errorMessage);
			}
		})
		request.fail(function (xhr) {
			form.find('#zip_errorDiv').text(form.find('#zip_errorDiv').attr('data-error'));
		});
	}

	/**
	 * AJAX call to invoke handleCreate for Join E-club Step3
	 */
	$(document).on("click", "#create_account_btn", function() {

		doAJAX($(this), null, successStep3Call);
		// preventing the page from being refreshed
		return false;
	});

	/**
	 * Success callback method for Join E-club Step 3
	 */
	function successStep3Call(response, form) {
		var errorDiv = $(response).find("#error_msg");
		form.find("#error_msg").html(errorDiv.html());

		if (!$.trim((errorDiv.html()))) {
			var headerLinksURL = form.find("#headerLinksURL").val();
			refreshHeaderLinks(headerLinksURL);
			if($("#dtmenabled").val()=="false")
				{
			/** Omniture tracking for Thankyou page view-- START **/
			clearOmnitureVars();
			s.events='event92';
			s.pageName = 'SignUp Thankyou Page';
			void(s.t());
			/** Omniture tracking -- END **/
				}
			$("#error_msg").empty();
			$('#myModal').modal('hide');
			loadEclubOverlay(response);
		}else
		{
			scrolloverlay($("#myModal"));
		}
	}

	/** ajax call for getCoupon button on join eclub step 4 **/
	$(document).on("click", "#personalize-coupon", function() {
		doAJAX($(this), null, successStep4GetCoupon);
		// preventing the page from being refreshed
		return false;
	});
	/** successcallback function for get coupon ajax call **/
	function successStep4GetCoupon(data, form) {
		var errorDiv = $(data).find("#error_msg_coupon");
		form.find("#error_msg_coupon").html(errorDiv.html());

		if (!$.trim((errorDiv.html()))) {
			var successURL = $("#getCouponSuccessURL").val();
			window.open(successURL);
		}
	}

	/** * AJAX call to invoke handleChangeCurrentRestaurant for Login */
	$(document).on("click", "#rest_change_btn", function() {
		var form = $(this).closest("form");
		form.submit();
	});

	function loadEclubThankyouOverlay(modalHTML) {
		$("#emailSignUpModal").remove();
		$("#myModal").remove();
		var modalDiv = $(modalHTML).filter("#myModal");
		modalDiv.find(".styled-select select, .styled-select-red select").each(function() {
			$(this).wrap("<span class='select-wrapper'></span>");
			$(this).after("<span class='holder'></span>");
			var firstOption = $(this).find("option:first").text();
			$(this).next(".holder").text(firstOption);
			});
		modalDiv.attr('style','top: 15% !important;width:43%;');
		scrolloverlay(modalDiv);
		modalDiv.modal();
		//calling dgStyle() function manually for the checkbox to work normally
		// as in a normal page load
		if(modalDiv.find(".checkbox_d").length > 0){
			modalDiv.find(".checkbox_d").dgStyle();
		}
	}

	/**
	 * Common method for loading overlay for E-club
	 */
	function loadEclubOverlay(modalHTML) {
		$("#myModal").remove();
		var modalDiv = $(modalHTML).filter("#myModal");
		var zipSearchEclubUrl = $("#zipSearchUrl").val();
		modalDiv.find(".styled-select select, .styled-select-red select").each(function() {
			$(this).wrap("<span class='select-wrapper'></span>");
			$(this).after("<span class='holder'></span>");
			var firstOption = $(this).find("option:first").text();
			$(this).next(".holder").text(firstOption);
			});
		modalDiv.attr('style','top: 0% !important');
		scrolloverlay(modalDiv);
		modalDiv.modal();
		//calling dgStyle() function manually for the checkbox to work normally
		// as in a normal page load
		if(modalDiv.find(".checkbox_d").length > 0){
			modalDiv.find(".checkbox_d").dgStyle();
		}
		//Added for ALM#1757, to prepopulate city state in step3
		var zipField = $(modalHTML).find('#eclub_zip');
		if(zipField && zipField.val() && zipField.val() != '') {
			findCityState(zipField,zipSearchEclubUrl);
		}
	}

	// to show login modal when user already exists
	if($("#loginExist").length != 0 && !(location.pathname.indexOf("/rewards/sign-up") != -1)){
		var loginExist = $("#loginExist").val();
		if (loginExist == 'true') {
			$("#loginModal").attr('style','top: 6% !important');
			$("#loginModal").modal();
		}
	}

	if(location.href.indexOf('customer-service/join/')>-1 && location.href.indexOf('?showConfirmation')>-1){
    
    var IndexOF = window.location.href.indexOf("/customer-service");
    var redirectURL = window.location.href.slice(0,IndexOF)
        redirectURL += "/home"
    $("#landingPageModal_overlayCloseButton").on("click", function(){
        
        window.location.href = redirectURL;
    });
	}

	//R4.2 Changes - to show landing confirmation overlay on landing page submit
	if ($("#landingConfirmation").length != 0) {
		var landingConfirmation = $("#landingConfirmation").val();
		if (landingConfirmation == 'true') {
			$("#landingPageModal").attr('style','top: 5% !important;width:70%;');
			$("#landingPageModal").modal();
		}

		/* PIPE fix for 152642*/
		if($("#dtmenabled").val()=="false")
			{
			if(location.href.indexOf('customer-service/join/eclub-referral-sign-up')>-1 && $("#error_msg").text().trim()==""
		                       && $("#landingPageModal").modal().length>0)

		                       {
		                       s.linkTrackVars='events,eVar7,eVar10'
		                       s.linkTrackEvents='event49,event7';
		                       s.events='event49,event7';


		                       var opt=$('#primaryOptin_reg').find('#offers').attr('checked');

		                       if (opt=="checked")
		                               {
		                               s.eVar7="Concept Opt-in";
		                               }

		                       var opt=$('.checkbox_d').find('#inAdditionCheck').attr('checked');

		                       if (opt=="checked")
		                               {
		                               s.eVar7="Global Opt-in";
		                               }

		                       s.eVar10="eClub-"+s.pageName+"optin";
		                       s.tl($(this),'o',s.pageName)

		        }
			}

		 /* End PIPE fix for 152642*/

	}

	//to populate states based on country (US/Canada) on change
	var firstRequestCountryCallDone = false;
	$(document).on("change", "[id^=reg_countryNameSelect]," +
			"#eclub_countryNameSelect,#add_countryName,#contactus_countryNameSelect", function() {

		var stateSelector = $($(this).attr('data-statebox'));
		populateState($(this), stateSelector);
	});

	function populateState(countryObj, stateSelector) {
		var currentValue = $(stateSelector).val();
		var url = stateSelector.attr('data-url');
		var pageURL = window.location+"";
		if(pageURL.indexOf('/delivery') > -1 && window.location.protocol == "https:"){
            url = $("#ajaxServletURL").val();
		}
	    request = $.ajax({
			url: url,
			type: "post",
			data: {AJAX_FUNCTION:"deliveryEditAddress",country:countryObj.val()}
		});
	    request.done(function (response, textStatus, jqXHR){
	    	getStates(response, stateSelector);
	    	var holderText = $(stateSelector).find("option:selected").text();
			  $(stateSelector).next(".holder").text(holderText);
				if(!firstRequestCountryCallDone){
					firstRequestCountryCallDone = true;
					$(stateSelector).val(currentValue);
					var holderText = $(stateSelector).find("option:selected").text();
					$(stateSelector).next(".holder").text(holderText);
				}
		});

		// callback handler that will be called on failure
		request.fail(function (jqXHR, textStatus, errorThrown){
			// log the error to the console
			if(!firstRequestCountryCallDone) firstRequestCountryCallDone = true;
			console.error("The following error occured: "+textStatus,
			errorThrown);

	});

	}
	function getStates(data, stateSelector) {
	    if ($.trim(data) == ':') {
	    	return;
	    }
	    else {
	          // Empty options just in case new drop down is shorter
	          stateSelector.find('option').remove();
	          // Populate the drop down with states from the selected country
	          var stateLineArray = $.trim(data).split("_");  // Split into
																// lines
	          for (var loop = 0; loop < stateLineArray.length; loop++) {
	            lineArray = stateLineArray[loop].split(":");
	            stateCode    = $.trim(lineArray[0]);
	            stateName    = $.trim(lineArray[1]);
	              if ( stateCode != undefined && stateCode != '' ) {
	            	  stateSelector.append(
	            	        	$('<option></option>').val($.trim(stateCode)).html($.trim(stateName))
	            	    	);
	              }
	          }
	    }
	}

	/**
	 * To highlight input fields that have incorrect data and clear those data  while registration
	 */
	if ($("input[id*='propertyName_']").length != 0) {
		$( "input[id*='propertyName_']" ).each(function() {
			var inputName = $(this).val();
			var $input = null;
			if(inputName=='dobDay' || inputName=='dobMonth' || inputName=='dobYear' ){
				$input = $("#"+inputName);
				$input.css('border', '1px solid #E9322D');
			} else {
				$input = $("input[name="+inputName+"]");
				$input.val('');

				$input.css({"border-color": "#E9322D",
					"box-shadow": "0 0 6px #F8B9B7"});
			}
		});

	}

	/**
	 * Send restauarant Information using SMS to user
	 *
	 */
	$(document).on("click", "#sendsms", function() {
		var phonenumber=document.getElementById('phone-ctn').value;
		var phonenumberformatted;
		var len;
		if (phonenumber.length > 0) {
			var phonenumberformatted=phonenumber.replace(/\D/g, '');
		}
		if(phonenumberformatted== undefined)
		{
			len=0;
		}
		else
		{
			var len=phonenumberformatted.length;
		}
		if (len<=0) {
		   $('#error_message_mobile,#locText label.error_msg').show();
	    	$('#error_message_mobile').text($('#invalidphone').val());
	    }
	    else if(len<10)
	    {  $('#error_message_mobile,#locText label.error_msg').show();
	    	$('#error_message_mobile').text($('#invalidphone').val());
	    }
	    else if (isNaN(phonenumberformatted)) {
		   $('#error_message_mobile,#locText label.error_msg').show();
	    	$('#error_message_mobile').text($('#invalidphone').val());
	    }
	    else {
	    	$("#locText").modal('hide');
			if($('#locationUpArrow').length){
				$('#locationDownArrow').show();
				$('#locationUpArrow').hide();
			}
	    	doAJAX($(this), null, hideSmsBlock);
	    	$("div#location-pop-up").hide();
	    }
		// preventing the page from being refreshed
		return false;
	});
	/**
	 * Send SMS Success call back function
	 *
	 */
	function hideSmsBlock(response, form) {
		$('#error_message_mobile').text('');
		$("#locText").modal('hide');
	}

	/**
	 * Send restauarant Information via email to user
	 *
	 */
	$(document).on("click", "#sendrestinfoemail", function() {
		var pattern = /^[a-zA-Z0-9\-_]+(\.[a-zA-Z0-9\-_]+)*@[a-z0-9]+(\-[a-z0-9]+)*(\.[a-z0-9]+(\-[a-z0-9]+)*)*\.[a-z]{2,4}$/;
		var emailcontent=document.getElementById('emailId').value;
	    if (pattern.test(emailcontent)) {
	    	$("#locEmail").modal('hide');
			if($('#locationUpArrow').length){
				$('#locationDownArrow').show();
				$('#locationUpArrow').hide();
			}
	    	doAJAX($(this), null, hideEmailBlock);
	    	$("input, button, a, span").prop("disabled", false);
	    	$("div#location-pop-up").hide();
	    } else {
		    $("label.error_msg").show();
			$('#error_message_email').show();
	    	$('#error_message_email').text($('#invalidemailaddr').val());
	    }
		return false;
	});

	/**
	 * Send restaurant info Success call back function
	 *
	 */
	function hideEmailBlock(response, form) {
		$('#error_message_email').text('');
		$("#locEmail").modal('hide');
	}

	/**
	 * Send restauarant Directions via email to user
	 *
	 */
	$(document).on("click", "#senddirectionsemail", function() {
		var dircontent =$("#print_directions").html();
		document.getElementById("showdirections").value=dircontent;
		var pattern = /^[a-zA-Z0-9\-_]+(\.[a-zA-Z0-9\-_]+)*@[a-z0-9]+(\-[a-z0-9]+)*(\.[a-z0-9]+(\-[a-z0-9]+)*)*\.[a-z]{2,4}$/;
		var emailcontent=document.getElementById('emailId').value;
	    if (pattern.test(emailcontent)) {
		doAJAX($(this), null,updateDirectionsMessage);
		$("input, button, a, span").prop("disabled", false);
	    }
	    else {
	    	$('.error_msg').text($('#invalidemail').val());
	    }
		// preventing the page from being refreshed
		return false;
	});

	/**
	 * Send restaurant directions call back function
	 *
	 */
	function updateDirectionsMessage(response, form) {
		$('.error_msg').text('');
		$('.error_msg').text($('#sentsuccessful').val());
	}

	/**
	 * Method for displaying the preferred restaurant details based on selection.
	 */
	$(document).on("click", "#myRestaurantModal *[id*='choose']", function(){
		var choose = $(this);
		var id = choose.attr('data-id');
		var url = choose.closest('div').attr('data-url');
		var endecaInds = choose.closest('div').attr('data-id');
		request = $.ajax({
			url: url,
			type: "post",
			data: "id=" + id +"&endecaRestIndicators=" + endecaInds
		});
	    request.done(function (response, textStatus, jqXHR){
	    	if($("#eclubPreferredRestaurant").length != 0){
	    		$("#eclubPrefRest").html(response);
	    		$("#eclubPreferredRestaurant").val(id);
	    	} else {
	    		$("#prefRest").html(response);
	    		$("#preferredRestaurant").val(id);
	    	}
	    	$("#myRestaurantModal").modal('hide');
	    	$("#myModal").show();
	        // restaurantNumber =  $('#locDetailsId').attr('href').split('/')[5];
			// motherDay();
		});

		// callback handler that will be called on failure
		request.fail(function (jqXHR, textStatus, errorThrown){
			// log the error to the console
			console.error("The following error occured: "+
					textStatus, errorThrown);
		});
	});
	
	$(document).on("change","#zip", function() {
		var $this = $("#zip");
		var countryObj = $this.attr("data-countrybox");
		var zipSearchUrl = $("#zipSearchUrl").val();
		var zipCode = $this.val().trim().replace(/ /g,'');
		if($(countryObj).val()=='US') {
			if(zipCode.length == 5) {
				findCityState($this,zipSearchUrl);
			}
		}
		if($(countryObj).val()=='CA') {
			if(zipCode.length == 6) {
				findCityState($this,zipSearchUrl);
			}
		}
	});
	/**
	 * Function used for getting city and state based on zip code provided.
	 */
	function findCityState(inputField,zipSearchUrl) {
		var $this = inputField;
		var form = $this.closest("form");
		if(($this.val()).trim() == "")
			return;
		var countrybox = $this.attr("data-countrybox");
		var cityfield = $this.attr("data-cityfield");
		var statebox = $this.attr("data-statebox");
		var jsonData = {"atg-rest-class-type": "com.darden.commerce.address.ZipSearchLookupRequest"};
		jsonData.zipCode = $this.val();
		jsonData.country = form.find(countrybox).val();
		$this.prop("disabled", true);
		var data = {};
		data.requestData=JSON.stringify(jsonData);
		if (window.location.protocol == "https:") {
			//alert("window.location.protocol"+window.location.protocol);
			zipSearchUrl = $("#ajaxServletURL").val();
			data.AJAX_FUNCTION = "zipSearch";
		}
		var request = $.ajax({
						cache: false,
						timeout: 5000,
						type: "POST",
						async: true,
						data: data, //Creates JSON query string.
						dataType: "json",
						url:zipSearchUrl
					})
		request.done(function (res) {
			if(res.errorMessage == null){
				form.find('#zip_errorDiv').empty();
				$(cityfield).val(res.city);
				$(statebox).val(res.state);
				var holderText = $(statebox).find("option:selected").text();
				$(statebox).next(".holder").text(holderText);
				$("#zip").blur();
			}
			else{
				$(cityfield).val("");
				$this.val("");
				form.find('#zip_errorDiv').text(res.errorMessage);
			}
		})
		request.fail(function (xhr) {
			form.find('#zip_errorDiv').text(form.find('#zip_errorDiv').attr('data-error'));
		});

		request.always(function() {
			$this.prop("disabled", false);
		});

	}

	/**
	 * This method focus-out when user completes the typing of zipcode based on the country
	 */
	$(document).on("keyup","#zip, #eclub_zip,#contactus_zip", function() {
		var $this = $(this);
		var countryObj = $this.attr("data-countrybox");
		var zipSearchUrl = $("#zipSearchUrl").val();
		var zipCode = $this.val().trim().replace(/ /g,'');
		if($(countryObj).val()=='US') {
			if(zipCode.length == 5) {
				findCityState($this,zipSearchUrl);
			}
		}
		if($(countryObj).val()=='CA') {
			if(zipCode.length == 6) {
				findCityState($this,zipSearchUrl);
			}
		}
	});

	/**
	 * validation for first name and last name for profile Add Address
	 */
	/*$(document).ready(function(){
		$(document).on("blur", "#n2",function() {
		var nameOnAddress = $('#n2').val();
		nameOnAddress = nameOnAddress.replace(/^[ ]+|[ ]+$/g,'');
		nameOnAddress = nameOnAddress.replace(/^\s+|\s+$/g,'');
		var nameOnAddrArr = nameOnAddress.split(new RegExp("\\s+"));
		if (nameOnAddrArr.length > 1) {
		$('#firstLastNameError').remove();
			return true;
		}else{
		if($('#firstLastNameError').length == 0){
		$('#n2').before('<label id="firstLastNameError" class="firstLastNameErrorMesage">Please enter First Name and Last Name.</label>');
		}
		}
		return false;
	});
	});	*/
	/**
	 * AJAX call to invoke handleXX Method for Add Address
	 */
	$(document).on("click", "#adrAddButton", function() {
		if($('#firstLastNameError').length == 0){
		var nameVal = $('#n2').val()
	    var nameLength = nameVal.length;
	    var nameSplit = nameVal.split(" ");
	    var lastLength = nameLength - nameSplit[0].length;
	    var lastNameLength = nameSplit[0].length + 1;
	    var lastName = nameVal.slice(lastNameLength);
	    $('#addfirst_name').val(nameSplit[0]);
	    $('#addlast_name').val(lastName);
		doAJAX($(this), null, successAddAddress);
		// preventing the page from being refreshed
		return false;
		}else{
			$("#n2").focus().select();
			$(window).scrollTop($('#addAddress').offset().top);
		}
	});


	/**
	 * Success callback method for Add Address
	 */
	function successAddAddress(response, form) {
		var pageURL = window.location+"";
		var errorDiv = $($.parseHTML(response)).find("#error_msg");
		var returnUrl = $('#addAddrReturnUrl').val();
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			if(pageURL.indexOf('/customer-service/express-checkout-settings') > -1 ){
				window.location.href ="/customer-service/express-checkout-settings?returnPage="+returnUrl;
			}else{
				$("#addAddress").replaceWith(response);
			}
		}
	}

	/**
	 * AJAX call to invoke handleXX Method for Edit Address
	 */
	$(document).on("click", "#adrEditButton", function() {
		var nameVal = $('#n1').val()
	    var nameLength = nameVal.length;
	    var nameSplit = nameVal.split(" ");
	    var lastLength = nameLength - nameSplit[0].length;
	    var lastNameLength = nameSplit[0].length + 1;
	    var lastName = nameVal.slice(lastNameLength);
	    $('#first_name').val(nameSplit[0]);
	    $('#last_name').val(lastName);
		doAJAX($(this), null, successEditAddress);
		// preventing the page from being refreshed
		return false;
	});

	/**
	 * Success callback method for Edit Address
	 */
	function successEditAddress(response, form) {
		var pageURL = window.location+"";
		var errorDiv = $($.parseHTML(response)).find("#error_msg");
		var returnUrl = $('#updateAddrReturnUrl').val();
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			if(pageURL.indexOf('/customer-service/express-checkout-settings') > -1 ){
				window.location.href =$("#express_checkout_Url_Id").val()+"?returnPage="+returnUrl;
			}else{
			$("#editAddress").replaceWith(response);
			}
		}
	}


	/**
	 * Method for setting nickname for removeAddress
	 */
	$(document).on("click", "a[id*='remove-ship-address']", function() {
		var inputObj = $(this);
		var removeModalURL = inputObj.attr('data-modal-url');
		var defaultAddressId = inputObj.attr('data-default-address');
		var noOfAddresses = inputObj.attr('data-address-count');
		var removeAdrId = inputObj.attr('data-remove-address');
		var defaultAddress ='false';
		if ($.trim(noOfAddresses) != 1 && ($.trim(removeAdrId) == $.trim(defaultAddressId))) {
			defaultAddress = 'true';
		}
		$.ajaxSetup({ cache: false });
		$.get(removeModalURL, { defaultAddress : defaultAddress }, function(data){
			$("#removeAddressModal").remove();
			var removeModal = $($.parseHTML(data)).filter("#removeAddressModal");
             scrolloverlay(removeModal) ;
			removeModal.modal();
			var nickName = inputObj.attr('data-nickname');
			removeModal.find("#removalNickName").val(nickName)
		});
		return false;
	});

	/**
	 * AJAX call for removeAddress function.
	 */
	$(document).on("click", "#remove-addr-confirm", function() {
		doAJAX($(this), null, reloadAddresses);
		$("#removeAddressModal").modal('hide');
		$("#removeAddressModal").remove();
		return false;
	});
	/**
	 * success callback function for removeAddress.
	 */
	function reloadAddresses(response, form){
		var errorDiv = $($.parseHTML(response)).filter("#error_msg");
		form.find("#error_msg").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#edit-address").replaceWith(response);
		}
	}

	/**
	 * AJAX call for selectDefaultAddress function.
	 */
	$(document).on("change", "input[id*='ship-addr-radio-']", function() {
		doAJAX($(this), null, reloadAddresses);
		return false;
	});

	/**
	 * Reset password using challenge question
	 */
	$(document).on("click", "#resetPassword", function() {
		var dataurl = $(this).attr("data-url");
		var extraParams = "&redirectURL="+dataurl;
		doAJAX($(this), extraParams, successResetPasswordStep1);
		return false;
	});

	// callback handler that will be called on success
	function successResetPasswordStep1(response, form) {
		var errorDiv = $($.parseHTML(response)).find("#error_chqn");
		form.find(".error_msg").html(errorDiv.html());
		var noErrors = form.find("#noErrors");
		if (noErrors.length) {
			$("#error_msg").empty();
			$("#challengeQnDiv").html(response);
			}
		$(".styled-select select, .styled-select-red select").each(function(){
			$(this).parent().wrap("<span class='select-wrapper'></span>");
			$(this).after("<span class='holder'></span>");
			var firstOption = $(this).find("option:first").text();
			$(this).next(".holder").text(firstOption);
		});
	}

	/**
	 * Reset password by sending email
	 */
	$(document).on("click", "#send_email", function() {

		doAJAX($(this), null, successSendEmail);
		return false;
	});

	/**
	 * Success callback method for Send Email while resetting password
	 */
	function successSendEmail(response, form) {
		$("#inValidTokenMessage").html('');
		var errorDiv = $($.parseHTML(response)).find("#error_sendemail");
		form.find("#error_sendemail").html(errorDiv.html());
		if (!$.trim((errorDiv.html()))) {
			$("#successMsg").html(form.find("#send_email_msg").html());
		} else {
			$("#successMsg").html('');
		}
	}

	/**
	 * When Reset Password page doesn't have a valid token.
	 */

	if ( $("#reset").length != 0 && $("#reset").val() == 'true') {
		if($("#inValidTokenMessage").length != 0 ) {
			$("#inValidTokenMessage").html('Reset Password link got expired. Please reset again');
		}
	}

//Manage Location

	/**
	 * Remove a favorite location
	 */
	$(document).on("click", "a[id*='favorite-remove-']", function() {
		var inputObj = $(this);
		var removeModalURL = inputObj.attr('data-modal-url');
		var locationId = inputObj.attr("data-id");
		var defaultLocationId = inputObj.attr("data-default-location");
		var noOfLocations = inputObj.attr("data-location-count");
		var defaultLocation ='false';
		if ($.trim(noOfLocations) != 1 && ($.trim(locationId) == $.trim(defaultLocationId))) {
			defaultLocation = 'true';
		}

		$.ajaxSetup({ cache: false });
		$.get(removeModalURL, { defaultLocation : defaultLocation }, function(data){
			$("#removeLocationModal").remove();
			var removeModal = $($.parseHTML(data)).filter("#removeLocationModal");
			scrolloverlay(removeModal) ;
			removeModal.modal();
			removeModal.find("#removeLocationId").val(locationId);
		});
		return false;
	});

	/**
	 * Remove location form submission
	 */
	$(document).on("click", "#removeLocation", function() {
		var form = $(this).closest("form");
		form.submit();
	});

	/**
	 * Make default a favorite location
	 */
	$(document).on("click", "input[id*='favorite-default-']", function() {
		var inputObj = $(this);
		var makeDefaultModalURL = inputObj.attr('data-modal-url');
		var locationId = inputObj.val();
		request = $.ajax({
			url: makeDefaultModalURL,
			type: "post",
			data: "locationId=" + locationId
		});
	    request.done(function (response, textStatus, jqXHR){
	    	var defaultLocation = $($.parseHTML(response)).filter("#makeDefaultLocationModal");
	    	scrolloverlay(defaultLocation) ;
	    	defaultLocation.modal();
	    	defaultLocation.find("#defaultLocationId").val(locationId);

		});
	});

	$(document).on("click", "#makeDefaultLocation", function() {
		var form = $(this).closest("form");
		form.submit();
	});

	$(document).on("click", "a[id*='favorite-location-cancel']", function() {
		window.location=$(this).attr("data-modal-url");
	});


	/**
	 * Omniture Tracking for Account Subscriptions on page load.
	 */
	if($("#dtmenabled").val()=="false")
		{
	if($("form#manage-subscriptions div.subscription-check").length > 0) {

		var doTracking = location.search.substring(1).indexOf('saveClicked');

		if( doTracking > -1) {
			s.linkTrackVars='eVar7,eVar10,events';
			//If any of the checkboxes are ticked, track optin-event.
			if($("form#manage-subscriptions input[checked='checked']").length > 0) {
					s.events='event7';
					s.eVar10= 'Account';
					var global = $("#selectall-concepts").data('checked');
					if ($.trim(global) == 'true') {
							s.eVar7 = 'Global opt-in';
					} else {
							s.eVar7 = 'Concept opt-in';
					}
					s.pageName = 'Account Subscriptions Opt-In'

			} else {
					//If NONE of the checkboxes are ticked, track optout-event.
					s.events='event37';
					s.eVar10= 'Account';
					s.eVar7 = 'Global opt-out';
					s.pageName = 'Account Subscriptions Opt-Out'
			}
			void(s.t());
		}
	}
		}

	//Recent Activity and Order History changes
	$(document).on("click", "a[id*='rtxt1']", function() {
		var inputObj = $(this);
		var orderId = inputObj.attr("data-id");
		var url = inputObj.attr('data-url');
		//added for  INC17342
		var checksum = inputObj.attr('data-checksum');
		if($("#order-details-"+orderId).length == 0) {
			request = $.ajax({
				url: url,
				type: "post",
				data: "orderId=" + orderId + "&checksum=" + checksum
			});
		    request.done(function (response, textStatus, jqXHR){

		    	$("#rdemo-"+orderId).html(response);
		    	$("#rdemo-"+orderId). css ('height','auto');


			});
		} else {
			$("#order-details-"+orderId).remove();
		}

	});

	$(document).on("click", "a[id*='hide-']", function() {
		var orderId = $(this).attr("data-id");
		$("#order-details-"+orderId).remove();

	});


	//Manage Favorite menu items.

	/**
	 * Remove a favorite location
	 */
	$(document).on("click", "a[id*='favoritemenu-remove-']", function() {
		var inputObj = $(this);
		var removeModalURL = inputObj.attr('data-modal-url');
		var favoriteId = inputObj.attr("data-favorite-id");
		var favoriteitemId = inputObj.attr("data-favoriteitem-id");
		request = $.ajax({
			url: removeModalURL,
			type: "post",
			data: "giftlistid=" + favoriteId
		});
	    request.done(function (response, textStatus, jqXHR){
	    	var removeFavoriteItem = $($.parseHTML(response)).filter("#removeFavoriteMenuItemModal");
	    	removeFavoriteItem.modal();
	    	removeFavoriteItem.find("#removalids").val(favoriteitemId);
	    	removeFavoriteItem.find("#giftlistid").val(favoriteId);
		});
	});

	/**
	 * Remove location form submission
	 */
	$(document).on("click", "#removeFavoriteMenuItem", function() {
		var form = $(this).closest("form");
		form.submit();
	});

	/**
	 * Remove a favorite location
	 */
	$(document).on("click", "a[id*='favoriteitem_indicator']", function() {
        var href = $(this).attr('href');
        if(!$.trim((href))){
			var inputObj = $(this);
			var prodID =  inputObj.attr('data-prodID');
			var catID =  inputObj.attr('data-catId');
			var size =  inputObj.attr('data-mode');
			$("#favCatId").val(catID);
			var extraParams = "&favproductId="+prodID+"&favcategoryId="+catID+"&favIcon="+size;
			doAJAX($(this), extraParams, successAddFavoriteItem);
			// preventing the page from being refreshed
			return false;
        }
	});

	/**
	 * Success callback method for add favorite item.
	 */
	function successAddFavoriteItem(response,form,inputObj) {
		var prodID =  inputObj.attr('data-prodID');
		$("#favItem-indicator-"+prodID).replaceWith(response);
	}
	/**
	 * Ajax call for add favorite location.
	 */
	$(document).on("click", "#favorites_anch,#fav-txts-location", function() {
		var inputObj = $(this);
		var restId =  inputObj.attr('data-restId');
		var extraParams = "&restaurantId="+restId;
		doAJAX($(this), extraParams, successAddFavoriteLocation);
		// preventing the page from being refreshed
		return false;
	});

	/**
	 * Success callback method for Add favorite location.
	 */
	function successAddFavoriteLocation(response,form,inputObj) {
		// added for DTM by Jaydeep START
		dtmEvent("addLocationToFavorites","location");
		// added for DTM by Jaydeep END
		$("#favorite_link_location_detail").replaceWith(response);
	}


	/** order-lookup - setting name and placeholder attr for validation*/
	$("input:radio[name='orderlookup_radio']").click(function(){
	    var inputName =  $(this).data("lookupname");
	    var gtext=$(this).data("name");
	    $("#emailPhoneDiv").find(":text").val("");
	    if (inputName === "phonenumber") {
	    	$("#emailPhoneDiv").find(":text").attr("id", "phone-ctn");
	    	$('#phone-ctn').attr("placeholder", gtext);
	    }
	    if (inputName === "email") {
		   $("#emailPhoneDiv").find(":text").removeAttr("id", "phone-ctn");
		   $("#emailPhoneDiv").find(":text").attr("id", "email-ctn");
		   $('#email-ctn').attr("placeholder", gtext);
	    }
	    if(!Modernizr.input.placeholder) {
			$('[placeholder]').focus( function() {
				var input = $(this);
				if (input.val() == input.attr('placeholder')) {
					input.val('');
					input.removeClass('placeholder');
				}
			}).blur( function() {
				var input = $(this);
				if (input.val() == '' || input.val() == input.attr('placeholder')) {
					input.addClass('placeholder');
					input.val(input.attr('placeholder'));
				}
			}).blur();
			$('[placeholder]').parents('form').submit( function() {
				$(this).find('[placeholder]').each( function() {
					var input = $(this);
					if (input.val() == input.attr('placeholder')) {
						input.val('');
					}
				});
			});
		}
	});


	/**
	 * Changes the default behaviour in custom.js for orderlookup phone field
	 * Max length is increased to 14
	 */
	$("#detail_radio_phone").click(function(){
	  	$("#emailPhoneDiv").find(":text").attr("maxlength","14");
	});

/**Maxlength increase*/

	$("#detail_radio_email").click(function(){

		var recProd = $('#maxlengthValue').val();
		 if(recProd != undefined){
			 $("#emailPhoneDiv").find(":text").attr("maxlength",recProd);
		    }

	});

    /** Order History - for collapse image unhide*/
	$("[id*='year_']").on('shown', function () {
        var arrowId = $(this).attr("data-arrow-id");
         $("#" + arrowId).addClass('arrow-up');
         $("#" + arrowId).removeClass('arrow-down');
     });

	/** Order History - for collapse image hide */
     $("[id*='year_']").on('hidden', function () {
         var arrowId = $(this).attr("data-arrow-id");
         $("#" + arrowId).addClass('arrow-down');
         $("#" + arrowId).removeClass('arrow-up');
    });

	//Scroll to error div when create account give error on order-confirmation screen
     if ($('#create_error').length && $('#rest-confirm-order').length) {
			window.location.hash = '#rest-confirm-order';
     }
 	//Scroll to error div when create account gives error on gift card order-confirmation screen
     if ($('#create_error').length && $('#order-payment').length) {
			window.location.hash = '#order-payment';
     }

     //Nutrition prefernces check for empty field
     $("#saveInterests").click(function(e){
    	 var preventDefault = false;
    	 $("input[id*='_editableOption']").each(function() {
    		 var id = $(this).attr('id');
    		 var idError = id.split('_')[0].concat('_error');
    		 var errorLabel = $('#'+idError);
    		 errorLabel.empty();
	    	 if($(this).prop('checked')){
	    		 var idInput = id.split('_')[0].concat('_editableInput');
	    		 var inputBox = $('#'+idInput);
	    		 if(!$.trim(inputBox.val())) {
	    			 var optionFieldError = $('#optionFieldError').val();
	    			 errorLabel.html(optionFieldError);
	    			 preventDefault = true;
	    		 }
	    	 }
    	 });
    	 if(preventDefault) e.preventDefault();
    	 if($("#dtmenabled").val()=="false")
    		 {
		 /** Omniture tracking R4.2 -- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'Save My Interests';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2 -- END **/
    		 }
     });
     if($("#dtmenabled").val()=="false")
    	 {
   //Save subscrioption prefernces check for omniture tracking
     $("#save-subscriptions").click(function(e){
    	 var emailOption = $("#subscriptionInfo_emailcheckbox").is(':checked');
    	 var textOption = $("#subscriptionInfo_textcheckbox").is(':checked');

    	 if ($.trim(emailOption) == 'true' && $.trim(textOption) == 'true' ) {
				/** Omniture tracking R4.2 -- START **/
				s.linkTrackVars='eVar70,prop49,eVar7,events';
				s.linkTrackEvents='event95,event96';
				s.events='event95,event96';
				s.eVar7 = 'Email Opt In And Text Opt In';
				var linkname=s.eVar70=s.prop49=s.pageName +' '+'Save My Subscriptions';
				s.tl($(this), 'o', linkname);
				/** Omniture tracking R4.2 -- END **/
    	 }else if ($.trim(emailOption) == 'true' ) {
				/** Omniture tracking R4.2-- START **/
				s.linkTrackVars='eVar70,prop49,eVar7,events';
				s.linkTrackEvents='event95';
				s.events='event95';
				s.eVar7 = 'Email Opt In';
			var linkname=s.eVar70=s.prop49=s.pageName +' '+'Save My Subscriptions Link';
				s.tl($(this), 'o', linkname);
				/** Omniture tracking R4.2-- END **/
    	 }else if ($.trim(textOption) == 'true') {
				/** Omniture tracking R4.2-- START **/
    		 s.linkTrackVars='eVar70,prop49,eVar7,events';
				s.linkTrackEvents='event96';
				s.events='event96';
				s.eVar7 = 'Text Opt In';
				var linkname=s.eVar70=s.prop49=s.pageName +' '+'Save My Subscriptions Link';
				s.tl($(this), 'o', linkname);

				/** Omniture tracking R4.2 -- END **/
    	 }

     });
     //ManageMyInterests link tracking for omniture.
     $("#interestsUrl").click(function(e){
    	 /** Omniture tracking R4.2-- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'Manage My Interests Link';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2-- END **/

     });
   //EditEamilLink tracking for omniture.
     $("#editEamilLink").click(function(e){
    	 /** Omniture tracking R4.2-- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'Edit Email Link';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2-- END **/

     });
     //EditPhoneLink tracking for omniture.
     $("#editPhoneLink").click(function(e){
    	 /** Omniture tracking R4.2 -- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'Edit Text Phone Link';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2-- END **/

     });
	 //Landing page phone type tracking for omniture
     /*	$("#floodLightSubmit").click(function() {

		s.linkTrackVars='eVar70,prop49,events';
		s.linkTrackEvents='event75';
		s.events='event75';
    var linkname=s.eVar70=s.prop49=s.pageName +' '+'SUBMIT link';
		s.tl($(this), 'o', linkname);

	});
	*/
		/** Omniture tracking R4.2 -- END **/
	 //Landing page clear button tracking for omniture
		$("#clearFields").click(function() {
		 /** Omniture tracking R4.2-- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'Clear Fields';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2-- END **/
	});
	//Edit Email address link in My Account page tracking for omniture
		$("#edit-email-toggle").click(function() {
		 /** Omniture tracking R4.2-- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'Edit Email Address link';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2-- END **/
	});
	// Communication elsewhere link tracking for omniture.
			 $("a.addedBrand").click(function(e){
			    var linktext = $(this).text();
		    	 /** Omniture tracking R4.2-- START **/
		 		s.linkTrackVars='eVar7,eVar70,prop49,events';
		 		s.linkTrackEvents='event75';
		 		s.events='event75';
		        var linkname=s.eVar7=s.eVar70=s.prop49=s.pageName +' '+linktext+' '+'Communitation Elsewhere Link';
		 		s.tl($(this), 'o', linkname);
		 		/** Omniture tracking R4.2-- END **/

	});
	//Create Account Overlay landing page tracking for omniture
		$("#createAccountLink").click(function() {
		 /** Omniture tracking R4.2-- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'E-Club Footer TY Overlay Create Account link';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2-- END **/
	});
	//Already subscribed Overlay landing page tracking for omniture
		$("#alreadySubscribedLink").click(function() {
		 /** Omniture tracking R4.2-- START **/
 		s.linkTrackVars='eVar70,prop49,events';
 		s.linkTrackEvents='event75';
 		s.events='event75';
        var linkname=s.eVar70=s.prop49=s.pageName +' '+'E-Club Footer TY Overlay Already Subscribed link';
 		s.tl($(this), 'o', linkname);
 		/** Omniture tracking R4.2-- END **/
	});

     function yesmailOmniture() {
         // Yes Mail Message ID
         s.eVar68 = s.getQueryParam('YM_MID');
         s.eVar68 = s.getValOnce(s.eVar68,'s_var_68',0);
         // Yes Mail Recipient ID
         s.eVar67 = s.getQueryParam('YM_RID');
         s.eVar67 = s.getValOnce(s.eVar67,'s_var_67',0);
     }
     $(yesmailOmniture);
   }
     // This function is to highlight the selection in selectboxes.
     $(document).on("change", ".styled-select select, .styled-select-red select", function() {
    	var selectedOption = $(this).find(":selected").text();
    	$(this).next(".holder").text(selectedOption);

    });
     
     /* Refer a Friend starts*/

    	/**
    	 * To show n number of referral section at load time.
    	 */
    	if (location.pathname
    			.indexOf("/customer-service/refer-a-friend") != -1) {
    		var numOfReferees = $("#numOfReferees").val();
    		var maxNumOfReferees = $("#maxNumOfReferees").val();
    		loadReferees(numOfReferees, maxNumOfReferees);
    	}
    	function loadReferees(numOfReferees, maxNumOfReferees, rafModal) {
    		for (var i = numOfReferees ; i > 0; i--) {
    			if(rafModal == undefined) {
    				$("#frnd"+i).css({display : "block"});
    				$("#ref-mail"+i+"-frind-name").removeAttr("disabled");
    				$("#ref-mail"+i+"-frind-l-name").removeAttr("disabled");
    				$("#ref-mail"+i+"-f-mail").removeAttr("disabled");
    				$("#ref-mail"+i+"-subject").removeAttr("disabled");
    				$("#ref-mail-desc-"+i).removeAttr("disabled");
    				$("#border-"+i).css({"display":"block","border-top":"0","padding-top":"0"});
    			} else {
    				rafModal.find("#frnd"+i).css({display : "block"});
    				rafModal.find("#ref-mail"+i+"-frind-name").removeAttr("disabled");
    				rafModal.find("#ref-mail"+i+"-frind-l-name").removeAttr("disabled");
    				rafModal.find("#ref-mail"+i+"-f-mail").removeAttr("disabled");
    				rafModal.find("#ref-mail"+i+"-subject").removeAttr("disabled");
    				rafModal.find("#ref-mail-desc-"+i).removeAttr("disabled");
    				rafModal.find("#border-"+i).css({"display":"block","border-top":"0","padding-top":"0"});
    			}
    		}
    		if (numOfReferees == maxNumOfReferees) {
    			if(rafModal == undefined){
    				$(".add-frnd-sec").hide();
    			}else {
    				rafModal.find(".add-frnd-sec").hide();
    			}
    		}
    	}


    	/**
    	 * Ajax call for RAF to show the overlay.
    	 */
    	$(document).on("click", "a[id*='referafriend']", function() {
    		var inputObj = $(this);
    		var myModalURL = inputObj.attr('data-modal-url');
    		$.get(myModalURL , function(overlayHTML){
    			successReferAFriend(overlayHTML)
    		});
    	});

    	/**
    	 * Success call back for RAF.
    	 */
    	function successReferAFriend(overlayHTML){
    		var rafModal =$(overlayHTML).filter("#refModal");
    		$('#myModal').modal('hide');
    		rafModal.modal();
    		var numOfReferees = rafModal.find("#numOfReferees").val();
    		var maxNumOfReferees = rafModal.find("#maxNumOfReferees").val();
    		loadReferees(numOfReferees, maxNumOfReferees, rafModal);
    	}

    	/**
    	 * Ajax call for RAF form submission.
    	 */
    	$(document).on("click", "#raf_button", function() {
    		if (location.pathname
    				.indexOf("/customer-service/refer-a-friend") == -1) {
    			var numOfReferees = $("#totalFriends").val();
    		}
    		else {
        		var numOfReferees = $("#numOfReferees").val();
    		}
    		var isPrepopulated = $("#isPrepopulated").val();
    		var n = numOfReferees;
    		for (var i=1;i<=n;i++) {
    			var isEmpty = true;
    			var fName = $("#ref-mail"+i+"-frind-name").val();
    			var lName = $("#ref-mail"+i+"-frind-l-name").val();
    			var email = $("#ref-mail"+i+"-f-mail").val();
    			var subject = $("#ref-mail"+i+"-subject").val();
    			var body = $("#ref-mail-desc-"+i).val();
    			if(fName != "" || lName!="" || email != "" || (isPrepopulated == "false" && subject!="")
    					|| (isPrepopulated == "false" && body !="")){
    				isEmpty = false;
    			}
    			$("#ref-mail"+i+"-frind-name").attr("name", "raf_f_"+i+"_firstName");
      			$("#ref-mail"+i+"-f-mail").attr("name", "raf_f_"+i+"_email");
      			$("#ref-mail"+i+"-subject").attr("name", "raf_f_"+i+"_subject");
    			if (isEmpty) {
    				$("#ref-mail"+i+"-frind-name").removeAttr("name");
    				$("#ref-mail"+i+"-f-mail").removeAttr("name");
    				$("#ref-mail"+i+"-subject").removeAttr("name");
    				$("#ref-mail-desc-"+i).removeAttr("name");
    				numOfReferees = numOfReferees-1;
    			}
    		}

    		if (location.pathname
    				.indexOf("/customer-service/refer-a-friend") == -1) {
    			$("#successURL").val($("#overlaySuccessURL").val());
    			$("#errorURL").val($("#overlayErrorURL").val());
    			doAJAXEnableInputs($(this), null, successReferFriend);

    		}
    		else {
    			var form = $(this).closest("form");
    			$("#successURL").val($("#pageSuccessURL").val());
    			$("#errorURL").val($("#pageErrorURL").val());
    			form.submit();
    		}
    	});

    	/**
    	 * Success callback method for RAF Form Submission.
    	 */
    	function successReferFriend(response, form) {
    		var errorDiv = $(response).find("#error_raf");
    		form.find("#error_raf").html(errorDiv.html());
    		if (!$.trim((errorDiv.html()))) {
    			//if no form errors show overlay
    			$("#error_raf").empty();
    			$('#refModal').modal('hide');
    			var modalDiv = $(response).filter("#refThankYouModal");
    			modalDiv.modal();
    		}
    		//Scroll to error div when form error occurs.
    		else {
    			scrolloverlay($("#error_raf"));
    		}
    	}



    	/**
    	 * To add more friend's in RAF by clicking (+ADD FRIEND).
    	 */
    	$(document).on("click", "a[id*='addFrnd']", function(e) {
    		e.preventDefault();

    		var numOfReferees = $("#numOfReferees").val();
    		var refereesToAdd = $("#refereesToAdd").val();
    		var maxNumOfReferees = $("#maxNumOfReferees").val();
    		var toalReferees = parseInt(numOfReferees) + parseInt(refereesToAdd);
    		for (var i=toalReferees;i>0;i--) {
    			document.getElementById("frnd"+i).style.display = "block";
    			$("#ref-mail"+i+"-frind-name").removeAttr("disabled");
    			$("#ref-mail"+i+"-frind-l-name").removeAttr("disabled");
    			$("#ref-mail"+i+"-f-mail").removeAttr("disabled");
    			$("#ref-mail"+i+"-subject").removeAttr("disabled");
    			$("#ref-mail-desc-"+i).removeAttr("disabled");
    			$("#border-"+i).css({"display":"block","border-top":"0","padding-top":"0"});
    		}
    		$("#numOfReferees").val(toalReferees);
    		$("#totalFriends").val(toalReferees);
    		if(toalReferees == maxNumOfReferees) {
    			$(".add-frnd-sec").hide();
    		}
    	});

    	/**
    	 * Profanity check in RAF
    	 */
    	$(document).on('keyup',"textarea[id*='ref-mail-desc-']", function(e){
    		if(e.keyCode ==32 || e.keyCode ==13 || e.keyCode ==39 || e.keyCode ==37){
    			var str = $(this).val();
    			var newString = str.replace(/[^a-zA-Z0-9 ]/g, " ");
    			var strList = newString.split(" ");
    			var badWords = $("#badwords").val();
    			var badWordList = badWords.split(",");
    			for (var i = 0; i < badWordList.length; i++) {
    				for (var j = 0; j < strList.length; j++) {
    					if(strList[j].toLowerCase() == badWordList[i]) {
    						$(this).val(str.replace(strList[j],repeat("*" , strList[j].length)));
    					}
    				}
    			}
    		}
    	});

    	/**
    	 * To repeat a string n number of times.
    	 */
    	function repeat(str, n) {
    		var repeatedStr="";
    		for (var a=0;a<n;a++) repeatedStr+=str;
    		return repeatedStr;
    	}
    	
    	/**
    	 * eClub success event call
    	 */
    	var eclubFlag = $('#eClubFlagID').val();  
 	    if(eclubFlag== 'true'){  
 	    dtmEvent("eclubComplete","eclub");
 	    }

    	/**
    	 * Clear datafields in RAF
    	 */
    	$(document).on("click", "button[id*='clear-raf-']", function() {
    		var isEditSubject = $("#isEditSubject").val();
    		var isEditComment = $("#isEditComment").val();
    		var inputObj = $(this);
    		var frndId = inputObj.attr("data-id");
    		if (isEditSubject == "true") {
    			$("#ref-mail"+frndId+"-subject").val("");
    		}
    		$("#ref-mail"+frndId+"-frind-name").val("");
    		$("#ref-mail"+frndId+"-frind-l-name").val("")
    		$("#ref-mail"+frndId+"-f-mail").val("");
    		if (isEditComment == "true") {
    			$("#ref-mail-desc-"+frndId).val("");
    		}
    	});

    	/* Refer a Friend ends*/
    /**
     * Viewing order details in orde confirmation page.
     */
    	$(document).on("click", "#lookUpOrder", function() {
        	$("#lookUpOrder").removeAttr('href');
            var form = $(this).closest("form");
            form.submit();
        });

 	/* START of omniture tagging for  MORE MENU  */
 	$(document).on("click", '#moreMenuIcon,#moreMenu', function() {
 		var Language = $("#language").val();
 		var Brand = $("#brand").val();
 		var linkval = $("#linkval").val();
 		omnitureTaggingFun(Brand,Language,'MoreMenu',linkval);
 	});
	$(".modal").focus();
 	/* END of  omniture tagging for MORE MENU   */
	
 	});


if ($("#eventLogin").length > 0) {
	var loggedin = $("#eventLogin").attr('data-logstatus');
	if(loggedin == 'true') {
		if($("#dtmenabled").val()=="false") { //dtm flag start
		s.linkTrackVars='eVar9';
		s.eVar9= 'Logged In';
		} //dtm flag end
	}
}

$(document).ready(
		function() {
			var loggedin = $("#eventLogin").attr('data-logstatus');
			if ((loggedin!="") && $("#doubleLine")) {
				$("#doubleLine").remove();
			}
		});
/**
 * omniture event for trackeing succesfully logged in user
 *
 * removed duplicate code
 */
/*if ($("#security_status").length > 0) {
	var loggedin=$("#security_status").val();

		s.linkTrackVars='eVar9,prop7';
		if(loggedin == '2' || loggedin == '3' || loggedin == '4' || loggedin == '5') {
			s.eVar9=s.prop7 = 'Logged In';
			var checkEvent=s.events;
			if(window.location.href.indexOf("requestid")>-1 && window.location.href.indexOf("giftcard")>-1){
			if(checkEvent){
				if(checkEvent.indexOf("event8") == -1){
				s.linkTrackEvents='event8';
				s.events = "event8";
			}
			}else{
				s.linkTrackEvents='event8';
				s.events = "event8";
		}
}

			s.tl($(this), 'o',  s.pageName);
		}else{
			s.eVar9=s.prop7 = 'Not Logged In';
		}
}*/
/**************start of code change for magic ticket 469098273 and 469098289****************/
/*$(function(){
	$("#offers").parent(".checkbox_d").click(function () {
	s.linkTrackVars='eVar7,eVar10,events';
	s.eVar10= 'Eclub';
	s.eVar7 = 'Global opt-in';
	s.tl($(this), 'o', 'Eclub Step1 SignUp');
	});

});*/
/***************end of code change for magic ticket 469098273 and 469098289 ****************/

/*START of omniture tagging **/
function omnitureTaggingFun(brand,language,linkName,linkType) {
	var pageURL = window.location+"";
	var parts=pageURL.split("/");
	var str=parts[parts.length-1];
	var end=str.lastIndexOf("#");
	if(end>=0){str=str.substring(0,end);}
	end=str.lastIndexOf("?");
	if(end>=0){str=str.substring(0,end);}
	var x=brand+"  |  "+language+"  |  "+str+"  :  "+linkName+" "+linkType;
		if(linkName!='MENUS' && linkName!='SPECIALS' && linkName!='Especiales' && linkName!='CONTACT US')
		{
			if($("#dtmenabled").val()=="false") { //dtm flag start
			s.linkTrackVars='events,eVar70,prop49';
			s.linkTrackEvents='event75';
			s.events='event75';
			var linkname=s.eVar70=s.prop49=x;
			s.tl($(this), 'o', linkname);
			}//dtm flag end
		}
}
/* END of  omniture tagging*/

/*START of webahead changes **/

$(document).ready(function(){
	$('.webahead').children('img').attr('style','display:none');
    	$('#webahead').attr('style','top: 50%;bottom: 50%; width: 380px; position: fixed; padding-left:4px; transform: translate(-50%, -50%);');
	$('#webahead').children('button.close').attr('style','margin-right:5px !important; right:0em !important; top:0em !important');
	$('#webahead').children('button').click(function() {
		document.getElementById('framwebahead').src = "about:blank";
});
if (location.pathname.indexOf('/locations/') != -1)
		{
		var isJoinWaitlist = getUrlParameter('joinwaitlist');
		var sid= getUrlParameter('SID');
			if (isJoinWaitlist == 'true')
			{
				var url = $('#webaheadURL').attr('value');
				if ($('#newlocations').attr('value') != null
					&& $('#newlocations').attr('value') != undefined){
						if ($('#newlocations').attr('value') == 'ALL') {
							if ($('#newwebaheadURL').attr('value') != null
								&& $('#newwebaheadURL').attr('value') != undefined){
								var restNum= getUrlParameter('restNum');
								var newurl = $('#newwebaheadURL').attr('value')+"&sid="+sid;
								url = newurl;
							}
						}else if ($('#newlocations').attr('value') == 'NONE') {
							url=url+"&SID="+sid;
						}
						else {
							if ($('#newwebaheadURL').attr('value') != null
								&& $('#newwebaheadURL').attr('value') != undefined){
								var restNum= getUrlParameter('restNum');
								var splitNewLocations = $('#newlocations').attr('value').split("|");
								var useNewUrl = false;
								for(i = 0; i < splitNewLocations.length; i++)
							   {
								  if (splitNewLocations[i] ==restNum ){
									useNewUrl = true;
								  }
							   }
							   if(useNewUrl){
									url = $('#newwebaheadURL').attr('value')+"&sid="+sid;
								} else {
									url=url+"&SID="+sid;
								}
							}
						}
					}
					document.getElementById('framwebahead').src = url;
					$('#webahead').toggleClass("hide");
			}
			$('#webahead').children('button.close').click(function () {
				$('#webahead').toggleClass("hide");
			}
			);
			if (location.pathname.indexOf("/menu-listing/dinner") != -1) {
				if (location.hash.indexOf("#soups-salads") != -1) {
					$('<img src="//pixel.mathtag.com/event/img?mt_id=627356&mt_adid=132197&v1=Equity&v2=&v3=&s1=E1&s2=&s3=" width="1" height="1" />').insertAfter( "input#media" );
				} else if (location.hash.indexOf("#cucina-mia") != -1) {
					$('<img src="//pixel.mathtag.com/event/img?mt_id=627356&mt_adid=132197&v1=Equity&v2=&v3=&s1=E1&s2=&s3=" width="1" height="1" />').insertAfter( "input#media" );
				}
				} else if (location.pathname.indexOf("/menu-listing/pronto-lunch") != -1) {
					if (location.hash.indexOf("#lighter-italian-fare") != -1) {
					$('<img src="//pixel.mathtag.com/event/img?mt_id=627356&mt_adid=132197&v1=Equity&v2=&v3=&s1=E1&s2=&s3=" width="1" height="1" />').insertAfter( "input#media" );
				}
			}
		}
});

function getUrlParameter(sParam)
{
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}

function getUrlParameterFromUrl(sUrl, sParam)
{
    /*var sUrl = sParam.search.substring(1);
    var sURLVariables = sPageURL.split('&');*/
    var sURLVariables = sUrl.split('&');
    for (var i = 0; i < sURLVariables.length; i++)
    {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam)
        {
            return sParameterName[1];
        }
    }
}
if($("#dtmenabled").val()=="false")
	{

$(window).on('load', function() {
			if ($("#security_status").length > 0) {
				var loggedin=$("#security_status").val();
				if($("#brand").val()=="OG"){
					if($("#dtmenabled").val()=="false") { //dtm flag start
					if(loggedin < 5){
						if((location.pathname.indexOf("/home") == 0)||(location.pathname.indexOf("/es/pagina-de-inicio") == 0))
						{
							s.eVar9=s.prop7 = 'Logged In';
						}
					}
					else{
						s.linkTrackVars='eVar9,prop7';
						if(loggedin == '2' || loggedin == '3' || loggedin == '4' || loggedin == '5') {
							s.eVar9=s.prop7 = 'Logged In';
							if(window.location.href.indexOf("requestid")>-1){
								s.linkTrackEvents='event8';
								s.events = "event8";
							}
							s.tl($(this), 'o',  s.pageName);
						}else{
							s.eVar9=s.prop7 = 'Not Logged In';
						}
					}
				}//dtm flag end
				}
			}
		});
	}

function urlchange(url)
	{
		if (location.pathname.indexOf('/fl/winter-park/winter-park-village/1275') != -1) {
			document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=38e07a9fc5064212a16b086d9f283b57";

		}
		if ($('#newlocations').attr('value') != null
			&& $('#newlocations').attr('value') != undefined){
				if ($('#newlocations').attr('value') == 'ALL') {
					if ($('#newwebaheadURL').attr('value') != null
						&& $('#newwebaheadURL').attr('value') != undefined){
						var sid= getUrlParameterFromUrl(url,'sid');
						var restNum=  getUrlParameterFromUrl(url,'restNum');
						var newurl = $('#newwebaheadURL').attr('value')+"&sid="+sid;
						url = newurl;
					}
				}else if ($('#newlocations').attr('value') == 'NONE') {
					url=url.slice(0,url.length-13);
				}else {
					if ($('#newwebaheadURL').attr('value') != null
						&& $('#newwebaheadURL').attr('value') != undefined){
						var restNum= getUrlParameterFromUrl(url,'restNum');
						var splitNewLocations = $('#newlocations').attr('value').split("|");
						var useNewUrl = false;
						for(i = 0; i < splitNewLocations.length; i++)
					   {
						  if (splitNewLocations[i] ==restNum ){
							useNewUrl = true;
						  }
					   }
					   if(useNewUrl){
							var sid= getUrlParameterFromUrl(url,'sid');
							url = $('#newwebaheadURL').attr('value')+"&sid="+sid;
						} else{
							url=url.slice(0,url.length-13);
						}
					}
				}
			}

		document.getElementById('framwebahead').src = url;
		if (location.pathname.indexOf('/locations/fl/') != -1) {
			if (location.pathname.indexOf('/1275') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=38e07a9fc5064212a16b086d9f283b57";
			}
			if (location.pathname.indexOf('/1181') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=af784c507a3f489f9fd3337a42c540e0";
			}
			if (location.pathname.indexOf('/1526') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=acbcbdcb4a5a459897a4d6e56539d6f0";
			}
			if (location.pathname.indexOf('/1614') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=3ae8c08d26e94d2a9d4ee70b3dca8cd9";
			}
			if (location.pathname.indexOf('/1702') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=a4aa41bba25543b78297bc5028490f51";
			}
			if (location.pathname.indexOf('/1002') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=66f8cfe799084d649dba59306f12c986";
			}
			if (location.pathname.indexOf('/1175') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=aeeb05c2a87844d3b7ee962ce48aa6be";
			}
			if (location.pathname.indexOf('/1547') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=01da87419a6f42be8b0ea8098ddde5d1";
			}
			if (location.pathname.indexOf('/1082') != -1) {
				document.getElementById('framwebahead').src = $('#newwebaheadURL').attr('value')+"&sid=3c0af129c5f6441fa05a07d6220d04ad";
			}
		}
	}

//Recent Activity and Order History changes
var gcAccords = $("a[id*='order-history-collapse-plus']");
if(typeof gcAccords[0] !== 'undefined'){
  $.each(gcAccords, function() {
	    $(this).attr("title", "expand");
	});
}

//Recent Activity and Order History changes
$(document).on("click", "a[id*='order-history-collapse']", function() {
	var inputObj = $(this);
	var orderId = inputObj.attr("data-id");
	var url = inputObj.attr('data-url');
	//added for  INC17342
	var checksum = inputObj.attr('data-checksum');
	if($("#order-details-"+orderId).length == 0) {
		request = $.ajax({
			url: url,
			type: "post",
			data: "orderId=" + orderId + "&checksum=" + checksum
		});
	    request.done(function (response, textStatus, jqXHR){

	    	$("#detailsContent"+orderId).html(response);
	    	$("#detailsContent"+orderId). css ('height','auto');
	    });
	}
    $(this).toggleClass("collapsed");
    var elementID = $(this).attr("id")
    if(elementID == "order-history-collapse-expand_link"+orderId || elementID == "order-history-collapse-click"+orderId ){
		$("#order-history-collapse-plus"+orderId).toggleClass("collapsed");
	}
    if($("#order-history-collapse-plus"+orderId).hasClass("collapsed")){
		$("#order-history-collapse-plus"+orderId).attr("title", "collapse");
	}else{
		$("#order-history-collapse-plus"+orderId).attr("title", "expand");
	}
	$(this).parents('.row').siblings(".gc_order_statuscontent").toggle();

});
/** END of webahead changes **/

		 /**
	  * Omniture tracking on refer-a-friend Page
	  */
		 if (location.pathname
	 			.indexOf("/customer-service/refer-a-friend-thank-you") != -1) {
			 if($("#dtmenabled").val()=="false") { //dtm flag start
	 	s.events = "event38";
		s.pageName = 'Refer a Friend Completed';
			 } //dtm flag end
	 }
/** END of webahead changes **/

// Change for Enhancement : Location update from sitemap - starts here [xsdamm1]
function setLocationCookie(locDetCookieVal){
	var locationCookie = $.cookie("DRIREST");
    var d = new Date();
    d.setTime(d.getTime() + (30*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
	if(locationCookie){
		$.cookie("DRIREST", null,{ expires: -1 });
		document.cookie = "DRIREST" + "=" + locDetCookieVal + "; " + expires + "; path=/";
	}
	else{

	    document.cookie = "DRIREST" + "=" + locDetCookieVal + "; " + expires + "; path=/";
	}


	//Following function call for Stability Fixes - Avinash [xsdaas1]
	setRestaurantIdCookie();
}

function setLocationHeader() {

	var locationCookie = $.cookie("DRIREST");

	if(locationCookie){
		locationCookie = locationCookie.replace(/\*/g,',');
		var locValues = locationCookie.split("@@");
		if(locValues.length > 0){
			// /state/city/restname/restnum
			var locURL = $('#locationURL').val()+"/"+locValues[5]+"/"+locValues[4]+"/"+locValues[1]+"/"+locValues[11];
			locURL = locURL.replace(/[^a-zA-Z0-9/]/g,'-');
			locURL = locURL.toLowerCase();
			/*Changes made for Multiple Hyphens Issue -Sai Priyanka */
			locURL=locURL.replace(/-{2,}/g, '-');

			// add links to location details
			$('#popRestNameLink').attr("href",locURL);
			$('#popRestHrsLink').attr("href",locURL);
			$('#popDirIconLink').attr("href",locURL);
			$('#popDirLink').attr("href",locURL);
			$('#popMapLink').attr("href",locURL);

			// set Rest_ID from cookie for SMS and Email
			$('#sms-current').attr("data-id",locValues[0]);
			$('#email-current').attr("data-id",locValues[0]);

			// lat_long
			var mapImg ="//media.olivegarden.com/en_us/images/marketing/italian-family-restaurant-olive-garden-g6-r1x1.jpg";
			$("#mapImg").attr("src",mapImg);

			$('#latLong_header').val(locValues[2]);
			// rest name
			$('#headRestName').text(locValues[1]);
			$('#popRestName').text(locValues[1]);
			$('#overlayRestName').text(locValues[1]);
			$('#headRestName').text(locValues[1]);
			// rest phone number
			$('#headRestPhone').text(locValues[7]);
			$('#popRestPhone').text(locValues[7]);
			// rest address
			$('#popRestAdd1').text(locValues[3]);
			$('#popRestCity').text(locValues[4]);
			$('#popRestState').text(locValues[5]);
			$('#popRestZip').text(locValues[6]);
			// rest Op hours
			$('#popRestHrs').html(locValues[8]);
			// link to nutrition page
			// $('#popNutritionIconLink').attr("href", "/nutrition");
			// $('#popNutritionLink').attr("href", "/nutrition");
			$('span#findRestaurantLink').hide();
			$('span#selected-location').show();
			var welcomeConfigValue = $('#welcomeConfigValue').val();
			var pageURL = window.location+"";
			if((pageURL.indexOf('/home') > -1 || pageURL.indexOf('/pagina-de-inicio') > -1) && locValues[10] == 'auto'){
				$("div#pop-up").show();
			    setTimeout('$("div#pop-up").hide()', parseInt(welcomeConfigValue));
			    var oldCookieVal = $.cookie("DRIREST");
			    oldCookieVal = oldCookieVal.replace(/(auto)/g, '~');
			    $.cookie("DRIREST", oldCookieVal, {expires: 365, path: "/"});
			}
			//showJoinWaitListDetails();
		}
	}

}
// Change for Enhancement : Location update from sitemap - ends here [xsdamm1]
//Following function added for Stability Fixes - Avinash [xsdaas1]
function setRestaurantIdCookie(){
	var restIdCookie = $.cookie("DRIRESTAURANTID");
	var locnCookie = $.cookie("DRIREST");
	var restId='';
	if(locnCookie){
		locnCookie = locnCookie.replace(/\*/g,',');
		var locValues = locnCookie.split("@@");
		restId = locValues[11];
	}

    var d = new Date();
    d.setTime(d.getTime() + (30*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
	if(restIdCookie){
		$.cookie("DRIRESTAURANTID", null,{ expires: -1 });
		document.cookie = "DRIRESTAURANTID" + "=" + restId + "; " + expires + "; path=/";
	}
	else{

	    document.cookie = "DRIRESTAURANTID" + "=" + restId + "; " + expires + "; path=/";
	}
}
//added by smitha for webahead changes
function showJoinWaitListDetails(){
	//waitListInfo
	var url = "/customer-service/includes/location-webahead-info.jsp";
	var dataPageURL = location.pathname;
	var data={};
	if (window.location.protocol == "https:") {
		url = $("#ajaxServletURL").val();
		data.AJAX_FUNCTION = "locationWebaheadinfo";
	}
	$.ajaxSetup({
		cache : false
	});
	if ($("#joinWaitListDetails").length > 0) {
		var join_wait_list_details = $("#joinWaitListDetails");
		data.dataPageURL = dataPageURL;
		$.get(url, data,  function(response) {
			join_wait_list_details.html($(response).filter('#waitListInfo').html());
		});
	}

}

	/**
	  * Omniture tracking on refer-a-friend Page
	  */
		 if (location.pathname
	 			.indexOf("/customer-service/refer-a-friend-thank-you") != -1) {
			 if($("#dtmenabled").val()=="false") { //dtm flag start
	 	s.events = "event38";
		s.pageName = 'Refer a Friend Completed';
			 }//dtm flag end
	 }

if($("#dtmenabled").val()=="false")
{
	/**
	  * Omniture tracking on tell-us-more Page && create-your-own-tour-sign-up && landing-page && olive-garden-facebook-eclub
	  */
	  if ((location.href.indexOf('/customer-service/landing-page')>-1) || (location.href.indexOf('/customer-service/join/olive-garden-facebook-eclub')>-1) || (location.href.indexOf('/customer-service/join/create-your-own-tour-sign-up')>-1) || (location.href.indexOf('/customer-service/tell-us-more')>-1)
		  || (location.href.indexOf('/customer-service/join/coca-cola-eclub-referral')>-1) || (location.href.indexOf('/customer-service/join/olive-garden-sams-club-sign-up')>-1)){
		s.linkTrackVars='eVar7,events,eVar10';
		if(location.href.indexOf('customer-service/join/ziosk-eclub-signup')>-1 && location.href.indexOf('showConfirmation')>-1){
			s.linkTrackEvents="event7";
			s.events="event7";
			s.pageName = 'ziosk-eclub';
		}
		if(location.href.indexOf('customer-service/tell-us-more')>-1 && location.href.indexOf('showConfirmation')>-1){
			s.linkTrackEvents="event7";
			s.events="event7";
			s.pageName = 'landing-page';
		}
		if(location.href.indexOf('customer-service/tell-us-more')>-1 && location.href.indexOf('showConfirmation')==-1){
			s.linkTrackEvents="event3";
			s.events="event3";
			s.pageName = 'tell-us-more';
		}
		if(location.href.indexOf('customer-service/join/create-your-own-tour-sign-up')>-1 && location.href.indexOf('showConfirmation')>-1){
			s.linkTrackEvents="event7";
			s.events="event7";
			s.pageName = 'create-your-own-tour-sign-up';
		}
		if(location.href.indexOf('customer-service/join/create-your-own-tour-sign-up')>-1 && location.href.indexOf('showConfirmation')==-1){
			s.linkTrackEvents="event3";
			s.events="event3";
			s.pageName = 'create-your-own-tour-sign-up';
		}
		if(location.href.indexOf('customer-service/join/olive-garden-facebook-eclub')>-1 && location.href.indexOf('showConfirmation')>-1){
			s.linkTrackEvents="event7";
			s.events="event7";
			s.pageName = 'landing-page';
		}
		if(location.href.indexOf('customer-service/join/olive-garden-facebook-eclub')>-1 && location.href.indexOf('showConfirmation')==-1){
			s.linkTrackEvents="event3";
			s.events="event3";
			s.pageName = 'tell-us-more';
		}
		if(location.href.indexOf('customer-service/join/coca-cola-eclub-referral')>-1 && location.href.indexOf('showConfirmation')>-1){
			s.linkTrackEvents="event7";
			s.events="event7";
			s.pageName = 'landing-page';
		}
		if(location.href.indexOf('customer-service/join/coca-cola-eclub-referral')>-1 && location.href.indexOf('showConfirmation')==-1){
			s.linkTrackEvents="event3";
			s.events="event3";
			s.pageName = 'tell-us-more';
		}
		if(location.href.indexOf('customer-service/join/olive-garden-sams-club-sign-up')>-1 && location.href.indexOf('showConfirmation')>-1){
			s.linkTrackEvents="event7";
			s.events="event7";
			s.pageName = 'landing-page';
		}
		if(location.href.indexOf('customer-service/join/olive-garden-sams-club-sign-up')>-1 && location.href.indexOf('showConfirmation')==-1){
			s.linkTrackEvents="event3";
			s.events="event3";
			s.pageName = 'tell-us-more';
		}
		//s.eVar7="Concept Opt-in";
		var opt=$('#primaryOptin_reg').find('#offers').attr('checked');
		if (opt=="checked")
		{
			s.eVar7="Concept Opt-in";
		}
		var opt=$('.checkbox_d').find('#inAdditionCheck').attr('checked');
		if (opt=="checked")
		{
			s.eVar7="Global Opt-in";
		}

		s.eVar10="EClub" + "-" + s.pageName +" option";
		//void(s.t());
	}

}
/**
*Wait list changes Start
*Added by Chander
* AJAX call to invoke join wait list step 1
*date modified: 12082015
 */


$(document).on("click", "#enterWaitListOnLoad", function(){
	if($("#dtmenabled").val()=="false")
		{
	//join wait list button from header
	$(this).prop("disabled", true);
	s.linkTrackVars='events,eVar70,prop49,eVar75,prop55';
	s.linkTrackEvents='event75,event97';
	s.linkType='lnk_o';
	s.events='event75,event97';
	s.pageName='og|us|en|WebAhead';
	s.prop55=$("#estimated_wait").val();
	s.eVar75=window.location.href;
	var linkname=s.eVar70=s.prop49=s.pageName + '|' + 'Join Wait List';
	s.tl($(this), 'o', linkname);
	//omniture ends
		}

/**
*Added by Sadanand For Fading off overlay
*date modified: 15082015
 */
$("#joinWaitListModal").modal('hide');
	$("#joinWaitListModal").remove();
/**
 * End of Comment
 */
	$(this).prop("disabled", true);
	var join_wait_list_url = $(this).attr('data-url');

	var base_wait_list_url = $(this).attr('base-url');

	/*var url=join_wait_list_url+"&base_wait_list_url="+base_wait_list_url;
	var restId = $(this).attr('data-restId');
	var data={};
	if (window.location.protocol == "https:") {
		//alert("window.location.protocol"+window.location.protocol);
		url = $("#ajaxServletURL").val();
		data.AJAX_FUNCTION = "joinwaitlist";
		data.restID= restId;
	}
	$.ajaxSetup({
		cache : false
	});
	*/
	if($("#dtmenabled").val()=="false")
		{
		 //ominture starts for join wait list load
			clearOmnitureVars();
		  s.linkTrackVars='events,eVar79,eVar75,eVar1,prop1';
			s.linkTrackEvents='event49,event98';
			s.events='event49,event98';
			s.pageName='og|us|en|WebAhead|Join Wait List';
			s.eVar79= $("#estimated_wait").val();
			s.eVar75=window.location.href;
			s.eVar1= s.prop1='WebAhead';
			var linkname=s.pageName;
			s.t($(this), 'o', linkname);
			//omniture ends
		}
	request = $.ajax({
		url:join_wait_list_url+"&base_wait_list_url="+base_wait_list_url,
		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
				"#joinWaitListModal");
		modalDiv.attr('style','top: 0% !important');
				  scrolloverlay_joinwaitlist(modalDiv);
		modalDiv.modal({backdrop: 'static', keyboard: false});
		var phoneTxt = modalDiv.find("#phone-ctn");
		if ( phoneTxt != undefined)	formatPhoneNumber2(phoneTxt);
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
});


$(document).on("click", "#enterWaitList", function(){
	if($("#dtmenabled").val()=="false")
		{
	//join wait list button from header
	var pagename=$(this).attr('omni_page_name');
	var linkText=$(this).text();
	$(this).prop("disabled", true);
	s.linkTrackVars='events,eVar70,prop49,eVar75,prop55';
	s.linkTrackEvents='event75,event97';
	s.linkType='lnk_o';
	s.events='event75,event97';
		var pagename_extra;
		var page=s.pageName;
	if(pagename=='joinwaitlist_headerpage')
		{
		s.pageName=page+'|'+linkText;
		pagename_extra='';
		}
	else if(pagename=='joinwaitlist_detailsoverlay')
		{
		pagename_extra='Location Details Overlay';
		s.pageName=page+' '+linkText;
		}
	else if(pagename=='joinwaitlist_locdetailspage')
		{
		pagename_extra='Location Details Page ';
		s.pageName=page+'|Location Details Page '+linkText;
		}
	else
		{
		s.pageName=page+' '+linkText;
		}

	s.prop55=$("#estimated_wait").val();
	s.eVar75=window.location.href;
	var linkname=s.eVar70=s.prop49=page + ' '+pagename_extra+''+ linkText+' link';

	s.tl($(this), 'o', linkname);
	//omniture ends
		}

/**
*Added by Sadanand For Fading off overlay
*date modified: 15082015
 */
$("#joinWaitListModal").modal('hide');
	$("#joinWaitListModal").remove();
	$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();
/**
 * End of Comment
 */
	$(this).prop("disabled", true);
	var join_wait_list_url = $(this).attr('data-url');

	var base_wait_list_url = $(this).attr('base-url');

	/*var url=join_wait_list_url+"&base_wait_list_url="+base_wait_list_url;
	var restId = $(this).attr('data-restId');
	var data={};
	if (window.location.protocol == "https:") {
		//alert("window.location.protocol"+window.location.protocol);
		url = $("#ajaxServletURL").val();
		data.AJAX_FUNCTION = "joinwaitlist";
		data.restID= restId;
	}
	$.ajaxSetup({
		cache : false
	});
	*/

	request = $.ajax({
		url:join_wait_list_url+"&base_wait_list_url="+base_wait_list_url,

		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {
		if($("#dtmenabled").val()=="false")
			{
		//ominture starts for join wait list load
			clearOmnitureVars();
		  s.linkTrackVars='events,eVar79,eVar75,eVar1,prop1';
			s.linkTrackEvents='event49,event98';
			s.events='event49,event98';
			var page_type= $("#enterWaitList").attr('page-name');
			var pgname='og|us|en|WebAhead';

				if(pagename=='joinwaitlist_headerpage')
				{
				pagename_extra='';
				}
				else if(pagename=='joinwaitlist_detailsoverlay')
				{
				pagename_extra='Location Details Overlay ';
				}
				else if(pagename=='joinwaitlist_locdetailspage')
				{
				pagename_extra='Location Details Page ';
				}
			s.pageName=pgname+'|'+pagename_extra+''+linkText;
			s.eVar79= $("#estimated_wait").val();
			s.eVar75=window.location.href;
			s.eVar1= s.prop1='WebAhead';
			var linkname=s.pageName;
			s.t($(this), 'o', linkname);
			//omniture ends
			}
		dtmEvent("waitlistStart","waitlist");
		var modalDiv = $($.parseHTML(response)).filter(
		 /* accessbilty sunil */
				"#joinWaitListModal").prepend("<button class='test' autofocus></button>");
		 /* accessbilty sunil */
		//optin checkbox hide changes end
		modalDiv.attr('style','top: 0% !important');
				  scrolloverlay_joinwaitlist(modalDiv);
				  var isTOGO = $('#TOGO').val();
				   if(isTOGO){
					$('body').addClass('join-wait-list-modal-open'); //Togo Refactring pages block scroll so We add custom class
				  }
		if(!$("#joinWaitListModal").length>0)
        {
		modalDiv.modal({backdrop: 'static', keyboard: false});
		//$(window).scrollTop(0);
		}else{$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				}
		var phoneTxt = modalDiv.find("#phone-ctn");
		if ( phoneTxt != undefined)	formatPhoneNumber2(phoneTxt);
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
	// Waitlist phase 2 JAN-19 Analytics change
	var waitlistDataModel = {
		"modalName": "joinWaitList",
		"modalContent": "waitlist form signup",
		"modalIntent": "form Submit"
	};          
	try {
		AU.dispatchEvent('AnalyticsEvent','ShowModal', waitlistDataModel);
	} catch(e) {
		Bugsnag.notifyException( new Error(e.message), e.title, waitlistDataModel, "error");
	}
});

/**
 * AJAX call to invoke waitlist Step2
 */
$(document).on("click", "#EnterWaitlistConfirmation", function() {
	$('#dobSelectMonth').val($('#dobMonth').val());
	$('#dobSelectDay').val($('#dobDay').val());
	$('#dobSelectYear').val($('#dobYear').val());
	var selectedPartySize = $('#partySize').val();
	var defaultPartySize = $('#restDefaultPartySize').val();
	if(selectedPartySize == null || selectedPartySize == "" || selectedPartySize == undefined) {
	    document.getElementById("partySize").value = defaultPartySize;
	}
	var form = $(this).closest("form");
	doAJAX($(this), null, waitListSuccessStep2Call);

	// preventing the page from being refreshed
	return false;
});


 /* Success callback method for waitlist step 2
 */
function waitListSuccessStep2Call(response,form, inputObj) {
	var errorDiv = $(response).find("#error_msg");

	form.find("#error_msg").html(errorDiv.html());

	if (!$.trim((errorDiv.html()))) {
		$("#error_msg").empty();
		$("#joinWaitListModal").remove();


		loadWaitList2(response);
	}else
	{		
		//WO38296 Decmonitor error code for Join wailist : Start
	    var decMonitorInput =$(response).filter("#DECMonitor");
	    form.append(decMonitorInput);
	    //WO38296 Decmonitor error code for Join wailist : End
		form.find("#error_msg").html(errorDiv.html());
		form.find("#error_msg").show();
		$('input:disabled').prop('disabled', false);
        $('button:disabled').prop('disabled', false);
}
}

function loadWaitList2(modalHTML) {
	if($("#joinWaitListModal"))
		{
		    $("#joinWaitListModal").modal('hide');
			$("#joinWaitListModal").remove();
			$('body').removeClass('modal-open');
			$('.modal-backdrop').remove();
		}
	var modalDiv;

	modalDiv = $(modalHTML).filter("#joinWaitListModal");
	if(modalDiv.html()==undefined)
	{
		modalDiv=$(modalHTML).filter("#switchLocationModal");
	}
	if($("#dtmenabled").val()=="false")
		{
	//omniture starts-for confirmation page load
	clearOmnitureVars();
	s.linkTrackVars='events,eVar79,eVar75,eVar81,eVar1,prop1';
	s.linkTrackEvents='event49,event99';
	s.events='event49,event99';

	if($("#page_confirm").val()=='editSuccess')
		{
		s.pageName='og|us|en|WebAhead|Edit Guests Confirmation';
		}
	else{
		s.pageName='og|us|en|WebAhead|Wait List Confirmation';
		}

	s.eVar79=$("#estimated_wait").val();
	s.eVar75= window.location.href;
	s.eVar81=$(modalHTML).find("#guest_size_val").val();
	s.eVar1= s.prop1='WebAhead';
	var linkname=s.pageName;
	s.t(true, 'o', linkname);
	//omniture ends
		}
	dtmEvent("waitlistComplete","waitlist");
	modalDiv.attr('style','top: 0% !important');
	scrolloverlay(modalDiv);
	modalDiv.modal({backdrop: 'static', keyboard: false});
    //$('input:disabled').prop('disabled', false);
	//$('button:disabled').prop('disabled', false);
    $(window).scrollTop(0);
}

/**
 * Common method for loading overlay for waitlist
 */
function loadWaitListOverlay(modalHTML) {

	var modalDiv = $(modalHTML).filter("#joinWaitListModal");
	modalDiv.attr('style','top: 0% !important');
	scrolloverlay(modalDiv);
	modalDiv.modal({backdrop: 'static', keyboard: false});

}

//email overlay changes
$(document).on("click", "#enterEmailWaitList", function(){
	if($(this).prop('disabled')) {
		return false;
	}
    var wait_list_email_url = $("#enterEmailWaitList").attr('data-url');

    request = $.ajax({
           url : wait_list_email_url,

           type : "post"
		   });
    request.done(function(response, textStatus, jqXHR) {
	    	if($("#joinWaitListModal"))
			{
				$("#joinWaitListModal").modal('hide');
				//$("#joinWaitListModal").remove();
			}
			if($("#joinWaitListStep1"))
	    	{
	    		//$("#joinWaitListStep1").modal('hide');
	    		$("#joinWaitListStep1").remove();
	    	}
			if($("#joinWaitListStep2"))
	    	{
	    		//$("#joinWaitListStep2").modal('hide');
	    		$("#joinWaitListStep2").remove();
	    	}
	    	if($("#joinWaitListStep3"))
	    	{
	    		//$("#joinWaitListStep3").modal('hide');
	    		$("#joinWaitListStep3").remove();
	    	}
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
           var modalDiv = $($.parseHTML(response)).filter(
                        "#joinWaitListStep2");

           if($("#dtmenabled").val()=="false")
        	   {
           //omniture starts- for confirm email page onload
           clearOmnitureVars();
           	s.linkTrackVars='events,eVar75,eVar1,prop1';
			s.linkTrackEvents='event49';
			s.events='event49';
			s.pageName='og|us|en|WebAhead|Send Via Email';
			s.eVar75=window.location.href;
			s.eVar1= s.prop1='WebAhead';
			var linkname=s.pageName;
			s.t($(this), 'o', linkname);
           //omniture ends
        	   }

           modalDiv.modal({backdrop: 'static', keyboard: false});
       	$(window).scrollTop(0);
    });

    // callback handler that will be called on failure
    request.fail(function(jqXHR, textStatus, errorThrown) {
           // log the error to the console
           console.error("The following error occured: " + textStatus,
                        errorThrown);
    });
});


/**
 * Send waitlist Information via email to user
 *
 */
$(document).on("click", "#emailWaitList", function() {
	if($(this).prop('disabled')) {
		return false;
	}

	var pattern = /^[a-zA-Z0-9\-_]+(\.[a-zA-Z0-9\-_]+)*@[a-z0-9]+(\-[a-z0-9]+)*(\.[a-z0-9]+(\-[a-z0-9]+)*)*\.[a-z]{2,4}$/;
	var emailcontent=document.getElementById('emailAddress').value;
    if (pattern.test(emailcontent)) {
    	doAJAX($(this), null, hideEmailBlock);
    	//$("input, button, a, span").prop("disabled", false);
    } else {
    	$('#error_message_email_waitlist').text($('#invalidemailaddr').val());
    	emailcontent="";
    }
	return false;
});


function hideEmailBlock(response, form) {
	$('#error_message_email_waitlist').text('');
	        if($("#joinWaitListStep1"))
	    	{
	    		//$("#joinWaitListStep1").modal('hide');
	    		$("#joinWaitListStep1").remove();
	    	}
			if($("#joinWaitListStep2"))
	    	{
	    		//$("#joinWaitListStep2").modal('hide');
	    		$("#joinWaitListStep2").remove();
	    	}
	    	if($("#joinWaitListStep3"))
	    	{
	    		//$("#joinWaitListStep3").modal('hide');
	    		$("#joinWaitListStep3").remove();
	    	}
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
			$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
	loadWaitListOverlay_email(response);
	/* $('#joinWaitListModal').modal({
	        show: 'true'
	    });*/
}
//waitlist email overlay display changes
function loadWaitListOverlay_email(modalHTML) {
	var modalDiv;
	modalDiv = $(modalHTML).filter("#joinWaitListModal");
	if(modalDiv.html()==undefined)
	{
		modalDiv=$(modalHTML).filter("#joinWaitListStep2");
	}
	modalDiv.attr('style','top: 0% !important');
	scrolloverlay(modalDiv);
	modalDiv.modal({backdrop: 'static', keyboard: false});

}

//send via phone changes
$(document).on("click", "#enterSmsWaitList", function(){
	if($(this).prop('disabled')) {
		return false;
	}
    var wait_list_sms_url = $("#enterSmsWaitList").attr('data-url');

    request = $.ajax({
           url : wait_list_sms_url,
           type : "post"
    });
    request.done(function(response, textStatus, jqXHR) {
		    	if($("#joinWaitListModal"))
				{
					$("#joinWaitListModal").modal('hide');
					//$("#joinWaitListModal").remove();
				}
				if($("#joinWaitListStep1"))
		    	{
		    		//$("#joinWaitListStep1").modal('hide');
		    		$("#joinWaitListStep1").remove();
		    	}
				if($("#joinWaitListStep2"))
		    	{
		    		//$("#joinWaitListStep2").modal('hide');
		    		$("#joinWaitListStep2").remove();
		    	}
		    	if($("#joinWaitListStep3"))
		    	{
		    		//$("#joinWaitListStep3").modal('hide');
		    		$("#joinWaitListStep3").remove();
		    	}
				if($("#removeWaitListModal"))
				{
					$("#removeWaitListModal").remove();
				}
           var modalDiv = $($.parseHTML(response)).filter(
                        "#joinWaitListStep3");
						  scrolloverlay(modalDiv);
						  if($("#dtmenabled").val()=="false")
							  {
						//omniture starts- for confirm text page onload
						  	clearOmnitureVars();
				           	s.linkTrackVars='events,eVar75,eVar1,prop1';
							s.linkTrackEvents='event49';
							s.events='event49';
							s.pageName='og|us|en|WebAhead|Send Via Text';
							s.eVar75=window.location.href;
							s.eVar1= s.prop1='WebAhead';
							var linkname=s.pageName;
							s.t($(this), 'o', linkname);
				        //omniture ends
							  }

           modalDiv.modal({backdrop: 'static', keyboard: false});
           $(window).scrollTop(0);
    });

    // callback handler that will be called on failure
    request.fail(function(jqXHR, textStatus, errorThrown) {
           // log the error to the console
           console.error("The following error occured: " + textStatus,
                        errorThrown);
    });
});



/**
* Send waitlist Information using SMS to user
*
*/
$(document).on("click", "#smsWaitList", function() {
    var phonenumber=document.getElementById('phone-ctn-waitlist').value;
    var phonenumberformatted;
    var len;
    if (phonenumber.length > 0) {
           var phonenumberformatted=phonenumber.replace(/\D/g, '');
    }
    if(phonenumberformatted== undefined)
    {
           len=0;
    }
    else
    {
           var len=phonenumberformatted.length;
    }
    if (len<=0) {
    $('#error_message_mobile_waitlist').text($('#invalidphone').val());
 }
 else if(len<10)
 {
    $('#error_message_mobile_waitlist').text($('#invalidphone').val());
 }
 else if (isNaN(phonenumberformatted)) {
    $('#error_message_mobile_waitlist').text($('#invalidphone').val());
 }
 else {
    doAJAX($(this), null, hideSmsBlock);
 }
    // preventing the page from being refreshed
    return false;
});
/**
* Send SMS Success call back function
*
*/
function hideSmsBlock(response, form) {
    $('#error_message_mobile_waitlist').text('');
	        if($("#joinWaitListStep1"))
	    	{
	    		//$("#joinWaitListStep1").modal('hide');
	    		$("#joinWaitListStep1").remove();
	    	}
			if($("#joinWaitListStep2"))
	    	{
	    		//$("#joinWaitListStep2").modal('hide');
	    		$("#joinWaitListStep2").remove();
	    	}
	    	if($("#joinWaitListStep3"))
	    	{
	    		//$("#joinWaitListStep3").modal('hide');
	    		$("#joinWaitListStep3").remove();
	    	}
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
			$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
	loadWaitListOverlay_sms(response);
}
//waitlist sms overlay display changes
function loadWaitListOverlay_sms(modalHTML) {
	var modalDiv;
	modalDiv = $(modalHTML).filter("#joinWaitListModal");
	if(modalDiv.html()==undefined)
	{
		modalDiv=$(modalHTML).filter("#joinWaitListStep3");
	}
	modalDiv.attr('style','top: 0% !important');
	scrolloverlay(modalDiv);
	modalDiv.modal({backdrop: 'static', keyboard: false});

}
/**
 * Allow only numbers for phone number field
 */
	$(document).on('keypress', '#phone-ctn-waitlist', function(e) {
		if (e.which > 31 && (e.which < 48 || e.which > 57)) {
			e.preventDefault();
		}
	});
/** Method for formatting phone number to (###) ###-#### format **/
$(document).on('keypress','#phone-ctn-waitlist', function(e)
	    {
	        var l=$(this).val().length;
	        var text = $(this).val();
	        var isNumber = (e.which > 47 && e.which < 58) || (e.which > 95 && e.which < 106);
	        if(isNumber) {
		        if (l<=4) {
		        	for(var i=0;i<=l;i++){

		        		var codeA = text.charCodeAt(i);
		        		if(codeA > 31 && (codeA < 48 || codeA > 57))
		        			{
		        			 $(this).val(text.replace(/(\d{3})\)?/g,'$1)'));
		        			 return true;
		        			}


		        	}
					/** alm 7526 change start  **/
		        	$(this).val(text.replace(/(\d{3})\)?/g,'($1) '));
		        	return true;
					/** alm 7526 change end **/
		        }
		        if (l==9){
		            $(this).val(text.replace(text, text +'-'));
		            return true;
		        }
	        }
	    });

/**
 * for redirection of close button in waitlist overlay
 */
 $(document).on("click", "#joinWaitListModal_overlayCloseButton_custom1", function() {

		$('input:disabled').prop('disabled', false);
 		$('button:disabled').prop('disabled', false);
 		$('body').removeClass('modal-open');
		$('.modal-backdrop').remove();

	var div=document.getElementById('waitlist-step1');
	var url=div.getAttribute("data-url");
	if(url == "null" ) url="" ;
	var name=div.getAttribute("data-name");
	if(name=='waitlist-step1')
		{
		  window.location.href =url;//un commented for the defect 25277
	}

	$(".inform-link #enterWaitList").prop('disabled', false);


});
$(document).on("click", "#joinWaitListModal_overlayCloseButton_custom2", function() {
	$('input:disabled').prop('disabled', false);
		$('button:disabled').prop('disabled', false);
		$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();

	var div=document.getElementById('waitlist-step2');
	if(null!=div)
		{
		var url=div.getAttribute("data-url");
		if(url == "null") url="" ;
		var name=div.getAttribute("data-name");
		if(name=='waitlist-step2')
			{
			 window.location.href =url;
			}
		}
	var div2=document.getElementById('session_msg');
	if(null!=div2)
	{
		var currentUrl1 = location.pathname;
		var splitUrl1 = currentUrl1.split("?");
		var url=splitUrl1[0];
		if(url == "null") url="" ;
		 window.location.href =url;
	}
});

$(document).on("click", "#joinWaitListModal_overlayCloseButton_custom3", function() {
	$('input:disabled').prop('disabled', false);
		$('button:disabled').prop('disabled', false);
		$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();

	var div=document.getElementById('waitlist-email');
	if(null!=div)
		{
		var name=div.getAttribute("data-name");
		if(name=='waitlist-email')
			{
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
			if($("#joinWaitListStep1"))
	    	{
	    		$("#joinWaitListStep1").remove();
	    	}
			if($("#joinWaitListStep2"))
	    	{
	    		$("#joinWaitListStep2").remove();
	    	}
			if($("#joinWaitListStep3"))
	    	{
	    		$("#joinWaitListStep3").remove();
	    	}
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
			$('#joinWaitListModal').modal('show');
			}
		}
});

$(document).on("click", "#joinWaitListModal_overlayCloseButton_custom4", function() {
	$('input:disabled').prop('disabled', false);
		$('button:disabled').prop('disabled', false);
		$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();

	var div=document.getElementById('waitlist-text');
	if(null!=div)
		{
		var name=div.getAttribute("data-name");
		if(name=='waitlist-text')
			{

			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
			if($("#joinWaitListStep1"))
	    	{
	    		$("#joinWaitListStep1").remove();
	    	}
			if($("#joinWaitListStep2"))
	    	{
	    		$("#joinWaitListStep2").remove();
	    	}
			if($("#joinWaitListStep3"))
	    	{
	    		$("#joinWaitListStep3").remove();
	    	}
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}

			$('#joinWaitListModal').modal('show');
			}
		}
});
 	$(document).on("click", "#joinWaitListModal_overlayCloseButton_custom5", function()
	{
 		$('input:disabled').prop('disabled', false);
 		$('button:disabled').prop('disabled', false);
 		$('body').removeClass('modal-open');
		$('.modal-backdrop').remove();

	var div=document.getElementById('edit-waitlist-text');
	var div2=document.getElementById('error_msg');
	if(null!=div)
		{
		var name=div.getAttribute("data-name");
		if(name=='edit-waitlist-text')
			{
				if($("#removeWaitListModal"))
				{
					$("#removeWaitListModal").remove();
				}
				if($("#joinWaitListStep1"))
				{
					$("#joinWaitListStep1").remove();
				}
				if($("#joinWaitListStep2"))
				{
					$("#joinWaitListStep2").remove();
				}
				if($("#joinWaitListStep3"))
				{
					$("#joinWaitListStep3").remove();
				}
				if($("#removeWaitListModal"))
				{
	    		$("#removeWaitListModal").remove();
				}
				$('#joinWaitListModal').modal('show');
			}

		}


});

/*added by chander */
$(document).on("click", "#joinWaitListModal_overlayCloseButton_custom6", function()
			{
			$('input:disabled').prop('disabled', false);
 		$('button:disabled').prop('disabled', false);
 		$('body').removeClass('modal-open');
		$('.modal-backdrop').remove();
			var div=document.getElementById('editconfirm-close');
			if(null!=div)
				{
				var url=div.getAttribute("data-url");
				var name=div.getAttribute("data-name");
				if(name=='editconfirm-close')
					{
					 window.location.href =url;
					}
				}
});
 /**By Chander-Waitlist Changes END here
 */
 /**
 * AJAX call to invoke remove waitlist step 1
 * Added by sadanand
 *
 */
$(document).on("click", "#CancelSwitch", function(){
	$('#CancelSwitch').modal('hide');

	var join_wait_list_url = $(this).attr('data-url');
	request = $.ajax({
		url : join_wait_list_url ,
		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
				"#joinWaitListModal");
		modalDiv.modal({backdrop: 'static', keyboard: false});
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
});
$(document).on("click", "#enterRMWaitList", function(){
	$('#enterRMWaitList').modal('hide');

	var join_wait_list_url = $(this).attr('data-url');
	var base_wait_list_url = $(this).attr('base-url');

	request = $.ajax({
		url : join_wait_list_url,
		type : "post",
		data: { base_wait_list_url : base_wait_list_url}

	});
	request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
				"#removeWaitListModal");
		modalDiv.modal({backdrop: 'static', keyboard: false});
		$(window).scrollTop(0);
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console

		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
});
//Changed for defect id 21469
$(document).on("click", "#RemoveWaitlistCancelConfirmation", function() {
	$('input:disabled').prop('disabled', false);
	$('button:disabled').prop('disabled', false);
	$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();
	var div=document.getElementById('removeWaitlist-text');
	if(null!=div)
		{
		var name=div.getAttribute("data-name");
		if(name=='removeWaitlist-text')
		{
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
			if($("#joinWaitListStep1"))
	    	{
	    		$("#joinWaitListStep1").remove();
	    	}
			if($("#joinWaitListStep2"))
	    	{
	    		$("#joinWaitListStep2").remove();
	    	}
			if($("#joinWaitListStep3"))
	    	{
	    		$("#joinWaitListStep3").remove();
	    	}
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}

			$('#joinWaitListModal').modal('show');
			}
		}
});

$(document).on("click", "#RemoveWaitlistConfirmation", function() {

//	$('#joinWaitListModal').modal('hide');
//	$("#joinWaitListModal").remove();
//	$('#switchLocationModal').modal('hide');
//	$('#switchLocationModal').remove();
    var form = $(this).closest("form");
	doAJAX($(this), null, RemovewaitListSuccessStep2Call);

	// preventing the page from being refreshed
	return false;
});
 /* Success callback method for waitlist step 2
 */
function RemovewaitListSuccessStep2Call(response,form, inputObj) {

	var errorDiv = $(response).find("#error_msg");

	$("#error_msg").html(errorDiv.html());

	if (!$.trim((errorDiv.html()))) {
		$("#error_msg").empty();
		$('#removeWaitListModal').modal('hide');
		$('#removeWaitListModal').remove();
		var eventNameDL;
		if(inputObj !== null){
			if(inputObj[0].value == "OK"){
				eventNameDL = "waitlistCancel";
			}else{
			eventNameDL = "waitlistChangeLocation";
			}
		}
		if($("#removeWaitListModal"))
	    	{

			$("#removeWaitListModal").remove();
	    	}
		if($("#switchLocationModal"))
	    	{

			$('#switchLocationModal').modal('hide');
			$('#switchLocationModal').remove();
			}
		loadRemoveWaitListOverlay(response);
		dtmEvent(eventNameDL,"waitlist");
	}else
	{
			$("div#error_msg").html(errorDiv.html());
			$("div#error_msg").show();
	}
}
function loadRemoveWaitListOverlay(modalHTML) {
	if($("#dtmenabled").val()=="false")
		{
	//omniture for -remove waitlist confiraiton page onload
	clearOmnitureVars();
	s.linkTrackVars='events,eVar75,eVar1,prop1,eVar79,eVar81';
	s.linkTrackEvents='event49,event100';
	s.events='event49,event100';
	s.pageName='og|us|en|WebAhead|Wait List Removal';
	s.eVar75=window.location.href;
	s.eVar79=$("#estimated_wait").val();
	s.eVar81=$(modalHTML).find("#guest_size_val").val();
	s.eVar1= s.prop1='WebAhead';
	var linkname=s.pageName;
	s.t($(this), 'o', linkname);
	//omiture ends
		}
	if($("#joinWaitListModal"))
	{
	$('#joinWaitListModal').modal('hide');
	$("#joinWaitListModal").remove();
	}
	if($("#joinWaitListModal"))
	{
		$("#joinWaitListModal").remove();
	}
	var modalDiv = $(modalHTML).filter("#joinWaitListModal");
	/*modalDiv.find(".styled-select select, .styled-select-red select").each(function() {
		$(this).wrap("<span class='select-wrapper'></span>");
		$(this).after("<span class='holder'></span>");
		var firstOption = $(this).find("option:first").text();
		$(this).next(".holder").text(firstOption);
		});*/
	modalDiv.attr('style','top: 10% !important');
	scrolloverlay(modalDiv);



	modalDiv.modal({backdrop: 'static', keyboard: false});
	//calling dgStyle() function manually for the checkbox to work normally
	// as in a normal page load
	if(modalDiv.find(".checkbox_d").length > 0){
		modalDiv.find(".checkbox_d").dgStyle();
	}

}
$(document).on("click", "#enterSwitchLoc", function(){

	$('#joinWaitListModal').modal('hide');
	$("#joinWaitListModal").remove();
	if($("#switchLocationModal"))
	    	{
			$('#switchLocationModal').modal('hide');
			$('#switchLocationModal').remove();
			}
		$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
	var join_wait_list_url = $(this).attr('data-url');
	var base_wait_list_url = $(this).attr('base-url');
	request = $.ajax({
		url : join_wait_list_url+"&base_wait_list_url="+base_wait_list_url,
		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
				"#switchLocationModal");
				  scrolloverlay(modalDiv);
				  var isTOGO = $('#TOGO').val();
				  if(isTOGO){
					modalDiv.removeClass("hide"); //Togo Refactring pages need to remove hide class from bootstrap modal
				  }
				  if($("#dtmenabled").val()=="false")
					  {
				  //omniture starts-for siwtch location page onload from location details page
				  	clearOmnitureVars();
				  	s.linkTrackVars='events,eVar75,eVar1,prop1';
					s.linkTrackEvents='event49';
					s.events='event49';
					s.pageName='og|us|en|WebAhead|Switch Location';
					s.eVar75=window.location.href;
					s.eVar1= s.prop1='WebAhead';
					var linkname=s.pageName;
					s.t($(this), 'o', linkname);
				  //omniture ends
					  }
		  if(!$("#switchLocationModal").length>0)
        {
		modalDiv.modal({backdrop: 'static', keyboard: false});
		}else{$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				}

	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
});
//added for close overlay functionality
$(document).on("click", "#removeWaitlistModal_overlayCloseButton_custom1", function() {
	$('input:disabled').prop('disabled', false);
		$('button:disabled').prop('disabled', false);
		$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();
	var div=document.getElementById('removeWaitlist-text');
	if(null!=div)
		{
		var name=div.getAttribute("data-name");
		if(name=='removeWaitlist-text')
			{
			if($("#removeWaitListModal"))
	    	{
	    		$("#removeWaitListModal").remove();
	    	}
			if($("#joinWaitListStep1"))
	    	{
	    		$("#joinWaitListStep1").remove();
	    	}
			if($("#joinWaitListStep2"))
	    	{
	    		$("#joinWaitListStep2").remove();
	    	}
			if($("#joinWaitListStep3"))
	    	{
	    		$("#joinWaitListStep3").remove();
	    	}
			$('#joinWaitListModal').modal('show');
			}
		}
});
//commented as duplicate functions being called on click of button
/*
$(document).on("click", "#RemoveWaitlistCancelConfirmation", function() {
	var div=document.getElementById('removeWaitlist-text');
	if(null!=div)
		{
		var name=div.getAttribute("data-name");
		if(name=='removeWaitlist-text')
			{
			$('#joinWaitListModal').modal('show');
			}
		}
});*/

$(document).on("click", "#removeWaitlistModal_overlayCloseButton_custom2", function() {
	$('input:disabled').prop('disabled', false);
	$('button:disabled').prop('disabled', false);
	$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();

	var currentUrl2 = location.pathname;
	var splitUrl2 = currentUrl2.split("?");
	var url=splitUrl2[0];
	if(url == "null") url="" ;
	 window.location.href =url;
});


$(document).on("click", "#removeWaitlistModal_overlayCloseButton_custom3", function() {
	$('input:disabled').prop('disabled', false);
	$('button:disabled').prop('disabled', false);
	$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();
	var currentUrl3 = location.pathname;
	var splitUrl3 = currentUrl3.split("?");
	var url=splitUrl3[0];
	if(url == "null") url="" ;
	 window.location.href =url;
});
/* End of modification by sadanand */

//Addition by Ajay
/**
 * AJAX call to invoke view waitlist step 1
 *
 */

$(document).on("click", "#viewWaitList", function(){
	var view_wait_list_url = $("#viewWaitList").attr('data-url');

	var base_wait_list_url = $(this).attr('base-url');
	$(this).prop("disabled", true);
	request = $.ajax({
		url : view_wait_list_url+"&base_wait_list_url="+base_wait_list_url,
		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {
		if($("#dtmenabled").val()=="false")
			{
		  if($('#omniture_page_type').val()=='location-info')
			{
				clearOmnitureVars();
				$(this).prop("disabled", true);
				s.linkTrackVars='events,eVar75,eVar70,prop49,prop55,eVar81';
				s.linkTrackEvents='event75,event97';
				s.linkType='lnk_o';
				s.events='event75,event97';
				s.prop55=$("#estimated_wait").val();
				s.eVar81=$(response).find("#guest_size_val").val();
				var page_extra=s.pageName+' '
				s.eVar75=window.location.href;
				var linkText=$('#viewWaitList').text();
				var linkname=s.eVar70=s.prop49=s.pageName+'|Location Details Page '+linkText+' link';
				s.tl($(this), 'o', linkname);
			}
			}
		var modalDiv = $($.parseHTML(response)).filter(
		/* accessbilty sunil */
				"#joinWaitListModal").prepend("<button class='test' autofocus></button>");
				/* accessbilty sunil */
				  scrolloverlay(modalDiv);

		modalDiv.modal({backdrop: 'static', keyboard: false});
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
	/*41459 - To update the wait list position*/
	setTimeout(function(){ 
	    getWaitPosition(); 
	}, 500);
});

/**
 * AJAX call to invoke edit waitlist step 1
 *
 *
 */

$(document).on("click", "#editWaitList", function(){

	var edit_wait_list_url = $("#editWaitList").attr('data-url');

	request = $.ajax({
		url : edit_wait_list_url,
		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
				"#joinWaitListStep1");
				  scrolloverlay(modalDiv);
				  if($("#dtmenabled").val()=="false")
					  {
				//omniture for -edit party size page onload
				  	clearOmnitureVars();
				  	s.linkTrackVars='events,eVar75,eVar1,prop1';
					s.linkTrackEvents='event49';
					s.events='event49';
					s.pageName='og|us|en|WebAhead|Edit Guests';
					s.eVar75=window.location.href;
					s.eVar1= s.prop1='WebAhead';
					var linkname=s.pageName;
					s.t($(this), 'o', linkname);
				//omiture ends
					  }

		modalDiv.modal({backdrop: 'static', keyboard: false});
		$(window).scrollTop(0);
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
});

/**
 * AJAX call to invoke edit wait list Step2
 */
$(document).on("click", "#EditWaitlistConfirmation", function() {
	var form = $(this).closest("form");
	doAJAX($(this), null, editConfirmationSuccess);

	// preventing the page from being refreshed
	return false;
});


 /* Success callback method for edit wait list step 2
 */
function editConfirmationSuccess(response,form, inputObj) {
	var errorDiv = $(response).find("#error_msg");
	form.find("#error_msg").html(errorDiv.html());

	if (!$.trim((errorDiv.html()))) {
		$("#error_msg").empty();
		$('#joinWaitListModal').remove();
		$('#joinWaitListStep1').remove();
		if($("#joinWaitListStep1"))
	    	{    $("#joinWaitListModal1").modal('hide');
	    		$("#joinWaitListStep1").remove();

	    	}
			$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
		//$('#joinWaitListModal').modal('hide');
				if($("#dtmenabled").val()=="false")
					{
		//omniture starts-for confirmation page load
		clearOmnitureVars();
		s.linkTrackVars='events,eVar79,eVar75,eVar81,eVar1,prop1';
		s.linkTrackEvents='event49,event99';
		s.events='event49,event99';
		s.pageName='og|us|en|WebAhead|Edit Guests Confirmation';
		s.eVar79=$("#estimated_wait").val();
		s.eVar75= window.location.href;
		s.eVar81=$(response).find("#guest_size_val").val();
		s.eVar1= s.prop1='WebAhead';
		var linkname=s.pageName;
		s.t(true, 'o', linkname);
		//omniture ends
					}
		loadWaitListOverlay_edit(response);
	}else
	{
			form.find("#error_msg").html(errorDiv.html());
			form.find("#error_msg").show();
	//scrolloverlay($("#joinWaitListModal"));
	}
}

//Edit guest overlay display changes
function loadWaitListOverlay_edit(modalHTML) {
	var modalDiv;
	modalDiv = $(modalHTML).filter("#joinWaitListModal");
	if(modalDiv.html()==undefined)
	{
	modalDiv=$(modalHTML).filter("#joinWaitListStep1");
	}
	modalDiv.attr('style','top: 0% !important');
	scrolloverlay(modalDiv);
	modalDiv.modal({backdrop: 'static', keyboard: false});

}

 /**
 * End of Modifications by Ajay
 */

//added by vara
//FOr onload waitlist confirmation page
$(document).on("click", "#EnterWaitlistConfirmationEmail", function(){

	var wait_list_confirmation_url = $("#EnterWaitlistConfirmationEmail").attr('data-url');

	request = $.ajax({
		url : wait_list_confirmation_url,
		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
				"#joinWaitListModal");
				  scrolloverlay(modalDiv);
		modalDiv.modal({backdrop: 'static', keyboard: false});
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
});
/*Added by sadanand as Mutliple overlays where opening on multiple clicks*/
$(document).on("click", "#editWaitList", function(){


	$(this).prop('disabled', true);


});
$(document).on("click", "#enterSmsWaitList", function(){

	$(this).prop('disabled', true);
});
$(document).on("click", "#enterRMWaitList", function(){

	$(this).prop('disabled', true);
});

$(document).on("click", "#enterEmailWaitList", function(){

	$(this).prop('disabled', true);
});
$(document).on("click", "#omni_webahead_search_map", function(){
$(this).prop('disabled', true);
});
$(document).on("click", "#omni_webahead_search", function(){
$(this).prop('disabled', true);
});
$(document).on("click", "#enterSwitchLoc", function(){
$(this).prop('disabled', true);
});
/*end of comments*/
$(document).on("click", "#enterWaitList1", function(){
	/**
	*Added by Sonika For onload overlay header issue
	*date modified: 15082015
	 */

	$("#joinWaitListModal").modal('hide');
		$("#joinWaitListModal").remove();
		$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
	/**
	 * End of Comment
	 */
		var join_wait_list_url = $(this).attr('data-url');

		var base_wait_list_url = $(this).attr('base-url');

		request = $.ajax({
			url : join_wait_list_url+"&base_wait_list_url="+base_wait_list_url,
			type : "post"
		});
		request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
		           /* accessbilty sunil */
					"#joinWaitListModal").prepend("<button class='test' autofocus></button>");
					/* accessbilty sunil */
					//optin checkbox hide changes starts
					/*modalDiv.find('#waitlist-step1 #joinWaitlistForm .overlay-check .confirm-check .checkbox_d_overlay').hide();
					modalDiv.find('#waitlist-step1 #joinWaitlistForm .overlay-check .confirm-check #newsOpts').hide();*/
					//optin checkbox hide changes end
					modalDiv.attr('style','top: 0% !important');
			if(!$("#joinWaitListModal").length>0)
            {
			modalDiv.modal({backdrop: 'static', keyboard: false});
			$(window).scrollTop(0);
			var phoneTxt = modalDiv.find("#phone-ctn");
			if ( phoneTxt != undefined)	formatPhoneNumber2(phoneTxt);
			}else{$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				}
			dtmEvent("waitlistStart","waitlist");
			var waitlistDataModel = {
				"modalName": "joinWaitList",
				"modalContent": "waitlist form signup",
				"modalIntent": "form Submit"
			};          
			try {
				AU.dispatchEvent('AnalyticsEvent','ShowModal', waitlistDataModel);
			} catch(e) {
				Bugsnag.notifyException( new Error(e.message), e.title, waitlistDataModel, "error");
			}
		});

		// callback handler that will be called on failure
		request.fail(function(jqXHR, textStatus, errorThrown) {
			// log the error to the console
			console.error("The following error occured: " + textStatus,
					errorThrown);
		});
	});

	$(document).on("click", "#enterSwitchLoc1", function(){
	$('#joinWaitListModal').modal('hide');
	$("#joinWaitListModal").remove();
	if($("#switchLocationModal"))
	    	{
			$('#switchLocationModal').modal('hide');
			$('#switchLocationModal').remove();
			}
		$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
	var join_wait_list_url = $(this).attr('data-url');
	var base_wait_list_url = $(this).attr('base-url');
	request = $.ajax({
		url : join_wait_list_url+"&base_wait_list_url="+base_wait_list_url,
		type : "post"
	});
	request.done(function(response, textStatus, jqXHR) {

		var modalDiv = $($.parseHTML(response)).filter(
				"#switchLocationModal");
				  scrolloverlay(modalDiv);
  if(!$("#switchLocationModal").length>0)
        {
		modalDiv.modal({backdrop: 'static', keyboard: false});
		$(window).scrollTop(0);
		}
		else{$('body').removeClass('modal-open');
				$('.modal-backdrop').remove();
				}
	});

	// callback handler that will be called on failure
	request.fail(function(jqXHR, textStatus, errorThrown) {
		// log the error to the console
		console.error("The following error occured: " + textStatus,
				errorThrown);
	});
});

	/*webahead omniture click events starts
	 * By chander
	**/
	if($("#dtmenabled").val()=="false")
		{
	//1.Home page waitlist banner click
	$(".slide[data-slide='5']").click(function() {
		clearOmnitureVars();
		s.linkTrackVars='events,eVar70,prop49,eVar75,prop55';
		s.linkTrackEvents='event75';
		s.linkType='lnk_o';
		s.events='event75';
		s.pageName='og|us|en|WebAhead';
		s.prop55=$("#estimated_wait").val();
		s.eVar75=window.location.href;
		var linkname=s.eVar70=s.prop49=s.pageName + '|' + 'Join Wait List Now Banner link';
		s.tl($(this), 'o', linkname);
	});

	//1.join wait list
		$(document).on("click", "#EnterWaitlistConfirmation,#waitlistCancel", function() {
		$('input:disabled').prop('disabled', false);
	    $('button:disabled').prop('disabled', false);
		$("#EnterWaitlistConfirmation").prop('disabled', true);
		clearOmnitureVars();
		s.linkTrackVars='events,eVar7,eVar79,eVar75,eVar10,eVar70,prop49';
		s.linkTrackEvents='event75';
		s.events='event75';
		var linkText;
		var globalOptin;
		//checkbox event
		if($(".checkbox_d_overlay.checkbox_checked").length )
			{
				globalOptin=true;
			}
		else
			{
				globalOptin=false;
			}
		if($(this).attr('id') =='EnterWaitlistConfirmation')
			{
				s.linkTrackEvents='event75,event7';
				s.events='event75,event7';
				s.eVar7='Wait List';
				if ($.trim(globalOptin) == 'true')
				{
					s.eVar10 = 'Global opt-in';
				} else
				{
					s.eVar10 = 'Concept opt-in';
				}
				linkText=$(this).attr('value');
			}
		if($(this).attr('id') =='waitlistCancel')
			{
				linkText=$('#waitlistCancel').text();
				$(".inform-link #enterWaitList").prop('disabled', false);

			}
		s.linkType='lnk_o';
		s.pageName='og|us|en|WebAhead|Join Wait List';
		s.eVar79=  $("#estimated_wait").val();
		s.eVar75=window.location.href;

		var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
		s.tl($(this), 'o', linkname);
		var selectedPartySize = $('#partySize').val();
		var defaultPartySize = $('#restDefaultPartySize').val();
		if(selectedPartySize == null || selectedPartySize == "" || selectedPartySize == undefined) {
			document.getElementById("partySize").value = defaultPartySize;
		}
	});
		//2.wait list confirmation and edit guest confirmation
		$(document).on("click", "#enterEmailWaitList,#enterSmsWaitList,#enterRMWaitList,#editWaitList,#directionsLink,#restNameLink,#mapLink", function(){
			clearOmnitureVars();
			s.linkTrackVars='events,eVar75,eVar70,prop49';
			s.linkTrackEvents='event75';
			s.linkType='lnk_o';
			var linkText;
			s.events='event75';
			if($("#page_confirm").val()=='editSuccess')
				{
				s.pageName='og|us|en|WebAhead|Edit Guests Confirmation';
				linkText=$(this).attr('value');
				}
			else{
				s.pageName='og|us|en|WebAhead|Wait List Confirmation';
				linkText=$(this).attr('value');
				}
			if($(this).attr('id') =='directionsLink')
				{
				linkText=$('#directionsLink').text();
				}
			if($(this).attr('id') =='restNameLink')
				{
				linkText=$('#restNameLink').text();
				}
			if($(this).attr('id') =='mapLink')
				{
				linkText=$('#mapLink').text();
				}
			s.eVar75=window.location.href;
			var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
			s.tl($(this), 'o', linkname);


		});
		//3.emial and text conmfirmation
		$(document).on("click", "#emailWaitList,#smsWaitList", function(){
			clearOmnitureVars();
			s.linkTrackVars='events,eVar75,eVar70,prop49';
			s.linkTrackEvents='event75';
			s.linkType='lnk_o';
			s.events='event75';
			if($(this).attr('id') =='smsWaitList')
				{
				s.pageName='og|us|en|WebAhead|Send Via Text';
				}
			else
				{
				s.pageName='og|us|en|WebAhead|Send Via Email';
				}

			s.eVar75=window.location.href;
			var linkText=$(this).attr('value');
			var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
			s.tl($(this), 'o', linkname);

		});

		//4.omniture starts for-location info- Wait List Details page button clicks
		$(document).on("click", "#locText_webahead,#locEmail_webahead, #viewMenu_webahead,#orderbtn_webahead", function(){
			clearOmnitureVars();
			s.linkTrackVars='events,eVar75,eVar70,prop49';
			s.linkTrackEvents='event75';
			s.linkType='lnk_o';
			s.events='event75';
			s.eVar75=window.location.href;
			var linkText;
			linkText=$(this).attr('value');
			if($(this).attr('id') =='locText_webahead')
			{
				linkText=$('#locText_webahead').text();
			}
			if($(this).attr('id') =='locEmail_webahead')
			{
				linkText=$('#locEmail_webahead').text();
			}
			var linkname=s.eVar70=s.prop49=s.pageName+' Location Details Page '+linkText+' link';
			s.tl($(this), 'o', linkname);
		});

		//5.remove waitlist confirm page-buttons click
		$(document).on("click", "#waitlistFindAnotherLoc,#waitlistToGoOrder", function(){
			clearOmnitureVars();
			s.linkTrackVars='events,eVar75,eVar70,prop49';
			s.linkTrackEvents='event75';
			s.linkType='lnk_o';
			s.events='event75';
			s.pageName='og|us|en|WebAhead|Wait List Removal';
			s.eVar75=window.location.href;
			var linkText=$(this).attr('value');
			var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
			s.tl($(this), 'o', linkname);

		});

		//6.edit NO.of guets page
		$(document).on("click", "#EditWaitlistConfirmation,#joinWaitListModal_overlayCloseButton_custom5", function(){
			clearOmnitureVars();
			var party=$('.holder').text();
			var linkText;
			if($(this).attr('id') =='EditWaitlistConfirmation')
			{
				s.linkTrackVars='events,eVar75,eVar70,prop49,prop55';
				s.prop55=party;
				linkText=$(this).attr('value');
			}
			if($(this).attr('id') =='joinWaitListModal_overlayCloseButton_custom5')
			{
				s.linkTrackVars='events,eVar75,eVar70,prop49';
				linkText=$(this).text();
			}
			s.linkTrackEvents='event75';
			s.linkType='lnk_o';
			s.events='event75';
			s.pageName='og|us|en|WebAhead|Edit Guests';
			s.eVar75=window.location.href;

			var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
			if(linkText=='Cancel'||linkText=='UPDATE')
			s.tl($(this), 'o', linkname);


		});
		//7.switch location button click from location details page
		$(document).on("click", "#enterSwitchLoc", function(){
			clearOmnitureVars();
			s.linkTrackVars='events,eVar75,eVar70,prop49,prop55';
			s.linkTrackEvents='event75,event97';
			s.linkType='lnk_o';
			s.events='event75,event97';
			s.pageName='og|us|en|WebAhead';
			s.eVar75=window.location.href;
			s.prop55=$("#estimated_wait").val();
			var linkText=$("#enterSwitchLoc").text();
			var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
			s.tl($(this), 'o', linkname);

		});

		//8.switch location page
		$(document).on("click", "#RemoveWaitlistConfirmation,#CancelSwitch", function() {
			if($("#RemoveWaitlistConfirmation").attr('value')!='OK')
			{
			if($("#dtmenabled").val()!="true"){
				clearOmnitureVars();
				s.linkTrackVars='events,eVar75,eVar70,prop49';
				s.linkTrackEvents='event75';
				s.linkType='lnk_o';
				s.events='event75';
				s.pageName='og|us|en|WebAhead|Switch Location';
				s.eVar75=window.location.href;
				var linkText=$(this).attr('value');
				var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
				s.tl($(this), 'o', linkname);
			}
		}
		});
		if($("#dtmenabled").val()!="true"){
		$(document).on("click", "a[id*='directionsLink-']", function() {
			clearOmnitureVars();
			s.linkTrackVars='events,eVar75,eVar70,prop49';
			s.linkTrackEvents='event75';
			s.linkType='lnk_o';
			s.events='event75';
			s.pageName='og|us|en|Join Waitlist Overlay';
			s.eVar75=window.location.href;
			var linkText=$(this).text();
			var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
			s.tl($(this), 'o', linkname);
		});
		}
		//9.Location Overlay page
		$(document).on("click", "#sms-current,#email-current,#popNutritionIconLink,#popDirLink,#overlayRestName,#omni_viewmenu_location_overlay,#omni_ordertogo_location_overlay", function() {
			if($('#omniture_page_name').val()=='header-info')
				{
					clearOmnitureVars();
					s.linkTrackVars='events,eVar75,eVar70,prop49';
					s.linkTrackEvents='event75';
					s.linkType='lnk_o';
					s.events='event75';
					s.pageName='og|us|en|Location Details Overlay';
					s.eVar75=window.location.href;
					var linkText=$(this).text();
					var linkname=s.eVar70=s.prop49=s.pageName+'|'+linkText+' link';
					s.tl($(this), 'o', linkname);
				}

		});
		//webahead omniture click events ends

		/*webahead page load events starts here*/
		//1.location show arrow page load
		$('#location-show-arrow ,#headRestName').click( function(){
			clearOmnitureVars();
			s.linkTrackVars='events,eVar79,eVar75,eVar1,prop1';
			s.linkTrackEvents='event49';
			s.events='event49';
			s.eVar79=$("#estimated_wait").val();
			s.pageName='og|us|en|Location Details Overlay';
			s.eVar75=window.location.href;
			s.eVar1= s.prop1='WebAhead';
			var linkname=s.pageName;
			s.t($(this), 'o', linkname);
		});
		/*webahead page load events ends here*/
		//omniture chnages ends
		}
//added by vara
		function scrolloverlay_joinwaitlist(getID){
	     	getID.animate({paddingTop:"0px"}, function(){
	     		var getscrolltop = parseInt($(window).scrollTop());
	     		$(window).scrollTop(getscrolltop-2000);
	     		//$(window).scrollTop(getscrolltop+161);
	     	});
	      }
/*Fix: send via email and send via text overlay persist error message after closing it */
			$(".close").click(function() {
					 $("label.error_msg").hide();

			});


/*====================================== R4.2 Subscriptions ==============================================*/
	/**
	* Function to display transfer mobile optin based on the selection of phone type
	*/
	$('html body').on('change','#phoneType',function() {
		var phoneType = $('#phoneType').val();
		if (phoneType == 'Mobile') {
			$("#mobileOptInOptions").show();
		}else{
			$("#mobileOptInOptions").hide();
		}
	});


	/**
	 * Function to enable/greyout text opt-in when phone type is changed
	 * to mobile and unchanged from mobile to others
	 */
	$('html body').on('change','#phone_type_wid',function()  {
		var phoneType = $('#phone_type_wid').val();
		if (phoneType != 'Mobile') {
		   $(".textAlerts").remove();
		   disableClicks('textAlerts','textAlerts');
		   $("#textoptin_checkbox_d").css("background-position","0% 0px");
		   var chk = $("#textoptin_checkbox").is(":checked");
		   if(chk){
			 $("#textoptin_checkbox").removeAttr("checked");
		   }
        }else{
		   $(".textAlerts").remove();
		}
	});



	/**
	 * Function to enable/greyout text opt-in when phone type others during page load
	 */
	if($('#phone_type_wid').length)	{
		var phoneType = $('#phone_type_wid').val();
		if (phoneType != 'Mobile') {
		  disableClicks('textAlerts','textAlerts');
        }
	}

	/**
	* Function to disable all clickable events under the div
	*/
	function disableClicks(el_id,clas){
		var el_id ='#'+el_id;
		var con2Width = $(el_id).width();
		var con2Height = $(el_id).height();
		$(el_id).css("position","relative");
		$(el_id).append("<div class='"+clas+"'></div>");
		$(el_id).find('a').css({'position':'relative','z-index':'2'});
		$(el_id).find(':input').attr('tabindex',-1);
		var clas ='.'+clas;
		$(clas).css({"width":con2Width,"height":con2Height,"position":"absolute","top":"0","left":"0","z-index":"1"});
	}

	/**
	 * Function to enable/greyout email subscriptions when email opt-in is checked/un-checked
	 * and show relevant message accordingly by enabling/hiding the div text
	 */
	function handleEmailSubscriptions(){
		var chk = $("#subscriptionInfo_emailcheckbox").is(":checked");
		var $div = $('#account-subscription-emailTopics');
        if (chk) {
		   $div.removeClass('subscriptionsContainerGrey');
		   $('#account-subscription-emailTopics :input').removeAttr('disabled',true);
		   $('#account-subscription-emailTopics :input').removeAttr('tabindex',-1);
		   $("#emailTopics-disable-msg").addClass("disp_none");
        }else{
		   $div.addClass('subscriptionsContainerGrey');
		   $('#account-subscription-emailTopics :input').attr('disabled',true);
		   $('#account-subscription-emailTopics :input').attr('tabindex',-1);
		   $("#emailTopics-disable-msg").removeClass("disp_none");
		}
	}

	/**
	 * Function to enable/greyout text subscriptions when text opt-in is checked/un-checked
	 * and show relevant message accordingly by enabling/hiding the div text
	 */
	function handleTextSubscriptions(){
		var chk = $("#subscriptionInfo_textcheckbox").is(":checked");
		var $div = $('#account-subscription-textTopics');
        if (chk) {
		   $div.removeClass('subscriptionsContainerGrey');
		   $('#account-subscription-textTopics :input').removeAttr('disabled',true);
		   $('#account-subscription-textTopics :input').removeAttr('tabindex',-1);
		   $("#textTopics-disable-msg").addClass("disp_none");
        }else{
		   $div.addClass('subscriptionsContainerGrey');
		   $('#account-subscription-textTopics :input').attr('disabled',true);
		   $('#account-subscription-textTopics :input').attr('tabindex',-1);
		   $("#textTopics-disable-msg").removeClass("disp_none");
		}
	}

	/**
	 * Function to enable/greyout email subscriptions when email opt-in is checked/un-checked
	 * and show relevant message accordingly by enabling/hiding the div text
	 */
	$('#subscriptionInfo_emailcheckbox').parent(".checkbox_d").click(function() {
		handleEmailSubscriptions();
	});

	/**
	 * Function to greyout email subscriptions after page load if email opt-in is false
	 * and show relevant message accordingly by enabling/hiding the div text
	 */
	if($('#subscriptionInfo_emailcheckbox').length)	{
		handleEmailSubscriptions();
	}


	/**
	 * Function to enable/greyout text subscriptions when text opt-in is checked/un-checked
	 * and show relevant message accordingly by enabling/hiding the div text
	 */
	$('#subscriptionInfo_textcheckbox').parent(".checkbox_d").click(function() {
		handleTextSubscriptions();
	});

	/**
	 * Function to greyout text subscriptions after page load if text opt-in is false
	 * and show relevant message accordingly by enabling/hiding the div text
	 */
	if($('#subscriptionInfo_textcheckbox').length)	{
		handleTextSubscriptions();
	}

	/**
	 * Function to greyout text checkbox and terms when mobile number does not eixts in preference page
	 */
	if($('#addMobilePhone').length)	{
		var $div = $('#textAlerts');
		disableClicks('textAlerts','textAlerts');
		$div.addClass('subscriptionsContainerGrey');
	}

	/**
	*Function to open a popup when user clicks on view sample
	*/
	$('[id^=emailSampleLink_], [id^=textSampleLink_]').click( function() {
		var url = $(this).attr("data-url");
		var imageUrl = $(this).attr("data-id");

		if($("#myModalSubscriptionSample").length){
			$("#myModalSubscriptionSample").remove();
		}
		request = $.ajax({
					url: url,
					type: "get",
					cache: false,
					data: { sampleImageURL : imageUrl }
		});
		request.done(function (response, textStatus, jqXHR){
			var imageModal = $(response).filter("#myModalSubscriptionSample");
			imageModal.modal();
		});
	});

	/**
	*Function to scroll to edit email section when clicked on edit button in preference center page
	*/
	if($('#editEmail').length > 0 && location.pathname.indexOf('/customer-service/account-profile') > -1){
		var divID = '#editEmail';
		$('html, body').animate({
			scrollTop: $(divID).offset().top
		}, 2000);
	}

	/**
	*Function to scroll to edit phone section when clicked on edit phone button in preference center page
	*/
	/*if($('#editPhone').length){
		var divID = '#editPhone';
		$('html, body').animate({
			scrollTop: $(divID).offset().top
		}, 2000);
	}*/

	/**
	*Function to scroll to add phone section when clicked on add phone button in preference center page
	*/
	if($('#addPhone').length > 0 && location.pathname.indexOf('/customer-service/account-profile') > -1){
		var divID = '#addPhone';
		$('html, body').animate({
			scrollTop: $(divID).offset().top
		}, 2000);
	}
/*====================================== R4.2 JS Changes for preference center end =================================
=============*/

/*Magic fix for 469462770 by xsdnxe1 */
$(".star-grey-big1").click(function() {

var prefix=$('#media').val();

$(this).find('img').attr('src', prefix+'/fav_star_active.jpg');
});
function formatPhoneNumber2(input) {

		var numsOnly = input.val().replace(/\D/g, '');
		if (numsOnly.length >= 10) {
			input.val(input.val().replace(/\D/g, ''));
	}
		input.val(input.val().replace(/(\d{3})(\d{3})(\d{4})/,'($1) $2-$3'));
		if (input.val().length > 14) {
			input.val(input.val().slice(0, 13));
		}
	}
function loadJoinWaitListModalFromSearch(restId, restNum,buttonType){
    $(".modal-backdrop ").attr('class', 'someClass');
	var headerLinks = $("#header-links");
	var join_wait_list_details;
	var data = {};
	var cookieRestId = '';
	var locnCookie = $.cookie("DRIREST");
	if(locnCookie){
		locnCookie = locnCookie.replace(/\*/g,',');
		var locValues = locnCookie.split("@@");
		cookieRestId=locValues[0];

	}
	if (restId != cookieRestId && headerLinks.length > 0) {
		var url = headerLinks.attr('data-url');
		data.restId = restId;
		data.changeCurrentLocation = 'true';
		data.restNum = restNum;
		var dataPageURL = location.pathname;
		if ($("#joinWaitListDetails").length > 0) {
			join_wait_list_details = $("#joinWaitListDetails");
			data.dataPageURL = dataPageURL;
		}
		if (window.location.protocol == "https:") {
			url = $("#ajaxServletURL").val();
			data.AJAX_FUNCTION = "headerLinks";
		}
		data.fromPage = location.pathname;
		//Change for restCatering ends

		$.ajaxSetup({
			cache : false
		});
		$.get(url, data,  function(response) {
			headerLinks.replaceWith(response);
			var locDetCookieVal = $("#locDetCookieVal").val();
					if(locDetCookieVal != '' && locDetCookieVal != null){
						locDetCookieVal = locDetCookieVal.replace(/#/g,'"');
						setLocationCookie(locDetCookieVal);
						setLocationHeader();
						if ($("#joinWaitListDetails").length > 0) {
						join_wait_list_details.html($(response).filter('#waitListInfo').html());
					}
					}
					if($("#dtmenabled").val()=="false")
						{
					joinwaitlistOmniClick(buttonType);
						}
			$("#enterWaitList1").trigger('click');
			if($("#dtmenabled").val()=="false")
			{
			joinwaitlistOmniLoad(buttonType);
			}
	});
	} else {
		if($("#dtmenabled").val()=="false")
		{
		joinwaitlistOmniClick(buttonType);
		}
		$("#enterWaitList1").trigger('click');
		if($("#dtmenabled").val()=="false")
		{
		joinwaitlistOmniLoad(buttonType);
		}

	}
	var waitlistDataModel = {
		"modalName": "joinWaitList",
		"modalContent": "waitlist form signup",
		"modalIntent": "form Submit"
	};          
	try {
		AU.dispatchEvent('AnalyticsEvent','ShowModal', waitlistDataModel);
	} catch(e) {
		Bugsnag.notifyException( new Error(e.message), e.title, waitlistDataModel, "error");
}
}
function joinwaitlistOmniClick(buttonType)
{
	 //location search and map joinwaitlist button click events
	if($("#dtmenabled").val()=="false") { //dtm flag start
	clearOmnitureVars();
	s.linkTrackVars='events,eVar70,prop49,eVar75,prop55';
	s.linkTrackEvents='event75,event97';
	s.linkType='lnk_o';
	s.events='event75,event97';
	s.prop55=$("#estimated_wait").val();
	s.eVar75=window.location.href;
	var pagename=s.pageName;
	 if(buttonType=='map_button')
		{
		s.pageName=pagename+'|Location Details Map Join Wait List'
		 pagename=pagename+'|Location Details Map ';
		}
	 else
		{
		s.pageName=pagename+'|Restaurent Search Join Wait List'
		 pagename=pagename+'|Restaurent Search ';
		}
	var linkname=s.eVar70=s.prop49=pagename+'Join Wait List link';
	s.tl($(this), 'o', linkname);
	//omniture ends
	} //dtm flag end
	}
function joinwaitlistOmniLoad(buttonType)
{
	if($("#dtmenabled").val()=="false") { //dtm flag start
	//ominture starts for join wait list load
	clearOmnitureVars();
		s.linkTrackVars='events,eVar79,eVar75,eVar1,prop1';
	s.linkTrackEvents='event49,event98';
	s.events='event49,event98';
	var pagename='og|us|en|WebAhead';
	 if(buttonType=='map_button')
		{
		pagename=pagename+'|Location Details Map Join Wait List';
		}
	 else
		{
		pagename=pagename+'|Restaurent Search Join Wait List';
		}
	s.pageName=pagename;
	s.eVar79= $("#estimated_wait").val();
	s.eVar75=window.location.href;
	s.eVar1= s.prop1='WebAhead';
	var linkname=pagename;
	s.t($(this), 'o', linkname);
	//omniture ends
	} //dtm flag end
	}

//defect 30455
if($('#menuTypes').length){
	var menus = $('#menuTypes').val();
	if(menus.indexOf('Catering') > -1 && $('#signupSource').length && $('#userPickupMethod').length){
		$('#signupSource').val("og_signup_catering");
	}
}


/*End of Magic fix by xsdnxe1 */
/* Contact us form changes */
$(window).on('load', function() {
			$('[id^=reg_countryNameSelect]').first().trigger('change');
			if(location.href.indexOf('contact-us')){
				var dateOfVisit="Date of Visit";
				var timeOfVisit="Time of Visit";
				var dateOfDelivery="Date of Delivery";
				var timeOfDelivery="Time of Delivery";
				if($("#dateofvisit").length)
				{
				dateOfVisit=$("#dateofvisit").val();
				}
				if($("#timeofvisit").length)
				{
				timeOfVisit=$("#timeofvisit").val();
				}
				if($("#dateofdelivery").length)
				{
				dateOfDelivery=$("#dateofdelivery").val();
				}
				if($("#timeofdelivery").length)
				{
				timeOfDelivery=$("#timeofdelivery").val();
				}
				var str1="catering";
				var str2="banquetes";
				if($("#cateringwalkin").length || $("#cateringonline").length)
				{
					str1=$("#cateringwalkin").val();
					str2=$("#cateringonline").val();
				}
			var str= $("#orderTypeContactus option:selected").text().trim();
			if( $("#orderTypeContactus option:selected").text()== $('#OrderTypeselectOrderType').val()){
		  	$("#contactUsOptionsiId").css({display : "none"});
			$("#contactus_restStateSelect").attr("name","preferredRestaurantState");
			$("#contactus_restaurantName").attr("name","preferredRestaurant");
			$("#beanvaluepickUporDelivery").attr("name","pickUporDelivery");
			}
		    else if(str.indexOf(str1) > -1||str.indexOf(str2) > -1)
			  {
			  $("#contactUsOptionsiId").css({display : "block"});
			  $("#pickupOrdeliveryid").css({display : "block"});
				$("#contactUsServername").css({display : "none"});
			  	$("#contactus_restStateSelect").attr("name","vpreferredRestaurantState");
				$("#contactus_restaurantName").attr("name","vpreferredRestaurant");
				$("#beanvaluepickUporDelivery").attr("name","vpickUporDelivery");
					var pickClassName=$("#togo_OnlineOrderPickup_radio").closest('div').attr("class");
					var deliveryClassName=$("#togo_OnlineOrderDelivery_radio").closest('div').attr("class");
					if(pickClassName.indexOf("radio_checked")>-1){
					document.getElementById("beanvaluepickUporDelivery").value = $("#togo_OnlineOrderPickup_radio").data("type");
					$("#contactUsOptionsiId label[for='datepickercontactus']").text(dateOfVisit);
					$("#contactUsOptionsiId label[for='timepicker']").text(timeOfVisit);
					}
					else if(deliveryClassName.indexOf("radio_checked")>-1)
					{
					document.getElementById("beanvaluepickUporDelivery").value = $("#togo_OnlineOrderDelivery_radio").data("type");
					$("#contactUsOptionsiId label[for='datepickercontactus']").text(dateOfDelivery);
					$("#contactUsOptionsiId label[for='timepicker']").text(timeOfDelivery);
					}
					}
			  }
			  else
			  {
			  $("#contactUsOptionsiId").css({display : "block"});
				$("#pickupOrdeliveryid").css({display : "none"});
				$("#contactUsServername").css({display : "block"});
				$("#beanvaluepickUporDelivery").attr("name","pickUporDelivery");
				$("#contactus_restStateSelect").attr("name","vpreferredRestaurantState");
				$("#contactus_restaurantName").attr("name","vpreferredRestaurant");
				$("#beanvaluepickUporDelivery").attr("name","pickUporDelivery");
			  }
		  });
$('#orderTypeContactus').change(function() {

				$("#orderTypeContactus option:selected").each(function() {
					str = $(this)
					.text().trim();
					var dateOfVisit="Date of Visit";
					var timeOfVisit="Time of Visit";
					var dateOfDelivery="Date of Delivery";
					var timeOfDelivery="Time of Delivery";
					if($("#dateofvisit").length)
					{
					dateOfVisit=$("#dateofvisit").val();
					}
					if($("#timeofvisit").length)
					{
					timeOfVisit=$("#timeofvisit").val();
					}
					if($("#dateofdelivery").length)
					{
					dateOfDelivery=$("#dateofdelivery").val();
					}
					if($("#timeofdelivery").length)
					{
					timeOfDelivery=$("#timeofdelivery").val();
					}
					  if($("#togo_OnlineOrderDelivery_radio").closest('div').hasClass("radio_checked"))
					  {
					     $("#contactUsOptionsiId label[for='datepickercontactus']").text("Date of Delivery");
					     $("#contactUsOptionsiId label[for='timepicker']").text("Time of Delivery");
					  }else if($("#togo_OnlineOrderPickup_radio").closest('div').hasClass("radio_checked")){
						  $("#contactUsOptionsiId label[for='datepickercontactus']").text("Date of Visit");
						  $("#contactUsOptionsiId label[for='timepicker']").text("Time of Visit");
					  }
					var str1="catering";
					var str2="banquetes";
					if($("#cateringwalkin").length || $("#cateringonline").length)
					{
						str1=$("#cateringwalkin").val();
						str2=$("#cateringonline").val();
					}
						if(str.indexOf(str1) > -1||str.indexOf(str2) > -1){
						if($("#togo_OnlineOrderDelivery_radio").is(':checked')){
						$("#contactUsOptionsiId label[for='datepickercontactus']").text(dateOfDelivery);
						$("#contactUsOptionsiId label[for='timepicker']").text(timeOfDelivery);
						}else{
							$("#contactUsOptionsiId label[for='datepickercontactus']").text(dateOfVisit);
							$("#contactUsOptionsiId label[for='timepicker']").text(timeOfVisit);
						}
					$("#contactUsOptionsiId").css({display : "block"});
					$("#contactUsServername").css({display : "none"});
					$("#pickupOrdeliveryid").css({display : "block"});
					$("#beanvaluepickUporDelivery").attr("name","vpickUporDelivery");
					var pickClassName=$("#togo_OnlineOrderPickup_radio").closest('div').attr("class");
					var deliveryClassName=$("#togo_OnlineOrderDelivery_radio").closest('div').attr("class");
					if(pickClassName.indexOf("radio_checked")>-1){
					document.getElementById("beanvaluepickUporDelivery").value = $("#togo_OnlineOrderPickup_radio").data("type");
					}
					else if(deliveryClassName.indexOf("radio_checked")>-1)
					{
					document.getElementById("beanvaluepickUporDelivery").value = $("#togo_OnlineOrderDelivery_radio").data("type");
					}
					}
					else{
						$("#contactUsOptionsiId label[for='datepickercontactus']").text(dateOfVisit);
						$("#contactUsOptionsiId label[for='timepicker']").text(timeOfVisit);
						$("#contactUsOptionsiId").css({display : "block"});
						$("#pickupOrdeliveryid").css({display : "none"});
						$("#contactUsServername").css({display : "none"});
						$("#beanvaluepickUporDelivery").attr("name","pickUporDelivery");
					}
						if(str  == 'Dine-In')
						{
						  $("#contactUsServername").css({display : "block"});	
	                    }
						
					$("#contactus_restStateSelect").attr("name","vpreferredRestaurantState");
					$("#contactus_restaurantName").attr("name","vpreferredRestaurant");
				});
	       });
$('.orderTypeRadio').click(function()
		{
		var dateOfVisit="Date of Visit";
		var timeOfVisit="Time of Visit";
		var dateOfDelivery="Date of Delivery";
		var timeOfDelivery="Time of Delivery";
		if($("#dateofvisit").length)
		{
		dateOfVisit=$("#dateofvisit").val();
		}
		if($("#timeofvisit").length)
		{
		timeOfVisit=$("#timeofvisit").val();
		}
		if($("#dateofdelivery").length)
		{
		dateOfDelivery=$("#dateofdelivery").val();
		}
		if($("#timeofdelivery").length)
		{
		timeOfDelivery=$("#timeofdelivery").val();
		}
	if ($("input[name=pickUporDeliveryOrder]:checked").length != 0) {
		//$("input[name=pickUporDeliveryOrder]:checked").parent().addClass("radio_checked");
		if($("#togo_OnlineOrderPickup_radio").is(':checked')){
			document.getElementById("beanvaluepickUporDelivery").value = $("#togo_OnlineOrderPickup_radio").data("type");
			$("#contactUsOptionsiId label[for='datepickercontactus']").text(dateOfVisit);
			$("#contactUsOptionsiId label[for='timepicker']").text(timeOfVisit);
			$("#togo_OnlineOrderPickup_radio").closest('div').addClass("radio_checked");
			$("#togo_OnlineOrderDelivery_radio").closest('div').removeClass("radio_checked");
		}
		if($("#togo_OnlineOrderDelivery_radio").is(':checked')){
			document.getElementById("beanvaluepickUporDelivery").value = $("#togo_OnlineOrderDelivery_radio").data("type");
			$("#contactUsOptionsiId label[for='datepickercontactus']").text(dateOfDelivery);
			$("#contactUsOptionsiId label[for='timepicker']").text(timeOfDelivery);
			$("#togo_OnlineOrderDelivery_radio").closest('div').addClass("radio_checked");
			$("#togo_OnlineOrderPickup_radio").closest('div').removeClass("radio_checked");
		}
		}
		});
				$(document).on('keypress change', '#phone-ctn1, #phoneExt,#loyaltyMemberPhone', function(e) {
			if (e.which > 31 && (e.which < 48 || e.which > 57)) {
				e.preventDefault();
			}
		});
		$(document).on('keypress','#phone-ctn1,#loyaltyMemberPhone', function(e)
			    {
			        var l=$(this).val().length;
			        var text = $(this).val();
			        var isNumber = (e.which > 47 && e.which < 58) || (e.which > 95 && e.which < 106);
			        if(isNumber) {
				        if (l<=4) {
				        	for(var i=0;i<=l;i++){

				        		var codeA = text.charCodeAt(i);
				        		if(codeA > 31 && (codeA < 48 || codeA > 57))
				        			{
				        			 $(this).val(text.replace(/(\d{3})\)?/g,'$1)'));
				        			 return true;
				        			}

				        	}
							/** alm 7526 change start  **/
				        	$(this).val(text.replace(/(\d{3})\)?/g,'($1) '));
				        	return true;
							/** alm 7526 change end **/
				        }
				        if (l==9){
				            $(this).val(text.replace(text, text +'-'));
				            return true;
				        }
			        }
			    });
				$(document).on('focusout','#phone-ctn1', formatPhoneNumber);
					if ($('#phone-ctn1').length > 0 ) {
		formatPhoneNumber();
	}
		function formatPhoneNumber(input) {
		var input = $('#phone-ctn1');
		var numsOnly = input.val().replace(/\D/g, '');
		if (numsOnly.length >= 10) {
				$(this).removeClass("err-border-value");
				$(".Phone-num-err").css("display","none");
			input.val(input.val().replace(/\D/g, ''));
	}
		input.val(input.val().replace(/(\d{3})(\d{3})(\d{4})/,'($1) $2-$3'));
		if (input.val().length > 14) {
			input.val(input.val().slice(0, 13));
		}
	}
				if ($('#phone-ctn1').length > 0 ) {
				formatPhoneNumber($('#phone-ctn1'));
			}

/* contact us form changes end */
/* INC45425  -- sunil */
 $(document).ready(function(){
        $('#idAmount').click(function(){
	  
        	
        	var total=$("#total").text().trim().split('$'); 
			var parsedTotal = parseFloat(total[1]).toFixed(2);;
	      $('#idAmount').focusout(function(){
		  var inputValue = $('#idAmount').val();
		 var parsedValue = parseFloat(inputValue);
		 res=parsedValue.toFixed(2);
		      if( parsedTotal > parsedValue )
			  {
			  $('#idAmount').val(res);
			  }
			 else
			  {
			   $('#idAmount').val(parsedTotal);
			  }
        	
		 });
		  });
		 /* INC45425  -- sunil */

        if ($("#language").val() == 'es') {
        	if ($("#occationNamesRB").length) {
        	var occationRB = $("#occationNamesRB").val();
        	var occationValue = $("#occasionValues").val();
        	var options = occationRB.split(",");
        	var values = occationValue.split(",");

        	var select = document.getElementById('cd-occation-type');
        	select.options[0] = new Option("Especificar su ocasión (opcional)", "");
        	for(var i=1,j=0; i<=options.length; i++,j++)
        	{

        	  select.options[i] = new Option(options[j], values[j]);  //new Option("Text", "Value")

        	}
        	}
        }
		/* INC111800  -- sunil*/
		 $(".cd-occasion .cd-select-occasion option").each(function(){
            //alert($(this).text() +" "+$(this).text().length);
			if($(this).text().length > 47)
			{
			 $('.cd-occasion').css('width','835px');
			  $('#cd-occation-type').css('width','835px');
			  $('.span5.txt-rgt.cd-occasion-text').css('float','left');
			}

        });
		/* INC111800  -- sunil*/
	  });

/*Accesibility changes*/
$(document).ready(
	function() {

$(".checkbox_d").attr("tabindex","0");
 $(".checkbox_d").on('keypress',function() {
                                var chekd = $(this).css("background-position");
                                //console.log(chekd );
                                if(event.charCode == 13) {
                                                if(chekd == "0% 0px"){
                                                  $(this).css('background-position','0% -24px');
												  $(this).find(":checkbox").attr('checked', true);
                                                }else
                                                {
                                                  $(this).css('background-position','0% 0px');
												  $(this).find(":checkbox").attr('checked', false);
                                                }
                                }
   });

/*$(".checkbox_d").focus(function(){
 var chekd = $(".checkbox_d :checkbox").attr("checked");
 //alert(chekd);
   $(this).on('keypress',function() {
     if(event.charCode == 13) {
	  if(chekd != "checked"){
			$(this).find(":checkbox").attr('checked', true);
            $(this).css('background-position','left -24px');
	 }else
	 {
	  $(this).find(":checkbox").attr('checked', false);
      $(this).css('background-position','left 0');
	 }
    }
   });

});
*/
/*$(".checkbox_d").attr("tabindex","0");
$(".checkbox_d").focus(function(){
$(this).on('keypress',function() {
if(event.charCode == 13) {
    $(this).toggleClass("demo");
	//alert("class added");
	if($(".checkbox_d").hasClass("demo"))
	{
	  $(this).find("input").attr("checked","checked");
	}
	else
	{
	 $(this).find("input").removeAttr("checked","checked");
	}
  }
});
}); */
		/*	$(".checkbox_d").attr("tabindex","0");
$(".confirm-check .checkbox_d").focus(function(){
                $(this).on('keypress',function() {
                                if(event.charCode == 13) {
                                    $(this).find("input").trigger("click");
									var checked = $(this).find("input").is(':checked');
									var input = $(this).find("input");
									//console.log(checked);
									setTimeout(function(){
									$(input).prop("checked", checked);
									if(!checked)
									$(input).removeAttr('checked');
									else
									$(input).attr('checked', 'checked');
									//console.log(input);
									}, 10)

                                }

                });

}); */

						  $("#datepicker").focus(function(){
						  $("#ui-datepicker-div").prepend('<button type="button" class="test" autofocus></button>');
						  $("#ui-datepicker-div").attr("tabindex","0");
						  $(".ui-datepicker-calendar").attr("tabindex","0");
						 $("a.ui-state-default").attr("tabindex","0");
						 	$(".ui-state-default").focus(function(){
					$(this).attr('alt',$(this).text())
				});

                    });
  $(".mobalbox").prepend('<button type="button" class="test" autofocus></button>');

  /* choose giftcard page tab accesibility starts */

    $("#addGCItemToOrderId").removeAttr("href");
	$("#addGCItemToOrder").attr("tabindex","0");
	$("#addGCItemToOrder").focus(function(){
	  $(this).keypress(function(e){
		 if(e.which==13)
		 {
		   $(this).trigger("click");
		 }
	  });
	});
   /* choose giftcard page tab accesibility starts */
   /*Notify recipent by email checkbox starts */
   $(".css-label").attr("tabindex","0");
 $(".css-label").on('keypress',function() {
                                //var chekd = $(this).css("background-position");
                                //console.log(chekd );
								$("#notifyRecipientChkBox0").css("display","none");
                                if(event.charCode == 13) {
									$(this).trigger("click");
                                }
   });
   /*Notify recipent by email checkbox ends */
   /* ADD NEW ADDRESS  button js */
   $("#addShipAddress span").attr("tabindex","0");
	$("#addShipAddress span").focus(function(){
	  $(this).keypress(function(e){
		 if(e.which==13)
		 {
		   $(this).trigger("click");
		 }
	  });
	});

  /* ADD NEW ADDRESS  button js */
}
/*Accesibility changes end*/
);

$(document).on("click", "#waitlist_offers", function() {
	if($('#waitlist_offers').prop("checked") == true && $("#DOBMandatoryonSignup").val() == 'true'){
	$("#brandOptionDOBDiv").show();
  } else{
	$("#brandOptionDOBDiv").hide();
  }
});

function waitlistdata(){
    var newWait = $(".waitlistnum_new").length > 0 ;
	if (newWait > 0){
		if($('#wl_pos_call_ref_enabled').val() == "true"){
			getWaitPosition();
		}
	}
}
function getWaitPosition(){
	 $.ajax({
	  url: '/ajax/waitlist-esttime-and-position.jsp',
	  type: 'post',
	  success: function(response){
		var getWlistPosition =  $(response).filter("#waitListJson").data("options").positionInWaitList;
		if (getWlistPosition == "" || getWlistPosition == null || getWlistPosition == undefined) {
			//$('#joinWaitListModal').modal('hide');
			//location.reload(true);
			$("#autoRemoveWaitListModal").show();
			$("#autoRemoveWaitListModal").removeClass("showhidewlautoremove");   
			$("#wlautoremove_eff").addClass("modal-backdrop fade in"); 
		}
		else {
			if (getWlistPosition == "0" || getWlistPosition == "1"){
				if ((location.href.indexOf('.com/es/') > -1)) {
					var nextPosition = "próximo en la fila";
					$('#wlposition').attr("style","display:none");
			    	$('.wl-text').attr("style","display:none");
					$('#nextposition_text').html(nextPosition);
				}
				else{
					var nextPosition = "You are next in line!";
					$('#wlposition').attr("style","display:none");
			    	$('.wl-text').attr("style","display:none");
					$('#nextposition_text').html(nextPosition);					
				}
			}
			else {
				$('#wlposition').removeAttr("style");
			    $('.wl-text').removeAttr("style");
				$('#nextposition_text').removeAttr("style");
			var addPosition = ["th","st","nd","rd"], vnum =getWlistPosition%100;
			var lastn = (addPosition[(vnum-20)%10]||addPosition[vnum]||addPosition[0]);	
			$('#wlposition').html(getWlistPosition+(lastn).sup());
		}
	  }
	  }
 });
}setInterval(waitlistdata,180000);
function showFranchiseModal(){
    //var getTogoRestPh = $("#franchiseTogo").attr("data-franchise");
    $("#franchiseModal").toggle();
    $("#franchiseModal").removeClass("franshide");   
    $("#franchise_eff").addClass("modal-backdrop fade in"); 
    //$("#franchise_restphno").html(getTogoRestPh);   
}

// Waitlist phase-2 JAN-19 rel enhancement
$(document).on("click", "#shareWLConfirmationInfo", function() {
	var wl_email = $("#confirm_waitList_email").val();
    var wl_subject = $("#confirm_waitList_email_subject").val();
    var wl_brandname = $("#confirm_waitList_siteName").val();
    var wl_fname = $("#confirm_waitList_fName").val();
    var wl_body1 = $("#confirm_waitList_email_body1").val();
    var wl_body2 = $("#confirm_waitList_email_body2").val();
    var wl_body3 = $("#confirm_waitList_email_body3").val();
    var wl_guestsize = $("#guest_size_val").val();
    var wl_restname = $("#restNameLink").text();
    var wl_address1 = $("#confirm_waitList_address1").val();
    var wl_restcity = $("#confirm_waitList_city").val();
    var wl_reststate = $("#confirm_waitList_state").val();
    var wl_restphone = $("#confirm_waitList_phone").val();
    var wl_restzipcode = $("#confirm_waitList_zipCode").val();
	var wl_viewUrl = $("#view_wait_list_status").val();
	var wl_toViewConfirmationUrl = location.origin + wl_viewUrl;
 	var wl_textForSymbol = '%26';
	var isWebShareTrue = "shareWLInfo=true";
	var wl_urlForEmailShare = wl_toViewConfirmationUrl.substr(0, wl_toViewConfirmationUrl.indexOf("&"));
 	var emailBody = 'mailto:' + wl_email + '?subject=' + wl_subject +' ' + wl_brandname + '&body=' + wl_fname + ' ' 
		+ wl_body1 	+ ' ' + wl_guestsize + ' ' + wl_body2 + ' ' + wl_brandname + ' - ' + wl_restname + ', ' + wl_address1 + ', ' 
		+ wl_restcity + ', ' + wl_reststate + ' ' + wl_restzipcode + ', ' + wl_restphone + '. ' + wl_body3 + ' ' + wl_urlForEmailShare 
		+ wl_textForSymbol + isWebShareTrue; 
	window.location = emailBody;
    var wlistEmailTimer;     
	$(window).blur(function() {
		clearTimeout(wlistEmailTimer);
    });
	wlistEmailTimer = setTimeout(function() {
		$("#enterEmailWaitList").trigger("click");
	}, 5000);
}); 
$(window).on('load', function() {
  if($.cookie("DRIRESTAURANTID") && !isToGoOneColumnTemplate()){
    
    var headerUrl = "/ajax/headerlocation.jsp?restNum="+$.cookie("DRIRESTAURANTID");
$.get( headerUrl, function( data ) {
            	
          	locationCookie = JSON.parse(data)
          	sessionStorage.setItem('locationDetails',locationCookie.join("@@"));
          	setHeaderViaAjax();
});
}

/*pasta pass contactus change*/


$("#contactUsUrlId").on('click',function(){
    
	if(window.location.pathname.indexOf("specials/never-ending-pasta-pass/contact-us") > -1 ){
        			    sessionStorage.removeItem("radioToremember");
        	}
});

/*end*/


});

// This method is verify if current page's template is togo-onecolumnpage
function isToGoOneColumnTemplate() {
	return ($('#EMTemplateName').val() !== undefined || $('#EMTemplateName').val() === 'togo-onecolumnpage') ? true : false;
}

function setHeaderViaAjax(){
	// restID##restaurantName##latLong##address1##city##state##zipCode##phoneNumber##operationalHrs##onlineTogo##isNearest
	$('span#selected-location').hide();
	$('span#findRestaurantLink').show();
	//var locationCookie = $.cookie("DRIREST");
	if(locationCookie){
		//locationCookie = locationCookie.replace(/\*/g,',');
		//var locValues = locationCookie.split("@@");
		var locValues = locationCookie.slice();
		if(locValues.length > 0){
			// /state/city/restname/restNum
			var locURL = $('#locationURL').val()+"/"+locValues[5]+"/"+locValues[4]+"/"+locValues[1]+"/"+locValues[11];
			locURL = locURL.replace(/[^a-zA-Z0-9/]/g,'-');
			locURL = locURL.toLowerCase();
			/*Changes made for Multiple Hyphens Issue -Sai Priyanka */
			locURL=locURL.replace(/-{2,}/g, '-'); 
			
			// add links to location details
			$('#popRestNameLink').attr("href",locURL);
			$('#popRestHrsLink').attr("href",locURL);
			$('#popDirIconLink').attr("href",locURL);
			$('#popDirLink').attr("href",locURL);
			$('#popMapLink').attr("href",locURL);

			// set Rest_ID from cookie for SMS and Email
			$('#sms-current').attr("data-id",locValues[0]);
			$('#email-current').attr("data-id",locValues[0]);

			// lat_long
			var mapImg = "//media.olivegarden.com/en_us/images/marketing/italian-family-restaurant-olive-garden-g6-r1x1.jpg";								
					
			$("#mapImg").attr("src",mapImg);

			$('#latLong_header').val(locValues[2]);
			// rest name
			$('#headRestName').text(locValues[1]);
			$('#popRestName').text(locValues[1]);
			$('#overlayRestName').text(locValues[1]);
			$('#headRestName').text(locValues[1]);
			// rest phone number
			$('#headRestPhone').text(locValues[7]);
			$('#popRestPhone').text(locValues[7]);
			// rest address
			$('#popRestAdd1').text(locValues[3]);
			$('#popRestCity').text(locValues[4]);
			$('#popRestState').text(locValues[5]);
			$('#popRestZip').text(locValues[6]);
			// rest Op hours
			$('#popRestHrs').html(locValues[8]);
			//webahead change start
			if(locValues.length > 16)
                {
                	var lowEstimatedWaitTime=locValues[14] ;
                	var highEstimatedWaitTime=locValues[15] ;
				
                	var exactEstimatedWaitTime=locValues[16] ;
		
                	 if(exactEstimatedWaitTime == "~")
                 		exactEstimatedWaitTime=exactEstimatedWaitTime.replace("~","") ;
                 	if(lowEstimatedWaitTime == "~")
                 		lowEstimatedWaitTime=lowEstimatedWaitTime.replace("~","") ;
                 	if(highEstimatedWaitTime == "~")
                 		highEstimatedWaitTime=highEstimatedWaitTime.replace("~","") ;
				
                
                	if("false" == locValues[12])
                	{
                		if(exactEstimatedWaitTime!= "" && lowEstimatedWaitTime!= "" && highEstimatedWaitTime!= "")
                		{
                			if($('#enterWaitListOnLoad').text() == "")
                				$('#enterWaitListOnLoad').text("JOIN WAITLIST") ;
                			
                			$('#enterWaitListOnLoad').attr("data-url","/locations/webahead/join-wait-list?restID="+locValues[0]) ;
                			estimatedWaitTimePrefixStr="Current Wait: " ;
                			estimatedWaitTimeStr="" ;
					
                			if("false" == locValues[13])
                			{
                				estimatedWaitTimeStr = estimatedWaitTimePrefixStr + exactEstimatedWaitTime +" min" ;
				
                				if($('#estimatedWaitTimeLabelOnLoad').text() =="")
                					$('#estimatedWaitTimeLabelOnLoad').text(estimatedWaitTimeStr) ;
                			}
                		else
						{

							estimatedWaitTimeStr = estimatedWaitTimePrefixStr + lowEstimatedWaitTime + "-"	+ highEstimatedWaitTime + "min" ;
							$('estimatedWaitTimeLabelOnLoad').text(estimatedWaitTimeStr) ;
						}
                			
							$("#joinWaitListButtonOnLoad").attr("style", "visibility: visible") ;
				
                		}
                		else
                			{
                				$("#joinWaitListButtonOnLoad").width(0) ;
                			
                			}
					}
                }
                if(locValues.length > 12)
                	{
                		if("true" == locValues[12])
                		{
			
                			$("#waitlistlabelspanonLoad").attr("style", "visibility: visible") ;
                	
                			if($('#waitlistLabel').text() =="")
                			$('#waitlistLabel').text("ON WAITLIST") ;
						}
                		else
                			{
                				$('#waitlistLabel').width(0) ;
                			}
                	}
			//webahead change end
			
			//link to nutrition page
			$('span#findRestaurantLink').hide();
			$('span#selected-location').show();
			
			var welcomeConfigValue = $('#welcomeConfigValue').val();
			var pageURL = window.location+"";			
			if((pageURL.indexOf('/home') > -1 || pageURL.indexOf('/pagina-de-inicio') > -1) && locValues[10] == 'auto'){
				$("div#pop-up").show();
			    setTimeout('$("div#pop-up").hide()', parseInt(welcomeConfigValue));
			    locValues[10] = '~';
				locationCookie[10] = '~';
				var oldCookieVal = $.cookie("DRIREST");
			    oldCookieVal = oldCookieVal.replace(/(auto)/g, '~');
			    $.cookie("DRIREST", oldCookieVal, {expires: 365, path: "/"});
			}
			//var restId=locValues[0];
			//showCateringInHeader(restId);
		}
	}
}