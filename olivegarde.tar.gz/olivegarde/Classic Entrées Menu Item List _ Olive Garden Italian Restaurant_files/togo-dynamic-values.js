var onlineTogoEnabled, cartItemsCount, orderTypeValue;
/* 
	This is function makes a server call to get all the dynamic data that a page needs
	including profile, rewards, data layer, session settings etc and
	
	1. Render header with dynamic data
	2. updates configuration DOM elements with dynamic value
	3. Updates DTM data layer with dynamic data.
	4. Trigger the triggerReadyFunction() which does most of init stuff for the page
*/
function locationPageDynamicValues() {
    var data = {};
    var headerContentName = '';
    if ($("#headerContentName").val() != null && $("#headerContentName").val() != 'undefined' && $("#headerContentName").length > 0) {
        headerContentName = $("#headerContentName").val();
    }
    var headerContentLinkName = '';
    if ($("#headerContentLinkName").val() != null && $("#headerContentLinkName").val() != 'undefined' && $("#headerContentLinkName").length > 0) {
        headerContentLinkName = $("#headerContentLinkName").val();
    }
    var headerContentShowLogout = '';
    if ($("#headerContentShowLogout").val() != null && $("#headerContentShowLogout").val() != 'undefined' && $("#headerContentShowLogout").length > 0) {
        headerContentShowLogout = $("#headerContentShowLogout").val();
    }
    data.headerContentName = headerContentName;
    data.headerContentLinkName = headerContentLinkName;
    data.headerContentShowLogout = headerContentShowLogout;

    var locale = $('#currentLocale').length ? $('#currentLocale').val() : "";
    var request = $.ajax({
        url: "/web-api/session/details?locale=" + locale + "&fromPage=" + location.pathname,
        type: "GET",
        cache: false,
        data: data,
        ContentType: "application/json"
    });

    request.done(function(response) {
        if (response && response.successResponse) {
            var currentTimeStamp = response.successResponse.currentTime ? moment(response.successResponse.currentTime.time) : '';
            if (currentTimeStamp) {
                currentTimeStamp = getConvertRestTime(currentTimeStamp);
                sessionStorage.setItem('currentTime', currentTimeStamp);
            }
			/*online alcohol sale change*/
			if(response.successResponse.restaurantDetails){		    
			    sessionStorage.setItem('isAlcoholAllowedForDelivery',response.successResponse.restaurantDetails.isAlcoholAllowedForDelivery);
			    sessionStorage.setItem('isAlcoholAllowedForToGo',response.successResponse.restaurantDetails.isAlcoholAllowedForToGo);
			}            
            onlineTogoEnabled = response.successResponse.onlineTogoEnabled;
            cartItemsCount = response.successResponse.sessionContext.itemCount;
            orderTypeValue = response.successResponse.sessionContext.orderTypeValue;
            var actualPickupDate = response.successResponse.sessionContext.actualPickupDate;
            var actualPickupTime = response.successResponse.sessionContext.actualPickupTime;
            if (actualPickupDate)
                sessionStorage.setItem('actualPickupDate', actualPickupDate);
            if (actualPickupTime)
                sessionStorage.setItem('actualPickupTime', actualPickupTime);
        }
        removeSessionCartItems(response);
        if (response.shoeBoxAjaxContent) {
            var htmlResp = $("<div id=\"headerInclude\" ></div>");
            htmlResp.html(response.shoeBoxAjaxContent)
            if (response.successResponse && response.successResponse.profile &&
                response.successResponse.profile.transient && response.successResponse.profile.transient === true) {
                $("#logoutOption").hide();
                if (htmlResp.find("#myaccountTextAjax")) {
                    $("#loginOption").find("#myaccountText").html(htmlResp.find("#myaccountTextAjax").html());
                }
                $("#loginOption").show();
            } else {
                $("#logoutOption").show();
                $("#loginOption").hide();
                if ($("#shoeBox") && htmlResp.find("#shoeBoxAjaxContent")) {
                    $("#logoutOption").find("#shoeBox").html(htmlResp.find("#shoeBoxAjaxContent"));
                }
            }
        }
        // dtm objtect refresh on chached pages START
        if ($("#dtmenabled").val() == "true") {
            if (window.digitalData && response &&
                response.successResponse && response.successResponse.dataLayerJSON) {
                window.digitalData = JSON.parse(response.successResponse.dataLayerJSON);
                // dtm logged-in and fav modal event alert START
                if (window.sessionStorage) {
                    var loginAndFavEvent = sessionStorage.getItem("dtmEventAlert");
                    var dtmOTChngAlrt = sessionStorage.getItem("dtmOTChngAlrt");
                    var dtmCngRestAlrt = sessionStorage.getItem("dtmCngRestAlrt");
                    var rstRidId = sessionStorage.getItem("rstRidId");
                    var addtoCartEvent = sessionStorage.getItem("dtmAddtoCartEvent");
                    if (addtoCartEvent && addtoCartEvent === "true") {
                        var eventObj = {};
                        eventObj = JSON.parse(sessionStorage.getItem("addToCartEventObj"));
                        if (eventObj) {
                            window.digitalData.event = digitalData.event || [];
                            window.digitalData.event.push(eventObj);
                        }
                        if (window.digitalData && window.digitalData.event && window.digitalData.event.length > 0) {
                            $(window.digitalData.event).each(function(index, item) {
                                if (item) {
                                    var productDet = {};
                                    if (item.product) {
                                        productDet = item.product;
                                        if (productDet) {
                                            var modalData = {
                                                "eventName": "add-to-cart",
                                                "eventStatus": "success",
                                                "product": [productDet]
                                            }
                                            dtmModelEvents("CartEvent", modalData);
                                        }
                                    }
                                }
                            });
                        }
                        sessionStorage.removeItem("addToCartEventObj");
                        sessionStorage.removeItem("dtmAddtoCartEvent");
                    }
                    if (loginAndFavEvent && loginAndFavEvent === "loginAndFavEvent" &&
                        window.digitalData.event && window.digitalData.event.length > 0 &&
                        window.digitalData.event[0].eventInfo &&
                        window.digitalData.event[0].eventInfo.eventName &&
                        window.digitalData.event[0].eventInfo.eventName === "customerLogin") {

                        var modalLoginData = {
                            "eventName": "user-login",
                            "eventStatus": "success"
                        };
                        var modalFavData = {
                            "eventName": "add-favorite",
                            "eventStatus": "success"
                        };
                        dtmModelEvents("UserEvent", modalLoginData);
                        dtmModelEvents("UserEvent", modalFavData);
                        sessionStorage.removeItem("dtmEventAlert");
                    }
                    if (dtmOTChngAlrt && dtmOTChngAlrt === "otChanged") {
                        var modalData = {
                            "eventName": "change-type",
                            "eventStatus": "success",
                            "pickupType": 2
                        };
                        dtmModelEvents("CartEvent", modalData);
                        sessionStorage.removeItem("dtmOTChngAlrt");
                    }
                    if (dtmCngRestAlrt && dtmCngRestAlrt === "rstChanged") {
                        var restId = "";
                        var restName = "";
                        var restState = "";
                        var restZip = "";
                        if (digitalData.location && digitalData.location.locationInfo) {
                            restId = digitalData.location.locationInfo.locationId;
                            restName = digitalData.location.locationInfo.locationName;
                            restState = digitalData.location.locationInfo.locationState;
                            restZip = digitalData.location.locationInfo.locationZip;
                        }
                        var modalData = {
                            "eventName": "change-location",
                            "eventStatus": "success",
                            "locationInfo": {
                                "locationId": restId,
                                "locationRID": rstRidId,
                                "locationName": restName,
                                "locationState": restState,
                                "locationZip": restZip
                            }
                        };
                        dtmModelEvents("CartEvent", modalData);
                        sessionStorage.removeItem("dtmCngRestAlrt");
                        sessionStorage.removeItem("rstRidId");
                    }
                }
                // dtm logged-in and fav modal event alert END
            }
        }
        // dtm objtect refresh on chached pages  END
        $.each(response.successResponse.sessionContext, function(key, value) {
            if ($("#" + key).is("input")) {
                $("#" + key).val(value !== undefined ? value : '');
            } else {
                $("#" + key).text(value !== undefined ? value : '');
            }
        });

        var redirectLink = getUrlParameter("redirectURL") !== '' ? getUrlParameter("redirectURL") : response.successResponse.sessionContext.locRedirectTargetURL;

        var redirectToMenu = getUrlParameter("redirectToMenu");
        if (redirectToMenu !== undefined && redirectToMenu === 'false' && redirectLink !== '' && redirectLink !== undefined) {
            $("#redirectLink").val(redirectLink + "&setRestaurant=");
            $("#redirectToMenuPage").remove();
            $("#orderOnline").remove();
        } else {
            if (redirectLink !== '' && redirectLink !== undefined) {
                $("#redirectToMenuPage").val(true);
            }
            $("#redirectLink").remove();
        }

        var responseData = response && response.successResponse;
        var responseWebahead = response && response.successResponse && response.successResponse.webahead && response.successResponse.webahead.outputHTML;

        if (responseData.profile['firstName'] == undefined) {

            sessionStorage.setItem('AccountName', 'My Account');
        }

        if ($("#hb-placeholder-header-profile").length) {
            var source = document.getElementById("hb-template-header-profile").innerHTML;
            var template = Handlebars.compile(source);
            $("#hb-placeholder-header-profile").html(template(responseData));
        }

        if ($("#hb-placeholder-header-profile-bb").length) {
            var source = document.getElementById("hb-template-header-profile-bb").innerHTML;
            var template = Handlebars.compile(source);
            $("#hb-placeholder-header-profile-bb").html(template(responseData));
        }

        if ($("#hb-placeholder-header-profile-yh").length) {
            var source = document.getElementById("hb-template-header-profile-yh").innerHTML;
            var template = Handlebars.compile(source);
            $("#hb-placeholder-header-profile-yh").html(template(responseData));
        }

        if ($("#hb-placeholder-header-profile-tcb").length) {
            var source = document.getElementById("hb-template-header-profile-tcb").innerHTML;
            var template = Handlebars.compile(source);
            $("#hb-placeholder-header-profile-tcb").html(template(responseData));
        }

        if ($("#headerJoinWaitListLink").length) {
            if (responseWebahead) {
                $("#headerJoinWaitListLink").html(responseWebahead);
            }
        }
        // ALM 40642 catering delivery link from gc flow START
        if ($("a#orderOnlineId")) {
            if ($("a#orderOnlineId") && $("a#orderOnlineId").attr("href") && $("a#orderOnlineId").attr("href") === "/cart") {
                $("a#orderOnlineId").attr("href", "/menu-listing/catering");
            }
            if ($("a#orderOnlineId") && $("a#orderOnlineId").attr("href") && $("a#orderOnlineId").attr("href") === "/es/cart") {
                $("a#orderOnlineId").attr("href", "/es/menu-listing/catering");
            }
        }
        // ALM 40642 catering delivery link from gc flow END

        /* ALM 42884 - re-initializing variable "orderTypeValue" post session detail call 
        response processing to configure it based on current order type. 
        Otherwise value from Akamai cached page uses and causes some inconsistancy issues */
        if (orderTypeValue !== undefined) {
            orderTypeValue = $('#orderTypeValue').val();
        }
        // ALM 42884 - END

        /* initiating 86ed item check procedure on page load. This becomes prevalent as we blocked 
        ordersettings - init() before adding an item to cart for stability reasons.*/
        process86edItems();

    });

    request.always(function() {
        $(document).trigger('triggerReadyFunction');
    });

    if ($("#headerReserveLink").length) {
        $.get("/web-api/session/reservationinfo", function(data) {
            $("#headerReserveLink").html(data.outputHTML);
        });
    }
}

/** Script required for targeters to function - start **/
function invokeTargeters() {
    $("form[name^='execute-ajax-targeter-form']").each(function() {
        var $form = $(this);
        var formId = $form.attr('id');
        var containerId = $form.find("input[name='containerId']").val();
        fetchTargetedContent(formId, containerId);
    });
}

function fetchTargetedContent(formid, divid) {
    var $form = $('#' + formid);
    var url = $form.attr('action');
    $.each($form.serialize().split('&'), function(index, elem) {
        var vals = elem.split('=');
        if (vals[1] != null && vals[1].length > 0) {
            url = url + "&" + vals[0] + "=" + vals[1];
        }
    });

    if ($("#" + divid).length) {
        $.get(url, function() {})
            .done(function(responseContent) {
                $("#" + divid).html(responseContent);
                $("#" + divid).find("script").each(function() {
                    eval($(this).text);
                });
            });
    }
}
/** Script required for targeters to function - end **/

/** Heartbeats are used to ensure that the guest's session stays active beyond global session timeout set for the application. 
	
	heartbeatEnabled - To enable the feature at page level
	heartbeatIntervalMS - the frequency of heart beat call in mill seconds... value must be set lower than application session.timeout.ms
	heartbeatLimit - Number of times to trigger heartbeat.
*/
function triggerHeartbeat() {
    var heartbeatEnabled = $("#heartbeat-enabled").val();
    var heartbeatIntervalMS = $("#heartbeat-interval-ms").val();
    var heartbeatLimit = $("#heartbeat-limit").val();
    var heartbeatTimes = 0;
    if (heartbeatEnabled !== undefined && heartbeatEnabled === 'true' &&
        heartbeatIntervalMS !== undefined && heartbeatLimit !== undefined) {
        var heartbeatLooper = setInterval(function() {
            heartbeatTimes++;
            if (heartbeatTimes >= heartbeatLimit) clearInterval(heartbeatLooper);
            $.ajaxSetup({
                cache: false
            }); // This part addresses an IE bug.  without it, IE will only load the first number and will never refresh
            $.get("/web-api/session/heartbeat", function() {});
        }, heartbeatIntervalMS);
    }
}
var channel;
$(document).ready(function() {
    invokeTargeters();
    locationPageDynamicValues();
    triggerHeartbeat();
    channel = $('#channel').val();
    pymtMethodChkForAlcoholItems();
});

/** @description common Function 
 * @param {string} locale
 * @param {string} conceptCode
 */
function addSiteCodes(reqBdy) {
    if (reqBdy) {
        reqBdy['locale'] = $('#currentLocale').val();
        //reqBdy['conceptCode'] = $('#conceptCode').val();
    }
}

/** @description common Function
 * @param reqBody
 * @param {string} restaurantId
 * @param {string} date
 */
function addRestaurantDate(reqBody, restaurantId, date) {
    reqBody['restaurantId'] = restaurantId;
    reqBody['pickupDate'] = date;
}

/*
 * @description It converts the restaurant time to their local time
 * @param {string} currentTimeStamp (format milliseconds)
 * @return {string} time (format milliseconds) 
 */
function getConvertRestTime(currentTimeStamp) {
    moment.tz.add('America/New_York|EST EDT|50 40|01010101010101010101010|1BQT0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Rd0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0 Op0 1zb0|21e6');
    var timesx12 = currentTimeStamp ? moment.tz(currentTimeStamp, "America/New_York").format('h:mm A') : '';
    var defaultDate = moment(currentTimeStamp).format('YYYY/MM/DD ').toString();
    var time = new Date(defaultDate + timesx12).getTime();
    return time;
}

/** @description This function is used for getting ASAP actual time in the format ' 03:10 PM' 
 * @param {string} leadTime (format milliseconds)
 * @return {string} asapTime (format 03:10 PM)
 */
function getAsapTime(leadTime) {
    var asapTime;
    if (leadTime) {
        asapTime = moment(leadTime).format('hh:mm A').toString();
    }
    return asapTime;
}

/** @description This function is to evaluate if leadtime required crosses day 
 * @param {int} leadTime (format minutes)
 * @param {string} currentTime (format milliseconds)
 * @return {boolean} true / false
 */
function isLeadTimeCrossesDay(currentTime, leadTime) {
    return moment(currentTime).date() !==
        moment(currentTime).add(leadTime, 'm').date();
}

/** @description This function is used for getting ASAP actual time in the format ' 03:10 PM' 
 * @param {int} leadTime (format minutes)
 * @param {string} currentTime (format milliseconds)
 * @return {string} asapTime (format 03:10 PM)
 */
function getAsapTimeFromMins(leadTime, currentTime) {
    var asapTime;
    var defaultTime;

    if (currentTime)
        defaultTime = moment(currentTime);
    else
        defaultTime = moment().valueOf();

    if (leadTime) {
        asapTime = moment(defaultTime).add(leadTime, 'm').format('hh:mm A').toString();
    }
    return asapTime;
}

/** @description This function is used for adding leadTime to the currentTime 
 * @param {int} leadTime (format minutes)
 * @param {string} currentTime (format milliseconds)
 * @return {string} updatedTime (format milliseconds)
 */
function addLeadTimeToCurrent(leadTime, currentTime) {
    var updatedTime;
    var defaultTime;
    if (currentTime)
        defaultTime = moment(currentTime);
    else
        defaultTime = moment().valueOf();

    if (leadTime) {
        updatedTime = moment(defaultTime).add(leadTime, 'm').valueOf();
    }
    return updatedTime;
}

/** @description This function is used for calculating minutes between current time (03:00 PM) and lead time (03:30 PM)
 * @param {string} leadTime (format milliseconds)
 * @param {string} currentTime (format milliseconds)
 * @return {int} differenceInMinutes (format mm)
 */
function calculateMinutesFromNow(leadTime, currentTime) {
    var differenceInMinutes;
    if (leadTime) {
        var differenceInMs = moment(leadTime).diff(moment(currentTime)); // diff yields milliseconds
        var duration = moment.duration(differenceInMs); // moment.duration accepts milliseconds
        differenceInMinutes = Math.ceil(duration.asMinutes());
    }
    return differenceInMinutes;
}

/*
 * This method check if the selectedTime falls within interval time or not 
 * @param selectedTime (07:30 PM)
 * @param interval (5 minutes) 
 */
function validateIfAsapTime(selectTime, interval) {
    var isAsapTime = false;
    var minuteVal;
    var regEx = new RegExp("1[012]|[1-9]:[0-5][0-9] AM|PM");
    if (selectTime && selectTime.match(regEx)) {
        var minArray = selectTime.split(":");
        var minValue = minArray[1].split(" ");
        minuteVal = minValue[0];
    }
    if (minuteVal && interval) {
        if (minuteVal % interval > 0) {
            isAsapTime = true;
        }
    }
    return isAsapTime;
}

/*
 * This method round the time to the nearest nth minute
 * 
 * @param {int} minute (10 minutes)
 * @param {string) selectTime(2:15 PM)
 */
function roundToMinutes(minute, selectTime) {
    var ROUNDING = minute * 60 * 1000; /*ms*/
    var start = moment(selectTime, "hh:mm a");
    start = moment(Math.ceil((+start) / ROUNDING) * ROUNDING);
    start = start.format("h:mm A");
    return start;
}

/** @description Function to make the api call for capacity timeslots
 * @param {string} restaurantId
 * @param {string} date
 * @param {string} orderType
 * @param {function} successCallBack - success callback function
 url: 'http://localhost:7003/api/order/pickup/capacitytimeslots'
 */
function getCapacityTimeslots(reqBody) {
    if ($('#isCapacityCheckEnabled').val() == 'true') {
        addSiteCodes(reqBody);
        return $.ajax({
            url: '/web-api/order/pickup/capacitytimeslots',
            data: reqBody,
            cache: false,
            type: "get"
        });
    } else {
        // returning a fack deferred promise
        return $.Deferred().resolve("").promise();
    }
}

/*
 * Check if the selected timeslot is within start/end time
 * @param {string} selectedTimeslot (format 03:00 PM)
 * @param {array} unavailableSlots (array of unavailable slots)
 * @param {long} currentTime (format milliseconds)
 * @return {boolean} isAvailable (format true/false)
 */
function isAvailableTimeslot(selectedTimeslot, unavailableSlots, currentTime) {
    var isAvailable = true;
    var defaultDate;
    if (currentTime)
        defaultDate = moment(currentTime).format('YYYY/MM/DD ').toString();
    else
        defaultDate = moment().format('YYYY/MM/DD ').toString();

    var regEx = new RegExp("1[012]|[1-9]:[0-5][0-9] AM|PM");
    for (var i = 0; i < unavailableSlots.length; i++) {
        var startTime = unavailableSlots[i].startTime;
        var endTime = unavailableSlots[i].endTime;
        if (startTime != null && endTime != null && startTime.match(regEx) && endTime.match(regEx)) {

            var result = new Date(defaultDate + selectedTimeslot).getTime();
            var result1 = new Date(defaultDate + startTime).getTime();
            var result2 = new Date(defaultDate + endTime).getTime();

            if (result >= result1 && result <= result2) {
                isAvailable = false;
                break;
            }
        }
    }
    return isAvailable;
}

/*
 * Convert HH:mm:ss to hh:mm A format (13:00:00 to 01:00 PM) 
 */
function convertTimeToPM(selectedTime) {
    var time;
    if (selectedTime) {
        time = moment(selectedTime, 'HH:mm:ss').format('hh:mm A');
    }
    return time;
}

/*
 * Find the next available time in minutes for ASAP 
 * @param {string} selectedTimeslot (format 01:00 PM)
 * @param {array} availableSlots (array of available slots)
 * @param {long} maxAsapTime (format 01:00 PM)
 * @param {long} currentTime (format milliseconds)
 * @return {int} nextAvailableSlot (format mm)
 */
function findNextAvailableMinutes(selectedTimeslot, availableSlots, maxAsapTime, currentTime) {
    var nextAvailableSlot;
    var defaultDate;
    if (currentTime)
        defaultDate = moment(currentTime).format('YYYY/MM/DD ').toString();
    else
        defaultDate = moment().format('YYYY/MM/DD ').toString();

    var regEx = new RegExp("1[012]|[1-9]:[0-5][0-9] AM|PM");
    for (var i = 0; i < availableSlots.length; i++) {
        var startTime = availableSlots[i].startTime;
        var endTime = availableSlots[i].endTime;
        if (startTime != null && endTime != null && startTime.match(regEx) && endTime.match(regEx)) {
            var result = new Date(defaultDate + selectedTimeslot).getTime();
            var result1 = new Date(defaultDate + startTime).getTime();
            var result2 = new Date(defaultDate + endTime).getTime();
            var result3 = new Date(defaultDate + maxAsapTime).getTime();

            if (result1 < result && result2 < result) {
                continue;
            } else if (result1 > result && result1 > result3) {
                break;
            } else if (result >= result1 && result <= result2) {
                nextAvailableSlot = calculateMinutesFromNow(result, currentTime);
                break;
            } else if (result1 > result && result1 <= result3) {
                nextAvailableSlot = calculateMinutesFromNow(result1, currentTime);
                break;
            }
        }
    }
    return nextAvailableSlot;
}

/*
 * Find the updated timeslot if the selected timeslot is out of capacity (format 03:00 PM)
 *  
 * @param {string} selectedTimeslot (format 01:00 PM)
 * @param {array} availableSlots (array of available slots)
 * @param {string} maxAsapTime (format 10:30 PM)
 * @param {long} currentTime (format milliseconds) - This is just for converting to the current date of the selected restaurant
 * @return {string} nextAvailableSlot (format 03:00 PM)
 */
function findUpdatedTimeSlot(selectedTimeslot, availableSlots, maxAsapTime, timeInterval, currentTime) {
    var nextAvailableSlot;
    var defaultDate;
    if (currentTime)
        defaultDate = moment(currentTime).format('YYYY/MM/DD ').toString();
    else
        defaultDate = moment().format('YYYY/MM/DD ').toString();

    var regEx = new RegExp("1[012]|[1-9]:[0-5][0-9] AM|PM");
    for (var i = 0; i < availableSlots.length; i++) {
        var startTime = availableSlots[i].startTime;
        var endTime = availableSlots[i].endTime;
        if (startTime != null && endTime != null && startTime.match(regEx) && endTime.match(regEx)) {
            var result = new Date(defaultDate + selectedTimeslot).getTime();
            var result1 = new Date(defaultDate + startTime).getTime();
            var result2 = new Date(defaultDate + endTime).getTime();
            var result3 = new Date(defaultDate + maxAsapTime).getTime();

            if (result1 < result && result2 < result) {
                continue;
            } else if (result >= result1 && result <= result2) {
                nextAvailableSlot = selectedTimeslot;
                break;
            } else if (result1 > result && result1 <= result3) {
                nextAvailableSlot = roundToMinutes(timeInterval, startTime);
            } else if (result1 > result && result1 > result3) {
                break;
            }
        }
    }
    return nextAvailableSlot;
}

/** @description Function to check if the slot is available (capacity check) & safe before rendering the slot to user
 * @param {array} - pickTimeInMins - slot converted into minutes
 * @param {array} - picktime - slot in guest friendly format
 * @param {array} - unavailableSlots - array as returned by capacity call
 * @param {array} - safeSlots - array as returned by times call
 */
function isValidSlot(pickTimeInMins, picktime, unavailableSlots, safeSlots, currentTime) {
    var isSafeSlot = true;
    var isSlotAvailable = true;

    if (unavailableSlots && unavailableSlots.length > 0) {
        isSlotAvailable = isAvailableTimeslot(picktime, unavailableSlots, currentTime);
    }

    if (isSlotAvailable && safeSlots && safeSlots.length > 0) {
        isSafeSlot = checkIfSafeSlot(pickTimeInMins, safeSlots);
    }

    if (isSafeSlot && isSlotAvailable)
        return true;
    else
        return false;
}

/** @description Function  to check if the give pickup time in minutes is safe to deliver or not
 * @param {Number} - pickTimeInMins - the slot that needs the check.
 * @param {array} - safeSlots - array as returned by times call
 */
function checkIfSafeSlot(pickTimeInMins, safeSlots) {
    var safeSlotsArr = safeSlots.filter(function(val) {
        return val !== ''
    });
    var isSafe = false;

    for (var i = 0; i < safeSlotsArr.length; i++) {
        var safeSlot = safeSlotsArr[i].split('#');
        var safeStart = safeSlot[0];
        var safeEnd = safeSlot[1];
        var safeStartMin = parseTime(safeStart);
        var safeEndMin = parseTime(safeEnd);
        if (pickTimeInMins >= safeStartMin && pickTimeInMins <= safeEndMin) {
            isSafe = true;
            break;
        }
    }
    return isSafe;
}

/** @description Function  to check if the CartItems is not available 
 * @param {response} - to check orderId
 */
function removeSessionCartItems(response) {
    var detailsValues = response && response.successResponse && response.successResponse.sessionContext;
    if (detailsValues && detailsValues != undefined) {
        var detailOrderId = detailsValues.orderId;
        var detailOrderVersion = detailsValues.orderVersion;
    }
    var cartItems = sessionStorage.getItem('CartItems');
    if (cartItems && cartItems != undefined) {
        var cartItemsJson = JSON.parse(cartItems);
        var cartItemsValues = cartItemsJson && cartItemsJson.successResponse && cartItemsJson.successResponse.order;
        if (cartItemsValues) {
            var cartItemsOrderId = cartItemsValues.orderId;
            var cartItemsOrderVersion = cartItemsValues.orderVersion;
        }
    }
    if ((detailOrderId && cartItemsOrderId && detailOrderId != cartItemsOrderId) || (detailOrderVersion != undefined && cartItemsOrderVersion != undefined && detailOrderVersion != cartItemsOrderVersion)) {
        sessionStorage.removeItem('CartItems');
    }
}

function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1);
    var sURLVariables = sPageURL.split('&');
    for (var i = 0; i < sURLVariables.length; i++) {
        var sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == sParam) {
            return sParameterName[1];
        }
    }
}

/** @description Function to make the api call for pickup time
 * @param {string} restaurantId
 * @param {string} date
 * @param {string} ordreType
 */
function getPickupTimeApi(reqBody) {
    reqBody['capacityEnabled'] = $('#isCapacityCheckEnabled').val().trim();
    addSiteCodes(reqBody);
    return $.ajax({
        url: '/web-api/order/pickup/times',
        data: reqBody,
        cache: true,
        type: "get"
    });
}


/**
 * Formats the zip code
 * 
 * @param {string} zipCode
 * @param {string} country
 * @returns formatted zip code
 * @todo Add any other zip code formatting here
 */
function formatZipCode(zipCode, country) {
    if (country == 'US')
        return zipCode.substr(0, 5); // only postal is enough for US location
    return zipCode;
}

function asapErrorDateTimeChangeHandler(val) {
    var restaurantId = $('#selected-Resid').val();
    if (!restaurantId) {
        restaurantId = getCookie('DRIREST', 0);
    }
    var asapcurrentdate = moment(val.date._d).format('MM/DD/YYYY');
    var reqBody = {
        'asapSelected': false,
        'restaurantId': restaurantId,
        'pickupDate': asapcurrentdate,
        'orderType': $('#orderTypeValue').val()
    };
    getPickupTimeApi(reqBody).done(function(response) {
        asapUpdateTimeslots(response, 'asap-timelist1');
    });
}

/** @description Function to make the api call for number of partSize
 * @param {string} partySize
 */
function partySizeApi(partySize, successCallBack) {
    var reqBody = {
        "partySize": partySize
    };
    addSiteCodes(reqBody);
    return $.ajax({
        url: '/web-api/ordersettings/setPartySize',
        data: reqBody,
        type: "POST"
    }).done(function(response) {
        var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;
        if (expResponse == 'sessionExpired') {
            $("#sessionExpired").modal('show');
        } else {
            successCallBack(response);
        }
    });
}

function pad(str, max) {
    str = str.toString();
    return str.length < max ? pad("0" + str, max) : str;
}

function parseTime(s) {
    if (s) {
        var c = s.split(':');
        return parseInt(c[0]) * 60 + parseInt(c[1]);
    }
}

/** @description util function for convert min to time */
function convertHours(mins) {
    var hour = Math.floor(mins / 60);
    var mins = mins % 60;
    var converted = pad(hour, 2) + ':' + pad(mins, 2);
    return converted;
}

/**
 * @description Function to get the end time after checking the safetimeslot
 * @param {endTime} restaurant start time
 * @param {safeTimeSlot} safe time slot
 */
function getEndTime(endTime, safeTimeSlot) {
    var time = endTime;
    if ($('#orderTypeValue').val() == "2" && safeTimeSlot) {
        var safetimeslotValue = safeTimeSlot.split("#");
        if (safetimeslotValue.length == 2) {
            if (endTime > safetimeslotValue[1]) {
                time = safetimeslotValue[1];
            }
        }
    }
    return time;
}

/**
 * @description Function to get the start time after checking the safetimeslot
 * @param {startTime} restaurant start time
 * @param {safeTimeSlot} safe time slot
 */

function getStartTime(startTime, safeTimeSlot) {
    var time = startTime;
    if ($('#orderTypeValue').val() == "2" && safeTimeSlot) {
        var safetimeslotValue = safeTimeSlot.split("#");
        if (safetimeslotValue.length == 2) {
            if (startTime < safetimeslotValue[0]) {
                time = safetimeslotValue[0];
            }
        }
    }
    return time;
}

/** @description Function to make the leadtime exit from asapCutoffTime  
 * @param {string} response  to calculate current time + leadtime added to crate new time slot
 * @param {string} locationAsapTime  to crate new time slot location modal
 */
function genrateNewTimeSlot(response, locationAsapTime, id, id1, unavailableSlots) {
    var pickUpTime = response && response.order && response.order.requestedPickupTime;
    if (!pickUpTime) {
        pickUpTime = response && response.actualPickupTime;
    }
    if (!pickUpTime) {
        pickUpTime = $('#default_jsondate').val();
    }
    var specificTime;
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    var leadTime = response && response.leadTime;
    if (!leadTime)
        leadTime = response && response.successResponse && response.successResponse.leadTime;
    specificTime = getAsapTimeFromMins(leadTime, currentTime);

    pickUpTime = getConvertRestTime(pickUpTime);
    var initialPickupDate = moment(pickUpTime).format("MM/DD/YYYY");
    var selectedTime = $('#' + id).val();
    var endDate = moment(initialPickupDate + ' ' + specificTime).format();
    var endTimestamp = moment(endDate).format("X");

    var timeList = document.getElementById(id);
    if (locationAsapTime) {
        timeList = document.getElementById(id1);
    }
    var arr = [];
    var regEx = new RegExp("1[012]|[1-9]:[0-5][0-9] AM|PM");
    if (timeList.options.length && timeList.options[0].value.match(regEx) && specificTime) {

        for (var y = 0; y < timeList.options.length; y++) {
            var startDate = moment(initialPickupDate + ' ' + timeList[y].value).format();
            var stratTimestamp = moment(startDate).format("X");
            if (parseInt(stratTimestamp) > parseInt(endTimestamp)) {
                arr.push(timeList[y].value);
            }
        }
        if (locationAsapTime) {
            $('#' + id1).empty();
            $.each(arr, function(key, value) {
                if (!unavailableSlots || isAvailableTimeslot(value, unavailableSlots, currentTime)) {
                    $('#' + id1).append($("<option></option>").attr("value", value).text(value));
                }
            });
            if (!unavailableSlots || isAvailableTimeslot(specificTime, unavailableSlots, currentTime)) {
                $('#' + id1).prepend("<option value='" + specificTime + "' selected='selected'>" + specificTime + "</option>");
            }
        } else {
            $('#' + id).empty();
            $.each(arr, function(key, value) {
                if (!unavailableSlots || isAvailableTimeslot(value, unavailableSlots, currentTime)) {
                    $('#' + id).append($("<option></option>").attr("value", value).text(value));
                }
            });
            if (!unavailableSlots || isAvailableTimeslot(specificTime, unavailableSlots, currentTime)) {
                $('#' + id).prepend("<option value='" + specificTime + "' selected='selected'>" + specificTime + "</option>");
            }

            if (sessionStorage.getItem('checkoutSelectedTime')) {
                $('#' + id).find("option[value='" + selectedTime + "']").attr("selected", true);
                sessionStorage.removeItem('checkoutSelectedTime')
            }
        }
    }
}

/** @description Function to make the leadtime exit from asapCutoffTime  
 * @param {string} response  to calculate current time + leadtime added to crate new time slot
 * @param {string} setPickupTimeCall  timepicker on change handler
 */
function checkoutGenrateNewTimeSlot(response, setPickupTimeCall, datepickerChange) {
    if (datepickerChange || !setPickupTimeCall) {
        var pickUpTime = response && response.order && response.order.requestedPickupTime;
        if (!pickUpTime) {
            pickUpTime = response && response.actualPickupTime;
        }
        if (!pickUpTime) {
            pickUpTime = $('#checkout-datetimepicker').val();
        }
        var specificTime;
        var currentTime = sessionStorage.getItem('currentTime');
        if (currentTime)
            currentTime = Number(currentTime);
        var leadTime = response && response.leadTime;
        if (!leadTime)
            leadTime = response && response.successResponse && response.successResponse.leadTime;

        specificTime = getAsapTimeFromMins(leadTime, currentTime);

        pickUpTime = getConvertRestTime(pickUpTime);
        var initialPickupDate = moment(pickUpTime).format("MM/DD/YYYY");

        var selectedTime = $('#select-time-list').val();
        var endDate = moment(initialPickupDate + ' ' + specificTime).format();
        var endTimestamp = moment(endDate).format("X");

        var timeList = document.getElementById("select-time-list");
        var arr = [];
        if (timeList.options.length && specificTime) {
            for (var y = 0; y < timeList.options.length; y++) {
                var startDate = moment(initialPickupDate + ' ' + timeList[y].text).format();
                var stratTimestamp = moment(startDate).format("X");
                if (parseInt(stratTimestamp) > parseInt(endTimestamp)) {
                    arr.push(timeList[y].text);
                }
            }
            $('#select-time-list').empty();
            $.each(arr, function(key, value) {
                $('#select-time-list').append($("<option></option>").attr("value", value).text(value));
            });

            if (specificTime) {
                $('#select-time-list').prepend("<option value='" + specificTime + "'>" + specificTime + "</option>");
            }
            $("#select-time-list").find("option[value='" + selectedTime + "']").attr("selected", true);
            if (sessionStorage.getItem('menuSelectedTime')) {
                sessionStorage.removeItem('menuSelectedTime')
            }
        }
    }
}

/** @description Function to convert minutes to hours
 * @param {array} number of minutes
 */
function getTimeFromMins(mins) {
    if (mins >= 24 * 60 || mins < 0) {
        // throw new RangeError("Valid input should be greater than or equal to 0 and less than 1440.");
    }
    var h = mins / 60 | 0,
        m = mins % 60 | 0;
    var hm, splitH, hoursMinutes;
    var hourstext = 'hour',
        minutext = 'min';
    if (h > 1) {
        hourstext = 'hours';
    }
    if (m > 1) {
        minutext = 'mins';
    }
    if (m == 0) {
        hoursMinutes = h + ' ' + hourstext;
    } else {
        hoursMinutes = h + ' ' + hourstext + ' ' + m + ' ' + minutext;
    }
    return hoursMinutes;
}

/** @description Function to get restaurant id from cookie
 * @param {string} key - restaurant key
 * @param {string} indexVal - return value based on array index
 */
function getCookie(key, indexVal) {
    var locationCookie = $.cookie(key);
    if (locationCookie) {
        locationCookie = locationCookie.replace(/\*/g, ',');
        var locValues = locationCookie.split("@@");
        if (locValues.length > 0) {
            if (!isNaN(indexVal)) {
                return locValues[indexVal];
            } else {
                return {
                    restaurantId: locValues[0],
                    restaurantName: locValues[1],
                    latLong: locValues[2],
                    addressCity: locValues[3] + ', ' + locValues[4] + ', ' + locValues[5] + ' ' + locValues[6],
                    address: locValues[3],
                    city: locValues[4] + ', ' + locValues[5] + ' ' + locValues[6],
                    phone: locValues[7]
                }
            }
        }
    }
    return '';
}

/* Format phone number field */
function formatPhoneNumber4(input) {
    var input = $('#loyaltyMemberPhone');
    var numsOnly = input.val().replace(/\D/g, '');
    if (numsOnly.length >= 10) {
        input.val(input.val().replace(/\D/g, ''));
    }
    input.val(input.val().replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3'));
    if (input.val().length > 14) {
        input.val(input.val().slice(0, 13));
    }
}

/* Checkout page - Car side API call */
function carSideApiHandler(response) {
    $.ajax({
        url: '/web-api/order/carsidepickup/check-avail',
        data: {},
        type: "POST"
    }).done(function(response) {
        if (response.successResponse) {
            checkAvailCarside(response);
        }
    });
}

/* Checkout page - if CurbSide Available */
function checkAvailCarside(response) {
    if ($("#carside-available-checkout").length > 0) {
        var checkCurbSideAvailable;
        var carServiceSession = $('#carServiceSession').val();
        if (response) {
            var curbSideAvailResp = response.successResponse.curbSideAvailable != null ? response.successResponse.curbSideAvailable : "";
            checkCurbSideAvailable = curbSideAvailResp;
        } else {
            checkCurbSideAvailable = $("#curbSideAvailable").val();
        }
        if ((checkCurbSideAvailable && checkCurbSideAvailable == "true") && (carServiceSession && carServiceSession == "true" || carServiceSession == "null" || carServiceSession == "")) {
            if ($("#carSideCheck") && $("#carSideCheck").prop('checked') == true) {
                $("#carService").val(true);
            } else {
                $("#carService").val(false);
            }
            $("#carside-available-checkout .available").removeClass("hidden");
            if (!($("#carside-available-checkout .not-available").hasClass("hidden"))) {
                $("#carside-available-checkout .not-available").addClass("hidden");
            }
        } else if ((checkCurbSideAvailable && checkCurbSideAvailable == "true") && (carServiceSession && carServiceSession == "false")) {
            $("#carService").val("false");
            $("#carside-available-checkout .available").removeClass("hidden");
            if (!($("#carside-available-checkout .not-available").hasClass("hidden"))) {
                $("#carside-available-checkout .not-available").addClass("hidden");
            }
        } else if (checkCurbSideAvailable == "false") {
            $("#carService").val(false);
            $("#carside-available-checkout .not-available").removeClass("hidden");
            if (!($("#carside-available-checkout .available").hasClass("hidden"))) {
                $("#carside-available-checkout .available").addClass("hidden");
            }
        }
    }
}

/* Render Checkout page - DateTimeTemplate */
function renderChceckoutDateTimeTemplate(selectedDate, time) {
    var isToday = moment(new Date()).format("MMM DD");
    var isTomorrow = moment(new Date()).add(1, 'days').format("MMM DD");
    var date = moment(selectedDate).format('MMM DD');

    if (!time || time.trim() == "")
        time = $('#noSlotAvaialbleMessage').val();

    if (isToday == date) {
        return "<span id='checkoutAsapTime'>" + time + "</span>";
    }
    if (isTomorrow == date) {
        return "<span id='checkoutAsapTime'>" + time + "</span>";
    }
    return "<span id='checkoutAsapTime'>" + time + "</span>";

}

/* Checkout page - Catering Rendering of Timeslots */
function cateringRenderTimeSlotOptions(startTime, endTime, interval, selectedValue, unavailableSlots, safeSlots) {
    var start = parseTime(startTime);
    var end = parseTime(endTime);
    var diff = parseInt(interval);
    var template = '';
    var endTime = '';
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);

    for (var i = start; i <= end; i = i + diff) {
        var timeString = convertHours(i);
        var timeFormat = moment(timeString, 'h:mm').format('h:mm A');
        var selected = (selectedValue === timeFormat) ? 'selected' : '';
        if ((unavailableSlots && unavailableSlots.length > 0) || (safeSlots && safeSlots.length > 0)) {
            if (i == end) {
                var endTimeAdjusted = convertHours(i - 1);
                endTimeAdjusted = moment(endTimeAdjusted, 'h:mm').format('h:mm A');
                if (isValidSlot(i, endTimeAdjusted, unavailableSlots, safeSlots, currentTime)) {
                    template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
                }
            } else if (isValidSlot(i, timeFormat, unavailableSlots, safeSlots, currentTime)) {
                template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
            }
        } else {
            template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
        }
    }
    return template;
}

/* Asap Lead time calculator for Checkout page */
function asapLeadTimeCalc(response, setPickupTimeCall, datepickerChange, pickupDate, id) {
    var leadTime = parseInt(response && response.leadTime);
    var cutOffTime = response && response.asapCutoffTime;
    var asapEnabled = response && response.asapEnabled;
    var asapSelected = response && response.asapSelected;
    var currentTime = response && response.currentTime; //milliseconds

    if (currentTime)
        currentTime = getConvertRestTime(currentTime.time);
    if (!currentTime) {
        currentTime = sessionStorage.getItem('currentTime');
        currentTime = Number(currentTime);
    }
    var asapTime = getAsapTimeFromMins(leadTime, currentTime); // 11:30 PM
    var updatedAsapTime;
    var availableSlots;
    var asapThreshold = cutOffTime;
    var restaurantId = getCookie('DRIREST', 0);
    var reqBody = {
        'orderType': orderTypeValue,
        'restaurantId': restaurantId,
        'pickupDate': pickupDate
    };

    if (leadTime && cutOffTime) {
        $('#checkout-asapdate #leadTime').empty();
        updatedAsapTime = leadTime;
        var maxTime = getAsapTimeFromMins(asapThreshold - 1, currentTime);

        if (response && response.capacitySlots) {
            availableSlots = response.capacitySlots.availableSlots;
            if (availableSlots && availableSlots.length > 0) {
                updatedAsapTime = findNextAvailableMinutes(asapTime, availableSlots, maxTime, currentTime);
            }
            asapUpdateTime(response, cutOffTime, asapEnabled, asapSelected, updatedAsapTime, setPickupTimeCall, datepickerChange, id);
        } else if (pickupDate) {
            getCapacityTimeslots(reqBody).done(function(responseCapacity) {
                if (responseCapacity && responseCapacity.successResponse && responseCapacity.successResponse.capacitySlots) {
                    availableSlots = responseCapacity.successResponse.capacitySlots.availableSlots;
                    if (availableSlots && availableSlots.length > 0) {
                        updatedAsapTime = findNextAvailableMinutes(asapTime, availableSlots, maxTime, currentTime);
                    }
                }
                asapUpdateTime(response, cutOffTime, asapEnabled, asapSelected, updatedAsapTime, setPickupTimeCall, datepickerChange, id);
            });
        } else {
            asapUpdateTime(response, cutOffTime, asapEnabled, asapSelected, updatedAsapTime, setPickupTimeCall, datepickerChange, id);
        }
    }
}

/* Checkout page - Specific Date Event */
function checkoutSpecificDateEvent(timeVal, id) {
    $('#' + id).show();
    var dateVal = $('#checkout-datetimepicker').val();
    if (!timeVal)
        timeVal = $('#select-time-list').val();
    if (sessionStorage) {
        if (referrer && referrer.indexOf("/locations/location-search") !== -1) {
            if (dateVal && sessionStorage.getItem("chkSelDate") &&
                sessionStorage.getItem("chkSelDate") !== dateVal) {
                sessionStorage.setItem("chkSelDate", dateVal);
                $('#ordertype-selected-day-errormodal').modal('show');
            } else if (timeVal && timeVal.trim() == "" && sessionStorage.getItem("chkSelTime") &&
                sessionStorage.getItem("chkSelTime") !== timeVal) {
                sessionStorage.setItem("chkSelTime", timeVal);
                $('#ordertype-selected-day-errormodal').modal('show');
            } else if (timeVal && sessionStorage.getItem("chkSelTime") &&
                sessionStorage.getItem("chkSelTime") !== timeVal) {
                sessionStorage.setItem("chkSelTime", timeVal);
                $('#ordertype-selected-rest-errormodal').modal('show');
            }
            referrer = location.pathname;
        } else {
            sessionStorage.setItem("chkSelDate", dateVal);
            sessionStorage.setItem("chkSelTime", timeVal);
        }
    }
    var template = renderChceckoutDateTimeTemplate(dateVal, timeVal);
    $('#checkout-asapdate').html(template);
}

/** @description Checkout page - checkoutMoreCookTimeValidation based on moreCookTimeFlag
 * make checkoutMoreCookTimeValidation
 * @param {object} response
 */
function checkoutMoreCookTimeValidation(response) {
    var moreCookVal = response && response.moreCookTimeFlag;
    var timeStamp = response && response.actualPickupTime && response.actualPickupTime.time;
    var checkoutOrderType = $('#orderTypeValue').val();
    if (checkoutOrderType != '2') {
        if (timeStamp) {
            var pickupTimeStamp = moment(timeStamp);
            pickupTimeStamp = getConvertRestTime(pickupTimeStamp);
            var selectedTime = moment(pickupTimeStamp).format('h:mm A');
            $('#select-time-list option:contains(' + selectedTime + ')').prop('selected', true);
        }
    }
    if (moreCookVal) {
        $('#pickupTimeUpdate').removeClass('hidden');
    } else {
        $('#pickupTimeUpdate').addClass('hidden');
    }
}

/* Added this dummy method to satisfy if(successCallBack == asapErrorUpdateTimeslots) 
 *  condition in updateDateApi method in togo-ordersettings-mobile.js 
 */
function asapErrorUpdateTimeslots() {}

/** @description Checkout page - update timeslots based on selected date
 * make update time slot api
 * @param {object} response
 */
function asapUpdateTimeslots(response, id) {
    var interval = response.interval;
    $('#' + id).empty();
    var selectedTime = $('#' + id).val();
    var bLunchHour = true;
    var bDinnerHour = true;

    var unavailableSlots;
    if (response && response.successResponse && response.successResponse.capacitySlots) {
        unavailableSlots = response.successResponse.capacitySlots.unavailableSlots;
    }

    if (response.times.lunch && response.times.lunch != "false") {
        var startTime = response.times.lunch.startTime;
        var endTime = response.times.lunch.endTime;
        var template = renderTimeSlotOptions(startTime, endTime, interval, selectedTime, unavailableSlots);
        if (!template) {
            bLunchHour = false;
        } else {
            $('#' + id).append(template);
        }
    }
    if (response.times.dinner && response.times.dinner != "false") {
        var dinnerStartTime = response.times.dinner.startTime;
        var dinnerEndTime = response.times.dinner.endTime;
        var template = renderTimeSlotOptions(dinnerStartTime, dinnerEndTime, interval, selectedTime, unavailableSlots);
        if (!template) {
            bDinnerHour = false;
        } else {
            $('#' + id).append(template);
        }
    }
    if (bLunchHour == false && bDinnerHour == false) {
        var template = '<option value=" " >' + $('#noSlotAvaialbleMessage').val() + '</option>';
        $('#' + id).append(template);
    }
}

/* Checkout page - ASAP validation */
function checkoutAsapValidation(response, setPickupTimeCall, datepickerChange, pickupDate, id) {
    var response = response && response.successResponse;
    var asapEnabled = response && response.asapEnabled;
    var asapSelected = response && response.asapSelected;
    if (asapEnabled) {
        $("label[for='checkout-asap']").show();
        if (asapSelected == true) {
            $('#checkout-asap').prop('checked', true);
            checkoutAsapEvent();
        } else {
            $('#checkout-specificdate').prop('checked', true);
            checkoutSpecificDateEvent(null, id);
        }
        asapLeadTimeCalc(response, setPickupTimeCall, datepickerChange, pickupDate, id);
    } else {
        $('#checkout-specificdate').prop('checked', true);
        $('label[for="checkout-asap"]').hide();
        checkoutSpecificDateEvent(null, id);
    }
}

/* Checkout page - Car side pickup */
function cartSidePickupChecked() {
    if ($("#carSideCheck").prop('checked')) {
        $('#carService').val('true');
        /*WO364517*/
        if ($("#carcolor-dropdwon li.selected").text()) {
            $("#carColor_bean").val($("#carcolor-dropdwon li.selected").text());
        } else if ($(".cartype-dropdwon button.selected").text()) {
            $("#carType_bean").val($(".cartype-dropdwon button.selected").text().trim());
        }
        if ($("#cartype_dropdown li.selected").text()) {
            $("#carType_bean").val($("#cartype_dropdown li.selected").text());
        } else if ($(".carcolor-dropdwon button.selected").text()) {
            $("#carColor_bean").val($(".carcolor-dropdwon button.selected").text().trim());
        }
        $(".checkout-pickup-dropdown,.checkout-carside-help").css("display", "block");
        $('#walk-in').css('display', 'none');
    } else {
        $('#carService').val('false');
        $("#carType_bean,#carColor_bean").val("");
        $(".checkout-pickup-dropdown,.checkout-carside-help").css("display", "none");
        $('#walk-in').css('display', 'block');
    }
    if ($('#orderTypeValue').val() == "0" && $('#currentLocale').val() === 'en_US') {
        if ($('#pay-online-continue').length > 0) {
            $(".checkout-payment-pay-online").css("display", "block");
            $(".checkout-pay-rest-btn").css({
                'border': 'none'
            });
        }
    }
}

/* Confirmation modal (global) - Date picker toggle */
function datePickerToggle(date) {
    var isToday = moment(date).isSame(moment(), "day");
    var selectedDate = moment(date).format("MMM DD");
    var todayDate;

    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    if (currentTime) {
        todayDate = moment(currentTime).format("MMM DD"); //moment(new Date()).format("MMM DD");	
    }

    if (todayDate == selectedDate) {
        $('#currentdate-field').text(selectedDate);
        $('#locationcurrent-date1').show();
    } else {
        $('#currentdate-field').empty();
        $('#locationcurrent-date1').hide();
    }
}

/** @description Function to render the template for location date and time
 * based on today
 * @param {string} date
 * @param {string} time
 */
function renderLocationDateTemplate(date, time) {
    var formatedDate = moment(date).format('MMM DD');

    var isToday;
    var isTomorrow;
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    if (currentTime) {
        isToday = moment(currentTime).format("MMM DD"); //moment(new Date()).format("MMM DD");	
        isTomorrow = moment(currentTime).add(1, 'days').format("MMM DD");
    }

    if (time != null)
        time = time.trim();
    if (time) {
        selectedTimeTxt = " <span id='atTime'>at</span> <span id='locselected-time'>" + time + "</span>";
    } else {
        selectedTimeTxt = unAvailableMsg;
    }

    if (isToday == formatedDate) {
        return "<span class='current-date-title' id='locationcurrent-date'>" + todaytxt + " (<span id='location_currentdate'>" + formatedDate + "</span>)</span>" + selectedTimeTxt;
    }
    if (isTomorrow == formatedDate) {
        return "<span class='current-date-title' id='locationcurrent-date'>" + tomorrowtxt + " (<span id='location_currentdate'>" + formatedDate + "</span>)</span>" + selectedTimeTxt;
    }
    return "<span class='current-date-title' id='locationcurrent-date'><span id='location_currentdate'>" + formatedDate + "</span></span>" + selectedTimeTxt;
}

/* ASAP updated time 
id = 'spacific-date-time' (desktop site)
     'checkout-specificdate' (mobile site)

*/
function asapUpdateTime(response, cutOffTime, asapEnabled, asapSelected, updatedAsapTime, setPickupTimeCall, datepickerChange, id) {
    if (updatedAsapTime && updatedAsapTime < cutOffTime) {
        $('#checkout-asapdate #leadTime, label[for="checkout-asap"] #leadTime').html(updatedAsapTime + ' mins');
        if (asapSelected) {
            $("#staticTimePicker .time_txt").html($('#checkout-asapdate').html());
            var staticTimePickerVal = $("#staticTimePicker .time_txt").html();
            if (staticTimePickerVal != null && !staticTimePickerVal.trim())
                $("#staticTimePicker .time_txt").html(unAvailableMsg_1);
        }
    } else {
        if (asapEnabled) {
            $("label[for='checkout-asap']").show();
            if (asapSelected == true) {
                $('#checkout-asap').prop('checked', true);
                checkoutAsapEvent();
            } else {
                sessionStorage.setItem('moreLeadFalse', true);
                $("label[for='checkout-asap']").hide();
                $('#checkout-specificdate').prop('checked', true);
                checkoutSpecificDateEvent(null, id);
                $("#staticTimePicker .time_txt").html($('#select-time-list').val());
                $("#selectedPickupTime").text($('#select-time-list').val());
            }
        } else {
            $('#checkout-specificdate').prop('checked', true);
            $('label[for="checkout-asap"]').hide();
            checkoutSpecificDateEvent(null, id);
            $("#staticTimePicker .time_txt").html($('#select-time-list').val());
            $("#selectedPickupTime").text($('#select-time-list').val());
        }

        var moreLeadFalse = sessionStorage.getItem('moreLeadFalse');
        if ((updatedAsapTime > cutOffTime && asapSelected === true) || (moreLeadFalse && moreLeadFalse == 'true' && updatedAsapTime > cutOffTime)) {
            sessionStorage.removeItem('moreLeadFalse');
            checkoutGenrateNewTimeSlot(response, setPickupTimeCall, datepickerChange);
            $('#checkout-specificdate').prop('checked', true);
            $('label[for="checkout-asap"]').hide();
            checkoutSpecificDateEvent(null, id);
            $("#staticTimePicker .time_txt").html($('#select-time-list').val());
            $("#selectedPickupTime").text($('#select-time-list').val());
        }
    }
    var staticTimePickerVal = $("#staticTimePicker .time_txt").html();
    if (staticTimePickerVal != null && !staticTimePickerVal.trim())
        $("#staticTimePicker .time_txt").html(unAvailableMsg_1);
}

/**
 *	@description This method update restaurant location when the restauarnt switch happens
 *	@param {object} reqBody - request body
 * 	@param {function} successCallBack - success callback function
 * 	@param {function} errorCallBack - error callback function
 */
function updateLocationApi(reqBody, successCallBack, errorCallBack, isSwitchRestaurant) {
    var isReloadPage = reqBody.removalCommerceIds || reqBody.validateCartItems;
    addSiteCodes(reqBody);
    $.ajax({
        url: '/web-api/restaurant/update',
        data: reqBody,
        type: "POST"
    }).done(function(response) {
        if (response.successResponse) {
            if (response.successResponse.isSiteCapacityAvailable && response.successResponse.restaurantDetails && response.successResponse.restaurantDetails.isCapacityAvailable) {
                if (response.successResponse.isSiteCapacityAvailable == true && response.successResponse.restaurantDetails.isCapacityAvailable == true) {
                    $('#isCapacityCheckEnabled').val(true);
                } else {
                    $('#isCapacityCheckEnabled').val(false);
                }
            } else {
                $('#isCapacityCheckEnabled').val(false);
            }
            successCallBack(response.successResponse, isReloadPage, false, isSwitchRestaurant);
        }
        if (response.errorResponse) {
            errorCallBack(response.errorResponse);
        }
    });
}

/** @description Function  to compare two time foramts
 * @param - time (12:00 PM)
 * @param - time1 (11:00 PM)
 * @param - currentTime (milliseconds)
 * @return - bValidTime (true/false)
 * 
 * isNotSelected & hourNotAv - Used for mobile site only
 */
function compareTime(time, time1, currentTime) {
    var defaultDate;
    var bValidTime = true;
    if (currentTime)
        defaultDate = moment(currentTime).format('YYYY/MM/DD ').toString();
    else
        defaultDate = moment().format('YYYY/MM/DD ').toString();
    var regEx = new RegExp("1[012]|[1-9]:[0-5][0-9] AM|PM");
    if (time != null && time1 != null && time.match(regEx) && time1.match(regEx)) {
        var result1 = new Date(defaultDate + time).getTime();
        var result2 = new Date(defaultDate + time1).getTime();
        if (result1 > result2) {
            bValidTime = false;
        } else {
            bValidTime = true;
        }
    }
    return bValidTime;
}

/** @description Function  to check if given time is within given range of time
 * @param - startTime (11:00:00) - 24 format
 * @param - time1 (15:00:00) - 24 format
 * @param - givenTime (2:00 PM) - 12 hour format
 * @return - true / false
 */
function isGivenTimeWithInRange(starTime, endTime, givenTime) {
    if (starTime && endTime && givenTime) {
        var startDateTime = moment(starTime, 'HH:mm:ss').toDate();
        var endDateTime = moment(endTime, 'HH:mm:ss').toDate();
        var givenDateTime = moment(givenTime, 'hh:mm a').toDate();
        return givenDateTime > startDateTime && givenDateTime < endDateTime;
    }
    return true;
}

/** @description Function  to split time values
 * @param {array} - startTime
 * @param {array} - endTime
 * @param {array} - interval
 * @param {array} - selectedValue
 * 
 * isNotSelected & hourNotAv - Used for mobile site only
 */
function ordersettingsRenderTimeSlotOptions(startTime, endTime, interval, selectedValue, response, unavailableSlots, safeSlots, isNotSelected) {

    var start = parseTime(startTime);
    var end = parseTime(endTime);
    var diff = parseInt(interval);
    var leadTime = response && response.leadTime;
    if (!leadTime)
        leadTime = response && response.successResponse && response.successResponse.leadTime;

    var template = '';
    var selectedItem = 0;
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    var bMinTimeCheck;
    var minTime;

    minTime = sessionStorage.getItem('updateCookTime');

    var date = moment($('#updated_EDate').val()).format('MM/DD/YYYY');
    var currentDt = moment(currentTime).format('MM/DD/YYYY');
    if (!minTime && date == currentDt) {
        minTime = getAsapTimeFromMins(leadTime, currentTime);
    }
    if (minTime)
        minTime = minTime.replace(/^0+/, ''); // remove leading zero - formatting 04:05 PM to 4:05 PM in order to match 'timeFormat'
    for (var i = start; i <= end; i = i + diff) {
        var timeString = convertHours(i);
        var timeFormat = moment(timeString, 'h:mm').format('h:mm A');

        if (minTime) {
            if (compareTime(minTime, timeFormat))
                bMinTimeCheck = true;
            else
                bMinTimeCheck = false;
        } else {
            bMinTimeCheck = true;
        }

        if ((unavailableSlots && unavailableSlots.length > 0) || (safeSlots && safeSlots.length > 0)) {
            var selected = '';
            if ((selectedValue === timeFormat) && selectedItem === 0) {
                selected = 'selected';
            } else if (isNotSelected != 'false' && selectedValue && (moment(timeFormat, 'h:mm A') > moment(selectedValue, 'h:mm A')) && selectedItem === 0) {
                selected = 'selected';
            }
            if (i == end) {
                var endTimeAdjusted = convertHours(i - 1);
                endTimeAdjusted = moment(endTimeAdjusted, 'h:mm').format('h:mm A');
                if (bMinTimeCheck && isValidSlot(i, endTimeAdjusted, unavailableSlots, safeSlots, currentTime)) {
                    template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
                }
            } else if (bMinTimeCheck && isValidSlot(i, timeFormat, unavailableSlots, safeSlots, currentTime)) {
                template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
                if (selected == 'selected')
                    selectedItem = timeFormat;
            }
        } else {
            var selected = (selectedValue === timeFormat) ? 'selected' : '';
            template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
        }
    }

    if (!template) {
        hourNotAv = true;
    }
    sessionStorage.removeItem("updateCookTime");
    return template;
}

/*
 * Generate Restaurant Details url
 */
function generateRestaurantDetailURL(restaurantDetails) {
    var restaurantName = function() {
        var restaurantNameChunks = restaurantDetails.restaurantName.toLowerCase().split(' ');
        restaurantNameChunks = restaurantNameChunks.filter(function(restName) {
            if (restName !== '-') {
                return true;
            }
            return false;
        });
        return restaurantNameChunks.join('-');
    }
    var prefixURL = '/locations/';
    if ($('#currentLocale').val() === 'es_US') {
        prefixURL = '/es/locations/';
    }
    var directionURL = prefixURL + restaurantDetails.address.state.toLowerCase() + '/' + restaurantDetails.address.city.toLowerCase() + '/' + restaurantName() + '/' + restaurantDetails.restaurantNum + '#DirectionContainer';
    return directionURL;
}

/**@description Function to render time slots in dropdown for togo/catering pickup order type
 * @param {string} startTime
 * @param {string} endTime
 * @param {string} interval
 * @param {string} selectedValue
 */
function renderTimeSlotOptions(startTime, endTime, interval, selectedValue, unavailableSlots) {
    if ($('#fromTimeConflict').val() == 'true' && $('#actualPickupTime').html().trim()) {
        selectedValue = moment($.trim($('#actualPickupTime').html()), "hh:mm aa").format("h:mm A");
    }
    var start = parseTime(startTime);
    var end = parseTime(endTime);
    var diff = parseInt(interval);
    var template = '';
    var endTime = '';
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    for (var i = start; i <= end; i = i + diff) {
        var timeString = convertHours(i);
        var timeFormat = moment(timeString, 'h:mm').format('h:mm A');
        var selected = (selectedValue === timeFormat) ? 'selected' : '';
        if (unavailableSlots && unavailableSlots.length > 0) {
            if (i == end) {
                i = i - 1;
                endTime = convertHours(i);
                endTime = moment(timeString, 'h:mm').format('h:mm A');
                if (isAvailableTimeslot(endTime, unavailableSlots, currentTime)) {
                    template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
                }
            } else if (isAvailableTimeslot(timeFormat, unavailableSlots, currentTime)) {
                template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
            }
        } else {
            template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
        }
    }
    if (!template) {
        hourNotAv = true;
    }
    return template;
}

/**@description Function to render time slots in dropdown for catering delivery order type
 * @param {string} startTime
 * @param {string} endTime
 * @param {string} interval
 * @param {string} selectedValue
 */
function renderTimeSlotOptionsForDelivery(startTime, endTime, interval, selectedValue, unavailableSlots, safeSlots) {
    var start = parseTime(startTime);
    var end = parseTime(endTime);
    var diff = parseInt(interval);
    var template = '';
    var selectedItem = 0,
        updatedSelectedTime = '';
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);

    for (var i = start; i <= end; i = i + diff) {
        var timeString = convertHours(i);
        var timeFormat = moment(timeString, 'h:mm').format('h:mm A');
        var selected = '';
        if ((selectedValue === timeFormat) && selectedItem === 0) {
            updatedSelectedTime = timeFormat;
            selected = 'selected';
        } else if ((moment(timeFormat, 'h:mm A') > moment(selectedValue, 'h:mm A')) && selectedItem === 0) {
            updatedSelectedTime = timeFormat;
            selected = 'selected';
        }
        if ((unavailableSlots && unavailableSlots.length > 0) || (safeSlots && safeSlots.length > 0)) {
            if (i == end) {
                var endTimeAdjusted = convertHours(i - 1);
                endTimeAdjusted = moment(endTimeAdjusted, 'h:mm').format('h:mm A');
                if (isValidSlot(i, endTimeAdjusted, unavailableSlots, safeSlots, currentTime)) {
                    template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
                }
            } else if (isValidSlot(i, timeFormat, unavailableSlots, safeSlots, currentTime)) {
                template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
                if (selected == 'selected')
                    selectedItem = timeFormat;
            }
        } else {
            template += '<option value="' + timeFormat + '" ' + selected + '>' + timeFormat + '</option>';
        }
    }
    return template;
}

/*
 * This method for calculating asap time based on the available slots on togo-ordersettings & togo-ordersettings-mobile.js
 * response - response from 'ordersettings' & 'addItem' service call
 * reqBody - Request parameters for capacity service call
 * dropdownId - pickup-timelist (desktop) & selected-timelist (mobile)
 * radioName - pickupdate-time (desktop) & selected-datetime (mobile)
 * radioAsapId - ordertype-asap (desktop) & selected-dt-asap (mobile)
 * isDesktop - true (desktop) & false (mobile)
 */
function asapLoadTimeCalc(response, reqBody, isDesktop) {
    var asapEnabled = $('#asapEnabled').val();
    var dropdownId;
    var radioName;
    var radioAsapId;
    if (isDesktop) {
        dropdownId = "pickup-timelist";
        radioName = "pickupdate-time";
        radioAsapId = "ordertype-asap";

    } else {
        dropdownId = "selected-timelist";
        radioName = "selected-datetime";
        radioAsapId = "selected-dt-asap";
    }
    if (asapEnabled == 'true') {
        var cutOffTime = parseInt(sessionStorage.getItem('cutOffTime'));
        if (!cutOffTime) {
            cutOffTime = response && response.asapCutoffTime;
            sessionStorage.setItem('cutOffTime', cutOffTime);
        }
        var currentTime = response && response.currentTime; //milliseconds
        if (currentTime)
            currentTime = getConvertRestTime(currentTime.time);

        if (!currentTime) {
            currentTime = sessionStorage.getItem('currentTime');
            currentTime = Number(currentTime);
        }

        // This is to support if 18hr lead time for OG's catering pickup order type...
        if (isLeadTimeCrossesDay(currentTime, response.leadTime)) {
            if (isDesktop) {
                getOrderSettingApi(true, init);

            } else {
                getOrderSettingApi(false, mobileInit, null, null, true);
            }
        } else {
            var asapThreshold = cutOffTime;
            var leadTime = parseInt(response.leadTime);
            var asapTime = getAsapTimeFromMins(response.leadTime, currentTime);
            var availableSlots;
            var unavailableSlots;
            var updatedAsapTime;
            if (leadTime && cutOffTime) {
                $('#ordertype-asap-element #leadTime').empty();
                var sessionLeadTime = parseInt(sessionStorage.getItem('leadTime'));
                var selectedId = $('input[name="' + radioName + '"]:checked').attr('id');
                var asapSelected = response && response.asapSelected;
                if (!asapSelected) {
                    asapSelected = response && response.isAsapSelected;
                }
                if (selectedId == radioAsapId || ((leadTime > cutOffTime) && (asapSelected && asapSelected === true))) {
                    if (sessionLeadTime) {
                        if (leadTime > sessionLeadTime) {
                            console.log("MoreLeadtime Show Modal");
                            $('#asapCutoffTimeModal').modal('show');
                        }
                    }
                }
                sessionStorage.setItem('leadTime', leadTime);
                updatedAsapTime = leadTime;
                var maxTime = getAsapTimeFromMins(asapThreshold - 1, currentTime);

                getCapacityTimeslots(reqBody).done(function(responseCapacity) {
                    if (responseCapacity && responseCapacity.successResponse && responseCapacity.successResponse.capacitySlots) {
                        availableSlots = responseCapacity.successResponse.capacitySlots.availableSlots;
                        unavailableSlots = responseCapacity.successResponse.capacitySlots.unavailableSlots;
                        if (availableSlots && availableSlots.length > 0) {
                            updatedAsapTime = findNextAvailableMinutes(asapTime, availableSlots, maxTime, currentTime);
                        } else if (unavailableSlots && unavailableSlots.length > 0) {
                            updatedAsapTime = null;
                        }
                    }
                    if (updatedAsapTime) {
                        if (updatedAsapTime < cutOffTime ) {
                            //#pickupdatetime #leadTime, #heading-date #leadTime - this updates for only mobile site
                            $('#ordertype-asap-element #leadTime, #pickup-asapdate #leadTime, #pickupdatetime #leadTime, #heading-date #leadTime').html(updatedAsapTime + ' mins');
                            leadTimeChangedToAsap(response);
                        } else {
                            leadTimeChangedToSpecificDate(response, unavailableSlots);
                            $('#' + dropdownId).attr('capacityFlow', true);
                        }
                    } else {
                        leadTimeChangedToSpecificDate(response, unavailableSlots);
                        $('#' + dropdownId).attr('capacityFlow', true);
                    }

                    var pickupSelection = sessionStorage.getItem('pickupSelection');
                    if(pickupSelection == 'datetime') {
                    	 $('#ordertype-specificdate').prop('checked', true); // for desktop site
                    	 $('#selected-dt-specific').prop('checked', true); // for mobile site
                    	 orderTypeSpecificDateEvent();
                    	 sessionStorage.removeItem('pickupSelection');
                    }
                });
            } else if (isNaN(leadTime)) {
                sessionStorage.removeItem('leadTime')
            }
        }

        // this executes only for mobile site
        if (!isDesktop) {
            if ($('#heading-date').text().length > '32') {
                $('.breadcrumb,.tg-menu').css('marginTop', '10px');
                $('.res-locationpickup-list .dropdown-menu').css('top', '61px');
            }
        }
    }
}

/*
 * This function is used for calculating asap time based on available slots on togo-webapi-location.js & togo-webapi-mobile-location.js
 * response - response from 'times' service call
 * availableSlots - capacity available slots
 * unavailableSlots - capacity unavailable slots
 * isDesktop - true (desktop) & false (mobile)
 */
function asapLocLoadTimeCalc(response, availableSlots, unavailableSlots, isDesktop) {
    var asapEnabled = $('#asapEnabled').val();
    if (asapEnabled == 'true') {
        var locLeadTime = response && response.successResponse && response.successResponse.leadTime;
        var cutOffTime = parseInt(sessionStorage.getItem('cutOffTime'));
        if (!cutOffTime) {
            cutOffTime = response && response.successResponse && response.successResponse.asapCutoffTime;
            sessionStorage.setItem('cutOffTime', cutOffTime);
        }
        var currentTime = response && response.successResponse && response.successResponse.currentTime; //milliseconds
        if (!currentTime)
            currentTime = response && response.successResponse && response.successResponse.currentTime;
        if (currentTime)
            currentTime = getConvertRestTime(currentTime.time);
        if (!currentTime) {
            currentTime = sessionStorage.getItem('currentTime');
            currentTime = Number(currentTime);
        }
        var asapThreshold = cutOffTime;
        var leadTime = parseInt(locLeadTime);

        var asapTime = getAsapTimeFromMins(locLeadTime, currentTime); // 03:30 PM
        var updatedAsapTime;
        if (leadTime && cutOffTime) {
            $('#location-asapElement #leadTime').empty();
            var sessionLeadTime = parseInt(sessionStorage.getItem('leadTime'));
            var selectedId = $('input[name="location-pickupdate"]:checked').attr('id');
            var asapSelected;
            
            if ((disableOrderSettings && onlineTogoEnabled && (orderTypeValue == 0 || orderTypeValue == 3) && cartItemsCount == 0)) {
            	asapSelected = response && response.successResponse.asapEnabled;
            } else {
            	asapSelected = response && response.successResponse.asapSelected;
            }
            
            if (!asapSelected) {
                asapSelected = response && response.successResponse.isAsapSelected;
            }
            if (selectedId == "location-asap" || ((leadTime > cutOffTime) && (asapSelected && asapSelected === true))) {
                if (sessionLeadTime) {
                    if (leadTime > sessionLeadTime) {
                        console.log("MoreLeadtime Show Modal");
                        $('#asapCutoffTimeModal').modal('show');
                    }
                }
            }
            sessionStorage.setItem('leadTime', leadTime);
            updatedAsapTime = leadTime;
            var maxTime = getAsapTimeFromMins(asapThreshold - 1, currentTime);

            if (availableSlots && availableSlots.length > 0) {
                updatedAsapTime = findNextAvailableMinutes(asapTime, availableSlots, maxTime, currentTime);
            } else if (unavailableSlots && unavailableSlots.length > 0) {
                updatedAsapTime = null;
            }
            if (updatedAsapTime) {
                if (updatedAsapTime < cutOffTime) {
                    if (isDesktop) {
                        $('#location-asapElement #leadTime, #location-asapdate #leadTime').html(updatedAsapTime + ' mins');
                    } else {
                        $('#location-asapElement #leadTime, .inner-pickup-asapdate #leadTime, .outer-pickup-asapdate #leadTime, #pickupdatetime #leadTime, #heading-date #leadTime').html(updatedAsapTime + ' mins');
                    }
                    leadTimeChangedToAsap_WebApi(response);
                } else {
                    leadTimeChangedToSpecificDate_WebApi(response, unavailableSlots);
                    $('#select-locationtime-list').attr('capacityFlow', true);
                }
            } else {
                leadTimeChangedToSpecificDate_WebApi(response, unavailableSlots);
                $('#select-locationtime-list').attr('capacityFlow', true);
            }
        } else if (isNaN(leadTime)) {
            sessionStorage.removeItem('leadTime');
        }
    }
}

/** Function to make the api call for Static Google Map Display Changes
 */
function fetchStaticMap(location) {
    var imageWidth = $('#imageWidth').val();
    var imageHeight = $('#imageHeight').val();
    var imageZoom = $('#imageZoom').val();

    var reqBody = {
        "imageWidth": imageWidth,
        "latLongOrAddress": location.latLong,
        "imageHeight": imageHeight,
        "zoomLevel": imageZoom
    };
    addSiteCodes(reqBody);
    $.ajax({
        url: '/web-api/restaurant/fetchStaticMap',
        data: reqBody,
        type: "POST"
    }).done(function(response) {
        if (response.successResponse) {
            if (response.successResponse.imageURL !== undefined) {
                $('#staticMapUrl').prop('src', response.successResponse.imageURL);
            }
        }
        if (response.errorResponse) {
            if (response.errorResponse.error !== undefined) {
                $('#staticMapUrl').prop('src', response.errorResponse.error);
            }
        }
    });
}

function URLPrefixLocale(url) {
    var prefixURL = url;
    if ($('#currentLocale').val() === 'es_US') {
        prefixURL = '/es' + url;
    }
    return prefixURL;
}

/** @description Function  to check thanksgiving holidays list from  rest_holidays hidden field
 */
function thanksgivingClosedDate() {
    var rest_holidays = $('#rest_holidays').val();
    var res_FormatedArray = [];
    if (rest_holidays && rest_holidays.length) {
        var res_Array = rest_holidays.split(";");
        var res_NoofArray = res_Array.filter(function(val) {
            return val !== ''
        });

        for (i = 0; i < res_NoofArray.length; i++) {
            res_FormatedArray.push(res_NoofArray[i].replace(/-/g, '/'))
        }
        sessionStorage.setItem('thanksDates', res_FormatedArray);
    } else {
        sessionStorage.removeItem('thanksDates');
    }
}

/** @description Function  to return thanksgiving holidays list into mobile time response
 */
function thanksGivingMobile(thanksFormattedDates) {
    var thanksGivingClosedDay = sessionStorage.getItem('thanksDates');
    var thanksDatesList, thanksFormattedDates = [];
    if (thanksGivingClosedDay && thanksGivingClosedDay != undefined && thanksGivingClosedDay != null) {
        thanksDatesList = thanksGivingClosedDay.split(',');
        for (i = 0; i < thanksDatesList.length; i++) {
            thanksFormattedDates.push(moment(thanksDatesList[i]).format("DD/MM/YYYY"));
        }
        return thanksFormattedDates;
    }
}

/** This is to satisfy brands need to make slots from 1:00 PM to 4:00PM unavailable */
/** Start */
function decorateUnavailableSlotsWithStatic(unAvailableSlots) {
    if (!unAvailableSlots || typeof unAvailableSlots === 'string') {
        unAvailableSlots = [];
    }
    return unAvailableSlots.concat(getStaticUnavaialableDeliveryHours());
}

function getStaticUnavaialableDeliveryHours() {
    return [];
}
/** End */

// 86ed status - START

function checkIf86edCallRequired() {
    var value = window.location.pathname;
    var allowedPages = ['/menu-listing'];
    for (var i = 0; i < allowedPages.length; i++) {
        if (value && value.indexOf(allowedPages[i]) > -1) {
            return true;
        }
    }
    return false;
}

function process86edItems() {
    if (checkIf86edCallRequired()) {
        var restaurantId = $("#pdRestId").val();
        $.ajax({
        	url: '/web-api/restaurant/86edProducts?restaurantId=' + restaurantId,
        	type: "GET"
        }).done(function (response) {
        	var data = response && response.successResponse && response.successResponse.products86ed;
        	if (data) {
        		process86edItemsData(data);
        	}
        }).then(function () {
            processProductsDayPartConfig();
        });
    }
}

function process86edItemsData(data) {
    $.each(data, function(key, val) {
        var prodId = key;
        var prodCont = 'orderToGo' + prodId;
        var chckProdID = $('#' + prodCont).find('.plpquick-viewicon').attr('data-prodid');
        var notAvailableDesktop = $('#notAvailableDesktop,#notAvailableTextMobile,#itemNotAvailable').val();
        if (prodId && chckProdID && (prodId == chckProdID)) {
            if (channel == 'MOBILE') {
                $('#' + prodCont).html('<div class="quick-add-btn itemNotAvailable"><p class="not-available-info">' + notAvailableDesktop + '</p><a class="plpnoquick-view" href="javascript:void(0)">"' + notAvailableDesktop + '"</a></div>');
            } else {
                if ($('#' + prodCont).find('.quick-add-btn-old').length == 0) {
                    $('#' + prodCont).find('.quick-add-btn').removeClass('quick-add-btn').addClass('quick-add-btn-old hide');
                    $('#' + prodCont).append('<div class="quick-add-btn" data-bubble="' + notAvailableDesktop + '"><a class="plpnoquick-view" href="javascript:void(0)">' + notAvailableDesktop + '</a></div>');
                }
            }
        }
    });
}

function processProductsDayPartConfig() {
    var restaurantId = $("#pdRestId").val();
    $.ajax({
        url: '/web-api/restaurant/getProductsDayPartInfo?restaurantId=' + restaurantId,
        type: "GET"
    }).done(function(response) {
        var dayInfo = response && response.successResponse && response.successResponse.productDaypartInfos;
        if (dayInfo) {
            processProductsDayPartConfigData(dayInfo);
        }
    }).then(function() {
        process86edItemsData(generate86edResponseFromLocalValues(getLocal86edValues()));
    });
}

function processProductsDayPartConfigData(dayInfo) {
    var prodId, prodCont, chckProdID, selectedDays;
    var notAvailableDesktop = $('#notAvailableDesktop,#notAvailableTextMobile,#itemNotAvailable').val();
    $.each(dayInfo, function(key, val) {
        prodId = key;
        prodCont = 'orderToGo' + prodId;
        chckProdID = $('#' + prodCont).find('.plpquick-viewicon').attr('data-prodid');
        var pageDate = $('#ordertype-datetimepicker').val();
        var pageTime = $('#pickup-timelist').val();
        var daysSelection = val && val[0] && val[0].daysSelection;
        if (prodId && chckProdID) {
            var validTime = false;
            selectedDays = (pageDate) ? moment(pageDate) : moment();
            for (var i = 0; i < daysSelection.length; i++) {
                if (selectedDays.day() + 1 === daysSelection[i].dayName) {
                    validTime = isGivenTimeWithInRange(daysSelection[i].startTime, daysSelection[i].endTime, pageTime);
                    break;
                }
            }
            if (!validTime) {
                if (channel == 'MOBILE') {
                    $('#' + prodCont).html('<div class="quick-add-btn itemNotAvailable"><p class="not-available-info">' + notAvailableDesktop + '</p><a class="plpnoquick-view" href="javascript:void(0)">"' + notAvailableDesktop + '"</a></div>');
                } else {
                    if ($('#' + prodCont).find('.quick-add-btn-old').length == 0) {
                        $('#' + prodCont).find('.quick-add-btn').removeClass('quick-add-btn').addClass('quick-add-btn-old hide');
                        $('#' + prodCont).append('<div class="quick-add-btn" data-bubble="' + notAvailableDesktop + '"><a class="plpnoquick-view" href="javascript:void(0)">' + notAvailableDesktop + '</a></div>');
                    }
                }
            }
        }
    });
}

function generate86edResponseFromLocalValues(local86edValues) {
    return local86edValues.map(generate86edResponse);
}

function generate86edResponse(value) {
    return {
        "id": value
    };
}

function getLocal86edValues() {
    var restaurantId = $("#pdRestId").val();
    return getSessionStorage('local86edValues' + '-' + restaurantId).split(',');
}

function appendLocal86edValues(value) {
    var restaurantId = $("#pdRestId").val();
    var newValue = getSessionStorage('local86edValues' + '-' + restaurantId).split(',');
    newValue.push(value);
    setSessionStorage('local86edValues' + '-' + restaurantId, newValue);
}

// 86ed status - END

/** @description Function to get the session storage value
 * @param {string} key
 */
function getSessionStorage(key) {
    var item = sessionStorage.getItem(key);
    return item || '';
}

/** @description Function to remove the session storage value
 * @param {string} key
 */
function removeSessionStorage(key) {
    sessionStorage.removeItem(key);
}

/** @description Function to remove the session storage value
 * @param {string} key
 */
function setSessionStorage(key, value) {
    sessionStorage.setItem(key, value);
}

function registerHandlebarsHelpers() {

	//All Handlebars helper register should be done here...
	if (typeof (Handlebars) !== 'undefined') {

		Handlebars.registerHelper('ifAnyOf', function (arg1, arg2, arg3, options) {
			if (arg1 == arg2 || arg1 == arg3) {
				return options.inverse(this)
			} else {
				return options.fn(this);
			}
		});

		Handlebars.registerHelper('toLocaleString', function(arg1) {
        	return parseInt(arg1).toLocaleString();
		});
        
		Handlebars.registerHelper('fixedListPrice', function(arg1, arg2) {
        	return arg1.toFixed(arg2);
		});        
		
		Handlebars.registerHelper('ifNotEquals', function (arg1, arg2, options) {
        	return (arg1 !== arg2) ? options.fn(this) : options.inverse(this);
		});

	}
}

$(document).on('triggerReadyFunction', function(event) {
    thanksgivingClosedDate();
    registerHandlebarsHelpers();
});

function setPickupInfoToSession(lunch, dinner, timeInterval, leadTime, asapEnabled, asapSelected, asapCutOffTime) {
    if (lunch.startTime) {
        var lunchStartTime = convertTimeToPM(lunch.startTime);
        sessionStorage.setItem('lunchStartTime', lunchStartTime);
    } else {
        sessionStorage.setItem('lunchStartTime', '');
    }

    if (lunch.endTime) {
        var lunchEndTime = convertTimeToPM(lunch.endTime);
        sessionStorage.setItem('lunchEndTime', lunchEndTime);
    } else {
        sessionStorage.setItem('lunchEndTime', '');
    }

    if (dinner.startTime) {
        var dinnerStartime = convertTimeToPM(dinner.StartTime);
        sessionStorage.setItem('dinnerStartTime', dinnerStartime);
    } else {
        sessionStorage.setItem('dinnerStartTime', '');
    }

    if (dinner.endTime) {
        var dinnerEndTime = convertTimeToPM(dinner.endTime);
        sessionStorage.setItem('dinnerEndTime', dinnerEndTime);
    } else {
        sessionStorage.setItem('dinnerEndTime', '');
    }

    sessionStorage.setItem('timeInterval', timeInterval);
    sessionStorage.setItem('leadTime', leadTime);
    sessionStorage.setItem('asapLocationEnabled', asapEnabled);
    sessionStorage.setItem('asapSelected', asapSelected);
    sessionStorage.setItem('asapCutOffTime', asapCutOffTime);
}


function getHeaderAjaxData(orderType, locationDetails, locValues) {
    var headerUrl = "/ajax/headerlocation.jsp?restNum=" + $.cookie("DRIRESTAURANTID");
    $.get(headerUrl, function(data) {
        var headerData = JSON.parse(data).join("@@");
        sessionStorage.setItem('locationDetails', headerData);
        locationDetails = sessionStorage.getItem('locationDetails');
        if (locationDetails && locationDetails != "undefined") {
            locValues = locationDetails.split("@@");
            if (locValues.length > 0) {
                populateOrderSettingBar(orderType, locValues);
            }
        }
    });
}

function generateOrderSettingRestaurantDetailURL(locValues) {
    var restaurantName = function() {
        var restaurantNameChunks = locValues[1].toLowerCase().split(' ');
        restaurantNameChunks = restaurantNameChunks.filter(function(restName) {
            if (restName !== '-') {
                return true;
            }
            return false;
        });
        return restaurantNameChunks.join('-');
    }
    var prefixURL = '/locations/';
    if ($('#currentLocale').val() === 'es_US') {
        prefixURL = '/es/locations/';
    }
    var directionURL = prefixURL + locValues[5].toLowerCase() + '/' +
        locValues[4].toLowerCase() + '/' + restaurantName() + '/' +
        locValues[11] + '#DirectionContainer';
    return directionURL;
}

function setOrderSettingDetails(orderTypeValue) {
    var orderType = orderTypeValue;
    $('#orderType-input').val(orderType);
    var changedResId = $('#selected-Resid').val();
    var locationDetails = sessionStorage.getItem('locationDetails');
    var locValues;
    if (locationDetails && locationDetails != "undefined") {
        locValues = locationDetails.split("@@");
        if (locValues.length > 0) {

            if (locValues[11] && locValues[0] !== changedResId) {
                getHeaderAjaxData(orderType, locationDetails, locValues);
            } else {
                populateOrderSettingBar(orderType, locValues);
            }
        }
    } else {
        getHeaderAjaxData(orderType, locationDetails, locValues);
    }

}

function populateLeadTime(locValues) {
	if(!sessionStorage.getItem("togoLeadTime")) {
		sessionStorage.setItem('togoLeadTime', locValues[15]);
	}
	if(!sessionStorage.getItem("asapLocationEnabled")) {
		sessionStorage.setItem('asapLocationEnabled', locValues[13]);
	}
	if(!sessionStorage.getItem("asapCutOffTime")) {
		sessionStorage.setItem('asapCutOffTime', locValues[14]);
	}
	if(!sessionStorage.getItem("catLeadTime")) {
		sessionStorage.setItem('catLeadTime', locValues[16]);
	}
}

// MenuItem detail - Quick Add overlay - menu config options UI client side - START

/**
 * This method fetches cart details from session storage. If not found fetches using API and populates session storage and returns
 *
 * @returns stored_cartItems
 */
function getCurrentOrderDetail() {
	var stored_cartItems = JSON.parse(sessionStorage.getItem('CartItems'));
	var isstoredItems = false;
	if (stored_cartItems) {
		var storedOrderType = stored_cartItems.successResponse && stored_cartItems.successResponse.order && stored_cartItems.successResponse.order.orderType;
		var currentOrderType = parseInt($('#orderType').val());
		if (storedOrderType === currentOrderType) {
			isstoredItems = true;
		}
	}
	if (!isstoredItems) {
		var data = {};
		apiCall('/web-api/order/detailed', 'GET', data, function (response) {
			if (response.successResponse) {
                stored_cartItems = JSON.stringify(response);
				sessionStorage.setItem('CartItems', stored_cartItems);
			}
		}, null);
	}
    return stored_cartItems;
}

/**
 * This method is to extracts selected config option id. Intended to use in the edit flow to
 * pre-select the config options that guest choosed already
 *
 * @param {*} commerceItemId
 * @returns selectedId[]
 */
function getCommerceItemDetails(commerceItemId) {
	var cartItems = getCurrentOrderDetail();
    if (cartItems) {
        var commerctItem = cartItems.successResponse.order.commerceItems.find(function (commerceItem) {
            if (commerceItem.id === commerceItemId) return commerceItem;
        });
        if (commerctItem) {
            return commerctItem.subItem.map(function (item) {
                return item.selectedId;
            });
        }
    }
}

/**
 * This method constructs selectedSkuDiv value. Intended to use in the edit flow to 
 * pre-select the sku that guest choose already
 *
 * @param {*} commerceItemId
 * @returns selectedSkuDiv
 */
function getselectedSkuDivValue(commerceItemId) {
	var cartItems = getCurrentOrderDetail();
    if (cartItems) {
        var commerctItem = cartItems.successResponse.order.commerceItems.find(function (commerceItem) {
            if (commerceItem.id === commerceItemId) return commerceItem;
        });
        if (commerctItem) {
            return commerctItem.productId + commerctItem.catalogRefId + 'sku';
        }
    }
    return '';
}

/**
 * This method sorts property bean by its mandatory & isCollapsible attribute value. 
 * All the mandatory & non-collapsible options goes top and rest follows
 * 
 * @param {MenuItemA API Response} response
 */
function sortMenuItemPropertyBeansByMandatoryOptions(response) {
    if (response && response.successResponse && response.successResponse.menubean) {
        response.successResponse.menubean.forEach(function (element) {
            if (element.menuSkuBean && element.menuSkuBean.propertyBeans) {
                element.menuSkuBean.propertyBeans.sort(function (a, b) {
                    return b.repositoryItem.isMandatory || !b.repositoryItem.isCollapsible ? 0 : a.repositoryItem.isMandatory || !a.repositoryItem.isCollapsible ? -1 : 0;
                });
            }
        });
    }
}

/**
 * This method is to decorate menu item's Sku Bean with greyOut & selected status
 * based on 86ed sku ids and selected Id / default config options
 *
 * @param {*} response
 * @param {*} skuIds86ed
 * @param {*} selectedIds
 */
function decorateMenuItemSkuBeanWithStatus(response, skuIds86ed, selectedIds) {
    if (response && response.successResponse && response.successResponse.menubean) {
        response.successResponse.menubean = filterMenuSkuBeansWithoutPrice(response);
        response.successResponse.menubean.forEach(function (element) {
            decorateSkuBeansWithStatus(element.menuSkuBean, skuIds86ed, '', selectedIds);
            if (element.menuSkuBean && element.menuSkuBean.propertyBeans) {
                element.menuSkuBean.propertyBeans.forEach(function (element) {
                    decorateProperyBean(element);
                    var defaultSelectedConfigOption = element.repositoryItem.defaultSelectedConfigOption;
                    if (element.skuBeans) {
                        element.skuBeans = filterSkuBeansForAlcoholStatus(element.skuBeans);
                        element.skuBeans.forEach(function (element) {
                            decorateSkuBeansWithStatus(element, skuIds86ed, defaultSelectedConfigOption, selectedIds);
                            if (element.propertyBeans) {
                                element.propertyBeans.forEach(function (element) {
                                    var defaultSelectedConfigOption = element.repositoryItem.defaultSelectedConfigOption;
                                    if (element.skuBeans) {
                                        element.skuBeans = filterSkuBeansForAlcoholStatus(element.skuBeans);
                                        element.skuBeans.forEach(function (element) {
                                            decorateSkuBeansWithStatus(element, skuIds86ed, defaultSelectedConfigOption, selectedIds);
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    }
}

/**
 * This method is to filter menuSkuBeans that are having no price object.
 * 
 * Additionaly this populate the price from price object to menuSkuBean itself for rendering.
 * 
 * Ideally the API /web-api/menuitem/{prodid} should not return an menuSkuBeanWithout Price.
 * this is a work around.
 *
 * @param {*} response
 * @returns
 */
function filterMenuSkuBeansWithoutPrice(response) {
    return response.successResponse.menubean.filter(function (value) {
        var menuSkuBeanPrice = getMenuSkuBeanPrice(value.menuSkuBean.id, response.successResponse.price);
        if (menuSkuBeanPrice) value.menuSkuBean.listPrice = menuSkuBeanPrice.listPrice;
        return (menuSkuBeanPrice);
    });
}

/**
 * This method is to filter alcoho skus from page if current location is confiugured to not sell alcohol online.
 */
function filterSkuBeansForAlcoholStatus(skuBeans) {
    return skuBeans.filter(function (skuBean) {
        return !skuBean.alcohol || 
            (orderTypeValue == '2' && sessionStorage.getItem('isAlcoholAllowedForDelivery') == 'true') || 
            (orderTypeValue != '2' && sessionStorage.getItem('isAlcoholAllowedForToGo') == 'true');
    });
}

/**
 * This method is to fetch price object for gieven skuId. Return undefined if price not defined.
 *
 * @param {*} skuid
 * @param {*} prices
 * @returns price object.
 */
function getMenuSkuBeanPrice(skuid, prices) {
    return prices.find(function (value) {
        if (skuid === value.skuId)
            return true;
    });
}

/**
 * This method is to decorate property bean at menuksubean level with below rule
 * If a property bean is not mandatory and also not collapsible then its presentation vise its should follow mandatory rule.
 * 
 * Only if not mandatory & collapsible then the other template would be used where it says (customize - description)

 * @param {*} propertyBean
 */
function decorateProperyBean(propertyBean) {
    if (propertyBean && !propertyBean.repositoryItem.isMandatory)
        propertyBean.repositoryItem.isMandatory = !propertyBean.repositoryItem.isCollapsible;
}

/**
 * This method is decorate sku bean with 86ed (greyout) and default selection.
 * 
 * skuIds86ed - are used to set sku bean's greyOut property value based 86ed sku ids list.
 * 
 * defaultSelectedConfigOption and selectedIDs are used to set sku bean 'selected' status.
 *
 * seletedIDs parameter takes precedance when both are passed.
 *
 * if 86ed then both  defaultSelectedConfigOption & selectedIDs are ignored.
 * 
 * defaultSelectedConfigOption - meant to use to select the default option as merchandiser sets its
 * selectedIDs - meant to use in Edit item scenario to preselect all the options using selected ids 
 * passed (to be extracted from cart item and passed as parameter) .
 *
 * @param {SKUBeanObject} skuBean - SKU Bean
 * @param {string[]} skuIds86ed - Array of 86ed item's sku id
 * @param {string} defaultSelectedConfigOption  - default sku to be selected
 * @param {string[]} selectedIDs - list of config options to be selected.
 */
function decorateSkuBeansWithStatus(skuBean, skuIds86ed, defaultSelectedConfigOption, selectedIDs) {
	if (skuIds86ed.successResponse.skus86ed.includes(skuBean.id)) {
		skuBean.greyOut = true;
		skuBean.greyOutMessage = $('#notAvailableDesktop,#notAvailableTextMobile,#itemNotAvailable').val();
	}
	if (skuBean.greyOut) {
		skuBean.selected = false;	
	} else {
		skuBean.selected = (selectedIDs) ?
        selectedIDs.includes(skuBean.selectedId) :
        defaultSelectedConfigOption === skuBean.id;
	}
}

// MenuItem detail - Quick Add overlay - menu config options UI client side - END

/** @description Function  to show/disable payonline and pay at restaurant buttons in checkout page 
 * depending on cart contains alcohol item or not.
 */
	function pymtMethodChkForAlcoholItems() {
		$('#alcoholAgeConfirmation').prop('checked',false);
		/*if($('#isCartContainsAlcoholItem').val() == "true"){
			if(sessionStorage.getItem('alcoholAgeConfirmation') == 'false'){
				$('#alcoholAgeConfirmation').prop('checked',false)	
			}else{
			    if(sessionStorage.getItem('alcoholAgeConfirmation') == null || sessionStorage.getItem('alcoholAgeConfirmation') == undefined){
			        $('#alcoholAgeConfirmation').prop('checked',false)
			    }else{
			         $('#alcoholAgeConfirmation').prop('checked',true)
			    }
			}
		}*/
	}

   //alcohol-buying-age-legal-check
	$(document).on("click", "#alcoholAgeConfirmation", function () {
		if ($("#alcoholAgeConfirmation").is(":checked")) {
			sessionStorage.setItem('alcoholAgeConfirmation',true);

		} else {
			sessionStorage.setItem('alcoholAgeConfirmation',false);

		}
	});
   
   
/*online alcohol sale change*/
$(window).on('load',function(){
   disableAlcoholItem();
});

function disableAlcoholItem(){
	
	/*To change age for CA*/
	if($("#exclusiveLegalAgeProvinces").length>0){
		if($("#exclusiveLegalAgeProvinces").val().split(",").indexOf($("#pdRestId").val())>-1){

		var ageText = $("label[for='alcoholAgeConfirmation']").text().replace(/19/g,$('#allowedLegalDrinkingAge').val());
		
		$("label[for='alcoholAgeConfirmation']").find('span').html(ageText);
		}
	}	 

   if ( ((orderTypeValue == '0' || orderTypeValue == '3' ) && sessionStorage.getItem('isAlcoholAllowedForToGo') == 'false') 
		||   ((orderTypeValue == '2' ) && sessionStorage.getItem('isAlcoholAllowedForDelivery') == 'false') ){
       
       if(orderTypeValue == '2'){         
           var bubbleText = $('#msgAlcoholNtAllowedInDel').val()      
       }else{         
           var bubbleText = $('#msgAlcoholNtAllowedInToGo').val()
       }
		
       /*for menulisting  items */	
       $(".item-includes-alcohol").each(function(){
           if($(this).find(".quick-add-btn").length>0){
				$(this).find(".quick-add-btn").attr('data-bubble',bubbleText);
				$(this).find(".quick-add-btn").children('a').removeClass('plpquick-viewicon').addClass('plpnoquick-view');
			}else{
				$(this).find("a.plpquick-viewicon").addClass('plpnoquick-view').removeClass('plpquick-viewicon');
			}
       });
       
       /*for cross related items in checkout page*/
       $('#cross-sell-modal-popup').find(".item-includes-alcohol").each(function(){
			if($(this).find(".quick-add-btn").length>0){
				$(this).find(".quick-add-btn").attr('data-bubble',bubbleText);
				$(this).find(".quick-add-btn").children('a').removeClass('quick-viewicon').addClass('plpnoquick-view');
			}else{				
				$(this).find("a.quick-viewicon").addClass('plpnoquick-view').removeClass('quick-viewicon');
			}
       });
       
       /*for pdp page*/
       $(".item-includes-alcohol").find("#addToCart").attr('disabled',true).text(bubbleText);
       $(".item-includes-alcohol").find(".qty-incr-decr").css('visibility','hidden');
   }else {
       $(".item-includes-alcohol").find(".qty-incr-decr").css('visibility','visible');
       
   }
       
}