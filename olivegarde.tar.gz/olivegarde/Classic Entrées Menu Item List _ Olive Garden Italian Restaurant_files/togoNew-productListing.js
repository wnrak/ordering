'use strict';
var notAvailableDesktop;
$(document).ready(function() {
	//function for lazy loading images in listing page.
	$("img.lazy").lazyload();
	if($("ul.ogproduct-list-view").length) {
		$(".plp-qick").each(function(){
			if($(this).children('.fav-tool').length>0) {
				$(this).children('.fav-tool').each(function() {
					if($(this).find('img').attr('src').indexOf('/sodiumphillyicon')>-1) {
						$(this).find('a').addClass("imageListview");
					}
				});
			}
		});
	} else {
		$(".plp-qick").each(function() {
			if($(this).children('.fav-tool').length>0) {
				$(this).children('.fav-tool').each(function() {
					if($(this).find('img').attr('src').indexOf('/sodiumphillyicon')>-1) {
					   $(this).find('img').css('margin-top','10px');
					    $(this).parent().css('position','static');
						$(this).insertAfter($(this).parent().children().last());
						$(this).parent().children().first().find('a').css('z-index','2')
						$(this).parent().find('.quick-add-btn').css('padding-top','30px')
						$(this).parent().parent().css('padding-bottom','10px');
					}
				});
			}
		});
	}
});

$(document).on('triggerReadyFunction', function(event) {
    var cateringView;
	notAvailableDesktop = $('#notAvailableDesktop,#itemNotAvailable').val();
	highlightMenuItem();
	subMenuNavigateHandler();	
	var favouriteText = $('.tg-favourtie').html();
	if(favouriteText) {
		$('#list-view').attr('disabled');
		$('#gride-view').attr('disabled');
	}else {
		$('#list-view').removeAttr('disabled');
		$('#gride-view').removeAttr('disabled');
	}	
	if($(".menuCat.active").length > 0) {
		$(".menuCat.active").next('span').attr('class','glyphicon glyphicon-menu-up');
	}
	var isInitialAsap = sessionStorage.getItem('isInitialAsap');
	if ($('#process86edItems').length && $('#productRecords').length && isInitialAsap == "true") {
			if($('#enable_86ed_calls').val() == "true"){
				process86edItems($('#productRecords'));
			}
	}
	
	if($('#orderTypeValue').val() == "2" || $('#orderTypeValue').val() == "3") {
	    if($('.menuCat.active').attr("data-id") === 'catering') {
    	    var cateringView = sessionStorage.getItem("menuCategory");
    		var parentEle = $('.menuCat.active').parents('.panel-default');
    		var isCustomAccordion = $(parentEle).hasClass('custom-icon-panel');
    		if($('.custom-icon-panel').find(".menuCat").siblings().hasClass("glyphicon-menu-up")) {
    		 	$('.custom-icon-panel').find(".glyphicon-menu-up").addClass("glyphicon-menu-down").removeClass("glyphicon-menu-up");   
    		}
    		var cateringHtml = $(parentEle).html();
    		$(parentEle).empty();
    		if(isCustomAccordion && !(cateringView == "catering")) {
        		$('.catering-accordion').append(cateringHtml);
        		$('.catering-accordion').removeClass('catering-accordion');	
        		window.scrollTo(0,0);
    		} else  if(cateringView == "catering") {
    		    $(parentEle).addClass('catering-accordion');	
        		$('.custom-icon-panel').append(cateringHtml);
        		if($('.custom-icon-panel').find(".menuCat").siblings().hasClass("glyphicon-menu-down")){
        		    $('.custom-icon-panel').find(".glyphicon-menu-down").removeClass("glyphicon-menu-up").addClass("glyphicon-menu-up");
        		}
        		$('.catering-accordion').append('');
        		window.scrollTo(0,0);
    		} else {
        		$(parentEle).addClass('catering-accordion');	
        		$('.custom-icon-panel').append(cateringHtml);
        		if($('.custom-icon-panel').find(".menuCat").siblings().hasClass("glyphicon-menu-down")){
    		    $('.custom-icon-panel').find(".glyphicon-menu-down").removeClass("glyphicon-menu-up").addClass("glyphicon-menu-up");
    	    	}
    		    window.scrollTo(0,0);
    		}
    	} else {
    	    $('.panel-default .menuCat').each(function(){
    	        if($(this).attr("data-id") == "catering"){
    	            var parentEle = $(this).parents('.panel-default');
    	            $('.custom-icon-panel').html(parentEle)
    	            $(this).parents('menuCat').addClass('active');
    	        }
    	    });
    	}
	}
		
	$('.ogproduct-list-view li').on('click', function() {
		sessionStorage.setItem('listView', true);		
	});
	
});

function highlightMenuItem() {
	var pathname = window.location.pathname;
	var pathArr = pathname ? pathname.split('/') : [];
	var menuCategory;
	var subMenuCategory;
	
	/*41963 start*/
	if(pathArr.indexOf('menu') != -1 && pathname.indexOf( "/prod") == -1) {
		menuCategory = sessionStorage.getItem('menuCategory');
		
		
	} else if(pathArr.indexOf('menu') != -1 && pathname.indexOf( "/prod") != -1) {
	    menuCategory = sessionStorage.getItem('menuCategoryreDirect');
	    subMenuCategory = sessionStorage.getItem('subMenuCategoryreDirect');
	/*41963 end*/		
	}else {
		if(pathArr.indexOf( "menu-listing") >0 && pathArr.indexOf( "menu-listing")<pathArr.length) {
	        menuCategory = pathArr[pathArr.indexOf( "menu-listing") +1];
	        subMenuCategory = pathArr.indexOf( "menu-listing")== pathArr.length-3?pathArr[pathArr.indexOf( "menu-listing") +2]:'';
	    } else {
	        menuCategory = pathArr[1];
	        subMenuCategory = '';
	    }
	}
	$('.menuCat').each(function(index, ele) {
		var $ele = $(ele);
		if($ele.attr('data-id') === menuCategory) {
		  $ele.addClass('active');
          sessionStorage.setItem('menuCategory',menuCategory);
		  $($($ele.siblings('span')[0]).attr('href')).addClass('in');
		  if(subMenuCategory) $($ele.siblings('span').attr('href')).find('.'+subMenuCategory+' a').addClass('active')
		} else {
		  $ele.removeClass('active');
		}
		if($ele.attr('data-id') === 'catering' && menuCategory === 'catering') {
			$(this).parent().parent().parent().addClass('catering-accordion');			
		}
	});
	
}

function subMenuNavigateHandler(menu) {
	if(window.location.search.indexOf('_requestid') != -1){
		updateURL();
	}
	var pathname = window.location.pathname;
	var pathArr = pathname ? pathname.split('/') : [];
	var selectedMenu = menu || pathArr.indexOf( "menu-listing")== pathArr.length-3?pathArr[pathArr.indexOf( "menu-listing") +2]:'';
	if(selectedMenu) {
		$('.sub-cat-detail').addClass('hide');
		$('#sub-'+selectedMenu).removeClass('hide');
		$('#parent_sub-'+selectedMenu).removeClass("hide");
		$('#parent_sub-'+selectedMenu).find('*').removeClass("hide");
		window.scrollTo(0, 0);
		$("img.lazy").lazyload();
	}	
}

function toggleViewHandler(isGridView) {
	var pathname = window.location.pathname;
	var urlHash = window.location.hash;
	var urlToNavigate = '';
	if(isGridView) {
		$('#list-view').css('display','block');
		$('#gride-view').css('display','none');
		urlToNavigate = pathname + '?view=grid' + urlHash;
		sessionStorage.setItem('listView', false);
	} else {
		$('#list-view').css('display','none');
		$('#gride-view').css('display','block');
		urlToNavigate = pathname + '?view=list' + urlHash;
		sessionStorage.setItem('listView', true);
	}
	window.location.href = urlToNavigate;	
}


function collapseHandler(event, category) {
}