$(document).on('triggerReadyFunction', function(event) {
	//Display preferred location modal
	var locationMismatch = $('#locationMismatch').val();
	if(locationMismatch === 'true' && (location.pathname.indexOf("/menu-listing") != -1 
			|| location.pathname.indexOf("/reorder") != -1 || location.pathname.indexOf("/favorites") != -1)) {
		$('#togoRestaurantChangeModal').modal();
		closeCartSlider();
	}
});
		
//Preferred location scripts starts
$(document).on('click', '#togoChangeCurrentRest', function() {
	var changePrefferedLocation = "/web-api/favorite/setPreferredLocation";
	$.ajax({
		type: 'GET',
		url: changePrefferedLocation,
		async: false,
		success: function (response) {
			window.location.reload();
		},
		error: function (xhr, text, err) {
			console.log("error");
		},
		dataType: 'json',
		contentType: 'application/json'
	});
});
		
$(document).on('click', '#togoDontChangeCurrentRest', function() {
	location.reload();
});

$('#noitems-location-continue').on('click', function () {
 if($('#viewMenuExceptions1').val()){
		var combine_errorid = $('#viewMenuExceptions1').val();
		var restaurantID = $('#viewMenuExceptions3').val();
		var removalCommerceIds = $('#viewMenuExceptions2').val();
		if($("#viewMenuExceptions2:contains(:)")){
		    removalCommerceIds = removalCommerceIds.replace(':',',');
		}
		var reqBody = {
			"validateCartItems": false,
			"restaurantId": restaurantID,
			"removalCommerceIds": removalCommerceIds,
			"togoNewFlow": true
		};
		updateRestaurantApi(reqBody, successnavigation , []);
	}else{
			var combine_errorid = errorid_array.join(", ");
		var restaurantID = $(this).attr("data-restnum");
		var reqBody = {
			"validateCartItems": false,
			"restaurantId": restaurantID,
			"removalCommerceIds": combine_errorid,
			"togoNewFlow": true
		};
		updateRestaurantApi(reqBody, init, restaurantErrorHandler);
	}
});

function updateRestaurantApi(reqBody, successCallBack, errorCallBack, isSwitchRestaurant, timeResponse, reqCapacityBody) {
	var isReloadPage = reqBody.removalCommerceIds || reqBody.validateCartItems;
	addSiteCodes(reqBody);
	$.ajax({
		url: '/web-api/restaurant/update',
		data: reqBody,
		type: "POST"
	}).done(function (response) {
		if (response.successResponse) {
			if(response.successResponse.isSiteCapacityAvailable && response.successResponse.restaurantDetails && response.successResponse.restaurantDetails.isCapacityAvailable) {
				if(response.successResponse.isSiteCapacityAvailable == true && response.successResponse.restaurantDetails.isCapacityAvailable == true) {
					$('#isCapacityCheckEnabled').val(true);
				} else {
					$('#isCapacityCheckEnabled').val(false);
				}
			} else {
				$('#isCapacityCheckEnabled').val(false);
			}
			if(timeResponse !== null && timeResponse !== undefined && timeResponse != '') {
				var defaultTime = $('#select-locationtime-list').val();
				var defaultDt = moment($('#datetimepicker-location').val()).format("MM/DD/YYYY");
				var unavailableSlots;
				var availableSlots;
				var pickupDate = reqCapacityBody['pickupdate'];
				getCapacityTimeslots(reqCapacityBody).done(function (responseCapacity) {
					if (responseCapacity && responseCapacity.successResponse && responseCapacity.successResponse.capacitySlots) {
						unavailableSlots = responseCapacity.successResponse.capacitySlots.unavailableSlots;
						availableSlots = responseCapacity.successResponse.capacitySlots.availableSlots;
					}
					formatClosedDates([], timeResponse);
					updateTimeslots(timeResponse, unavailableSlots);
					setLocationDateTime(pickupDate, timeResponse, availableSlots, unavailableSlots);

					var selectTime = $('#select-locationtime-list').val();
					if(selectTime)
						selectTime = selectTime.trim();
					var date = moment($('#datetimepicker-location').val()).format("MM/DD/YYYY");

					$('#locselected-time').html(selectTime);
					$('#locselected-time-val').val(selectTime);

					if(isSwitchRestaurant == true) {
						if(!selectTime)
							$('#ordertype-selected-day-errormodal').modal('show');
						else if(defaultDt) {
							if(defaultDt != date) {
									$('#ordertype-selected-day-errormodal').modal('show');
							} else if(defaultTime != "" && defaultTime != null && defaultTime != undefined) {
								if(defaultTime != selectTime) {
									$('#ordertype-selected-rest-errormodal').modal('show');
								}
							}
						}
					}
				});
			}
			successCallBack(response.successResponse, isReloadPage, false, isSwitchRestaurant);
		}
		if (response.errorResponse) {
			errorCallBack(response.errorResponse);
		}
	});
}

function successnavigation(response,isReloadPage){
     $("form#locationViewMenu").submit();
}
//Preferred location scripts ends