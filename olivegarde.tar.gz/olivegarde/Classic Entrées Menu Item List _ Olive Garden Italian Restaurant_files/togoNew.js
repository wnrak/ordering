var pickupdateselect, timeslottextselect, notAvailableDesktop;

/**
 *  Introducing empty implementation of DFA_floodLight() here
 *  to save togo-one-column-template is not including custom.js where this 
 *  function is originally defined.
 */
function DFA_floodLight(pageName) {}

$(document).on('triggerReadyFunction', function (event) {
	//Goto top button
	/*IE Only issue fix ALM: 40681*/
	var ua = window.navigator.userAgent;
	var msie = ua.indexOf("MSIE");
	if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) { // If Internet Explorer, return version number
		$('html, body').scrollTop(0);
	}
	var gobtn = $('#goto-top');
	$(window).scroll(function () {
		if ($(window).scrollTop() > 300) {
			gobtn.addClass('show');
		} else {
			gobtn.removeClass('show');
		}
	});
	gobtn.on('click', function (e) {
		e.preventDefault();
		$('html, body').animate({
			scrollTop: 0
		}, '300');
	});

	$(document).on("click", "#join_checkbox", function () {
		var linktext = "Email Optin checkbox";
		sendCustomTrafficEvent(linktext);
	});

	/*Footer Join e-club functionality*/
	$('.restaurants-offers input[type="checkbox"]').click(function () {
		if (this.checked) {
			$(this).attr('checked', 'checked');
		} else {
			$(this).removeAttr('checked');
		}
	});
	if (location.pathname.indexOf("menu-listing") > 0) {
		sessionStorage.setItem("lastMenuUrl", location.pathname);
	}

	/*improve image quality enhancement*/
	if (window.location.href.indexOf("/menu") != -1 && window.location.href.indexOf("/prod") != -1) {

		if ($('#enableImageZoom').val() !== '' && $('#enableImageZoom').val() !== undefined && $('#enableImageZoom').val() === 'true' && $('#enableImageZoom').val() !== null) {
			/*improve image quality enhancement*/
			$(".modal-backdrop").hide().css('opacity', 0.8);
			$("#zoomDisplayModel").hide()

			$(document).on("click", '#pdpImage,#imageZoom', function () {

				$("#zoomDisplayModel").find(".test").remove();
				$(".modal-backdrop").show();
				$(".zoomImg").css({
					'width': '1000px',
					'height': '600px'
				});
				$("#zoomDisplayModel").show();
			});

			$(document).on("click", "#zoomDisplayModel_overlayCloseButton,.modal-backdrop ", function () {
				$(".modal-backdrop").hide();
				$("#zoomDisplayModel").hide();
			});
		}
	}

	//Wait list functionality copied from custom.js
	$(document).on("slid.bs.carousel", ".wlcarousel", function () {
		if ($('.carousel-inner .item:last').hasClass('active')) {
			$(".moveright").attr("style", "opacity:0.2;");
			$(".moveleft").removeAttr("style");
			$(".moveleft").removeClass("disable-wlLeftarrow");
			$(".moveright").addClass("disable-wlRightarrow");
		} else if ($('.carousel-inner .item:first').hasClass('active')) {
			$(".moveleft").attr("style", "opacity:0.2;");
			$(".moveright").removeAttr("style");
			$(".moveright").removeClass("disable-wlRightarrow");
			$(".moveleft").addClass("disable-wlLeftarrow");
		} else {
			$(".moveright").removeAttr("style");
			$(".moveleft").removeAttr("style");
			$(".moveleft").removeClass("disable-wlLeftarrow");
			$(".moveright").removeClass("disable-wlRightarrow");
		}
	});

	var sessionExpired = getUrlParameter("cartEmpty");
	if (sessionExpired == 'true') {
		$("#sessionExpired").modal('show');
	}

	$("#sessionExpiredOk").click(function () {
		$("#sessionExpired").modal('hide');
		sessionStorage.clear();
		history.replaceState(null, '', window.location.href.split("?")[0]);
		sessionStorage.setItem('disableOrderSettings', "false");
		location.reload();
	});

	//favourite through from facebook 
	if (window.location.search.indexOf('isFavorite=true') != -1) {
		var prodId = getUrlParameter('prodId');
		$('#favoriteitem-indicator-' + prodId).click();
	}

	//header outside click issue
	$('body').click(function (e) {
		if ($("#locText,#locEmail").is(':visible')) {
			locationDownArrow();
		} else {
			if (!$(e.target).closest('#headRestName, #locationDownArrow').length) {
				$("#location-pop-up").hide();
				$('#locationDownArrow').show();
				$('#locationUpArrow').hide();
			}
		}
	});

	var parentdiv = document.querySelector('#location-pop-up');
	var childsms = document.querySelector('#sms-current');
	var childemail = document.querySelector('#email-current');
	if ($('#location-pop-up').length) {
		parentdiv.addEventListener('click', function (e) {
			e.stopPropagation();
		});
	}
	if ($('#sms-current').length) {
		childsms.addEventListener('click', function (e) {
			$('#locText #phone-ctn').val('');
			var text = $(this);
			var restId = text.attr('data-id');
			$('#smsRestaurantId').val(restId);
			$('#locText').modal('show');
		});
	}
	if ($('#email-current').length) {
		childemail.addEventListener('click', function (e) {
			$('#locEmail #emailId').val('');
			var email = $(this);
			var restId = email.attr('data-id');
			$('#emailRestaurantId').val(restId);
			$('#locEmail').modal('show');
		});
	}

	$('#locText .error_msg span').hide();
	$(document).on("click", "#locEmail .close", function () {
		$('#locEmail #error_message_email').hide();
	});

	$(document).on("click", "#locText .close", function () {
		$('#locText #error_message_mobile').hide();
	});

	/*eClub Learnmore modal*/
	$('#signupBenefitsModal').removeClass('hide');
	$('#global-Optin').on('click', function () {
		$('#signupBenefitsModal').modal('show');
	});

	if ($('.order-confirmation-rest #sms-current').length > 0) {
		$('.order-confirmation-rest #sms-current').hide();
	}

	// input field validation for custom tip in order conformation page
	var oldInputValue;
	$('#cl_tipAmountCheckLevel').on('keydown', function (e) {
		oldInputValue = e.target.value;
	});
	$('#cl_tipAmountCheckLevel').on('input', function (e) {
		var el = e.target,
			newValue = el.value;
		if (e.target.value.length > 6) {
			el.value = oldInputValue;
			return false;
		}
		if (newValue.match(new RegExp(/^(?:\d{1,3}\.\d{0,2}|\d{1,3})$/)) || !newValue) {
			el.value = newValue;
		} else {
			el.value = oldInputValue;
		}
	});

	/*hidden field values*/
	pickupdateselect = $('#pickupdateselect').val();
	timeslottextselect = $('#timeslottextselect').val();
	notAvailableDesktop = $('#notAvailableDesktop,#itemNotAvailable').val();
	// check for session change and clear the web session storage.
	clearWebSessionStorage();
	// check and get all favorite items for current user
	if ($('#isProfileTransient').val() === 'false') {
		if (($(location).attr("href").indexOf('/menu-listing') >= 0)) {
			checkForFavoriteItems();
		}
		if ($(location).attr("href").indexOf('/menu/') >= 0) {
			checkForFavoriteItems();
		}
	}
	// Date picker icon clicks open the date picker
	var ocDobCheck;
	$('#oc-dob-datepicker').datetimepicker({
		format: "MM/DD/YYYY",
		maxDate: moment().subtract(13, 'years').subtract(1, 'days').format("MM/DD/YYYY"),
		debug: true,
		ignoreReadonly: true
	});

	$('#oc-dob-datepicker').on('dp.change', function (val) {
		$('#dobMonth').val(moment(val.date._d).format('MM'));
		$('#dobDay').val(moment(val.date._d).format('DD'));
		$('#dobYear').val(moment(val.date._d).format('YYYY'));
	});

	$('#oc-dob-datepicker,.datepicker-icons').on('click', function () {
		$('#dobPlaceholder').addClass('hidden');
		sessionStorage.setItem("ocDobCheck", true);
	});

	ocDobCheck = sessionStorage.getItem("ocDobCheck");
	if (ocDobCheck == "true") {
		$('#dobPlaceholder').addClass('hidden');
	}

	$('#createAccountId').click(function (event) {
		ocDobCheck = sessionStorage.getItem("ocDobCheck");
		if (ocDobCheck) {
			var dobMonth = $('#dobMonth').val();
			var dobDay = $('#dobDay').val();
			var dobYear = $('#dobYear').val();
		}
		$("#create_error_dob").hide();
		if (!(dobYear != '' && dobDay != '' && dobMonth != '' && dobYear != undefined && dobDay != undefined && dobMonth != undefined)) {
			event.preventDefault();
			$("#create_error_dob").show();
		}
	});

	if ($('#create_error').length) {
		togoScrolloverlay($("#create_error"));
	}

	// for validating email id in order conformation page
	$('#subscription').submit(function (e) {
		var emailRegex = new RegExp(/^[_A-Za-z0-9-\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$/);
		if (!emailRegex.test($('#emailid').val())) {
			e.preventDefault();
			$('#subscription-email-error').show();
		}
	});

	$('#catering-datepicker+span.datepicker-icons,#asap-datetimepicker,#asap-datetimepicker1, .datepicker-icons, #checkout-datetimepicker+span.datepicker-icons, #oc-dob-datepicker+span.datepicker-icons').on('mousedown', function (event) {
		var datePickerInp = $(this).siblings('input');
		var datePickerInpID = datePickerInp && datePickerInp.length ? $('#' + datePickerInp[0].id + '') : null;
		if (datePickerInpID) {
			var dp1 = datePickerInpID.data("DateTimePicker");
			if (dp1) {
				dp1.toggle();
			}
			event.preventDefault();
		}
	});
	// close datePicker for outside click 
	$('#ordertype-datetimepicker,#asap-datetimepicker,#asap-datetimepicker1, #delivery-datetimepicker, #datetimepicker-location, #catering-datepicker, #checkout-datetimepicker, #datepicker, #oc-dob-datepicker').on('blur', function (e) {
		$(this).data('DateTimePicker').hide();
	});
	$("#OrderlocationURL").click(function () {
		window.location.href = $(this).attr('data-url');
	});
	$(document).on("click", "#lookUpOrder", function () {
		$("#lookUpOrder").removeAttr('href');
		var form = $(this).closest("form");
		form.submit();
	});

	$("#triage-togo-pickup, #triage-catering-pickup").on('click tap', function () {
		var ordertype = $('#orderTypeValue').val();
		var itemCount = $('#itemCount').val();
		if ((itemCount > 0) && (ordertype == '2')) {
			$('#triage-deliveryToPickupModal').modal('show');
		} else {
			if (giftCardOrderExists()) {
				validateGiftCardOrder();
			} else {
				$("#orderTypeSelection").val($(this).attr("data-orderType"));
				$("#orderTriageForm").submit();
			}
		}
	});

	$("#triage-deliveryToPickupCancel").click(function () {
		$('#triage-deliveryToPickupModal').modal('hide');
	});

	$("#triage-deliveryToPickupContinue").click(function () {
		window.location.href = URLPrefixLocale('/menu-listing');
		sessionStorage.setItem('changedtoPickup', true);
	});

	$("#triage-catering-delivery").on('click tap', function () {
		var sessionOrderType = $('#sessionOrderType').val();
		if (giftCardOrderExists()) {
			validateGiftCardOrder();
		} else {
			if (sessionOrderType && (sessionOrderType == 'togo-pickup-order' || sessionOrderType == 'catering-pickup-order')) {
				$('#triage-change-pickup-to-delivery').modal('show');
			} else {
				$("#orderTypeSelection").val($(this).attr("data-orderType"));
				$("#orderTriageForm").submit();
			}
		}
	});
	$('#triage-change-pickup-to-delivery #pickup-to-deliverycontinue').on('click', function () {
		$('#triage-change-pickup-to-delivery').modal('hide');
		var delivery_url = $('#triage-change-pickup-to-delivery #pickup-to-deliverycontinue').attr("data-link");
		window.location = delivery_url;
	});
	/*submenu active Class*/
	$('.leftnav-submenu li a').on('click', function () {
		$('.leftnav-submenu li a').removeClass('active');
		var currenthashurl = window.location.hash.substr(1);
		var currentData = $(this).parent().attr('class');
		if (currenthashurl = currentData) {
			$(this).addClass('active');
		}
		/*41963*/
		sessionStorage.setItem('menuCategoryreDirect', $(this).parent().attr('category'));
		sessionStorage.setItem('subMenuCategoryreDirect', $(this).parent().attr('class'));
	});
	/*41963*/
	$('.menuCat').on('click', function () {
		sessionStorage.setItem('menuCategoryreDirect', $(this).attr('category'));
		sessionStorage.setItem('subMenuCategoryreDirect', "");
	});

	//Disable View more button in the new togo flow
	if (!($('#isShowViewMore').val() != undefined && $('#isShowViewMore').val() === 'true')) {
		$('#viewMoreOrders').hide();
	} else {
		$('#viewMoreOrders').show();
	}

	//Favourites Grid new Indicator rendering code
	$("#grid-viewdiv").find("li").each(function (i, obj) {
		var prodId = $(obj).data("id");
		var isNew = $(obj).find(prodId).data("id");
		if (isNew) {
			$(obj).find(".new-label").removeClass("hide").addClass("show")
		}
	});

	//Favourites list new Indicator rendering code
	$("#list-viewdiv").find("li").each(function (i, obj) {
		var prodId = $(obj).data("id");
		var isNew = $(obj).find(prodId).data("id");
		if (isNew) {
			$(obj).find(".list-new-btn").removeClass("hide").addClass("show")
		}
	});

	//order confirmation send sms
	$(document).on("click", "#togo-sendsms", function () {
		var phonenumber = document.getElementById('restaurantDetailsText').value;
		var phonenumberformatted;
		var len;
		if (phonenumber.length > 0) {
			var phonenumberformatted = phonenumber.replace(/\D/g, '');
		}
		if (phonenumberformatted == undefined) {
			len = 0;
		} else {
			var len = phonenumberformatted.length;
		}
		if (len <= 0) {
			$('#error_message_mobile').text($('#invalidphone').val());
			$("div#error_message_mobile").parent().css("display", "block");
		} else if (len < 10) {
			$('#error_message_mobile').text($('#invalidphone').val());
			$("div#error_message_mobile").parent().css("display", "block");
		} else if (phonenumber.length > 14) {
			var invalidPhoneNumber = phonenumber.split(",").pop();
			if (invalidPhoneNumber.length != 14) {
				$('#error_message_mobile').text($('#invalidphone').val());
				$("div#error_message_mobile").parent().css("display", "block");
			}
		} else if (isNaN(phonenumberformatted)) {
			$('#error_message_mobile').text($('#invalidphone').val());
			$("div#error_message_mobile").parent().css("display", "block");
		} else {
			$("#locText").modal('hide');
			doAJAX($(this), null, hideSmsBlock);
			$("div#location-pop-up").hide();
		}
		// preventing the page from being refreshed
		return false;
	});

	$('#location-show, #location-show-arrow , #headRestName').click(function () {
		$("div#location-pop-up").toggle();

		if ($("#location-pop-up").is(':visible')) {
			$('#locationUpArrow').show();
			$('#locationDownArrow').hide();
		} else {
			$('#locationUpArrow').hide();
			$('#locationDownArrow').show();
		}
	});

	/*left nav arrow on change*/
	$('.collapse').on('shown.bs.collapse', function () {
		$(this).parent().find(".glyphicon-menu-down").removeClass("glyphicon-menu-down").addClass("glyphicon-menu-up");
	}).on('hidden.bs.collapse', function () {
		$(this).parent().find(".glyphicon-menu-up").removeClass("glyphicon-menu-up").addClass("glyphicon-menu-down");
	});
	//Bootstrap left nav Acordion bg change 
	$('.nav-accordion .panel-heading a[data-toggle="collapse"]').on('click', function () {
		$('.nav-accordion .panel-heading a[data-toggle="collapse"]').removeClass('active');
		$(this).addClass('active');
	});
	/*left nav arrow on change end*/
	$('#vcheckoutemail').on('keypress', function (event) {
		var character = String.fromCharCode(event.keyCode);
		return isValid(character);
	});

	// Order conformation subAmount value css fix

	$subAmount = document.getElementsByClassName('subvalues-amount');
	if ($subAmount.length > 0) {
		$('.subvalues-amount').parent('.configOption-orderconf').addClass('subDash-amount clearfix');
	}
	/* drop down collapse issue */
	$('#restaurant-list-orderPage').click(function () {
		$('.custom-select').toggleClass('active');
	});
	$('#restaurant-list-conformationPopUp').click(function () {
		$('.custom-select').toggleClass('active');
	});
	if ($('#oc-dob-datepicker').length) {
		if ($('#oc-dob-datepicker').val().split('/').length === 3) {
			var dob = $('#oc-dob-datepicker').val().split('/');
			$('#dobMonth').val(dob[0]);
			$('#dobDay').val(dob[1]);
			$('#dobYear').val(dob[2]);
		}
	}

	if ($("#continue-previous-order").length > 0 && $("#startNewOrderConfirmModal").length > 0) {
		$("#continue-previous-order").click(function (event) {
			event.stopPropagation();
			$("#startNewOrderConfirmModal").modal('hide');
		});
	}

	//WO4042529 Changes
	$("[id=\\/order-online]").attr("href", "#");
	$("[id=\\/es\\/order-online]").attr("href", "#");
	getUpdatesCall();
	$('#offers').on('change', function () {
		getUpdatesCall();
	});

	/*Clear session after confirm*/
	if (location.pathname.indexOf("/commerce/order-confirmation") != -1) {
		clearSessionAfterConfirmation();
	}

	if (location.pathname.indexOf("menu/") > 0) {
		if ($("#currentCategory").length > 0 && $("#currentCategory").val() != undefined) {
			var currentCategory = $("#currentCategory").val().toLowerCase().replace(/ /g, "-");
			if (!($(".menuCat.active").attr("data-id") === currentCategory || $(".menuCat.active").children(".sub-link" + currentCategory).length > 0)) {
				if (!($(".menuCat.active").attr("data-id") === currentCategory)) {
					$('*[data-id="' + currentCategory + '"]').nextAll("span")[0].trigger("click");
				} else if ($(".sub-link" + currentCategory).length > 0 && $(".sub-link" + currentCategory).closest(".panel.panel-default").children(".menuCat.active").length === -1) {
					$(".sub-link" + currentCategory).closest(".panel.panel-default").find(".panel-title").find("span").trigger("click");
				}
			}

		}
	}
	//DP- Minor Enhancement change for kerrow/franchise location header menu changes
	var franchiseLocPhone = $("#togoFranchisePhoneNo").val();
	var isOnlineTogoEnabledValue = $("#isOnlineTogoEnabled").val();
	var inRestTogoEnabled = $("#inRestTogoEnabled").val();
	// messages
	var togoText = $("#togoText").val();
	var onlineTogoText = $("#onlineTogoText").val();
	var inrestTogoText = $("#inrestTogoText").val();
	var togoOffText = $("#togoOffText").val();
	if (typeof inRestTogoEnabled == 'undefined') {
		inRestTogoEnabled = false;
	} else {
		if (inRestTogoEnabled === "true") {
			inRestTogoEnabled = true;
		} else {
			inRestTogoEnabled = false;
		}
	}
	if (typeof isOnlineTogoEnabledValue == 'undefined') {
		isOnlineTogoEnabledValue = false;
	} else {
		if (isOnlineTogoEnabledValue === "true" || isOnlineTogoEnabledValue == "" || isOnlineTogoEnabledValue == null) {
			isOnlineTogoEnabledValue = true;
		} else {
			isOnlineTogoEnabledValue = false;
		}
	}

	if (!isOnlineTogoEnabledValue && inRestTogoEnabled) {
		if (window.location.href.indexOf('/es') > -1) {
			$("#\\/es\\/order-online").html("ToGo");
			//$(".franchiseOverlay").html(inrestTogoText)	
			$("#\\/es\\/order-online").attr("onclick", "showFranchiseModal();");
			$("#\\/es\\/order-online").attr("id", "franchiseMenuHeading");
			$("#franchiseMenuHeading").attr("style", "display: none;");
		} else {
			$("#\\/order-online").html("ToGo");
			$("#\\/order-online").removeAttr("onclick");
			$("#\\/order-online").attr("id", "franchiseMenuHeading");
			$("#franchiseMenuHeading").attr("style", "visibility: hidden;");
			//$(".franchiseOverlay").html(inrestTogoText)
		}
		$("#franchiseMenuHeading").removeAttr("href");
		$("#franchiseMenuHeading").attr("style", "cursor:pointer");
		$("#franchise_restphno").html(franchiseLocPhone);
		$("#omni_ordertogo_location_overlay").attr("style", "text-decoration:none");
		$("#omni_ordertogo_location_overlay").removeAttr("href");
		$("#omni_ordertogo_location_overlay").parent().attr("style", "width:150px!important;display:none;");
	} else if (!isOnlineTogoEnabledValue && !inRestTogoEnabled) {
		if (window.location.href.indexOf('/es') > -1) {
			$("#\\/es\\/order-online").html("ToGo");
			//$(".franchiseOverlay").html(togoOffText);	
			$("#\\/es\\/order-online").attr("onclick", "showFranchiseModal();");
			$("#\\/es\\/order-online").attr("id", "franchiseMenuHeading");
			$("#franchiseMenuHeading").attr("style", "display: none;");
		} else {
			$("#\\/order-online").html("ToGo");
			$("#\\/order-online").removeAttr("onclick");
			$("#\\/order-online").attr("id", "franchiseMenuHeading");
			$("#franchiseMenuHeading").attr("style", "visibility: hidden;");
			//$(".franchiseOverlay").html(togoOffText);
		}
		$("#franchiseMenuHeading").removeAttr("href");
		$("#franchiseMenuHeading").attr("style", "cursor:pointer");
		$("#franchise_restphno").html(franchiseLocPhone);
		$("#omni_ordertogo_location_overlay").attr("style", "text-decoration:none;");
		$("#omni_ordertogo_location_overlay").removeAttr("href");
		$("#omni_ordertogo_location_overlay").parent().attr("style", "width:150px!important;display:none;");
	}
	
	
	/*Consider inline form field validation*/ 
    
    $(".mandatoryEmail").on('focusout blur', function(event){
        
        var sEmail = $(this).val();
        if ($.trim(sEmail).length == 0) {

            $("#errorMsg_"+$(this).attr('id')).html($('#errorRB_'+$(this).attr('id')).val());
            $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
            event.preventDefault();
        }
        else{
            
            if (validateEmail(sEmail)) {
                $("#errorMsg_"+$(this).attr('id')).hide();
            }else{
                $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
                $("#errorMsg_"+$(this).attr('id')).html($('#invalidLoginVal_emailid').val());
            
            
            }
             event.preventDefault();
        }
        
        
    });
    
    $(".mandatoryPhone").on('focusout blur', function(event){
        
        var phoneNumber = $(this).val();
        if (phoneNumber.length==0) {
            
            $("#errorMsg_"+$(this).attr('id')).show();
            $("#errorMsg_"+$(this).attr('id')).html($('#errorRB_'+$(this).attr('id')).val());
            $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
			if(window.location.href.indexOf('/commerce/checkout')>-1){
                $("#errorMsg_"+$(this).attr('id')).appendTo($(this).parent());
            }
			event.preventDefault();
        }
        else{

        var input = $(this);
		var numsOnly = input.val().replace(/\D/g, '');
		if (numsOnly.length >= 10) {
			$("#errorMsg_"+$(this).attr('id')).hide();
			
	    }else{
	        $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
            $("#errorMsg_"+$(this).attr('id')).html($('#invalidPhoneVal_'+$(this).attr('id')).val());
			if(window.location.href.indexOf('/commerce/checkout')>-1){
                $("#errorMsg_"+$(this).attr('id')).appendTo($(this).parent());
            }
	        
	    }
		
		if (input.val().length >= 14) {
			$("#errorMsg_"+$(this).attr('id')).hide();
		}else{
		    $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
            $("#errorMsg_"+$(this).attr('id')).html($('#invalidPhoneVal_'+$(this).attr('id')).val());
			if(window.location.href.indexOf('/commerce/checkout')>-1){
                $("#errorMsg_"+$(this).attr('id')).appendTo($(this).parent());
            }		    
		}
             event.preventDefault();
        }
        
        
    });
    
    $('.formatPhone').on('focusout blur', function(event){
        
        
        var input = $(this);
		var numsOnly = input.val().replace(/\D/g, '');
		if (numsOnly.length >= 10 ||numsOnly.length == 0) {
			
			$("#errorMsg_"+$(this).attr('id')).hide();
			
	    }else{
	        $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
            $("#errorMsg_"+$(this).attr('id')).html($('#invalidPhoneVal_'+$(this).attr('id')).val());
	        
	    }
		
		if (input.val().length >= 14 ||numsOnly.length == 0) {

			$("#errorMsg_"+$(this).attr('id')).hide();
		}else{
		    $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
            $("#errorMsg_"+$(this).attr('id')).html($('#invalidPhoneVal_'+$(this).attr('id')).val());
		    
		}
             event.preventDefault();
        
    });
    
    $(".mandatoryFields").on('focusout blur', function(event){
        
        var InputVal = $(this).val();
        if ($.trim(InputVal).length == 0) {

            $("#errorMsg_"+$(this).attr('id')).html($('#errorRB_'+$(this).attr('id')).val());
            $("#errorMsg_"+$(this).attr('id')).css({'color':'#953E2A','display': 'block'}).show();
            event.preventDefault();
        }
        else{
            $("#errorMsg_"+$(this).attr('id')).hide();
             event.preventDefault();
        }
        
        
    });
	
	$("#guestSize").on('focusout blur', function(event){
        
        var InputVal = $(this).val();
        if ($.trim(InputVal).length == 0) {

            $("#guest-validation-error").show();
            event.preventDefault();
        }
        else{
            $("#guest-validation-error").hide();
			event.preventDefault();
        }
        
        
    });
	
	

});

function validateEmail(sEmail) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail)) {
        return true;
    }
    else {
        return false;
    }
}              
function validateEmail(confEmail) {
    var filter1 = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter1.test(confEmail)) {
        return true;
    }
    else {
        return false;
    }
}


/*copied from custom.js for join popup 
 * @Yes, send me special offers and news about Olive Garden checkbox event
 **/
function sendCustomTrafficEvent(linkName) {
	if ($('#dtmenabled').val() == "false") { //dtm flag start
		if (linkName != "Continue to Review" && linkName != "CHECK BALANCE" && linkName.trim() != "BUY PLASTIC GIFT CARD") {

			var pageName = s.pageName;
			var x = pageName + "|" + linkName + " link";
			s.linkTrackVars = 'events,eVar70,prop49,prop65';
			if (pageName.indexOf('purchase|gift-cards|choose-your-card') > -1 && linkName == 'CHECKOUT') {
				s.linkTrackVars = 'events,eVar70,prop49,eVar21,eVar22,eVar16';
				s.eVar21 = s.eVar66 = $('#couponCode').val();
				s.eVar22 = $('#total').text().replace('$', '').trim();
				s.eVar16 = $('.gc-img-sec').length;
			}
			if (pageName.indexOf('commerce|checkout-payment-method') > -1 && linkName == 'SUBMIT ORDER') {
				s.linkTrackVars = 'events,eVar70,prop49,eVar61,prop67,prop59';
				var pickupTime = $("#userRequestedPickupTime").val();
				var quotedPickupTime = $('#quotedPickupTime').val();
				s.eVar61 = s.prop67 = quotedPickupTime;
				s.prop59 = pickupTime;
			}
			if (pageName.indexOf('locations|pick-date-and-time') > -1 && linkName == 'CONTINUE') {
				var userActualPickupTime = $('#userActualPickupTime').val();
				var pickupTime = $("#requestedPickupTime").val();
				s.linkTrackVars = 'events,eVar70,prop49,eVar60,prop59,prop60';
				if (pickupTime != null && pickupTime != undefined && pickupTime != '') {
					s.eVar60 = s.prop59 = pickupTime;
				}
				if (userActualPickupTime != undefined && userActualPickupTime != '' && userActualPickupTime != null) {
					var pickFullDate = new Date(userActualPickupTime.split(' ')[0]);
					var weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
					var toGoDay = weekDays[pickFullDate.getDay()];
					s.prop60 = toGoDay;
				}
			}

			s.linkTrackEvents = 'event75';
			s.events = 'event75';

			var linkname = s.eVar70 = s.prop49 = x;
			s.tl($(this), 'o', linkname);
		}
	} //dtm flag end
}

$(function () {
	$(document).on("click", ".checkbox_d_overlay input[type='checkbox']", function () {
		var checked1 = $(this).is(':checked');
		if (checked1) {
			$('.checkbox_d_overlay input[type="checkbox"]:checked').parent().addClass('checkbox_checked');
		} else {
			$(this).parent().removeClass('checkbox_checked');
		}
	});
});

/*copied from custom.js end*/

/** @description Happy Hour handling 
 * @param {string} URL
 *
 */
function seourlconstruct(hhURL) {
	if (hhURL.indexOf('/happy-hour') > -1 || hhURL.indexOf('/chalkboard-series') > -1) {
		var locURL = '';
		var locationCookie = $.cookie("DRIREST");
		if (locationCookie) {
			locationCookie = locationCookie.replace(/\*/g, ',');
			var locValues = locationCookie.split("@@");
			if (locValues.length > 0) {
				if (hhURL.indexOf('/happy-hour') > -1) {
					locURL = '/happy-hour' + "/" + locValues[5].toLowerCase() + "/" + locValues[4].toLowerCase() + "-restaurant/" + locValues[11];
					locURL = locURL.replace(/[^a-zA-Z0-9/]/g, '-');
					/*Changes made for Multiple Hyphens Issue -Sai Priyanka */
					locURL = locURL.replace(/-{2,}/g, '-');
					$("a[href='/menu-listing/happy-hour']").attr('href', locURL);
				} else if (hhURL.indexOf('/chalkboard-series') > -1) {
					var pageURL = window.location + "";
					if (pageURL.indexOf('/locations') > -1) {
						$('html, body').animate({
							scrollTop: $("#chalkboardBeer").offset().top - 120
						}, 1000);
						$("a[href='/chalkboard-series']").attr('href', locURL + "#ChalkboardSeries");
					} else {
						locURL = '/locations' + "/" + locValues[5].toLowerCase() + "/" + locValues[4].toLowerCase() + "/" + locValues[1].toLowerCase() + "/" + locValues[11];
						locURL = locURL.replace(/[^a-zA-Z0-9/]/g, '-');
						/*Changes made for Multiple Hyphens Issue -Sai Priyanka */
						locURL = locURL.replace(/-{2,}/g, '-');
						if (hhURL.indexOf('/menu-listing/chalkboard-series') > -1) {
							$("a[href='/menu-listing/chalkboard-series']").attr('href', locURL + "#ChalkboardSeries");
						} else {
							$("a[href='/chalkboard-series']").attr('href', locURL + "#ChalkboardSeries");
						}
					}
				}
			}
		} else {
			if (hhURL.indexOf('/happy-hour') > -1) {
				$("a[href='/menu-listing/happy-hour']").attr('href', '/happy-hour');
			} else {
				$("a[href='/chalkboard-series']").attr('href', 'locations/location-search');
			}
		}
	}
}

function isValid(str) {
	return !/[~`!#$%\^&*()+=\-\[\]\\';,/{}|\\":<>\?]/g.test(str);
}

function AvoidSpace(event) {
	var spaceElement = event ? event.which : window.event.keyCode;
	if (spaceElement == 32) return false;
}

/**
 * Location confirmation popup changes starts
 * Favorities page changes starts
 */
$(document).on("click", "#plpquick-viewicon", function () {
	var isToGoLocationConfirmed = $('#isToGoLocationConfirmed').val();
	var navURL = $('#navURL').val();
	if (isToGoLocationConfirmed === 'true') {
		window.open(navURL, '_self')
	} else {
		// Set callback identifier in local storage
		sessionStorage.setItem('locationCallback', 'toGoFavorites');
		sessionStorage.setItem('locationNavURL', navURL);
		loadLocationConfirmationPopup();
	}
});
//Favorite page changes ends

//Reorder page changes starts
$(document).on("click", "[id*='togo_reorder_addtocart']", function () {
	var isToGoLocationConfirmed = $('#isToGoLocationConfirmed').val();
	var LoggedInUserPastDateVal = sessionStorage.getItem('cateringLoggedInUserPastDate');
	if (isGiftCardOrderExists()) {
		checkGiftCardOrder();
	} else if (LoggedInUserPastDateVal != undefined && LoggedInUserPastDateVal === 'true') {
		var delivery_url = $('#pickup-to-deliverycontinue').attr("data-link");
		window.location = delivery_url;
	} else {
		if (isToGoLocationConfirmed === 'true') {
			toGoReorder(this);
		} else {
			var commerceId = $(this).attr('data-commerce-id');
			if (commerceId) {
				$('#reOrderSource').val(commerceId);
			} else {
				$('#reOrderSource').val($(this).attr('data-orderId'));
			}
			// Set callback indentifier in local storage
			sessionStorage.setItem('locationCallback', 'toGoReOrder');
			loadLocationConfirmationPopup();
		}
	}
});
//Reorder page changes ends

//Reorder - View More starts
$(document).on("click", "#viewMoreOrders", function () {
	var buttonObj = $(this);
	var url = buttonObj.attr('data-url');
	var startIndex = Number($('#startIndex').val()) + Number($('#numOrders').val());
	request = $.ajax({
		url: url,
		type: "post",
		cache: false,
		data: {
			startIndex: startIndex
		},
		success: function (result) {
			$('#startIndex').val(startIndex);
			$('#tg-reorder').append(result);
			if (result.trim().indexOf('<input type="hidden" id="isShowViewMore" value="true"/>') == -1) {
				$('#viewMoreOrders').hide();
			} else {
				$('#viewMoreOrders').show();
			}
		}
	});
});
//Reorder - View More ends
//Location confirmation popup changes ends

function toGoReorder(data) {
	var orderIdForReorder = $(data).attr('data-order-id');
	var url = $(data).attr('data-url');
	var orderType = $(data).attr('data-orderType');
	request = $.ajax({
		url: url,
		type: "get",
		cache: false,
		data: {
			orderIdForReorder: orderIdForReorder,
			is_validate_cart_empty: 'Y',
			orderType: orderType
		}
	});
	request.done(function (response, textStatus, jqXHR) {
		togoSuccessReorder(response);
	});
}

/**
 * This Function is called when 'Continue'
 * button is clicked from Reorder Error States Overlay *
 */
$(document).on("click", "#togo-reorder-continue", function () {
	var orderIdForReorder = $(this).attr('data-order-id');
	var url = $(this).attr('data-url');
	var itemIdsForContinue = $("#itemIdsForContinue");
	var itemIdsForReorder = $.trim($("#itemIdsForReorder").val());
	var data = {
		orderIdForReorder: orderIdForReorder,
		itemIdsForReorder: itemIdsForReorder
	};
	if (itemIdsForContinue.length > 0) {
		var validItemIds = $.trim(itemIdsForContinue.val());
		data.validItemIds = validItemIds;
	}
	if (location.pathname
		.indexOf("location-confirmation") != -1 || location.pathname
		.indexOf("pick-date-and-time") != -1) {
		var requestedPickupDate = $.trim($("#requestedPickupDate").val());
		var requestedPickupTime = $.trim($("#requestedPickupTime").val());
		var selectedMenuType = $.trim($("#selectedMenuType").val());
		data.selectedMenuType = selectedMenuType;
		data.requestedPickupDate = requestedPickupDate;
		data.requestedPickupTime = requestedPickupTime;
		var ajaxurl = "togoReOrderStates";
		data.AJAX_FUNCTION = ajaxurl;
		url = $("#ajaxServletURL").val();
	}

	request = $.ajax({
		url: url,
		type: "get",
		cache: false,
		data: data
	});

	request.done(function (response, textStatus, jqXHR) {
		if (location.pathname
			.indexOf("location-confirmation") == -1 ||
			location.pathname
			.indexOf("pick-date-and-time") == -1) {
			togoSuccessReorder(response);
		} else {
			togoSuccessReorderFromPickUpPage(response);
		}
	});
});

//Add/Remove favorite item with login feature
$(document).on("click", "a[id*='favoriteitem-indicator']", function (event) {
	event.preventDefault();
	var inputObj = $(this);
	var prodID = inputObj.data('prodid');
	$('#source').val('favoriteitem-indicator-' + prodID);
	if ($(this).hasClass('active')) {
		$('a#favoriteitem-indicator-' + prodID).closest("li").append('<div class="togo-loader" id="favoriteitem_loader-' + prodID + '">Loader...</div>');
		$('#favoriteitem_loader-' + prodID).show();
		var giftItemId = inputObj.data('glitemid');
		var giftListId = inputObj.data('glistid');
		var data = {
			"giftItemId": giftItemId,
			"giftListId": giftListId
		};
		addSiteCodes(data);
		$.ajax({
			type: 'POST',
			url: '/web-api/favorite/remove-favorite',
			async: true,
			data: JSON.stringify(data),
			success: function (response) {
				$('#favoriteitem_loader-' + prodID).hide();
				$('#favoriteitem_loader-' + prodID).remove();
				if (response.hasOwnProperty('successResponse')) {
					getAllFavoriteItems(false);
					if (inputObj.data('remove')) {
						if (inputObj.closest('ul').find('li').length > 1) {
							inputObj.closest('li').remove();
						} else {
							sessionStorage.removeItem('favouriteItems');
							window.location.reload(true);
						}
					} else {
						inputObj.removeClass("active");
						inputObj.find('.fav-tooltip').html($('#favoriteAddMessage').val());
						inputObj.data('glistid', '');
						inputObj.data('glitemid', '');
					}
				} else if (response.hasOwnProperty('errorResponse')) {
					console.log('errorResponse', response);
				}
			},
			error: function (xhr, text, err) {
				console.log('error', err);
			},
			dataType: 'json',
			contentType: 'application/json'
		});
	} else {
		if ($('#isProfileTransient').val() === 'true') {
			// dtm login modal event START
			if ($("#dtmenabled").val() == "true") {
				var modalData = {
					"modalName": "login prompt",
					"modalIntent": "user login",
					"modalContent": "login form"
				};
				dtmModelEvents("DisplayModal", modalData);
			}
			// dtm login modal event END
			$("#loginPassword").val("");
			$('#catering-login-modal').modal('show');
			$('#cross-sell-modal-popup').modal('hide');
			var socialSuccessValue = '/menu-listing/pronto-lunch';
			var catID = inputObj.data('catid');
			$('#socialLoginForm_successURL').val(socialSuccessValue + '?isFavorite=true&prodId=' + prodID);
		} else {
			$('a#favoriteitem-indicator-' + prodID).closest("li").append('<div class="togo-loader" id="favoriteitem_loader-' + prodID + '">Loader...</div>');
			$('#favoriteitem_loader-' + prodID).show();
			var prodID = inputObj.data('prodid');
			var catID = inputObj.data('catid');
			var size = inputObj.data('mode');
			$("#favCatId").val(catID);
			var data = {
				"productId": prodID,
				"categoryId": catID,
				"togoNewFlow": true
			};
			addSiteCodes(data);
			$.ajax({
				type: 'POST',
				url: '/web-api/favorite/add-favorite',
				async: true,
				data: JSON.stringify(data),
				success: function (response) {
					$('#favoriteitem_loader-' + prodID).hide();
					$('#favoriteitem_loader-' + prodID).remove();
					if (response.hasOwnProperty('successResponse')) {
						getAllFavoriteItems(false);
						inputObj.addClass("active");
						inputObj.find('.fav-tooltip').html($('#favoriteRemoveMessage').val());
						inputObj.data('glistid', response.successResponse.giftListId);
						inputObj.data('glitemid', response.successResponse.giftListItemId);
					} else if (response.hasOwnProperty('errorResponse')) {
						var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;
						if (expResponse == 'sessionExpired') {
							$("#sessionExpired").modal('show');
						}
						console.log('errorResponse', response);
					}
				},
				error: function (xhr, text, err) {
					console.log('error', err);
				},
				dataType: 'json',
				contentType: 'application/json'
			});
		}
	}
});

$(document).on('click', '.listItemEvent', function (event) {
	var pdpUrl = $(this).find(".currentUrl").val();
	var senderElementName = event.target.tagName.toLowerCase();
	if (senderElementName !== 'a' && senderElementName !== 'img' && !$(event.target.parentElement).hasClass('dinein-icon')) {
		window.location.href = pdpUrl;
	}
});

function sendParam(formPrd, productUrl) {
	formPrd.action = productUrl;
	formPrd.method = "post";
	formPrd.submit();
}

//WO4042529 Changes
$(document).on("click", "[id=\\/order-online]", function () {
	if ($("#itemCount").val() > 0) {
		$("#startNewOrderConfirmModal").modal("show");
	} else {
		$(this).attr('href', '/order-online');
		window.location.href = "/order-online";
	}
});

$(document).on("click", "[id=\\/es\\/order-online]", function () {
	if ($("#itemCount").val() > 0) {
		$("#startNewOrderConfirmModal").modal("show");
	} else {
		$(this).attr('href', '/es/order-online');
		window.location.href = "/es/order-online";
	}
});

/**
 * Function to get all favorite items for current user.
 * Note: if it is ProfileTransient(i.e. if user has not logged in), the service responds with a failure status.
 * @param {boolean} markItems flag to decide whether to mark the items as favourite or not.
 */
function getAllFavoriteItems(markItems) {
	var locale = $('#currentLocale').val();
	$.ajax({
		type: 'GET',
		url: '/web-api/profile/favorite/products?locale=' + locale,
		async: true,
		success: function (response) {
			if (response.hasOwnProperty('successResponse') && response['successResponse']['favorites']) {
				sessionStorage.setItem('favouriteItems', JSON.stringify(response['successResponse']['favorites']));
				if (markItems) markItemsToFavorite(response['successResponse']['favorites']);
			}
		},
		error: function (xhr, text, err) {
			console.log('error', err);
		}
	});
}

/**
 * Function to check favorite items available for current user in session.
 * If not avalible in session get it from service.
 */
function checkForFavoriteItems() {
	if (typeof (Storage) !== "undefined") {
		var favouriteItems = JSON.parse(sessionStorage.getItem('favouriteItems'));
		if (favouriteItems) markItemsToFavorite(favouriteItems);
		else getAllFavoriteItems(true);
	} else {
		getAllFavoriteItems(true);
	}
}

/**
 * Function to Mark the items as favorite.
 * @param {Array} favoriteList Array of Objects containing the favorite item details
 */
function markItemsToFavorite(favoriteList) { //favoriteitem-indicator-prod81195
	if (favoriteList && favoriteList.length) {
		for (var itemIndex = 0; itemIndex < favoriteList.length; itemIndex++) {
			var itemDetails = favoriteList[itemIndex];
			$('#favoriteitem-indicator-' + itemDetails.productId).addClass("active")
				.data('glistid', itemDetails.giftListId)
				.data('glitemid', itemDetails.giftItemId)
				.find('.fav-tooltip').html($('#favoriteRemoveMessage').val());
		}
	}
}

/**
 * Function to clear some web session storage manually if application session changed or
 * user role changed before the window's session over.
 * Note: currently this function clears only favourite items of user stored in session
 * @todo Add the other data to be cleared from web session storage here.
 */
function clearWebSessionStorage() {
	var profileInfo = window.digitalData && window.digitalData.user && window.digitalData.user.profile && window.digitalData.user.profile.profileInfo;
	var prevProfileInfo = sessionStorage.getItem('profileInfo') ? JSON.parse(sessionStorage.getItem('profileInfo')) : '';
	if (profileInfo) {
		if (!prevProfileInfo) {
			sessionStorage.setItem('profileInfo', JSON.stringify(profileInfo));
		} else if (prevProfileInfo.sessionID != profileInfo.sessionID || profileInfo.profileID != prevProfileInfo.profileID) {
			sessionStorage.setItem('profileInfo', JSON.stringify(profileInfo));
			sessionStorage.removeItem('favouriteItems');
		}
	}
}

function getUpdatesCall() {
	if ($('#offers').prop('checked')) {
		$('#general-longhorn-logo').prop('checked', true);
		$('#general-bahama-breeze-logo').prop('checked', true);
		$('#general-seasons-logo').prop('checked', true);
		$('#general-capital-logo').prop('checked', true);
		$('#general-eddie-logo').prop('checked', true);
		$('#general-yard-logo').prop('checked', true);
		$('#general-cheddars-logo').prop('checked', true);
	} else {
		$('#general-longhorn-logo').prop('checked', false);
		$('#general-bahama-breeze-logo').prop('checked', false);
		$('#general-seasons-logo').prop('checked', false);
		$('#general-capital-logo').prop('checked', false);
		$('#general-eddie-logo').prop('checked', false);
		$('#general-yard-logo').prop('checked', false);
		$('#general-cheddars-logo').prop('checked', false);
	}
}

/**
 * success Function for Reorder from TOGO orders page
 */
function togoSuccessReorder(data) {
	$("#reorderErrorStates").modal('hide');
	$("#reorderErrorStates").remove();

	var callHandleReorder = $(data).find("#callHandleReorder");
	var orderType = $(data).find("#orderType");
	var noItems = $(data).find("#noItems");
	if ($.trim(orderType.val()) == "2" && $("#orderTypeValue").val() != "2") {
		var reorderErrorModal = $(data).filter("#reorderErrorStates");
		scrolloverlay($("#reorderErrorStates"));
		reorderErrorModal.modal();
	} else if ($.trim(noItems.val()) == "true") {
		$("#reorderErrorStates").modal('hide');
	} else if ($.trim(callHandleReorder.val()) == "true") {
		var formObj = $(data).find("form#reorder");
		$("body").append(formObj);
		formObj.submit();
	} else {
		var reorderErrorModal = $(data).filter("#reorderErrorStates");
		scrolloverlay($("#reorderErrorStates"));
		reorderErrorModal.modal();
		reorderErrorModal.find(".styled-select selectmenu-layoutform").each(function () {
			$(this).wrap("<span class='select-wrapper'></span>");
			$(this).after("<span class='holder'></span>");
			var firstOption = $(this).find("option:first").text();
			$(this).next(".holder").text(firstOption);
		});
		var datePicker = reorderErrorModal.find("#reorder_pickup_time");
		if (datePicker.length > 0) {
			var pickupTimeSelectBox = reorderErrorModal.find("#reorder_pickup_time");
			var intervalInMins = reorderErrorModal.find('#intervalInMinsReorder').val();
			var pickupDate = reorderErrorModal.find("#date_picker_reorder").val();
			populatePickUpTimeBox(pickupTimeSelectBox, intervalInMins, pickupDate);

			loadDatePicker(reorderErrorModal.find("#date_picker_reorder"));
		}
		$(window).scrollTop(0);
	}
}

/**
 * success Function for Reorder when guest is redirected to pick up
 * time page.
 */
function togoSuccessReorderFromPickUpPage(data) {
	$("#reorderErrorStates").modal('hide');
	$("#reorderErrorStates").remove();
	if (!!($.trim($("#requestedPickupDate").val()) && $.trim($("#requestedPickupTime").val()))) {
		$("#requestedPickupDate").val($(data).find("#reorder_reqPickupDate").val());
		$("#requestedPickupTime").val($(data).find("#reorder_reqPickupTime").val());
		$("#selectedMenuType").val($(data).find("#selectedMenuType").val());
	}

	$("#pickup_validItemIds").val($(data).find("#itemIdsForReorder").val());
	var callHandleReorder = $(data).find("#callHandleReorder");
	var noItems = $(data).find("#noItems");
	if ($.trim(noItems.val()) == "true") {
		location.reload();
	} else if ($.trim(callHandleReorder.val()) == "true") {
		$("form#form-pick-up-time").submit();
	} else {
		var reorderErrorModal = $(data).filter("#reorderErrorStates");
		reorderErrorModal.modal();
		reorderErrorModal.find(".styled-select selectmenu-layoutform").each(function () {
			$(this).wrap("<span class='select-wrapper'></span>");
			$(this).after("<span class='holder'></span>");
			var firstOption = $(this).find("option:first").text();
			$(this).next(".holder").text(firstOption);
		});
		var datePicker = reorderErrorModal.find("#reorder_pickup_time");
		if (datePicker.length > 0) {
			var pickupTimeSelectBox = reorderErrorModal.find("#reorder_pickup_time");
			var intervalInMins = reorderErrorModal.find('#intervalInMinsReorder').val();
			var pickupDate = reorderErrorModal.find("#date_picker_reorder").val();
			populatePickUpTimeBox(pickupTimeSelectBox, intervalInMins, pickupDate);
			loadDatePicker(reorderErrorModal.find("#date_picker_reorder"));
		}
		$(window).scrollTop(0);
	}
}

function validateMob(input1, input2, e) {
	var input3 = "#" + input1;
	var ftext = "";
	var mobArray, finalArray = new Array();
	var txtid = input1;
	var text = $(input3).val();
	if (e.keyCode == 44) {
		var inputLength = text.length;
		if (inputLength > 13 && text.substring(inputLength - 1) != ",") {
			var commaDivisions = text.split(",");
			var actualLength = inputLength - commaDivisions.length + 1;
			if (actualLength % 14 == 0) {
				$(input3).val(text + ",");
				return false;
			}
		}
	}
	if (e.keyCode != 32 && e.keyCode != 44 && e.keyCode != 188) {
		var data = $(input3).val();
		$(document).on('keypress', input3, function (e) {
			if (e.keyCode == 188 || e.keyCode == 44 || e.keyCode == 32 ||
				(e.keyCode != 32 && (e.keyCode > 31 && (e.keyCode < 48 || e.keyCode > 57)))) {
				e.preventDefault();
			}
		});
		if (input2 != undefined) {
			mobArray = input2.split(",");
		}

		$(input3).bind("paste", function (e) {
			e.preventDefault();
		});

		for (var index = 0; index < mobArray.length; index++) {
			if (isNotEmpty(mobArray[index])) {
				var input = mobArray[index];
				if ((mobArray[index].indexOf("-") > -1 && mobArray[index].indexOf("(") > -1 && mobArray[index].length == 14)) {
					var lastIndex = true;
					if (index + 1 == mobArray.length - 1) {
						if (mobArray[mobArray.length - 1].length == 0) {
							lastIndex = false;
						}
					}
					if (lastIndex) {
						var data = mobArray[index].substring(mobArray[index].length - 1);
						mobArray[index] = mobArray[index] + ",";
						finalArray.push(mobArray[index]);
						$(input3).val(mobArray);
					}
				} else {
					if (e.keyCode != 8 && e.keyCode != 188 && e.keyCode != 44 && e.keyCode != 32) {
						var fInput = mobArray[index];
						var input = mobArray[index];
						var l = mobArray[index].length;
						var text = mobArray[index];
						if (l <= 4) {
							for (var i = 0; i <= l; i++) {
								var codeA = text.charCodeAt(i);
								if (codeA > 31 && (codeA < 48 || codeA > 57)) {
									fInput = text.replace(/(\d{3})\)?/g, '$1)');
								}
							}
							if (text.charAt(0) != "(") {
								fInput = text.replace(/(\d{3})\)?/g, '($1) ');
							} else {
								fInput = text.replace(/(\d{3})\)?/g, '$1) ');
							}
						}
						if (l == 9) {
							fInput = text.replace(text, text + '-');
						}
						if (l >= 14) {
							fInput = text.substring(0, 14);
						}
						for (var index = 0; index < mobArray.length; index++) {
							if (mobArray[index - 1] != undefined) {
								ftext = mobArray[index - 1] + ftext;
							}
						}
						$(input3).val(ftext + fInput);
						return true;
					} else {
						$(document).on('keypress', input3, function (e) {
							if (e.keyCode == 188 || e.keyCode == 44 || (e.keyCode != 32 && (e.keyCode > 31 && (e.keyCode < 48 || e.keyCode > 57)))) {
								finalArray.push(mobArray[index]);
								$(input3).val(mobArray);
							}
						});
					}
					return true;
				}
			}
		}
	}
}

function isNotEmpty(propertyValue) {
	return propertyValue != null && propertyValue != '' &&
		propertyValue != undefined;
}

function togoScrolloverlay(getID) {
	getID.animate({
		paddingTop: "0px"
	}, function () {
		var getscrolltop = parseInt($(window).scrollTop());
		$('#create_error').show();
		$('.modal-backdrop').removeClass('modal-backdrop fade in');
		$('.modal-open').removeClass('modal-open');
		var headerH = $('#header').height();
		var createPosition = $('#order-confirmation').position().top - parseInt(headerH);
		$(window).scrollTop(createPosition);
	});
}

//Wait list functionality copied from custom.js
function getPartySize(a, wlRestId) {
	$(".partysize").removeClass("selected-partysize");
	var partySizeVal = a.innerHTML;
	document.getElementById("partySize").value = partySizeVal;
	$(a).addClass("selected-partysize");
	sendEstimatedWaitTime(partySizeVal, wlRestId);
}

function sendEstimatedWaitTime(partyvalue, wlRestId) {
	var data = {};
	data.partySize = partyvalue;
	data.wlRestId = wlRestId;
	data.page = "joinWaitList";
	$.ajax({
		url: '/ajax/waitlist-esttime-and-position.jsp',
		type: 'post',
		data: data,
		success: function (response) {
			var getFromTime = $(response).filter("#waitListJson").data("options").lowQuote;
			var getToTime = $(response).filter("#waitListJson").data("options").highQuote;
			var wl_estimateWaitTimeThreshold = $(response).filter("#waitListJson").data("options").estimateWaitTimeThreshold;
			var wl_thresholdMsg = $("#estimatedThresholdText").val();
			if (wl_estimateWaitTimeThreshold === true) {
				if ($("#waitThresMsg").length > 0) {
					$("#waitThresMsg").html(wl_thresholdMsg);
				}
				if ($("#waitTime").length > 0) {
					$("#waitTime").html(wl_thresholdMsg);
				}
				$('.new-time-num').attr("style", "display:none");
			} else {
				if ($("#waitThresMsg").length > 0) {
					if ((location.href.indexOf('.com/es/') > -1)) {
						$("#waitThresMsg").html("Tiempo aprox. de espera:");
					} else {
						$("#waitThresMsg").html("Estimated Wait time:");
					}
				}
				if ($("#waitTime").length > 0) {
					if ((location.href.indexOf('.com/es/') > -1)) {
						$("#waitTime").html("Tiempo aprox. de espera:");
					} else {
						$("#waitTime").html("Estimated Wait time:");
					}
				}
				$('.new-time-num').removeAttr("style");
				var wlAutoRemoveMinsVal = $(response).filter("#waitListJson").data("options").waitListAutoRemoveMinutes;
				if ((getFromTime && getToTime) == "0" || (getFromTime && getToTime) == undefined) {
					$('.new-time-num').html("No Wait");
					$('#wlautoremovemins').html(wlAutoRemoveMinsVal);
				} else if ((getFromTime && getToTime) == "" || (getFromTime && getToTime) == null) {
					$('.new-time-num').html("Unknown");
					$('#wlautoremovemins').html(wlAutoRemoveMinsVal);
				} else {
					$('.new-time-num').html(getFromTime + " - " + getToTime + " " + "min");
					$('#wlautoremovemins').html(wlAutoRemoveMinsVal);
				}
			}
		}
	});
}

function locationDownArrow() {
	$('#locationUpArrow').show();
	$('#locationDownArrow').hide();
	$('#location-pop-up').show();
}

function locationUpArrow() {
	$('#locationDownArrow').show();
	$('#locationUpArrow').hide();
	$('#location-pop-up').hide();
}

/**
 * Function to clear checkoutpage session storage manually if after conformation page
 * guestcount chnaged manually, partysize
 */
function clearSessionAfterConfirmation() {
	sessionStorage.removeItem('partySize');
	sessionStorage.removeItem('guestCount');
	sessionStorage.removeItem('asapEnabled');
	sessionStorage.removeItem('silverware');
	sessionStorage.removeItem('plates');
	sessionStorage.removeItem('cups');
	sessionStorage.removeItem('bowls');
	sessionStorage.removeItem('ice');
	sessionStorage.removeItem('heatingkit');
	sessionStorage.removeItem('cutOffTime');
	sessionStorage.removeItem("InstructionItem");
	sessionStorage.removeItem("cd_cartamount");
	sessionStorage.removeItem("leadTime");
	sessionStorage.removeItem("selectedTime");
	sessionStorage.removeItem("SamePickupPerson");
	$.removeCookie('silverwareSelect', {
		path: '/'
	});
	$.removeCookie('selected-val', {
		path: '/'
	});
	$.removeCookie('selected-val-guest', {
		path: '/'
	});
	$.removeCookie('guestcount', {
		path: '/'
	});
	$.removeCookie('platesVal', {
		path: '/'
	});
	$.removeCookie('ptgBowls', {
		path: '/'
	});
	$.removeCookie('ptgCups', {
		path: '/'
	});
	$.removeCookie('ptgIce', {
		path: '/'
	});
	$.removeCookie('ptgPlates', {
		path: '/'
	});
	$.removeCookie('cupsqty', {
		path: '/'
	});
	$.removeCookie('bowlsVal', {
		path: '/'
	});
}

/**
 * Triage and payment page initmap undefined issue fix
 * */
if (location.pathname.indexOf("/order-online") != -1 || location.pathname.indexOf("commerce/checkout-payment-method") != -1) {
	function initMap() {
		// console.log("initMap undefined");
	}
}

/* DP- Minor Enhancement change for kerrow/franchise location requirement */
$(document).on("click", "#franchiseModalClose , #done_ok", function () {
	$("#franchiseModal").hide();
	$("#franchiseModal").addClass("franshide");
	$("#franchise_eff").removeClass("modal-backdrop fade out");
	return false;
});

$(document).on("click", "#franchiseMenuHeading", function () {
	$("#franchiseModal").toggle();
	$("#franchise_eff").addClass("modal-backdrop fade in");
	$("#franchiseModal").attr("style", "display:block!important;");
});
/* DP- Minor Enhancement change for kerrow location franchise modal changes -end*/

$(window).on('load', function () {
	if (window.location.href.indexOf("/menu") != -1 && window.location.href.indexOf("/prod") != -1) {
		if ($('#enableImageZoom').val() !== '' && $('#enableImageZoom').val() !== undefined && $('#enableImageZoom').val() === 'true' && $('#enableImageZoom').val() !== null) {
			$('#imageQuality').zoom({
				on: 'click'
			});
		}
	}
	if($("#registrationId").length>0){
	    
	    if($("#registrationId").html() == "" ){
	    
	        $("#registrationId").html(sessionStorage.getItem('AccountName'));

	    }
	}
	
	
});