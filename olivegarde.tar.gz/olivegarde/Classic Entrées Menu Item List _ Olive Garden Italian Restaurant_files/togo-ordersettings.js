//Darden PLP list view and Grid view
'use strict';
const phoneNumberRegex = /(\d{3})(\d{3})(\d{4})/;
const phoneNumberFormat = '($1) $2-$3';
var restaurantId, ordertype, orderTypeSelected, currentDate;
var orderTypeValue = $('#orderTypeValue').val();
var errorid_array = [];
var dterrorid_array = [];
var todaytxt, tomorrowtxt, sorryNoTxt;
var closedText = $('#closedDayMessage').val();
var selectedTimeTxt;
var unAvailableMsg = "&nbsp;" + $('#noSlotAvaialbleMessage').val();
var disableOrderSettings;
var isDisableOrderSettingsVal = $('#disable_ordset_times_onload').val();
var disableOrderSettingSession = sessionStorage.getItem('disableOrderSettings');
if(disableOrderSettingSession == null || disableOrderSettingSession == undefined){
    sessionStorage.setItem('disableOrderSettings', isDisableOrderSettingsVal);
    disableOrderSettings = JSON.parse(isDisableOrderSettingsVal);
} else if (disableOrderSettingSession == 'true'){
	disableOrderSettings = true;
} else {
    disableOrderSettings = false;
}
var isExecuted = false;
$(document).on('triggerReadyFunction', function(event) {
    if (giftCardOrderExists()) {
        $('#order-type').hide();
        $('.content-wrapper').css('margin-top', '20px')
    }
    todaytxt = $('#today').val();
    tomorrowtxt = $('#tomorrow').val();
    sorryNoTxt = $('#sorryNoRestulsFound').val();
    currentDate = moment().format("MM/DD/YYYY");
    var deliveryCurrentDate = moment(new Date()).add(1, 'days').format("MM/DD/YYYY");
    var today_MMMDD = moment().format('MMM DD');
    restaurantId = getCookie('DRIREST', 0);
    $('#selected-Resid').val(restaurantId);
    var pathName = window.location.href;
    var newRestNum = sessionStorage.getItem('newRestNum');
    if (pathName.search('cart') != -1) {
        if (newRestNum) {
            $('#selected-Resid').val(newRestNum);
        }
    }

    // Avoid ordersettings & times call during on page load when the togo flag is disabled for the selected restaurant & no items in their cart
    if (!onlineTogoEnabled || (disableOrderSettings && onlineTogoEnabled && (orderTypeValue == 0 || orderTypeValue == 3) && cartItemsCount == 0)) {
        setOrderSettingDetails(orderTypeValue);
        sessionStorage.removeItem('locationChanged'); //added this to avoid the 2nd location time call with the default slot time in click of add to cart
        sessionStorage.setItem('isInitialAsap', "false"); //added this param to fix even though time selected asap is showing in header
        $('.rest-pickupdate-drop').hide();
    } else if (cartItemsCount > 0 && (orderTypeValue == 0 || orderTypeValue == 3)) { // Avoid ordersettings & times call after added items into their cart
        setOrderSettingDetails(orderTypeValue);
        displayDateTimeHeader();
    } else {
        getOrderSettingApi(true, init);
    }

    $(document).on('click.locationpickup-list li', '.keep-inside-clicks-open', function(e) {
        e.stopPropagation();
    });

    $('#noitems-continue').on('click', function() {
        var checkoutPageErrorid = sessionStorage.getItem('dterrorid_array');
        if (checkoutPageErrorid) {
            var combine_errorid;
            if (checkoutPageErrorid) {
                combine_errorid = checkoutPageErrorid;
                sessionStorage.removeItem('dterrorid_array');
            } else {
                combine_errorid = errorid_array.join(", ");
            }
            var restaurantID = $('#selected-Resid').val();
            if (!restaurantID) {
                restaurantID = getCookie('DRIREST', 0);
            }
            var isAsap = false;
            var reqBody = {
                "validateCartItems": false,
                "restaurantId": restaurantID,
                "removalCommerceIds": combine_errorid,
                "togoNewFlow": true
            };
            sessionStorage.setItem('mustsetTimeapi', true);
            updateLocationApi(reqBody, init, cartDatetimeErrorHandler);
            clearLocalSessionValues();
        } else {
            var combine_errorid = errorid_array.join(", ");
            var restaurantID = $('#selected-Resid').val();
            var isAsap = false;
            var selectedId = $('input[name="pickupdate-time"]:checked').attr('id');
            if (selectedId == "ordertype-asap") {
                isAsap = true;
            }
            var reqBody = {
                "validateCartItems": false,
                "restaurantId": restaurantID,
                "removalCommerceIds": combine_errorid,
                "togoNewFlow": true,
                "asapSelected": isAsap
            };
            sessionStorage.setItem('mustsetTimeapi', true);
            updateLocationApi(reqBody, init, restaurantErrorHandler);
            sessionStorage.removeItem('CartItems');
        }
    });
    $('#datetime-continue').on('click', function() {
        var combine_errorid = dterrorid_array.join(", ");
        var date = moment($('#ordertype-datetimepicker').val()).format('MM/DD/YYYY');
        var time = $('#pickup-timelist').val();
        var isAsap = false;
        var selectedId = $('input[name="pickupdate-time"]:checked').attr('id');
        if (selectedId == "ordertype-asap") {
            isAsap = true;
        }
        var reqBody = {
            "validateCartItems": false,
            "requestedPickupDate": date,
            "requestedPickupTime": time,
            "removalCommerceIds": combine_errorid,
            "asapSelected": isAsap
        };
        var moreListItem = $('#datetime-continue').attr('moreListItem');
        if (moreListItem) {
            setPickupTimeApi(reqBody, moreListItemSuccess, datetimeErrorHandler);
            $('#datetime-continue').removeAttr('moreListItem')
        } else {
            setPickupTimeApi(reqBody, init, datetimeErrorHandler);
        }
    });
    $('#eventdatetime-continue').on('click', function() {
        var combine_errorid = dterrorid_array.join(", ");
        var date = $('#updated_EDate').val();
        var time = $('#updated_ETime').val();
        var reqBody = {
            "validateCartItems": false,
            "requestedPickupDate": date,
            "requestedPickupTime": time,
            "removalCommerceIds": combine_errorid
        };
        setPickupTimeApi(reqBody, init, eventdatetimeErrorHandler);
    });
    $('#select-pickup').on('click', function() {
        ordertype = $('#orderType-input').val();
        if (ordertype == 2) {
            $('#deliveryToPickupModal').modal('show');
        }
    });

    $('#deliveryToPickupCancel,#deliveryToPickupClose').on('click', function() {
        $('#deliveryToPickupModal').modal('hide');
        $('#select-delivery').prop('checked', true);
    });

    $('#deliveryToPickupContinue').on('click', function() {
        changetoPickup();
    });

    $('#select-delivery').on('click', function() {
        ordertype = $('#orderType-input').val();
        if (ordertype == 0 || ordertype == 3) {
            $('#change-pickup-delivery').modal('show');
        }
    });
    $('#pickup-to-deliverycancel, #pickup-to-deliveryclose').on('click', function() {
        $('#select-pickup').prop('checked', true);
    });
    $('#pickup-to-deliverycontinue').on('click', function() {
        $('#change-pickup-delivery').modal('hide');
        var delivery_url = $('#pickup-to-deliverycontinue').attr("data-link");
        // dtm order type change alert from togo bar START
        if ($("#dtmenabled").val() == "true" && window.sessionStorage) {
            sessionStorage.setItem("dtmOTChngAlrt", "otChanged");
        }
        // dtm order type change alert from togo bar END
        window.location = delivery_url;
    });
    $("#number-guestlist").on('click', 'li', function() {
        $('#no-ofguest-vales').html($(this).text());
        var partySize = $(this).text().trim();
        partySizeApi(partySize, init);
        $('#no-of-guests').removeClass("open");
    });
    //datepicker
    $('#ordertype-asap').on('click', function() {
        orderTypeAsapEvent();
    });
    // call goes to ordersettings & times services when we click on pickup date/time header and the selected radio is specific date/time
    $("div.res-locationpickup-list-item.rest-pickupdate-drop.dropdown.keep-inside-clicks-open").click(function() {
        if ($("div.res-locationpickup-list-item.rest-pickupdate-drop.dropdown.keep-inside-clicks-open.open").length == 0) {
            var radioType = $('input[name="pickupdate-time"]:checked').attr('id');
            if (!isExecuted && radioType == 'ordertype-specificdate') {
                getOrderSettingApi(true, init);
                isExecuted = true;
            }
        }
    });
    $('#ordertype-specificdate').on('click', function() {
    	sessionStorage.setItem('pickupSelection', 'datetime');
        if (!isExecuted) { // Avoid calling multiple times call to ordersettings & times services
            getOrderSettingApi(true, init);
            isExecuted = true;
        } else {
        	orderTypeSpecificDateEvent();
        }
    });
    $(document).on('click', '.ordertype-selected-rest', function() {
        $('#ordering-frm-restaurantname,#restaurant-details').html($(this).closest('li').find('h3').html());
        $('#ordering-frm-default-address').html($(this).closest('li').find('.restaurant-address').html());
        $('#ordering-frm-default-city').html($(this).closest('li').find('.restaurant-city').html());
        $('#ordering-frm-default-ph').html($(this).closest('li').find('.restaurant-phone').html());
        $('#ordertype-orderingform').removeClass('open');
        $('#item-list-loc-results li').removeClass('selected_item');
        $(this).closest('li').addClass('selected_item');
        restaurantId = $(this).parent().find('input[type=hidden]').val();
        $('#selected-Resid').val(restaurantId);
        $('#ordertype-autocomplete').val('');
        var isAsapId = $('input[name="pickupdate-time"]:checked').attr('id');
        var isAsapSelected = false;
        var leadasapSelected = sessionStorage.getItem('leadasapSelected');
        if (isAsapId == 'ordertype-asap' || (leadasapSelected && leadasapSelected == 'true')) {
            isAsapSelected = true;
        }
    	if (!onlineTogoEnabled || (disableOrderSettings && onlineTogoEnabled && (orderTypeValue == 0 || orderTypeValue == 3) && cartItemsCount == 0)) {
    		isAsapSelected = false;
        }
        var reqBody = {
            "validateCartItems": true,
            "restaurantId": restaurantId,
            "togoNewFlow": true,
            "asapSelected": isAsapSelected
        };
        var isSwitchRestaurant = true;
        // dtm restaurant change alert from togo bar START
        if ($("#dtmenabled").val() == "true" && window.sessionStorage && $(this).parent().parent().find('a')) {
            var restUrl = "";
            restUrl = $(this).parent().parent().find('a').attr("href");
            if (restUrl && restUrl.indexOf("/") != -1) {
                restUrl = restUrl.slice(restUrl.lastIndexOf("/"));
                restUrl = restUrl.replace("/", "");
                restUrl = restUrl.replace("#DirectionContainer", "");
            }
            sessionStorage.setItem("dtmCngRestAlrt", "rstChanged");
            sessionStorage.setItem("rstRidId", restUrl);
        }
        // dtm restaurant change alert from togo bar END
        updateLocationApi(reqBody, init, restaurantErrorHandler, isSwitchRestaurant);
    });

    /*Date time updated json call*/
    $('body').on('click', function(evt) {
        $("#pickup-datetime-update").click(function(evt) {
            evt.stopPropagation();
        })
        var updatedTime = $('#updated_Time').val();
        var updatedDate = $('#updated_Date').val();
        if ($('#asapRadio').val()) {
            var asapRadio = $('#asapRadio').val().trim();
        }
        if ($('#spacificRadio').val()) {
            var spacificRadio = $('#spacificRadio').val().trim();
        }
        var isAsap = false;
        var dateValue = $('#ordertype-datetimepicker').val();
        var timeValue = $('#pickup-timelist').val();
        if (asapRadio && asapRadio == 'true') {
            isAsap = true;
            if (!updatedTime && !updatedDate && dateValue && timeValue) {
                var reqBody = {
                    "validateCartItems": true,
                    "requestedPickupDate": dateValue,
                    "requestedPickupTime": timeValue,
                    "asapSelected": isAsap
                };
                setPickupTimeApi(reqBody, init, datetimeErrorHandler);
            }
            $('#asapRadio').val('');
        }
        if (spacificRadio && spacificRadio == 'true') {
            isAsap = false;
            if (!updatedTime && !updatedDate && dateValue && timeValue) {
                var reqBody = {
                    "validateCartItems": true,
                    "requestedPickupDate": dateValue,
                    "requestedPickupTime": timeValue,
                    "asapSelected": isAsap
                };
                setPickupTimeApi(reqBody, init, datetimeErrorHandler);
            }
            $('#spacificRadio').val('');
        }

        if (updatedDate && !updatedTime) {
            updatedTime = $('#pickup-timelist').val();
        }
        if (!updatedDate && updatedTime) {
            updatedDate = $('#default_jsondate').val();
        }
        if (updatedTime && updatedDate) {
            $('#updated_EDate').val(updatedDate);
            $('#updated_ETime').val(updatedTime);
            var reqBody = {
                "validateCartItems": true,
                "requestedPickupDate": updatedDate,
                "requestedPickupTime": updatedTime,
                "asapSelected": isAsap
            };
            setPickupTimeApi(reqBody, init, datetimeErrorHandler);
        }

        $('#updated_Time').val('');
        $('#updated_Date').val('');
    }); /*Date time updated json call end*/

    setTimeout(function() {
        $("#delivery-currentdate,#pickup-currentdate").text(today_MMMDD);
    }, 600);

    $('#delivery-timelist').on('change', function() {
        $('#delivery-selected-time').html(this.value);
        $('#updated_Delivery_Time, #updated_Delivery_ETime, #default_Delivery_jsontime').val(this.value)
    });
    $('#pickup-timelist').on('change', function() {
        $('#pickup-selected-time').html(this.value);
        $('#actualPickupTime').html(this.value);
        $('#updated_Time, #updated_ETime, #default_jsontime').val(this.value);
        sessionStorage.setItem('menuSelectedTime', true);
    });

    $('body').on('click', function(evt) {
        $("#event-datetime-update").click(function(evt) {
            evt.stopPropagation();
        });
        if ($('#updated_Delivery_Time').val()) {
            var updatedTime = $('#updated_Delivery_Time').val().trim();
        }
        if ($('#updated_Delivery_Date').val()) {
            var updatedDate = $('#updated_Delivery_Date').val().trim();
        }
        if (updatedDate && !updatedTime) {
            if ($('#delivery-timelist').val()) {
                updatedTime = $('#delivery-timelist').val().trim();
            }
        }
        if (!updatedDate && updatedTime) {
            if ($('#default_Delivery_jsondate').val()) {
                updatedDate = $('#default_Delivery_jsondate').val().trim();
            }
        }
        if (updatedTime && updatedDate) {
            var reqBody = {
                "validateCartItems": true,
                "requestedPickupDate": updatedDate,
                "requestedPickupTime": updatedTime
            };
            setPickupTimeApi(reqBody, init, eventdatetimeErrorHandler);
        }
        $('#updated_Delivery_Time').val('');
        $('#updated_Delivery_Date').val('');
    });
    $('#ordertype-loader').hide();
    $('#ordertype-autocomplete,#restaurant-location-autocomplete').keyup(function() {
        var yourInput = $(this).val();
        var re = /[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\\/]/gi;
        var isSplChar = re.test(yourInput);
        if (isSplChar) {
            var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\=?;:'",.<>\{\}\[\]\\\/]/gi, '');
            $(this).val(no_spl_char);
        }
    });

    /*Datetime modal cancel page reload to revert datetime*/
    $('#dt-ordertype-errormodal .fav-crte-acc,#dt-ordertype-errormodal .close,#event-ordertype-errormodal .fav-crte-acc,#event-ordertype-errormodal .close').on('click', function() {
        location.reload();
    });

    $('#asapEnabled-ok').on('click', function() {
        var asapDatepickerVal = moment($('#asap-datetimepicker1').val()).format("MM/DD/YYYY");
        var selectedTime = $('#asap-timelist1').val();
        var reqBody = {
            "validateCartItems": true,
            "requestedPickupDate": asapDatepickerVal,
            "requestedPickupTime": selectedTime,
            'asapSelected': false

        };
        setPickupTimeApi(reqBody, asapOrderSettingsSetPickupTimeSuccess, []);
    });

    $('#pickup-timelist').attr('asapFlow', true);

    $(document).on('click', '#catringdeliverydatepickerId, #catringdeliverydatepickerId>a', function() {
        var delivery_url = $('#pickup-to-deliverycontinue').attr("data-link");
        window.location = delivery_url;
    });

    //future date limit crossed
    $("#close-order_simpleItem,#simpleItemErrorModel .close").on("click", function() {
        if ($('#selected_res_id').val() != $('#selected-Resid').val()) {
            var headerRefresh = $("#confirm-location-btn").attr('data-refresh');
        }
        if ($(this).attr("futuredaylimitcrossed") == "true" || (headerRefresh && headerRefresh == 'true')) {
            window.location.reload();
        }
    });
}); //Document ready end

function moreListItemSuccess(response) {
    if (response) {
        sessionStorage.removeItem('CartItems');
        checkoutCall();
    }
}

/*Asap Ordersetting function*/
function asapOrderSettingsSetPickupTimeSuccess(response) {
    $('#asapEnabled-Errormodal').modal('hide');
    var isAsapSelected = response && response.asapSelected;
    var restaurantId = $('#selected-Resid').val();
    var reqBody = {
        "validateCartItems": true,
        "restaurantId": restaurantId,
        "togoNewFlow": true,
        "asapSelected": isAsapSelected
    };
    updateLocationApi(reqBody, init, restaurantErrorHandler);
    window.location.reload();
}

function orderTypeAsapEvent(leadTimeUpdate) {
    if (!leadTimeUpdate) {
        $('#asapRadio').val('true');
        $('#spacificRadio').val('');
    }
    $('#pickup-asapdate').empty();
    $('#pickup-asapdate').html($('#ordertype-asap:checked').val());
    $('#pickup-asapdate #leadTime').html($('#ordertype-asap-element #leadTime').html());
    $('#ordertype-specific-datetime').hide();
}

function orderTypeSpecificDateEvent(leadTimeUpdate) {
    $('#pickup-asapdate').empty();
    if (!leadTimeUpdate) {
        $('#asapRadio').val('');
        $('#spacificRadio').val('true');
    }
    $('#ordertype-specific-datetime').show();
    var selectedDate = moment($('#ordertype-datetimepicker').val()).format('MMM DD');
    var selectedTime = $('#pickup-timelist').val();
    var isToday = moment($('#ordertype-datetimepicker').val()).isSame(moment(), 'd');
    if (isToday) {
        $('#pickup-dt-title-panel').show();
    } else {
        $('#pickup-dt-title-panel').hide();
    }
    var template = renderPickupDateTemplate(selectedDate, selectedTime);
    $('#pickup-asapdate').append(template);
    restaurantClosedValidation();
}

/*Asap Ordersetting function end*/
/** @description Function to change catering delivery to pickup 
 */
function changetoPickup() {
    $('.rest-pickupdelivery-drop').removeClass('open');
    restaurantId = $('#selected-Resid').val();
    var pickupTime = null;
    var type_date = $('#default_Delivery_jsondate').val();
    var type_updateddate = $('#updated_Delivery_EDate').val();
    var pickupDate1 = type_date ? type_date : '' || type_updateddate ? type_updateddate : '';
    var pickupDate = moment().format('MM/DD/YYYY');
    var reqBody = {
        'restaurantId': restaurantId,
        'pickupDate': pickupDate,
        'asapSelected': [],
        'orderType': 0
    };

    getPickupTimeApi(reqBody).done(function(response) {
        var lunch, dinner, interval, leadTime, inizialAsap, asapSelected, asapCutOffTime;
        if (response) {
            lunch = response.times && response.times.lunch;
            dinner = response.times && response.times.dinner;
            interval = response.interval;
            leadTime = response.successResponse && response.successResponse.leadTime;
            inizialAsap = response.successResponse && response.successResponse.asapEnabled;
            asapSelected = response.successResponse && response.successResponse.asapSelected;
            asapCutOffTime = response.successResponse && response.successResponse.asapCutoffTime;
        }
        setPickupInfoToSession(lunch, dinner, interval, leadTime, inizialAsap, asapSelected, asapCutOffTime);
        if (lunch && lunch != "false") {
            pickupTime = response.times.lunch.startTime;
        } else if (dinner && dinner != "false") {
            pickupTime = response.times.dinner.startTime;
        }

        var currentPickupTime = moment(pickupTime, 'h:mm').format('h:mm A');
        ordertypeApi(restaurantId, pickupDate, currentPickupTime, inizialAsap).done(function(response) {
            if (response.status == 'success') {
                $('#select-pickup').prop('checked', true);
                $('#delivery-errorMsg').hide();
                getOrderSettingApi(null, init);
                window.location.reload();
            } else if (response.errorResponse) {
                $('#delivery-errorMsg').html(response.errorResponse.fault.faultDescription);
                $('#delivery-errorMsg').show();
            }
        });
    });
}

function loadTimePicker(response, isPickup, unavailableSlots, date) {
    if (orderTypeSelected == 'delivery') {
        timepicker_API(response, false, unavailableSlots);
    } else {
        timepicker_API(response, true, unavailableSlots);
    }
    var locationDate = date || today.format("MM/DD/YYYY");
    setLocationDateTime(locationDate, response);
    /*Leadtime exit 59 min onpage load handler*/
    var asapenabled = response && response.successResponse && response.successResponse.asapEnabled;
    if (asapenabled) {
        var leadTimecheck = response && response.successResponse && response.successResponse.leadTime;
        var cutOffTime = parseInt(sessionStorage.getItem('cutOffTime'));
        if (!cutOffTime) {
            cutOffTime = response && response.successResponse && response.successResponse.asapCutoffTime;
            sessionStorage.setItem('cutOffTime', cutOffTime);
        }
        if ($('#pickup-timelist').attr('asapFlow') || $('#pickup-timelist').attr('specificFlow')) {
            if (leadTimecheck && cutOffTime && leadTimecheck > cutOffTime) {
                leadTimeChangedToSpecificDate(response, unavailableSlots);
                orderTypeSpecificDateEvent(true);
            }
            $('#pickup-timelist').removeAttr('asapFlow');
            $('#pickup-timelist').removeAttr('specificFlow');
        }
        if ($('#pickup-timelist').attr('capacityFlow')) {
            sessionStorage.setItem('checkoutSelectedTime', true);
            if (leadTimecheck && cutOffTime && leadTimecheck > cutOffTime) {
                leadTimeChangedToSpecificDate(response, unavailableSlots);
            }
            $('#pickup-timelist').removeAttr('capacityFlow');
        }
    }
}

/** @description Function to get current date time response
 * @param {string} data - ordersetting response
 * @param {string} isReloadPage - callback
 */
function init(response, isReloadPage, isNextSlot, isSwitchRestaurant, isInitialLoad, frmLocationModal) {
    var locationApiCallBack = null;

    var initialAsap = sessionStorage.getItem('isInitialAsap');
    if (initialAsap != undefined && initialAsap != null)
        sessionStorage.setItem('isInitialAsap', "true");
    else
        sessionStorage.setItem('isInitialAsap', "false");

    if (response) {
        var orderType = response ? response.orderType : null;
        var leadTime = response.leadTime ? response.leadTime : 0;

        $('#orderType-input').val(orderType);
        var newLocation = sessionStorage.getItem('locationChanged');
        var currentTime = sessionStorage.getItem('currentTime');
        if (currentTime)
            currentTime = Number(currentTime);
        var restaurantDetails = response ? response.restaurantDetails : null;
        var restaurantId = restaurantDetails.restaurantInfo;
        var pickupTimeStamp = response.requestedPickupTime ? moment(response.requestedPickupTime.time) : '';

        if (!pickupTimeStamp || newLocation) {
            // This is temporary fix added for populating the leadTime during non-operating hours. These variables are being used only during the first time load of menu page.
            if (leadTime == 0) {
                if (orderType == 0) {
                    leadTime = 25;
                } else if (orderType == 3) {
                    leadTime = 60;
                } else if (orderType == 2) {
                    leadTime = 1380;
                }
            }
            pickupTimeStamp = addLeadTimeToCurrent(leadTime, currentTime);
            sessionStorage.removeItem('locationChanged');
            sessionStorage.setItem('asapEnabled', response.asapEnabled);
            locationApiCallBack = setPickupDateTimeonLoad;
        }

        pickupTimeStamp = getConvertRestTime(pickupTimeStamp);
        var timesx12 = moment(pickupTimeStamp).format('h:mm A');
        var initialDate = moment(pickupTimeStamp).format("MM/DD/YYYY");
        var orderBarDspDate = moment(pickupTimeStamp).format("MMM DD");

        if (restaurantDetails && initialDate) {
            var formattedClosedDates = formatClosedDates(restaurantDetails.holidayDateInfo);
            while (formattedClosedDates.indexOf(initialDate) != -1) {
                var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
                initialDate = newDate.format('MM/DD/YYYY');
            }
        }
        $('#default_jsondate').val(initialDate);
        $('#default_jsontime').val(timesx12);
        if (orderBarDspDate && orderType == 2) {
            $("span#pickup-todaydate").html(orderBarDspDate);
            $("span#pickup-selected-time").html(timesx12);
        }
        var asapSelected = response.asapSelected;
        var reqBody = {
            'orderType': orderType,
            'nextAvailableSlot': 'true',
            'restaurantId': restaurantId,
            'pickupDate': initialDate,
            'asapSelected': asapSelected
        };

        if (orderType == 0 || orderType == 3) {
            orderTypeSelected = 'pickup';
        } else if (orderType == 2) { //delivery type type 2				
            orderTypeSelected = 'delivery';
        }

        var isExecuteUpdateCall = false;
        if (isInitialLoad) {
            var isTodayClosed = false;
            if (!pickupTimeStamp && initialDate != moment().format("MM/DD/YYYY")) {
                isTodayClosed = true;
                sessionStorage.setItem('isTodayClosed', 'true');
            }
            // Open location conformation popup
            var showPopupOnLoad = $('#showPopupOnLoad').val();
            var isToGoLocationConfirmed = $('#isToGoLocationConfirmed').val();
            var renderOrderSettingsOnPageLoad = $('#renderOrderSettingsOnPageLoad').val();
            if (isToGoLocationConfirmed && isToGoLocationConfirmed === 'false') {
                if ((showPopupOnLoad && showPopupOnLoad === 'true') &&
                    (renderOrderSettingsOnPageLoad && renderOrderSettingsOnPageLoad === 'false')) {
                    $("#confirm-location-btn").attr('data-refresh', true);
                    loadLocationConfirmationPopup(initialDate, isTodayClosed);
                }
            }
        }
        if (!isNextSlot) {
            updateDateTimeApi(loadTimePicker, false, reqBody, isSwitchRestaurant, initUpdateOrder, response, isReloadPage, frmLocationModal, isInitialLoad, locationApiCallBack);
            isExecuteUpdateCall = true;
        }

        if (isExecuteUpdateCall == false) {
            initUpdateOrder(response, reqBody, initialDate, restaurantId, isReloadPage);
        }
    }
}

function initUpdateOrder(response, reqBody, initialDate, restaurantId, isReloadPage) {
    var restaurantDetails = response ? response.restaurantDetails : null;
    var loggedInUser = $('#isProfileTransient').val();
    var orderType = $('#orderType-input').val();

    /*get date and time from timestamp for delivery*/
    var deliveryTimeStamp = response.deliveryServiceTime ? moment(response.deliveryServiceTime.time) : ''; //requestedPickupTime
    var delivery_timesx12 = moment(deliveryTimeStamp).format('h:mm A');
    var delivery_initialDate = moment(deliveryTimeStamp).format("MM/DD/YYYY");
    var delivery_initialDate_picker = moment(deliveryTimeStamp).format("DD MMM YYYY");
    if (orderType == 0 || orderType == 3) { //pickup type 0,1	
        sessionStorage.removeItem('cateringLoggedInUserPastDate');
        $('.date-service-drop').removeAttr('id');
        orderTypeSelected = 'pickup';
        $('#pickup-panel').show();
        $('#delivery-panel').hide();

        $('#select-pickup').prop('checked', true);
        $('#pickup-delivery').html($('#select-pickup').val());
        if (restaurantDetails) {
            $('#ordertype-latLong').val(restaurantDetails.address.longitudeLatitude);
            $('#ordering-frm-restaurantname, #restaurant-details').html(restaurantDetails.restaurantName);
            var address1 = (restaurantDetails.address && restaurantDetails.address.address1) ? restaurantDetails.address.address1 : '';
            var address2 = (restaurantDetails.address && restaurantDetails.address.address2) ? restaurantDetails.address.address2 : '';
            $('#ordering-frm-default-address').html(address1 + ' ' + address2);
            $('#ordering-frm-default-city').html(restaurantDetails.address.city + ', ' + restaurantDetails.address.state + ' ' + formatZipCode(restaurantDetails.address.zipCode, restaurantDetails.address.country));
            $.each((restaurantDetails.restPhoneNumber || []), function(index, value) {
                if (value.useType == 'Primary') {
                    var phoneNumber = value.Phone.replace(phoneNumberRegex, phoneNumberFormat); //phone number formate changed
                    $('#ordering-frm-default-ph').html(phoneNumber);
                }
            });
        }
        datePicker('ordertype-datetimepicker', [], orderDateTimeChangeHandler, initialDate, null, reqBody);
    } else if (orderType == 2) { //delivery type type 2				
        orderTypeSelected = 'delivery';
        $('#delivery-panel').show();
        $('#pickup-panel').hide();
        $('#default_Delivery_jsontime').val(delivery_timesx12);
        $('#default_Delivery_jsondate').val(delivery_initialDate);
        var address = response.deliveryGroup ? response.deliveryGroup.address1 + ', ' + response.deliveryGroup.city + ', ' + response.deliveryGroup.state + ' ' + response.deliveryGroup.postalCode : '';
        var partySize = response.deliveryGroup ? response.deliveryGroup.partySize : '';
        $('#delivery-address').html(address);
        $('#delivery-panel .edit-icon ').attr('title', address);
        $('#no-ofguest-vales').html(partySize);
        $('#select-delivery').prop('checked', true);
        $('#pickup-delivery').html($('#select-delivery').val());
        $('#pickup-panel').hide();
        var loggedInUserDate = moment(delivery_initialDate).format("MM/DD/YYYY");
        if (new Date(currentDate) > new Date(loggedInUserDate) && loggedInUser != undefined && loggedInUser === 'false') {
            sessionStorage.setItem('cateringLoggedInUserPastDate', true);
            $('#event-datetime-update').hide();
            $('.date-service-drop').attr('id', 'catringdeliverydatepickerId');
        } else {
            $('.date-service-drop').removeAttr('id');
            sessionStorage.removeItem('cateringLoggedInUserPastDate');
            $('#delivery-panel').show();
            reqBody = {
                "restaurantId": restaurantId,
                "pickupdate": delivery_initialDate,
                'orderType': orderType,
                'nextAvailableSlot': 'true',
                'asapSelected': false
            };
            datePicker('delivery-datetimepicker', [], deliveryDateChangeHandler, delivery_initialDate, null, reqBody);
            delivery_Initdate(delivery_initialDate_picker);
        }
    }

    $('#restaurant-details').attr('href', generateRestaurantDetailURL(restaurantDetails));
    // TODO: below code will changed in future		
    if (response.asapEnabled) {
        $('#asapEnabled').val(response.asapEnabled);
    } else {
        $('#asapEnabled').val(response.asapEnabled);
    }

    var isToday = moment(initialDate).isSame(moment(), 'd');
    if (isToday) {
        $('#pickup-dt-title-panel').show();
    } else {
        $('#pickup-dt-title-panel').hide();
    }

    orderTypeSelectHandler(response, reqBody);

    var mustsetTimeapi = sessionStorage.getItem('mustsetTimeapi');
    if (mustsetTimeapi) {
        sessionStorage.removeItem('mustsetTimeapi');
        afterUnavailableItemRemovedUpdateTime();
    }

    var pageReload = sessionStorage.getItem('pageReload');
    if (isReloadPage || pageReload) {
        window.location.reload();
        sessionStorage.removeItem('pageReload');
    }
}

/** @description Function to set current date time to elements in delivery flow
 * @param {string} date - current date
 */
function delivery_Initdate(date) {
    var datePickerVal = moment(date).format('MMM DD');
    var selectedDeliverytime = $('#default_Delivery_jsontime').val();
    var isToday = moment(date).isSame(moment(), 'd');
    if (selectedDeliverytime != null)
        selectedDeliverytime = selectedDeliverytime.trim();
    if (date) {
        setTimeout(function() {
            if (selectedDeliverytime) {
                selectedTimeTxt = " at <span id='delivery-selected-time'>" + selectedDeliverytime + "</span>";
            } else {
                selectedTimeTxt = unAvailableMsg;
            }
            if (isToday) {
                $('#delivery-asapdate').html("<span class='current-date-title' id='delivery-datetime-title'>" + todaytxt + " (<span id='delivery-todaydate'>" + datePickerVal + "</span>)</span>" + selectedTimeTxt);
                $('#delivery-todaydate-only').show();
            } else {
                $('#delivery-todaydate-only').hide();
                $('#delivery-asapdate').html("<span class='current-date-title' id='delivery-datetime-title'><span id='delivery-todaydate'>" + datePickerVal + "</span></span>" + selectedTimeTxt);
            }
        }, 800);
    }
}

/** @description Function to datepicker on change evenHander
 * @param {string} date - current values of datePicker
 */
function deliveryDateChangeHandler(val, reqBody) {
    var datePickerVal = moment(val.date._d).format('MMM DD');
    var hidden_eventdate = moment(val.date._d).format('MM/DD/YYYY');
    var isSame = moment(val.date._d).isSame(new Date(), "day");
    var selectedeventtime = $('#delivery-timelist').val();
    $('#delivery-asapdate').empty();
    if (isSame) {
        $('#delivery-todaydate-only').show();
    } else {
        $('#delivery-todaydate-only').hide();
    }
    var restaurantId = $('#selected-Resid').val();
    $('#updated_Delivery_Date,#updated_Delivery_EDate').val(hidden_eventdate);
    reqBody['asapSelected'] = false;
    updateDateTimeApi(timepicker_API, false, reqBody);
    var template = renderdeliveryDateTemplate(datePickerVal, selectedeventtime);
    $('#delivery-asapdate').append(template);
}

function orderDateTimeChangeHandler(val, reqBody) {
    var datePickerVal = moment(val.date._d).format('MMM DD');
    var hidden_datePickerVal = moment(val.date._d).format('MM/DD/YYYY');
    var isToday = moment(val.date._d).isSame(moment(), "day");
    var selectedtime = $('#default_jsontime').val();
    if ($('#pickup-timelist').val()) {
        selectedtime = $('#pickup-timelist').val();
    }
    var restaurantId = $('#selected-Resid').val()
    $('#pickup-asapdate').empty();
    if (isToday) {
        $('#pickup-dt-title-panel').show();
    } else {
        $('#pickup-dt-title-panel').hide();
    }
    $('#updated_Date, #updated_EDate').val(hidden_datePickerVal);
    reqBody['asapSelected'] = false;
    updateDateTimeApi(timepicker_API, true, reqBody);
    var template = renderPickupDateTemplate(datePickerVal, selectedtime);
    var isAsap = false;
    var selectedId = $('input[name="pickupdate-time"]:checked').attr('id');
    if (isToday && selectedId == "ordertype-asap") {
        isAsap = true;
    }
    var reqBody = {
        "validateCartItems": true,
        "requestedPickupDate": hidden_datePickerVal,
        "requestedPickupTime": selectedtime,
        "asapSelected": isAsap
    };
    setPickupTimeApi(reqBody, init, datetimeErrorHandler);
    $('#pickup-asapdate').append(template);
    restaurantClosedValidation();
}

/** @description Function to set common datepicker evenHander
 * @param {string} eleId - elementID
 * @param {string} closedDates - dynamic closedDates
 * @param {string} callback - callback 
 * @param {string} defaultDate - api date 
 */
function datePicker(eleId, closedDates, callback, defaultDate, asapmindate, reqBody) {
    var pickerMinDate;
    var dateTimePicker = $('#' + eleId).data("DateTimePicker");
    var orderTypeValue = $('#orderTypeValue').val();
    if (orderTypeValue == '2') {
        pickerMinDate = moment(new Date()).add(1, 'days').format("MM/DD/YYYY");
    } else if (asapmindate == true) {
        pickerMinDate = moment(new Date()).add(1, 'days').format("MM/DD/YYYY");
    } else {
        pickerMinDate = moment().format("MM/DD/YYYY");
    }
    if (dateTimePicker) {
        dateTimePicker.destroy();
        if ($._data($('#' + eleId)[0], 'events')) $('#' + eleId).off();
        $('#' + eleId).val('');
    }
    var formattedClosedDates = [];
    var isTodayClosed = sessionStorage.getItem('restaurantTimeOver') || sessionStorage.getItem('isTodayClosed');
    var disabledDates = sessionStorage.getItem('disabledDates');
    if (disabledDates) {
        var dateStr = disabledDates.split(',');
        formattedClosedDates = formattedClosedDates.concat(dateStr || []);
    }
    if (isTodayClosed) {
        sessionStorage.removeItem('isTodayClosed')
        formattedClosedDates.push(moment().format("MM/DD/YYYY"))
    }

    if (formattedClosedDates.length) sessionStorage.setItem('disabledDates', formattedClosedDates)
    var futureDaysThreshold = $('#futureDaysThreshold').val();
    if (futureDaysThreshold) {
        futureDaysThreshold = parseInt($('#futureDaysThreshold').val() - 1);
    } else {
        futureDaysThreshold = 29;
    }
    $('#' + eleId).datetimepicker({
        format: 'MM/DD/YYYY',
        extraFormats: ['MM/DD/YYYY'],
        debug: true,
        useCurrent: false,
        minDate: pickerMinDate,
        maxDate: moment().add(futureDaysThreshold, "day").format("MM/DD/YYYY"),
        disabledDates: formattedClosedDates,
        defaultDate: defaultDate || moment(),
        ignoreReadonly: true //for accessing in readonly input field
    });
    $('#' + eleId).on('dp.change', function(val) {
        addRestaurantDate(reqBody, restaurantId, moment(val.date._d).format('MM/DD/YYYY'));
        reqBody['nextAvailableSlot'] = false;
        var availableSlots = "";
        var isShowModal = false;
        getCapacityTimeslots(reqBody).done(function(responseCapacity) {
            if (responseCapacity && responseCapacity.successResponse && responseCapacity.successResponse.capacitySlots) {
                availableSlots = responseCapacity.successResponse.capacitySlots.availableSlots;
                if (availableSlots && availableSlots.length <= 0) {
                    isShowModal = true;
                }
            }
            if (isShowModal == true) {
                $('#' + eleId).val(defaultDate);
                $('#ordertype-selected-day-errormodal').modal('show');
                $('#ordertype-selected-day-errormodal').attr("style", "width:100% !important");
            } else {
                callback(val, reqBody);
                var pathName = window.location.href;
                if ((pathName.search('favorites') != -1) || (pathName.search('reorder') != -1)) {
                    sessionStorage.setItem('pageReload', true);
                }
            }
        });
    });
}

/** @description Function changes the closeddate format to the required disabling format and also stores in session
 * @param {any} closedDates
 * @param {any} response
 * @return {array} returns the formated closed dates 
 */
function formatClosedDates(closedDates, response) {
    var holidayList = (response && response.restaurantHolidays) || closedDates || '';
    var formattedClosedDates = [],
        formattedClosedDates1 = [],
        formattedClosedDates2 = [];
    var thanksGivingDisabledDates = sessionStorage.getItem('thanksDates');
    if (holidayList && holidayList.length > 0) {
        formattedClosedDates2 = holidayList.split('@');
        for (var i = 0; i < formattedClosedDates2.length; i++) {
            formattedClosedDates1 = formattedClosedDates2[i].split('/');
            formattedClosedDates.push(moment(formattedClosedDates1[1] + '/' + formattedClosedDates1[0] + '/' + formattedClosedDates1[2]).format("MM/DD/YYYY"));
        }
        if (thanksGivingDisabledDates) {
            formattedClosedDates.push(thanksGivingDisabledDates);
        }
        sessionStorage.setItem('disabledDates', formattedClosedDates);
    } else if (thanksGivingDisabledDates) {
        formattedClosedDates.push(thanksGivingDisabledDates);
        sessionStorage.setItem('disabledDates', formattedClosedDates);
    } else {
        sessionStorage.removeItem('disabledDates');
    }
    return formattedClosedDates;
}

function orderTypeSelectHandler(response, reqBody) {
    $('#pickup-asapdate').empty();
    var isAsapSelected = response.asapSelected;

    var isInitialAsap = sessionStorage.getItem('isInitialAsap');
    if (!isAsapSelected && isInitialAsap == "false") {
        isAsapSelected = true;
    }

    var asapEnabled = response.asapEnabled;
    var asapNotAvailable = response.asapNotAvailable;
    if (asapEnabled) {
        $('#pickup-asapdate').empty();
        $('#ordertype-asap-element').show();
        asapLoadTimeCalc(response, reqBody, true);
        if (asapNotAvailable) {
            $('#asapEnabledErrortext').html(asapNotAvailable);
            $('#asapEnabled-Errormodal').modal('show');
            asapInitialErrorDatetime();
        } else {
            if (isAsapSelected === true) {} else {
                orderSettingDatehandler();
            }
        }
    } else {
        $('#ordertype-asap-element').hide();
        orderSettingDatehandler();
    }
}

function orderSettingDatehandler() {
    $('#ordertype-specificdate').prop('checked', true);
    $('#ordertype-specific-datetime').show();

    var dateVal = $('#default_jsondate').val();
    if (dateVal) {
        var selectedDate = moment($('#default_jsondate').val()).format("MMM DD");
        var selectedTime = $('#default_jsontime').val();
        var template = renderPickupDateTemplate(selectedDate, selectedTime);
        $('#pickup-asapdate').html(template);
    }
}

/*
 * Populate ASAP & Pickup date/time in the menu header based on the session values
 */
function displayDateTimeHeader() {
    var asapSelected = sessionStorage.getItem('asapSelected');
    var asapEnabled = sessionStorage.getItem('asapLocationEnabled');
    var leadTime = sessionStorage.getItem('leadTime');
    var togoLeadTime = sessionStorage.getItem('togoLeadTime');
    var catLeadTime = sessionStorage.getItem('catLeadTime');
    var asapCutOffTime = sessionStorage.getItem('asapCutOffTime');
    var actualPickupDate = sessionStorage.getItem('actualPickupDate');
    var actualPickupTime = sessionStorage.getItem('actualPickupTime');
    
    if(leadTime)
    	leadTime = parseInt(leadTime);
    if(togoLeadTime)
    	togoLeadTime = parseInt(togoLeadTime);
    if(catLeadTime)
    	catLeadTime = parseInt(catLeadTime);
    
    if(asapCutOffTime)
    	asapCutOffTime = parseInt(asapCutOffTime);
    
    if (asapSelected == "true") {
    	asapSelected = true;
    } else {
    	asapSelected = false;
    }
    
    if (asapEnabled == "true") {
    	asapEnabled = true;
    } else {
    	asapEnabled = false;
    }
    
    if(orderTypeValue == 0 && !leadTime) {
    	leadTime = togoLeadTime;
    } else if(orderTypeValue == 3 && !leadTime) {
    	leadTime = catLeadTime;
    }

    if (asapEnabled && leadTime && leadTime < asapCutOffTime) {
        $('#ordertype-asap-element #leadTime').html(leadTime + " mins");
        leadTimeChangedToAsapCustom(asapSelected);
    } else {
        if(!actualPickupDate) {
        	var currentTime = sessionStorage.getItem('currentTime');
        	if (currentTime)
        		currentTime = Number(currentTime);
        	actualPickupDate = moment(currentTime).format('MMM DD');
        	actualPickupTime = getAsapTimeFromMins(leadTime, currentTime);
        }
        actualPickupDate = moment(actualPickupDate).format('MMM DD');
        var template = renderPickupDateTemplate(actualPickupDate, actualPickupTime);
        $('#pickup-asapdate').append(template);
        leadTimeChangedToSpecificDateCustom(asapSelected);
    }
}

/** @description Function to make the leadtime less then asapCutoffTime to display  
 * @param {string} response
 */
function leadTimeChangedToAsap(response) {
    var asapSelected = response && response.asapSelected;
    if (!asapSelected) {
        asapSelected = response && response.isAsapSelected;
    }
    var isInitialAsap = sessionStorage.getItem('isInitialAsap');
    if (!asapSelected && isInitialAsap == "false") {
        asapSelected = true;
    }

    $('#ordertype-asap-element').show();
    
    if (asapSelected) {
        $("#ordertype-asap").prop("checked", true);
        orderTypeAsapEvent(true);

    } else {
        $('#pickup-timelist').attr('specificFlow');
    }
    
}

/*
 * During initial load after added items to their cart, ASAP minutes display in the header
 */
function leadTimeChangedToAsapCustom(asapSelected) {
    $('#ordertype-asap-element').show();
    if (asapSelected) {
        $("#ordertype-asap").prop("checked", true);
        orderTypeAsapEvent(true);
    } else {
        $('#pickup-timelist').attr('specificFlow');
    }
}

/*
 * During initial load after added items to their cart, Pickup date/time display in the header
 */
function leadTimeChangedToSpecificDateCustom(asapSelected) {
    $('#ordertype-asap-element').hide();
    $("#ordertype-specificdate").prop("checked", true);
    if (asapSelected && asapSelected === true || asapSelected === false) {
        sessionStorage.setItem('leadasapSelected', asapSelected);
    }
}

/** @description Function to make the leadtime exit from asapCutoffTime  
 * @param {string} response
 */
function leadTimeChangedToSpecificDate(response, unavailableSlots) {
    $('#ordertype-asap-element').hide();
    $("#ordertype-specificdate").prop("checked", true);

    var cutOffTime = parseInt(sessionStorage.getItem('cutOffTime'));
    var leadTime = response && response.leadTime;
    if (!leadTime) {
        leadTime = response && response.successResponse && response.successResponse.leadTime;
    }
    var asapSelected = response && response.successResponse && response.successResponse.asapSelected;
    if (asapSelected === undefined) {
        asapSelected = response && response.asapSelected;
        if (asapSelected === undefined) {
            asapSelected = response && response.isAsapSelected;
        }
    }
    if (asapSelected && asapSelected === true || asapSelected === false) {
        sessionStorage.setItem('leadasapSelected', asapSelected);
    }
    if ((leadTime && cutOffTime && leadTime > cutOffTime) && (asapSelected && asapSelected === true)) {
        genrateNewTimeSlot(response, false, 'pickup-timelist', 'select-locationtime-list', unavailableSlots);
    }

    if (!$('#pickup-timelist').attr('asapFlow')) {
        orderTypeSpecificDateEvent(true);
    }
}

function restaurantClosedValidation() {
    var todayClosed = $('#ordertype-datetimepicker').attr('todayClosed');
    var asapEnabledVal = $('#asapEnabled').val();
    if (todayClosed && todayClosed == 'true') {
        if ($("#orderTypeValue") && $("#orderTypeValue").val() === "2") {
            if ($(".timelist-select") && $('.datetimepicker-panel')) {
                $(".timelist-select").hide()
                $('.datetimepicker-panel').after($('<div id="orderTodayErrorMsg" class="todayErrorMsg">' + closedText + '</div>'));
            }
        } else {
            $('#ordertype-specificdate').prop('checked', true);
            $('#pickup-asapdate').empty();
            $('#asapRadio').val('');
            $('#spacificRadio').val('true');
            $('#ordertype-specific-datetime').show();
            var selectedDate = moment($('#ordertype-datetimepicker').val()).format('MMM DD');
            var selectedTime = $('#pickup-timelist').val();
            var isToday = moment($('#ordertype-datetimepicker').val()).isSame(moment(), 'd');
            if (isToday) {
                $('#pickup-dt-title-panel').show();
            } else {
                $('#pickup-dt-title-panel').hide();
            }
            var template = renderPickupDateTemplate(selectedDate, selectedTime);
            $('#pickup-asapdate').append(template);
            $('#ordertype-specific-datetime .timelist-select,#pickup-selected-time,#ordertype-asap-element,#pickup-selected-time,#orderAtTime').hide();
            $('#orderTodayErrorMsg').remove();
            $('#ordertype-specific-datetime .datetimepicker-panel').after($('<div id="orderTodayErrorMsg" class="todayErrorMsg">' + closedText + '</div>'));

        }
    } else {
        $('#orderTodayErrorMsg').remove();
        $('#ordertype-specific-datetime .timelist-select,#pickup-selected-time,#pickup-selected-time,#orderAtTime').show();
        if ($("#orderTypeValue") && $("#orderTypeValue").val() == "2") {
            if ($(".timelist-select") && $('.datetimepicker-panel')) {
                $(".timelist-select").show();
            }
            $('#orderTodayErrorMsg').each(function() {
                $(this).remove();
            });
        }
    }
}

function renderPickupDateTemplate(selectedDate, time) {
    var isToday;
    var isTomorrow;
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    if (currentTime) {
        isToday = moment(currentTime).format("MMM DD"); //moment(new Date()).format("MMM DD");	
        isTomorrow = moment(currentTime).add(1, 'days').format("MMM DD");
    }

    if (time != null)
        time = time.trim();
    if (time) {
        selectedTimeTxt = " <span id='orderAtTime'>at</span> <span id='pickup-selected-time'>" + time + "</span>";
    } else {
        selectedTimeTxt = unAvailableMsg;
    }
    if (isToday == selectedDate) {
        return "<span class='current-date-title' id='pickup-datetime-title'>" + todaytxt + " (<span id='pickup-todaydate'>" + selectedDate + "</span>)</span>" + selectedTimeTxt;
    }
    if (isTomorrow == selectedDate) {
        return "<span class='current-date-title' id='pickup-datetime-title'>" + tomorrowtxt + " (<span id='pickup-todaydate'>" + selectedDate + "</span>)</span>" + selectedTimeTxt;
    }
    return "<span class='current-date-title' id='pickup-datetime-title'><span id='pickup-todaydate'>" + selectedDate + "</span></span>" + selectedTimeTxt;
}

function renderdeliveryDateTemplate(selectedDate, time) {
    var isToday;
    var isTomorrow;
    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    if (currentTime) {
        isToday = moment(currentTime).format("MMM DD"); //moment(new Date()).format("MMM DD");	
        isTomorrow = moment(currentTime).add(1, 'days').format("MMM DD");
    }

    var date = moment(selectedDate).format('MMM DD');
    if (time != null)
        time = time.trim();
    if (time) {
        selectedTimeTxt = " at <span id='delivery-selected-time'>" + time + "</span>";
    } else {
        selectedTimeTxt = unAvailableMsg;
    }
    if (isToday == selectedDate) {
        return "<span class='current-date-title' id='delivery-datetime-title'>" + todaytxt + " (<span id='delivery-todaydate'>" + selectedDate + "</span>)</span>" + selectedTimeTxt;
    }
    if (isTomorrow == selectedDate) {
        return "<span class='current-date-title' id='delivery-datetime-title'>" + tomorrowtxt + " (<span id='delivery-todaydate'>" + selectedDate + "</span>)</span>" + selectedTimeTxt;
    }
    return "<span class='current-date-title' id='delivery-datetime-title'><span id='delivery-todaydate'>" + selectedDate + "</span></span>" + selectedTimeTxt;
}

/** @description Function to get current datetime  response
 * @param {data} - response
 * @param {isPickup} - to handle whether delivery or pickup
 */
function timepicker_API(response, isPickup, unavailableSlots) {
    var restaurantClosed = response && response.restaurantClosed;
    var lunch = response && response.times && response.times.lunch;
    var dinner = response && response.times && response.times.dinner;
    if (restaurantClosed && restaurantClosed == 'true' || (lunch == false && dinner == false)) {
        if (lunch == false && dinner == false) {
            $('#ordertype-datetimepicker').attr('todayClosed', true);
        } else {
            $('#ordertype-datetimepicker').attr('todayClosed', restaurantClosed);
        }
    } else {
        if (response.orderType && response.orderType === 2 && restaurantClosed && restaurantClosed == true) {
            $('#ordertype-datetimepicker').attr('todayClosed', restaurantClosed);
        } else {
            $('#ordertype-datetimepicker').removeAttr('todayClosed');
        }
    }
    restaurantClosedValidation();
    var id = 'pickup-timelist';
    var selectedTime = $('#default_jsontime').val();
    if (!isPickup) {
        id = 'delivery-timelist';
        selectedTime = $('#default_Delivery_jsontime').val();
    }

    var timeTemplate = '';
    var interval = response.interval;
    $('#' + id).empty();
    var orderTypeValue = response.orderType;
    if (orderTypeValue == '2') {
        if (response && response.firstTimeSlot) {
            var firstTimeSlots = response.firstTimeSlot.split('#');
            var restAvaildate = new Date(response.restaurantAvailableDate);
            var requestedDate = new Date(response.requestedDate);
            var startTime = firstTimeSlots[0];
            var endTime = firstTimeSlots[2];
            if (restAvaildate.getTime() > requestedDate.getTime()) {
                timeTemplate = null;
            } else {
                if (restAvaildate.getTime() === requestedDate.getTime()) {
                    var startTime = firstTimeSlots[1];
                    var currentLocHour = response.restCurrenthoursForDeliveryDate + ":00";
                    if (parseTime(currentLocHour) > parseTime(startTime))
                        startTime = currentLocHour;
                }
                if (response && response.safeTimeSlot) {
                    var safeSlots = response && response.safeTimeSlot.split(',');
                }
                unavailableSlots = decorateUnavailableSlotsWithStatic(unavailableSlots);

                timeTemplate = ordersettingsRenderTimeSlotOptions(startTime, endTime, interval, selectedTime, response, unavailableSlots, safeSlots);
            }

            if (timeTemplate) {
                $('#' + id).append(timeTemplate);
            } else {
                $('#' + id).append('<option value=" " >' + $('#noSlotAvaialbleMessage').val() + '</option>');
            }
        } else {
            $("#sessionExpired").modal('show');
        }
    } else {
        var newPickupTime = "";
        if (sessionStorage && sessionStorage.getItem("newPickupTime")) {
            newPickupTime = sessionStorage.getItem("newPickupTime");
            sessionStorage.removeItem("newPickupTime");
            if (response.successResponse.capacitySlots.capacityDate) {
                var defaultDateTimeVal = renderPickupDateTemplate(response.successResponse.capacitySlots.capacityDate, newPickupTime);
                response.successResponse.asapEnabled = false;
                response.successResponse.asapSelected = false;
                $('#pickup-asapdate').empty().append(defaultDateTimeVal)
            }
        }
        if (response.times.lunch && response.times.lunch != "false") {
            var lunchStartTime = "";
            var lunchEndTime = getEndTime(response.times.lunch.endTime);
            if (newPickupTime) {
                lunchStartTime = newPickupTime;
            } else {
                lunchStartTime = getStartTime(response.times.lunch.startTime);
            }
            if (response.times.dinner && response.times.dinner != "false") {
                var dinnerStartTime = getStartTime(response.times.dinner.startTime);
                var dinnerEndTime = getEndTime(response.times.dinner.endTime);
                timeTemplate = ordersettingsRenderTimeSlotOptions(lunchStartTime, dinnerEndTime, interval, selectedTime, response, unavailableSlots);
            } else {
                timeTemplate = ordersettingsRenderTimeSlotOptions(lunchStartTime, lunchEndTime, interval, selectedTime, response, unavailableSlots);
            }
        } else if (response.times.dinner && response.times.dinner != "false") {
            var dinnerStartTime = "";
            if (newPickupTime) {
                dinnerStartTime = newPickupTime;
            } else {
                dinnerStartTime = getStartTime(response.times.dinner.startTime);
            }
            var dinnerEndTime = getEndTime(response.times.dinner.endTime);
            timeTemplate = ordersettingsRenderTimeSlotOptions(dinnerStartTime, dinnerEndTime, interval, selectedTime, response, unavailableSlots);
        }
        if (timeTemplate) {
            $('#' + id).append(timeTemplate);
        } else {
            $('#' + id).append('<option value=" " >' + $('#noSlotAvaialbleMessage').val() + '</option>');
        }
        if (!selectedTime) {
            $('#pickup-selected-time').html($('#pickup-timelist').val());
        }
    }
}

/** @description Function to eventdatetimeErrorHandler on event datetime change 
 * @param {data} - response
 */
function eventdatetimeErrorHandler(response) {
    var unavailableItems = response.unavailableItems;
    var htmlText = "";
    if (unavailableItems) {
        $('#event-ordertype-errormodal').modal('show');
        for (var i = 0; i < unavailableItems.length; i++) {
            if (unavailableItems[i]) {
                var template = "<p><b>- '" + unavailableItems[i].displayName + "'</b></p>";
                htmlText += template;
            }
        }
    } else {
        var template = "<p class='clearfix'>" + sorryNoTxt + "</p>";
        htmlText += template;
        $('#simpleItemErrorMsg #errorMessage').html(response.fault.faultDescription);
        $("#close-order_simpleItem,#simpleItemErrorModel .close").attr("futureDayLimitCrossed", true);
        $('#simpleItemErrorModel').attr("data-backdrop", "static");
        $('#simpleItemErrorModel').attr("data-keyboard", "false");
        $('#simpleItemErrorModel').modal('show');
    }
    $("p#event-unavailable-list").html(htmlText);
    $("p#event-unavailable-list").show();
    dterrorid_array = [];
    if (unavailableItems) {
        $.each(unavailableItems, function(index, value) {
            var ResponseList = value.id;
            dterrorid_array.push(ResponseList);
        });
    }
}

/** @description Function to datetimeErrorHandler unavailable Item on datetime change 
 * @param {data} - response
 */
function datetimeErrorHandler(response) {
    var htmlText = "";
    var asapError = response && response.fault && response.fault.faultCode;
    var asapErrorDes = response && response.fault && response.fault.faultDescription;
    var reconcileItemId = response && response.errorResponse && response.errorResponse.reconcileItemId;
    var expResponse = response && response.fault && response.fault[0] && response.fault[0].faultCode;
    var listItem = $('#renderedorderdetails li').length;
    if (reconcileItemId) {
        if (reconcileItemId.length < listItem) {
            $('#datetime-continue').attr('moreListItem', true);
        }
        for (var i = 0; i < reconcileItemId.length; i++) {
            if (reconcileItemId[i]) {
                dterrorid_array.push(reconcileItemId[i].id);
                htmlText += "<p><b>- '" + reconcileItemId[i].displayName + "'</b></p>";
            }
        }
    }

    if (asapError == 'asap_not_available_pickup') {
        $('#asapEnabledErrortext').html(asapErrorDes);
        $('#asapEnabled-Errormodal').modal('show');
        asapInitialErrorDatetime();
    } else {
        if (expResponse == 'sessionExpired') {
            $("#sessionExpired").modal('show');
        } else if ((reconcileItemId && reconcileItemId.length > 0) || response.unavailableItems.length > 0) {
            $('#dt-ordertype-errormodal').modal('show');
        } else {
            $('#simpleItemErrorMsg #errorMessage').html(asapErrorDes);
            $("#close-order_simpleItem,#simpleItemErrorModel .close").attr("futureDayLimitCrossed", true);
            $('#simpleItemErrorModel').attr("data-backdrop", "static");
            $('#simpleItemErrorModel').attr("data-keyboard", "false");
            $('#simpleItemErrorModel').modal('show');
        }
        var unavailableItems = response.unavailableItems;
        if (unavailableItems) {
            for (var i = 0; i < unavailableItems.length; i++) {
                if (unavailableItems[i]) {
                    var template = "<p><b>- '" + unavailableItems[i].displayName + "'</b></p>";
                    htmlText += template;
                }
            }
        } else {
            if (!reconcileItemId) {
                var template = "<p class='clearfix'>" + sorryNoTxt + "</p>";
                htmlText += template;
            }
        }
        $("p#dt-unavailable-list").html(htmlText);
        $("p#dt-unavailable-list").show();

        if (unavailableItems) {

            $.each(unavailableItems, function(index, value) {
                var ResponseList = value.id;
                dterrorid_array.push(ResponseList);
            });
        }
    }
}

/** @description Function to restaurantErrorHandler unavailable Item on location change 
 * @param {data} - response
 */
function restaurantErrorHandler(response) {
    var asapError = response && response.fault && response.fault.faultCode;
    var asapErrorDes = response && response.fault && response.fault.faultDescription;
    if (asapError == 'asap_not_available_pickup') {
        $('#asapEnabledErrortext').html(asapErrorDes);
        $('#asapEnabled-Errormodal').modal('show');
        var asapLocationChange = true;
        asapInitialErrorDatetime(asapLocationChange);
    } else {
        var unavailableItems = response.unavailableItems;
        var htmlText = "";
        var duplicateunavailableitems = [];
        duplicateunavailableitems = unavailableItems.map(function(item) {
            return item.displayName;
        }).filter(function(value, index, self) {
            return self.indexOf(value) === index;
        });
        if (unavailableItems) {
            $('#ordertype-errormodal').modal('show');
            for (var i = 0; i < duplicateunavailableitems.length; i++) {
                if (duplicateunavailableitems[i]) {
                    var template = "<p><b>- '" + duplicateunavailableitems[i] + "'</b></p>";
                    htmlText += template;
                }
            }
        } else {
            var template = "<p class='clearfix'>" + sorryNoTxt + "</p>";
            htmlText += template;
        }
        $("p#unavailable-list").html(htmlText);
        $("p#unavailable-list").show();

        errorid_array = [];
        if (unavailableItems) {
            $.each(unavailableItems, function(index, value) {
                var ResponseList = value.id;
                errorid_array.push(ResponseList);
            })
        }
    }
}

/** @description Function to make order setting api call
 * @param {object} params - request body
 * @param {function} successCallBack - success callback function
 * @param {function} errorCallBack - error callback function
 */
function getOrderSettingApi(params, successCallBack, errorCallBack, newParam, frmLocationModal) {
    var locale = $('#currentLocale').val();
    $.ajax({
        url: '/web-api/progressbar/ordersettings?locale=' + locale,
        cache: false,
        type: "GET"
    }).done(function(response) {
        successCallBack(response.successResponse, null, null, null, params, frmLocationModal);
        if (newParam) {
            $("#" + $("#confirm-location-btn").attr("data-element")).trigger("click");
        }
    });
}

/** @description Function to make api call setpickuptime
 * @param {object} reqBody - request body
 * @param {function} successCallBack - success callback function
 * @param {function} errorCallBack - error callback function
 */
function setPickupTimeApi(reqBody, successCallBack, errorCallBack, isNextSlot) {
    reqBody['togoMenuFlow'] = true;
    addSiteCodes(reqBody);
    $.ajax({
        url: '/web-api/ordersettings/setpickuptime',
        data: reqBody,
        type: "POST"
    }).done(function(response) {
        moreCookTimeValidation(response);
        if (response.successResponse) {
            if (successCallBack) {
                successCallBack(response.successResponse, reqBody.removalCommerceIds, isNextSlot);
                if ($('#process86edItems').length && $('#productRecords').length) {
                    process86edItems($('#productRecords'));
                } else if ($("#itemNADueToPrice").length == 0 && window.location.search.indexOf("editFlag") == -1) {
                    var prodId = $('#menuItemID').val();
                    var request = $.ajax({
                        url: "/ajax/togo-menu-item-add-button.jsp",
                        type: "post",
                        data: "menuItemID=" + prodId,
                        cache: false
                    });
                    request.done(function(response, textStatus, jqXHR) {
                        $(".pdp-addtocart-right").html($(response).find(".pdp-addtocart-right").html());
                        $("#quantity").attr('readonly', true);
                        //code for change the time the quantity launguage will change
                        var quantity = getQuantity();
                        $('#quantity').val($('#cartQuantity').val() + ' ' + quantity);
                        updateInitialCardPrice();
                    });
                }
                // dtm time change event from togo bar START
                if ($("#dtmenabled").val() == "true") {
                    var dateTimeSelected = "";
                    if (reqBody && reqBody['requestedPickupDate'] && reqBody['requestedPickupTime']) {
                        dateTimeSelected = new Date(reqBody['requestedPickupDate'].trim() + " " + reqBody['requestedPickupTime'].trim());
                    }
                    var modalData = {
                        "eventName": "change-timedate",
                        "eventStatus": "success",
                        "datetime": dateTimeSelected
                    };
                    dtmModelEvents("CartEvent", modalData);
                }
                // dtm time change event from togo bar END
            }
        }
        if (response.errorResponse) {
            if (errorCallBack) {
                errorCallBack(response.errorResponse);
            }
        }
    });
}

function updateDateTimeChangeHandler(updatedDt, isNextSlot) {
    var datePickerVal = moment(updatedDt).format('MMM DD');
    var hidden_datePickerVal = moment(updatedDt).format('MM/DD/YYYY');
    var isToday = moment(updatedDt).isSame(moment(), "day");
    var selectedtime = $('#default_jsontime').val();
    var restaurantId = $('#selected-Resid').val();
    $('#pickup-asapdate').empty();
    if (isToday) {
        $('#pickup-dt-title-panel').show();
    } else {
        $('#pickup-dt-title-panel').hide();
    }
    $('#updated_Date, #updated_EDate').val(hidden_datePickerVal);

    var template = renderPickupDateTemplate(datePickerVal, selectedtime);
    var isAsap = false;
    var selectedId = $('input[name="pickupdate-time"]:checked').attr('id');
    if (isToday && selectedId == "ordertype-asap") {
        isAsap = true;
    }
    var reqBody = {
        "validateCartItems": true,
        "requestedPickupDate": hidden_datePickerVal,
        "requestedPickupTime": selectedtime,
        "asapSelected": isAsap
    };
    setPickupTimeApi(reqBody, init, datetimeErrorHandler, isNextSlot);
    $('#pickup-asapdate').append(template);
    restaurantClosedValidation();
}

function updateDeliveryDateChangeHandler(updatedDt) {
    var datePickerVal = moment(updatedDt).format('MMM DD');
    var hidden_eventdate = moment(updatedDt).format('MM/DD/YYYY');
    var isSame = moment(updatedDt).isSame(new Date(), "day");
    var selectedeventtime = $('#delivery-timelist').val();
    $('#delivery-asapdate').empty();
    if (isSame) {
        $('#delivery-todaydate-only').show();
    } else {
        $('#delivery-todaydate-only').hide();
    }
    var restaurantId = $('#selected-Resid').val();
    $('#updated_Delivery_Date, #updated_Delivery_EDate').val(hidden_eventdate);

    var template = renderdeliveryDateTemplate(datePickerVal, selectedeventtime);
    $('#delivery-asapdate').append(template);
}

/** @description Function to make the api call for time
 * @param {string} restaurantId
 * @param {string} date
 * @param {function} successCallBack - success callback function
 * @param {string} isPickup - whether pickup or delivery
 * Note: renderPickupDateTemplate method will invoked if there is any problem with overriding
 */
function updateDateTimeApi(successCallBack, isPickup, reqBody, isSwitchRestaurant, initCallBack, initResponse, isReloadPage, frmLocationModal, isInitialLoad, locationApiCallBack) {
    var unavailableSlots = "";
    var availableSlots = "";
    var newPickupDate = "";
    var newPickupTime = "";
    var date = reqBody['pickupDate'];
    var restaurantId = reqBody['restaurantId'];
    var isAsapSelected = reqBody['asapSelected'];
    var isChangeSlotModal;
    var isChangeDayModal;
    var bErrorModal = false;
    var pickupTime = null;
    var inizialAsap = false;
    var restaurantClosed = false;
    var pickupTimeNotAvailable = false;
    reqBody['capacityEnabled'] = $('#isCapacityCheckEnabled').val().trim();
    addSiteCodes(reqBody);
    $.ajax({
        url: '/web-api/order/pickup/times',
        data: reqBody,
        cache: false,
        type: "get"
    }).done(function(response) {
        if (response) {
            var lunch = response.times && response.times.lunch;
            var dinner = response.times && response.times.dinner;
            var interval = response.interval;
            var leadTime = response.successResponse && response.successResponse.leadTime;
            inizialAsap = response.successResponse && response.successResponse.asapEnabled;
            var asapCutOffTime = response.successResponse && response.successResponse.asapCutoffTime;
            var asapSelected = response.successResponse && response.successResponse.asapSelected;
            setPickupInfoToSession(lunch, dinner, interval, leadTime, inizialAsap, asapSelected, asapCutOffTime);

            //This call to execute location-time service one time when the pickuptime is empty - START
            if (lunch != false) {
                pickupTime = lunch.startTime;
            } else if (dinner != false) {
                pickupTime = dinner.startTime;
            }

            restaurantClosed = response.restaurantClosed;
            if (restaurantClosed == 'true' || (lunch == false && dinner == false)) {
                pickupTimeNotAvailable = true;
                var newDate = moment(reqBody['pickupDate'], "MM/DD/YYYY").add('days', 1);
                reqBody['pickupDate'] = newDate.format('MM/DD/YYYY');
                //This will be invoked when the selected date is closed or after the restaurant closing hours with passing newDate
                updateDateTimeApi(successCallBack, isPickup, reqBody, isSwitchRestaurant, initCallBack, initResponse, isReloadPage, frmLocationModal, isInitialLoad, locationApiCallBack);
            } else if (locationApiCallBack)
                locationApiCallBack(reqBody['pickupDate'], pickupTime, inizialAsap);
            //This call to execute location-time service one time when the pickuptime is empty - END
        }
        if (!pickupTimeNotAvailable) {
            if (response && response.successResponse && response.successResponse.capacitySlots) {
                unavailableSlots = response.successResponse.capacitySlots.unavailableSlots;
                availableSlots = response.successResponse.capacitySlots.availableSlots;
                newPickupDate = response.successResponse.capacitySlots.capacityDate;
                if (availableSlots && availableSlots.length > 0) {
                    if (orderTypeValue == 0 || orderTypeValue == 3) {
                        newPickupTime = roundToMinutes(response.interval, availableSlots[0].startTime);
                    } else if (orderTypeValue == 2) {
                        newPickupTime = roundToMinutes(response.interval, availableSlots[0].startTime);
                    }
                }
            }
            if (newPickupDate) {
                if (newPickupDate != date) {
                    date = newPickupDate;
                    if (newPickupTime) {
                        if (orderTypeValue == 0 || orderTypeValue == 3) {
                            $('#default_jsontime').val(newPickupTime);
                            if (sessionStorage) {
                                sessionStorage.setItem("newPickupTime", newPickupTime);
                            }
                        } else if (orderTypeValue == 2) {
                            $('#delivery-timelist').val(newPickupTime);
                        }
                    }
                    if (orderTypeValue == 0 || orderTypeValue == 3) {
                        updateDateTimeChangeHandler(date, true);
                    } else if (orderTypeValue == 2) {
                        updateDeliveryDateChangeHandler(date);
                    }
                }
            }

            successCallBack(response, isPickup, unavailableSlots, date);
            formatClosedDates('', response);

            var showRestDateModal = sessionStorage.getItem('showRestDateErrorModal');
            var showRestTimeslotModal = sessionStorage.getItem('showRestTimeslotErrorModal');

            if (showRestDateModal == "true") {
                $('#ordertype-selected-day-errormodal').modal('show');
                sessionStorage.setItem('showRestDateErrorModal', false);
                bErrorModal = true;
            } else if (showRestTimeslotModal == "true") {
                $('#ordertype-selected-rest-errormodal').modal('show');
                sessionStorage.setItem('showRestTimeslotErrorModal', false);
                bErrorModal = true;
            }

            if (orderTypeValue == 0 || orderTypeValue == 3) {
                var selectTime = $('#pickup-timelist').val();
                if (isSwitchRestaurant == true) {
                    var defaultDt = $('#default_jsondate').val();
                    var defaultTime = $('#default_jsontime').val();
                    if (defaultDt) {
                        if (date && defaultDt != date) {
                            sessionStorage.setItem('showRestDateErrorModal', true);
                        } else if (defaultTime) {
                            if (selectTime && defaultTime != selectTime) {
                                sessionStorage.setItem('showRestTimeslotErrorModal', true);
                            }
                        }
                    }
                    $('#default_jsontime').val(selectTime);
                    $('#default_jsondate').val(date);
                    $('#pickup-selected-time').html(selectTime);
                    var reqSetPickupBody = {
                        "validateCartItems": true,
                        "requestedPickupDate": date,
                        "requestedPickupTime": selectTime,
                        "asapSelected": isAsapSelected
                    };
                    setPickupTimeApi(reqSetPickupBody);
                } else {
                    var defaultDt = $('#default_jsondate').val();
                    var prevSelectedTime = sessionStorage.getItem('selectedTime');

                    if (defaultDt) {
                        if (date && defaultDt != date) {
                            isChangeDayModal = 'true';
                        } else if (prevSelectedTime) {
                            if (prevSelectedTime && !validateIfAsapTime(selectTime, response.interval) && !validateIfAsapTime(prevSelectedTime, response.interval) && prevSelectedTime != selectTime) {
                                isChangeSlotModal = 'true';
                            }
                        }
                    }
                    sessionStorage.setItem('selectedTime', selectTime);
                    $('#default_jsontime').val(selectTime);
                    $('#default_jsondate').val(date);
                    $('#pickup-selected-time').html(selectTime);
                }
            } else if (orderTypeValue == 2) {
                var selectTime = $('#delivery-timelist').val();
                $('#delivery-selected-time').html(selectTime);
            }
            var changedResId = $('#selected-Resid').val();
            var currentResId = getCookie('DRIREST', 0);
            if (currentResId == changedResId) {
                frmLocationModal = false;
            }
            if (!frmLocationModal && initCallBack && initResponse) {
                initCallBack(initResponse, reqBody, date, restaurantId, isReloadPage);
            }
            var radioType = $('input[name="pickupdate-time"]:checked').attr('id');
            if (isInitialLoad && ((radioType == 'ordertype-specificdate' && isChangeSlotModal == 'true') || isChangeDayModal == 'true') && !bErrorModal) {
                $('#ordertype-selected-rest-errormodal').modal('show');
            }
            // DTM Code if cart id is emplty START
            if (digitalData && digitalData.cart && digitalData.cart.item && digitalData.cart.attributes && !digitalData.cart.cartID) {
                digitalData.cart.attributes.orderType = orderTypeValue;
                digitalData.cart.attributes.orderSubType = "New";
                if ($("#default_jsontime") && $("#default_jsondate")) {
                    var pickupDateDeflt = new Date($("#default_jsondate").val() + " " + $("#default_jsontime").val());
                    digitalData.cart.attributes.pickupTime = pickupDateDeflt.toString();;
                }
                digitalData.cart.item = [];
            }
        } // pickupTimeNotAvailable END
        // DTM Code if cart id is emplty END
    });
}

/** @description Function to make the api call for location time
 * @param {string} restaurantId
 * @param {string} pickupDate
 * @param {string} pickupTime
 */
function ordertypeApi(restaurantId, pickupDate, pickupTime, inizialAsap) {
    var isAsapSelected = false;
    var selected_Id = $('input[name="pickupdate-time"]:checked').attr('id');
    if (selected_Id == "ordertype-asap" || inizialAsap) {
        isAsapSelected = true;
    }
    var reqBody = {
        "restaurantId": restaurantId,
        "requestedPickupDate": pickupDate,
        "requestedPickupTime": pickupTime,
        "orderFlow": 'togo-pickup-order',
        "asapSelected": isAsapSelected
    };
    addSiteCodes(reqBody);
    return $.ajax({
        url: '/web-api/order/pickup/location-time',
        data: reqBody,
        type: "POST"
    });
}

/*ASAP DateTime Error function*/
function asapInitialErrorDatetime(asapLocChange) {
    var asapTodayDate;
    var restaurantId = $('#selected-Resid').val();
    if (!restaurantId) {
        restaurantId = getCookie('DRIREST', 0);
    }
    var asapmindate = true;
    var initialDate = moment(new Date()).add(1, 'days').format("MM/DD/YYYY");
    var closedDates = sessionStorage.getItem('disabledDates');
    if (closedDates) {
        var formattedClosedDates = closedDates.split(',');
        while (formattedClosedDates.indexOf(initialDate) != -1) {
            var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
            initialDate = newDate.format('MM/DD/YYYY')
        }
    }
    asapTodayDate = initialDate;
    if (asapLocChange) {
        asapTodayDate = moment().format("MM/DD/YYYY");
        asapmindate = false;
    }

    var newDate = sessionStorage.getItem('newDate');
    var pickupDate;
    if (newDate) {
        sessionStorage.removeItem('newDate');
        pickupDate = newDate;
    } else {
        pickupDate = asapTodayDate;
    }

    var reqBody = {
        'restaurantId': restaurantId,
        'pickupDate': pickupDate,
        'orderType': $('#orderTypeValue').val()
    };
    getPickupTimeApi(reqBody).done(function(response) {
        var initialDate = pickupDate;
        var formattedClosedDates = formatClosedDates(response.restaurantHolidays);
        var restaurantClosed, lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime;
        if (response) {
            restaurantClosed = response.restaurantClosed;
            lunch = response.times && response.times.lunch;
            dinner = response.times && response.times.dinner;
            interval = response.interval;
            leadTime = response.successResponse && response.successResponse.leadTime;
            asapEnabled = response.successResponse && response.successResponse.asapEnabled;
            asapSelected = response.successResponse && response.successResponse.asapSelected;
            asapCutOffTime = response.successResponse && response.successResponse.asapCutoffTime;
        }
        setPickupInfoToSession(lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime);
        if (restaurantClosed && restaurantClosed == 'true' || (lunch === false && dinner === false)) {
            do {
                var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
                initialDate = newDate.format('MM/DD/YYYY')
            } while (formattedClosedDates.indexOf(initialDate) != -1);
        } else {
            while (formattedClosedDates.indexOf(initialDate) != -1) {
                var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
                initialDate = newDate.format('MM/DD/YYYY')
            }
        }
        if (initialDate != pickupDate) {
            sessionStorage.setItem('restaurantTimeOver', 'true');
            sessionStorage.setItem('newDate', initialDate);
            sessionStorage.setItem('isTodayClosed', 'true');
            asapInitialErrorDatetime(asapLocChange);
        } else {
            sessionStorage.removeItem('restaurantTimeOver');
            asapUpdateTimeslots(response, 'asap-timelist1');
            datePicker('asap-datetimepicker1', [], asapErrorDateTimeChangeHandler, initialDate, asapmindate, reqBody);
        }
    });
}

/** @description moreCookTimeValidation based on moreCookTimeFlag
 * make moreCookTimeValidation
 * @param {object} response
 */
function moreCookTimeValidation(response) {
    var moreCookVal = response && response.successResponse && response.successResponse.moreCookTimeFlag;
    if (moreCookVal) {
        $('#pickupTimeUpdate').modal('show');
    }
}

/** @description afterUnavailableItemRemovedUpdateTime after removing unavailable item 
 * make setPickupTimeApi to set available times into backend
 */
function afterUnavailableItemRemovedUpdateTime() {
    var date = moment($('#ordertype-datetimepicker').val()).format('MM/DD/YYYY');
    var time = $('#pickup-timelist').val();
    var isAsap = false;
    var selectedId = $('input[name="pickupdate-time"]:checked').attr('id');
    if (selectedId == "ordertype-asap") {
        isAsap = true;
    }
    var reqBody = {
        "validateCartItems": false,
        "requestedPickupDate": date,
        "requestedPickupTime": time,
        "asapSelected": isAsap
    };
    setPickupTimeApi(reqBody);
}

function populateOrderSettingBar(orderType, locValues) {
    if ((orderType == 0 || orderType == 3)) { // pickup type 0,1
        $('.date-service-drop').removeAttr('id');
        orderTypeSelected = 'pickup';
        $('#pickup-panel').show();
        $('#delivery-panel').hide();
        $('#select-pickup').prop('checked', true);
        $('#pickup-delivery').html($('#select-pickup').val());

        $('#ordertype-latLong').val(locValues[2]);
        $('#ordering-frm-restaurantname, #restaurant-details').html(
            locValues[1]);
        var address1 = (locValues[3]) ? locValues[3] : '';
        var address2 = (locValues[12] && locValues[12] !== '~') ? locValues[12] : '';
        $('#ordering-frm-default-address').html(address1 + ' ' + address2);
        $('#ordering-frm-default-city')
            .html(
                locValues[4] + ', ' + locValues[5] + ' ' +
                locValues[6]);
        $('#ordering-frm-default-ph').html(locValues[7]);

        $('#restaurant-details').attr('href',
            generateOrderSettingRestaurantDetailURL(locValues));
        populateLeadTime(locValues);
    }
}