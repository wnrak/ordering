/*IOS browser back/Device back issue fixed*/
window.onpageshow = function(event) {
	if (event.persisted) {
		window.location.reload();
	}
};
/*IOS browser back/Device back issue fixed end*/

var optType="";
Handlebars.registerHelper('ifEquals', function (arg1, arg2, options) {
	return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper("xif", function (expression, options) {
	return Handlebars.helpers["x"].apply(this, [expression, options]) ? options.fn(this) : options.inverse(this);
});

Handlebars.registerHelper('greaterthan', function (v1, v2, options) {
	'use strict';
	if (v1 > v2) {
		return options.fn(this);
	}
	return options.inverse(this);
});

Handlebars.registerHelper('fixed', function (passedString) {
	if (passedString !== null && passedString !== undefined) {
		return parseFloat(passedString).toFixed(2);
	} else {
		return "0.00";
	}
});

Handlebars.registerHelper('trimString', function (passedString) {
	var theString = passedString.substring(10, 16);
	return new Handlebars.SafeString(theString)
});

Handlebars.registerHelper('renderingOption', function (aString) {
	if (aString === 'radioButton')
		return 'radio';
	else if (aString === 'dropdown') {
		return 'radio';
	} else {
		return 'checkbox';
	}
});

var noItemInCart,noRewardApplicable,sorryText,cateringPickupInfoText1,switchCateringPickup1,cateringPickupInfoText2,switchCateringPickup2;
var earnedInfotext1, earnedInfotext2, rewardText, couponText, pointsText, couponErrorMessage, couponRemovedText, minDeliveryAmtThreshold;
$(document).on('triggerReadyFunction', function(event) { 
    minDeliveryAmtThreshold = parseInt($('#minDeliveryAmtThreshold').val());
	noItemInCart = $('#noItemInCart').val();
	noRewardApplicable = $('#noRewardApplicable').val();
	sorryText = $('#sorryText').val();
	cateringPickupInfoText1 = $('#cateringPickupInfoText1').val();
	switchCateringPickup1 = $('#switchCateringPickup1').val();
	cateringPickupInfoText2 = $('#cateringPickupInfoText2').val();
	switchCateringPickup2 = $('#switchCateringPickup2').val();
	earnedInfotext1 = $('#earnedInfotext1').val();
	earnedInfotext2 = $('#earnedInfotext2').val();
	rewardText = $('#rewardText').val();
	couponText = $('#couponText').val();
	pointsText = $('#pointsText').val();
	couponRemovedText = $('#couponRemovedText').val();	
	invalidCoupon = $('#invalidCoupon').val();
	unrecognizedCoupon = $('#unrecognizedCoupon').val();
	expiredCoupon = $('#expiredCoupon').val();
	couponNotEligible = $('#couponNotEligible').val();
	couponNotApplicable = $('#couponNotApplicable').val();
	couponAlreadyRedeemed = $('#couponAlreadyRedeemed').val();
	invalidCouponText = $('#invalidCouponText').val();
	expiredCouponText = $('#expiredCouponText').val();
	requirementsNotMetText = $('#requirementsNotMetText').val();
	couponAlreadyRedeemedText = $('#couponAlreadyRedeemedText').val();
  	couponErrorMessage = $('#couponErrorMessage').val();
	var isLoyaltyenabled = $('#isLoyaltyEnabledLocation').val() === 'true';
	$('#rewards-enabled-section').hide();
	$('#rewards-disabled-section').show();
	$('#cart-info-messages').hide();
	if (isLoyaltyenabled && $('#isProfileTransient').val() === 'true') {
		$('#rewards-enabled-section').show();
		$('#rewards-disabled-section').hide();
		if ($('#iscouponDisplayEnabled').val() !== 'true') {
			if ($('#isProfileTransient').val() === 'true') {
				$('#togo-rewards').hide();
				$('#earned-points').hide();
				$('#rewards-login').show();

			} else {
				$('#togo-rewards').show();
				$('#earned-points').show();
				$('#rewards-login').hide();
			}
		}
	}
	$('#rewards-point,#rewardsRadio').click(function () {
		if ($('#isProfileTransient').val() === 'true') {
			$('#togo-rewards').hide();
			$('#earned-points').hide();
			$('#rewards-login').show();

		} else {
			$('#togo-rewards').show();
			$('#earned-points').show();
			$('#rewards-login').hide();
		}
	});
	$('#rewards-login').click(function () {
		$('#fromSlider').val('true');
		$("#loginPassword").val("");
	});

	$('#remove-point,#couponRadio').click(function () {
		$('#togo-rewards').hide();
		$('#earned-points').hide();
		$('#rewards-login').hide();
	});
	var notify = window.location.href.indexOf('cartOpen=true') >= 0;
	if (notify) {
		openCartSlider();
		updateURL();
	}

	$('.deleteXicon span').hide();
	$('#rewards-enabled-section').find('#coupon-certificate-field').on('change keyup paste mouseup', function () {
		 $('#coupon-certificate-error').removeClass('invalid_coupon_error');
		var couponVal = $('#rewards-enabled-section').find('#coupon-certificate-field').val();
		if (couponVal) {
			$('#rewards-enabled-section').find('.deleteXicon span').show();
		} else {
			$('#rewards-enabled-section').find('.deleteXicon span').hide();
		}
	});
	$('#rewards-disabled-section').find('#coupon-certificate-field').on('change keyup paste mouseup', function () {
		var couponVal = $('#rewards-disabled-section').find('#coupon-certificate-field').val();
		if (couponVal) {
			$('#rewards-disabled-section').find('.deleteXicon span').show();
		} else {
			$('#rewards-disabled-section').find('.deleteXicon span').hide();
		}
	});
	$('#close-to-pickup').click(function () {
		$('#myModalSwitchPickup').modal('hide');
	});
	$('#switch-to-pickup').click(function () {
		$('#myModalSwitchPickup').modal('hide');
		closeCartSlider();
		changetoPickup();
	});

	$(document).on('click', function () {
		var attr = $('#addCart-popup').attr('style');

		if (typeof attr !== typeof undefined && attr !== false) {
			$('#addCart-popup').fadeOut(500);
		}
	});
	
    $('#continue-shopping').click(function () {
		closeCartSlider();
	});
	if (($(location).attr("href").indexOf('/cart') >= 0) || ($(location).attr("href").indexOf('/commerce/checkout') >= 0) || $('#isRightRailCartEnabled').val() === 'true') {
		if (($(location).attr("href").indexOf('/cart') >= 0)) {
			$(".header-heading").remove();
		}
		callOrderDetail();
		if ($('#cartSuggestionsEnabled').val() === 'true' && $(location).attr("href").indexOf('/commerce/checkout') <= 0 ) {
			cart_page_related_products();
		}
	}
	if($(location).attr('href').indexOf('/commerce/checkout-payment-method') >= 0) {
		var paymentTitle = '<p>' + $('#paymentTitle').val() + '</p>';
		$('.header-heading').empty();
		$('.header-heading').append(paymentTitle);
	}
	$('#goBackCart').click(function () {
		if (document.referrer.indexOf('?') != -1) {
			window.location = document.referrer + '&cartOpen=true';
		} else {
			window.location = document.referrer + '?cartOpen=true';
		}
	});
	
	$('#myCarousel.cross-sell-carousel').carousel({
			interval: false,
			wrap: false
	});
	
	carousel_checkitem();
	$("#myCarousel.cross-sell-carousel").on("slid.bs.carousel", "", carousel_checkitem);
	
	$('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", true);
	$('#clearCouponBtn').hide()
	$('#coupon-certificate-field1').keyup(function () {
		if (this.value == "") {
			$('#rewards-disabled-section').find('#coupon-certificate-btn').prop('disabled', true);
			$('#clearCouponBtn').hide();
		} else {
			$('#rewards-disabled-section').find('#coupon-certificate-btn').prop('disabled', false);
			$('#clearCouponBtn').show();
		}

	});
	$('#clearCouponBtn').on('click', function () {
		$('#rewards-disabled-section').find('#coupon-certificate-btn').prop('disabled', true);
		$('#coupon-certificate-field1').val('');
		$('#coupon-certificate-error').removeClass('invalid_coupon_error');
		$('#clearCouponBtn').hide();
		$('#rewards-disabled-section').find('#coupon-certificate-error').html(couponErrorMessage);
	});

	/*Number of Item counts*/
	$('.fav-icon').on('click', function () {
		$(this).toggleClass('fav-icon-active');
	});

	if ($('#cartSliderCrossSellEnabled').val() === 'true' && $(location).attr("href").indexOf('/commerce/checkout') <= 0 && $(location).attr("href").indexOf('/cart') <= 0) {
		cart_slider_related_products();
	}
	var certicoupon = document.getElementById('couponRadio');
	if (certicoupon) {
		certicoupon.checked = true;
	}
	$("#couponRadio").on('click', function () {
		$("#togo-rewards").removeClass('in active');
		$("#coupon-certificate").addClass('in active');
	});
	$("#rewardsRadio").on('click', function () {
		$("#togo-rewards").addClass('in active');
		$("#coupon-certificate").removeClass('in active');
	});
	
	if($('#coupon-tab').hasClass('active')){
	    $("#coupon-certificate").addClass('in active');
	}
});

function infoMessage() {
    var currentLocale = $('#currentLocale').val();
	if (($('#orderTypeValue').val() !== undefined && $('#orderTypeValue').val() !== '' && $('#orderTypeValue').val() !== '2')) {
		$('#catering-message').hide();
		$('#pickup-message').show();
		if ($('#orderTypeValue').val() === '3') {//catering-pickup
			$('#togo-pickup-msg').hide();
			$('#catering-pickup-msg').show();
		} else {//togo-pickup
			$('#togo-pickup-msg').show();
			$('#catering-pickup-msg').hide();
		}
		$('#renderedDeliveryDetail').hide();
	} else {//catering-delivery
		$('#renderedDeliveryDetail').show();
		$('#catering-message').show();
		var cateringItemCount = $('#cateringItemCount').val();
		if (cateringItemCount > 0) {
			var estAmt = $('#cateringTotal').val();
			var minCateringAmt = $('#minDeliveryAmtThreshold').val();
			var orderminval = minCateringAmt - estAmt;
			$('#info-messages').show();
			if (orderminval > 0) {
				var msg = $('#cateringQualifierMessage').val().replace('minDeliveryAmtThreshold', orderminval.toFixed(2));
				$('#cateringinnerQualifyMessage').html(msg);
				$('#cateringQualifyMessage').show();
				$('#minimumCateringInfoMsg').hide();
				if(currentLocale == "en_US"){
				    $('#info-messages #deliveryPlaceDetails').removeClass('mintooltip');
				}else{
				    $('#info-messages #deliveryPlaceDetails').addClass('mintooltip');   
				}
				$('#qualifiedForDelivery').hide();
			} else {
				$('#qualifiedForDelivery').show();
				$('#cateringQualifyMessage').hide();
				$('#minimumCateringInfoMsg').hide();
				if(currentLocale == "en_US"){
				    $('#info-messages #deliveryPlaceDetails').addClass('mintooltip');
				}else{
				    $('#info-messages #deliveryPlaceDetails').removeClass('mintooltip');   
				}
			}
		} else {
			var itemCount = $('#itemCount').val();
			if (itemCount > 0) {
				$('#info-messages').hide();
				$('#minimumCateringInfoMsg').hide();
				if(currentLocale == "en_US"){
				    $('#info-messages #deliveryPlaceDetails').addClass('mintooltip');
				}else{
				    $('#info-messages #deliveryPlaceDetails').removeClass('mintooltip');   
				}
			} else {
				$('#info-messages').show();
				$('#minimumCateringInfoMsg').show();
				if(currentLocale == "en_US"){
				    $('#info-messages #deliveryPlaceDetails').removeClass('mintooltip');
				}else{
				    $('#info-messages #deliveryPlaceDetails').addClass('mintooltip');   
				}
			}
			$('#qualifiedForDelivery').hide();
			$('#cateringQualifyMessage').hide();
		}
		$('#pickup-message').hide();
	}
	cartSliderInnerscroll();
}

var quantityTimeout = {};

function carousel_checkitem() {
		var $this;
		$this = $("#myCarousel.cross-sell-carousel");
		if ($("#myCarousel.cross-sell-carousel .carousel-inner .item:first").hasClass("active")) {
			$this.children(".left").addClass('not-active');
			$this.children(".right").removeClass('not-active');
		} else if ($("#myCarousel.cross-sell-carousel .carousel-inner .item:last").hasClass("active")) {
			$this.children(".right").addClass('not-active');
			$this.children(".left").removeClass('not-active');
		} else {
			$this.children(".carousel-control").show();
			$this.children(".left").removeClass('not-active');
			$this.children(".right").removeClass('not-active');
		}
}

function callOrderDetail() {
	var stored_cartItems = JSON.parse(sessionStorage.getItem('CartItems'));
	var isstoredItems = false;
	if (stored_cartItems) {
		var storedOrderType = stored_cartItems && stored_cartItems.successResponse && stored_cartItems.successResponse.order && stored_cartItems.successResponse.order.orderType;
		var currentOrderType = parseInt($('#orderType').val());
		if (storedOrderType === currentOrderType) {
			isstoredItems = true;
		}
	}
	if (isstoredItems) {
		getOrderDetails(stored_cartItems);		
	} else {
		var data = {};
		apiCall('/web-api/order/detailed', 'GET', data, function (response) {
			if (response.successResponse) {
				sessionStorage.setItem('CartItems', JSON.stringify(response));
				getOrderDetails(response);				
			}
		}, null);
	}
	var isLoyaltyenabled = $('#isLoyaltyEnabledLocation').val() === 'true';
	if (isLoyaltyenabled && $('#isProfileTransient').val() === 'false') {
		var rewardsuri = "/web-api/profile/loyaltyInfo";
		var rewardData = {};
		apiCall(rewardsuri, 'GET', rewardData, getRewardsList, null);
	}
}

function debounce(func, wait, timeout, itemCount) {
	if (quantityTimeout.hasOwnProperty(timeout)) {

		clearTimeout(quantityTimeout[timeout][timeout]);
		quantityTimeout[timeout]['count'] = itemCount;
		quantityTimeout[timeout][timeout] = setTimeout(function () {
			func(quantityTimeout[timeout]['count'], timeout);
			delete quantityTimeout[timeout];
		}, wait);
	} else {
		var timeoutVal = setTimeout(function () {
			func(quantityTimeout[timeout]['count'], timeout);
		}, wait);
		var quantityObj = {};
		quantityObj[timeout] = timeoutVal;
		quantityObj['count'] = itemCount;
		quantityTimeout[timeout] = quantityObj;
	}
}

//get order Details Service
function deleteHandler(orderId, canDelete) {
	if (!canDelete) {
		$('#' + orderId).removeClass('active');
		return;
	}
	$('#drawer-panel,.item-list-mycart').prepend('<div class="togo-loader" id="cartLoader" style="display: block;"></div>');
	// added for DTM START
	var skuId = "";
	var productId = "";
	
	if(($("#"+orderId)) && ($("#"+orderId)).find("#skuId") && ($("#"+orderId)).find("#productId")){
		skuId = ($("#"+orderId)).find("#skuId").val();
		productId =($("#"+orderId)).find("#productId").val();
	}	
	// added for DTM END
	var data = {
		"removalCommerceIds": orderId,
		"skuId": skuId,
		"productId": productId
	};
	var uri = "/web-api/order/delete"
	apiCall(uri, 'POST', data,
		function (response) {
			if (response.formError) {
				$("#" + orderId).removeClass('active');
				$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
				var errorCode = response.formExceptions[0].errorCode
				var errorMsg = response.formExceptions[0].localizedMessage;
				if(errorCode == 'cart_TimeConflicts'){
					$('#timeConflictMessage').html(errorMsg);
					$('#timeConflictOk').attr('remove-Id', orderId);
					$('#timeConflictOk').attr('remove-data', true);
					$('#timeConflict').modal('show');
				}
				if (errorCode === 'errorRemovingItemFromOrder' || errorCode === 'errorUpdatingOrder') {
				    sessionStorage.removeItem('CartItems');
				    window.location.reload();
				}
			} else {				
				var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;				
				if(expResponse == 'sessionExpired'){
					$("#sessionExpired").modal('show');
				}else{
				// update data layer
				if(response && response.successResponse && response.successResponse.dataLayerJSON){
				window.digitalData= JSON.parse(response.successResponse.dataLayerJSON);
				}
				var itemCount = 0;
				$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
				var removeItemRes = response && response.successResponse && response.successResponse.order && response.successResponse.order.commerceItems;
				for (var i in removeItemRes) {
					itemCount += response.successResponse.order.commerceItems[i].quantity;
				}
				if (window.location.href.indexOf(orderId) >= 0) {
					window.location.href = itemCount > 0 ? window.location.origin + '/menu-listing?showCart=true' : window.location.origin + '/menu-listing';
				}
				$('#itemCount').val(itemCount + '');
				sessionStorage.setItem('CartItems', JSON.stringify(response));
				$("#" + orderId).remove();
				$('.drawer-list li.list-item').length == 0 ? $('.warning-exceeded').addClass('hidden') : '';
				var couponVal = response && response.successResponse && response.successResponse.order && response.successResponse.order.couponDiscount;
				var promoVal = response && response.successResponse && response.successResponse.order && response.successResponse.order.promotionDiscount;
				if(couponVal == 0 && promoVal == 0){
				    if(response.successResponse.order.discountType!=undefined){
    			        $('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", false);
        				$('#rewards-enabled-section').find('#coupon-certificate-error').html(couponRemovedText);
        				$('#rewards-disabled-section').find('#coupon-certificate-error').html(couponRemovedText);
        				$('#coupon-discount').hide();
        				$('#coupon-apply-section').show();
        				$('#togo-rewards').removeClass('hidden');
        				$('.deleteXicon span').hide();
        				$("#rewards-tab").removeClass();
        				$("#coupon-tab").removeClass();
						$('.enter-coupon-txt').removeClass('rm-coupon-sec');
						$('.hide-coupon-section').addClass('rm-coupon-sec');
				        if(response.successResponse.order.discountType ==='REWARD' || response.successResponse.order.discountType ==='VOUCHER'){
            				$("#rewards-tab").addClass('active');
        				}else { 
        				    $("#coupon-tab").addClass('active');
        				}
				    }
				}
				getOrderDetails(response);
				cartSliderInnerscroll();
				var orderType = $('#orderTypeValue').val();
				var restaurantId = $('#selected-Resid').val();
				var pickupDate = $('#default_jsondate').val();
				var reqBody = {
							"restaurantId": restaurantId, 
							"pickupdate": pickupDate, 
							"orderType": orderType
						};
				if(response && response.successResponse && response.successResponse.leadTime) {
					var response =  response.successResponse;									
					asapLoadTimeCalc(response, reqBody, true);
				}
				}	
			}
		}, null);
}

//Get Order Details Service
function getOrderDetails(commerceItems) {
	checkoutPageCouponValidation(commerceItems);
	$('.warning-exceeded').removeClass('drawer-item-no-cart');
	var data = commerceItems && commerceItems.successResponse && commerceItems.successResponse.order;
	var source = $('#source').val();
	var orderdetailsSource;
	if($('#orderdetails-template').html()){
		orderdetailsSource = document.getElementById("orderdetails-template").innerHTML;
		var orderdetailsResultTemplate = Handlebars.compile(orderdetailsSource);
		$("#renderedorderdetails").html(orderdetailsResultTemplate(data));
		$("#renderedorderdetails-2").html(orderdetailsResultTemplate(data));
	}
	
	if ($('#orderdetails-template-delivery').html()) {
		var orderdetailsSource1 = document.getElementById("orderdetails-template-delivery").innerHTML;
		var orderdetailsResultTemplatedel = Handlebars.compile(orderdetailsSource1);
		$("#renderedDeliveryDetail").html(orderdetailsResultTemplatedel(data));
	}
	
	$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
	var Ordertype = $('#orderTypeValue').val();
	var itemCount = 0;
	var isCateringitemExists = true;
	var cateringTotal = 0;
	var cateringItemCount = 0;
	var dataCommerceItems = data && data.commerceItems;
	for (var i in dataCommerceItems) {
		itemCount += data.commerceItems[i] && data.commerceItems[i].quantity;

			cateringItemCount += data.commerceItems[i] && data.commerceItems[i].quantity;
			isCateringitemExists = true;
			cateringTotal += data.commerceItems[i] && data.commerceItems[i].priceInfo && data.commerceItems[i].priceInfo.rawtotalprice;
		
	}
	$('#cateringItemCount').val(cateringItemCount);
	$('#cateringTotal').val(cateringTotal);
	if ((!isCateringitemExists && itemCount > 0) &&
		(($('#orderType-input').val() !== undefined && $(
			'#orderType-input').val() === '2') || $('#orderType').val() === '2')) {
		$("#deliveryNotQualified").show();
	} else {
		$("#deliveryNotQualified").hide();
	}
	if (itemCount == 0) {
		$("#cart-slider-cross-sell-modal").hide();
		$("#cart-cross-sell-modal").hide();
	}else if(isNaN(itemCount)){
		$('#renderedorderdetails,#renderedorderdetails-2').html('');
	}else {
		$("#cart-slider-cross-sell-modal").show();
		$("#cart-cross-sell-modal").show();
		$("#myCarousel.cross-sell-carousel").on("slid.bs.carousel", "", carousel_checkitem);
	}
	$('#itemCount').val(itemCount + '');
	if (itemCount > 0) {
		$('.dar-cart-count').show();
		$('#order-item-count').css({
			"display": "inline-block"
		});
		$('.dar-cart-count').html(itemCount + '');
		$('.order_num,#order-item-count').text(itemCount);
		$('.drawer-check-btn,.perspective-cart .btn.login-btn').prop("disabled", false);
	}else if(isNaN(itemCount)){
		$('.dar-cart-count').hide();
		$('#order-item-count').css({
			"display": "inline-block"
		});
		$('#order-item-count').html('0');	
		$('.order_num').remove();
		$('.drawer-check-btn,.perspective-cart .btn.login-btn').prop("disabled", true);
		$('#coupon-discount').hide();
		$('#rewards-enabled-section').find('#coupon-certificate-error').html($('#couponErrorMessage').val());
		$('#rewards-disabled-section').find('#coupon-certificate-error').html($('#couponErrorMessage').val());
		$('#rewards-success').hide();	
	} else {
		$('.dar-cart-count,#order-item-count').hide();
		$('.order_num').remove();
		$('.drawer-check-btn,.perspective-cart .btn.login-btn').prop("disabled", true);
		$('#coupon-discount').hide();
		$('#rewards-enabled-section').find('#coupon-certificate-error').html(couponErrorMessage);
		$('#rewards-disabled-section').find('#coupon-certificate-error').html(couponErrorMessage);
		$('#rewards-success').hide();
	}

	if (itemCount !== 0 && !isNaN(itemCount)) {
		if($("#source").val() == "checkout"){
	        var dataTotal = commerceItems.successResponse.order.priceInfo.total;   
	    }else{
	         var dataTotal = commerceItems.successResponse.order.priceInfo.amount;   
	    }
		var taxAmt = commerceItems.successResponse.order.priceInfo.tax;
		//continue shopping disabled and enabled based on amount
		var orderAmtExceeds;
		if (($('#orderTypeValue').val() !== undefined && $('#orderTypeValue').val() !== '' && $('#orderTypeValue').val() !== '2')) {
			if ($('#orderTypeValue').val() == '3') { //catering-pickup			
				orderAmtExceeds = parseInt($('#catThresholdAmt').val());
			} else {//togo-pickup			
				orderAmtExceeds = parseInt($('#togoThresholdAmount').val());
			}
			$('#renderedDeliveryDetail').hide();
		} else {
			orderAmtExceeds = parseInt($('#deliveryThresholdAmt').val());
		}
		if (dataTotal === orderAmtExceeds) {
			$('.drawer-shop-btn').prop("disabled", true);
		} else {
			$('.drawer-shop-btn').prop("disabled", false);
		}//continue shopping disabled and enabled end
		$('.checkout-payment-estimatedTotal .amount').html('$' + dataTotal.toFixed(2));
		$('.checkout-payment-tax .amount').html('$' + taxAmt.toFixed(2));
	}else if(isNaN(itemCount)){
		$('.checkout-payment-estimatedTotal .amount').html('$' + 0.00);
		$('.checkout-payment-tax .amount').html('$' + 0.00);
		$('.warning-exceeded').removeClass('hidden');
		$('.warning-exceeded').addClass('drawer-item-no-cart');
		$('.warning-exceeded').html(noItemInCart);
		$('.enter-coupon-txt').removeClass('rm-coupon-sec');
		$('.hide-coupon-section').addClass('rm-coupon-sec');
	} else {
		$('.checkout-payment-estimatedTotal .amount').html('$' + 0.00);
		$('.checkout-payment-tax .amount').html('$' + 0.00);

		$('.warning-exceeded').removeClass('hidden');
		$('.warning-exceeded').addClass('drawer-item-no-cart');
		$('.warning-exceeded').html(noItemInCart);
		$('.enter-coupon-txt').removeClass('rm-coupon-sec');
		$('.hide-coupon-section').addClass('rm-coupon-sec');
		if (!onlineTogoEnabled
				|| (disableOrderSettings && onlineTogoEnabled && (orderTypeValue == 0 || orderTypeValue == 3))) {
			var ischannelTypeValue = $("#channel").val();
			if (ischannelTypeValue !== 'MOBILE') {
				$('.rest-pickupdate-drop').hide();
			} else {
				$('#pickupdatetime').parent().parent().css("display", "none");
				$('#heading-date').hide();
			}
		}
	}

	$("#renderedorderdetails li,#renderedorderdetails-2 li").each(function (i, e) {
		var currentListId = $(e).attr('id');
		var currentItemQty = $('#' + currentListId).find('#quantityText-' + currentListId).val();
		var currentMaxData = $('#' + currentListId).find('.drawer-inc').data("max");
		currentMaxData = parseInt(currentMaxData);
		if (currentItemQty == 1) {
			$('#' + currentListId).find('.drawer-dec').attr('disabled', 'true');
		} else if (currentItemQty == currentMaxData) {
			$('#' + currentListId).find('.drawer-inc').attr('disabled', 'true');
		}
	});
		var dataCouponDiscount = data && data.couponDiscount;
	if (dataCouponDiscount != 0) {
		$('#coupon-discount').show();
		var dataDiscount = data && data.discount;
		var discountAmt = Math.abs(dataDiscount);
		var totalAmt = data && data.subTotalWithoutItemDiscount;
		if (totalAmt === orderAmtExceeds) {
			$('.drawer-shop-btn').prop("disabled", true);
		} else {
			$('.drawer-shop-btn').prop("disabled", false);
		}
		if($("#source").val() == "checkout"){
			var estimatedAmt = data && data.priceInfo && data.priceInfo.total;
	    }else{
	       var estimatedAmt = data && data.priceInfo && data.priceInfo.amount;
	    }
		$('#coupon-apply-section').hide();
		if(discountAmt){
			$('#coupon_disc_price').html('-$' + discountAmt.toFixed(2));
		}
		if(totalAmt){
			$('#total').html('$' + totalAmt.toFixed(2));
		}
		if(estimatedAmt){
			$('#estimatedAmt').html('$' + estimatedAmt.toFixed(2));
		}
	} else {
		$('#rewards-enabled-section').find('.coupon-error').html(couponErrorMessage);
		$('#rewards-disabled-section').find('.coupon-error').html(couponErrorMessage);

		$('#rewards-enabled-section').find('#coupon-certificate-error').show();
		$('#rewards-disabled-section').find('#coupon-certificate-error').show();
	}
		var dataOfferType = data && data.offerType;
		var dataDisType = data && data.discountType
		var datarewardDes = data && data.rewardDescription;
		var dataCouponCode = data && data.couponCode;
	if ((dataOfferType==='REWARD' || dataDisType === 'REWARD') && dataCouponDiscount && (dataCouponDiscount < 0) && datarewardDes != null ) {
		var Description = data.rewardDescription != null ? data.rewardDescription : data.couponDescription ;
		$('#coupon-success').html('<span>'+rewardText+' '+ Description +'</span><a href="javascript:void(0)" class="coupon-cancel-btn" onClick="removeRewards(\' reward ,' + data.rewardPromotionCode + '\')">X</a>');
		$('#coupon-apply-section').hide();
		$('#togo-rewards').addClass('hidden');
		$('.enter-coupon-txt').addClass('rm-coupon-sec');

	}
	if (dataDisType !== 'REWARD' && dataCouponDiscount && (dataCouponDiscount < 0) && dataCouponCode != null) {
		if((dataOfferType==='VOUCHER' || dataDisType === 'VOUCHER')){
			couponText = rewardText;
		}
	    var Description = data.rewardDescription != null ? data.rewardDescription : data.couponDescription ;
		$('#coupon-success').html('<span>'+couponText+' '+ Description +'</span> <a href="javascript:void(0)" class="coupon-cancel-btn" onClick="removeCoupon(\'' + data.couponCode + '\')">X</a>');
		$('#rewards-enabled-section').find('#coupon-certificate-field').val('');
		$('#rewards-disabled-section').find('#coupon-certificate-field').val('');

		$('#rewards-enabled-section').find('#coupon-certificate-btn').prop("disabled", true);
		$('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", true);

		$('#rewards-enabled-section').find('#coupon-certificate-error').show();
		$('#rewards-disabled-section').find('#coupon-certificate-error').show();

		$('#coupon-discount').show();
		$('#coupon-apply-section').hide();
		$('#togo-rewards').addClass('hidden');
		$('.enter-coupon-txt').addClass('rm-coupon-sec');
	}

	if (!($('#rewards-enabled-section').find('.deleteXicon').length)) {
		$('#rewards-enabled-section').find('#coupon-certificate-field').wrap('<span class="deleteXicon" />').after($('<span class="cupon-clear-btn" style="display:none">x</span>').click(function () {
			$('#coupon-certificate-error').removeClass('invalid_coupon_error');
			$('#rewards-enabled-section').find('#coupon-certificate-error').html(couponErrorMessage);
			$(this).prev('input').val('').trigger('change').focus();
			$('#rewards-enabled-section').find('.deleteXicon span').css('display', 'none');
		}));
	}

	if (!($('#rewards-disabled-section').find('.deleteXicon').length)) {
		$('#rewards-disabled-section').find('#coupon-certificate-field').wrap('<span class="deleteXicon" />').after($('<span class="cupon-clear-btn" style="display:none">x</span>').click(function () {
			$('#rewards-disabled-section').find('#coupon-certificate-error').html(couponErrorMessage);
			$(this).prev('input').val('').trigger('change').focus();
			$('#rewards-disabled-section').find('.deleteXicon span').css('display', 'none');
		}));
	}

	if ($('#rewards-disabled-section').find('#coupon-certificate-field').val() == '') {
		$('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", true);
	}

	if ($('#rewards-enabled-section').find('#coupon-certificate-field').val() == '') {
		$('#rewards-enabled-section').find('#coupon-certificate-btn').prop("disabled", true);
	}
	if(source && source === 'checkout'){
		if(data.discount !=0 ){
			$('.checkout-payment-coupon').show();
		}else if(data.discount == 0 ){
			$('.checkout-payment-coupon').hide();
		}
	}
	$('#taxSection').hide();
	infoMessage();
	if($(".checkout-payment-tax").length > 0){
	    if($(".checkout-payment-tax #deliveryFee").length > 0 ){
	        $(".checkout-payment-tax #deliveryFee").text(data.deliveryFee.toFixed(2));
	    }
	    if($(".checkout-payment-tax #costPerPerson").length > 0 ){
	        $(".checkout-payment-tax #costPerPerson").text(data.costPerPerson.toFixed(2));
	    }
		if($(".checkout-payment-tax #deliveryNewSubtotal").length > 0 ){
	        $(".checkout-payment-tax #deliveryNewSubtotal").text("$" + data.priceInfo.total.toFixed(2));
	    }
	}
	sessionStorage.setItem("cd_cartamount", cateringTotal);	
}

function quantityHandler(id, type) {
	switch (type) {
		case "inc":
			$("#" + id).closest('.drawer-qty').children(".drawer-dec").removeAttr('disabled')
			if ($("#" + id).val() < $(".drawer-inc").data("max")) {
				$("#" + id).val(parseInt($("#" + id).val()) + 1);
			}

			if ($("#" + id).val() == $(".drawer-inc").data("max")) {
				$("#" + id).closest('.drawer-qty').children(".drawer-inc").attr('disabled', true);
			}
			break;
		case 'dec':
			$("#" + id).closest('.drawer-qty').children(".drawer-inc").removeAttr('disabled')
			if ($("#" + id).val() > $(".drawer-dec").data("min")) {
				$("#" + id).val(parseInt($("#" + id).val()) - 1);
			}

			if ($("#" + id).val() == $(".drawer-dec").data("min")) {
				$("#" + id).closest('.drawer-qty').children(".drawer-dec").attr('disabled', true);
			}
			break;
	}
	var count = document.getElementById(id).value;
	optType = type;
	debounce(updateOrderAPI, 500, id, count);
	var totalItemCount = 0
	$('#renderedorderdetails li,#renderedorderdetails-2 li').each(function (i, e) {
		var quantity = $(this).find('.drawer-qty .orderQuantity').val();
		quantity = parseFloat(quantity);
		totalItemCount = totalItemCount + quantity;

	});
	$('#order-item-count').html(totalItemCount + '');
	cartSliderInnerscroll();
}

//get applyCoupon Service
$('#coupon-discount').hide();

function applyCoupon(selectedCouponCode, voucherbutton) {
	if(voucherbutton){
		$('#togo-rewards .togo-btn').prop('disabled', true);
	}else{
		$('#coupon-certificate-btn').prop('disabled', true);
	}
	var rewardsCode = $('#renderedRewardList option:selected').text();
	$('#drawer-panel,.item-list-mycart').prepend('<div class="togo-loader" id="cartLoader" style="display: block;"></div>');
	$('.warning-exceeded').addClass('hidden');
	var couponCode = document.getElementById('coupon-certificate-field').value;

	if($("#coupon-certificate-field1").length > 0){
	var couponCode2 = document.getElementById('coupon-certificate-field1').value;
	}
	if($("#coupon-certificate-field1").length > 0  && couponCode2 !== null && couponCode2 !== 'undefined' && couponCode2.length > 0){
	    couponCode = document.getElementById('coupon-certificate-field1').value;
	}
	if (selectedCouponCode) {
		couponCode = selectedCouponCode;
	}
	var uri = "/web-api/order/applycoupon";
	var data = {
		"suppressCouponErrors": "true",
		"currentCouponCode": couponCode,
		"webapi": "true",
		"postCheckout" : false
	}
	if($('#source').val() == "checkout"){
		var data = {
			"suppressCouponErrors": "true",
			"currentCouponCode": couponCode,
			"webapi": "true",
			"postCheckout" : true
		}
	}
	apiCall(uri, 'POST', data,
		function (response) {
			if(voucherbutton){
				$('#togo-rewards .togo-btn').removeAttr('disabled');
			}else{
				$('#coupon-certificate-btn').removeAttr('disabled');
			}			
			if (response.errorResponse) {
				var expResponse = response && response.errorResponse && response.errorResponse.fault && response.errorResponse.fault.faultCode;				
				var faultDescription = response.errorResponse.fault.faultDescription;
				var sorryTextNew;
				//Invalid coupon
				if (faultDescription === invalidCoupon || faultDescription === unrecognizedCoupon) {
				sorryTextNew= invalidCouponText;
				}
				//Expired coupon
				else if (faultDescription === expiredCoupon) {
  				sorryTextNew = expiredCouponText;
				} 
				//Requirements not met
				else if (faultDescription === couponNotEligible || faultDescription === couponNotApplicable) {
  				sorryTextNew = requirementsNotMetText;
				}
				//Already Redeemed
				else if (faultDescription=== couponAlreadyRedeemed) {
  				sorryTextNew = couponAlreadyRedeemedText;
				} else if (response.errorResponse.fault.faultCode === 'appOnlyCouponError') {
					sorryTextNew = response.errorResponse.fault.faultDescription;
				} else {
 				 sorryTextNew = sorryText;
				}				
				if(expResponse == 'sessionExpired'){
					$("#sessionExpired").modal('show');
				}else{	
				if (selectedCouponCode) {
					$('#rewards-error').html(noRewardApplicable);
					$('#rewards-error').removeClass('hidden');
				} else {
					$('#rewards-enabled-section').find('.coupon-error').html(sorryTextNew).css('color','#c13f29');
					$('#rewards-disabled-section').find('.coupon-error').html(sorryTextNew);
					$('#rewards-enabled-section').find('#coupon-certificate-btn').prop("disabled", true);
					$('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", true);
					$('#rewards-enabled-section').find('#coupon-certificate-error').show();
					$('#rewards-disabled-section').find('#coupon-certificate-error').show();
					$("#coupon-certificate-error").addClass("invalid_coupon_error");
				}
				$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
				}
			} else {
				if($('#source').val() == "checkout"){
					var estimatedTotal = response.successResponse && response.successResponse.orderPriceInfo && response.successResponse.orderPriceInfo.amount;
					if(!estimatedTotal) window.location.reload();
				}
				sessionStorage.setItem('CartItems', JSON.stringify(response));
				if (selectedCouponCode) {
					$('#rewards-success').show();
					$('#rewards-success').html('<span>'+rewardText+' '+ rewardsCode + '</span> <a href="javascript:void(0)" class="coupon-cancel-btn" onClick="removeCoupon(\'' + selectedCouponCode + '\')">X</a>');
					$('.checkout-payment-coupon .amount').html(response.successResponse.order.couponDiscount);
					$('#togo-rewards').addClass('hidden');
					$('#rewards-error').addClass('hidden');
					$('#coupon-discount').show();
					$('#coupon-apply-section').hide();
					$('.enter-coupon-txt').addClass('rm-coupon-sec');
					if($('.checkout-payment-estimatedTotal').length){
						$('.checkout-payment-estimatedTotal .amount').html(response.successResponse.order.priceInfo.total);
						$('.checkout-payment-tax .amount').html(response.successResponse.order.priceInfo.tax);
					}
					$('#rewards-success').hide();
				} else {
					$('#coupon-success').html('<span>'+couponText+ ' ' + couponCode + '</span> <a href="javascript:void(0)" class="coupon-cancel-btn" onClick="removeCoupon(\'' + couponCode + '\')">X</a>');
					$('.checkout-payment-coupon .amount').html(response.successResponse.order.couponDiscount);
					$('.checkout-payment-estimatedTotal .amount').html(response.successResponse.order.priceInfo.total);   
					if($('.checkout-payment-tax').length){
    			        $('.checkout-payment-tax .amount').html(response.successResponse.order.priceInfo.tax);
    			    }
					$('#coupon-certificate-field').val('');
					$('#coupon-certificate-btn').prop("disabled", true);
					$('#rewards-enabled-section').find('#coupon-certificate-error').show();
					$('#rewards-disabled-section').find('#coupon-certificate-error').show();
					$('#coupon-discount').hide();
					$('#coupon-apply-section').hide();
					$('.enter-coupon-txt').addClass('rm-coupon-sec');
				}
				getOrderDetails(response);
			}
		}, null);
}

function removeCoupon(code) {
	$('#drawer-panel,.item-list-mycart').prepend('<div class="togo-loader" id="cartLoader" style="display: block;"></div>');
	var data = {
		"currentCouponCode": code,
				 "postCheckout" : false
			};
	if($('#source').val() == "checkout"){
		var data = {
			"currentCouponCode": code,
			"postCheckout" : true
		}
	}
	apiCall('/web-api/order/removecoupon', 'POST', data,
		function (response) {
			$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
			var expResponse = response && response.errorResponse && response.errorResponse.fault && response.errorResponse.fault.faultCode;				
			if(expResponse == 'sessionExpired'){
				$("#sessionExpired").modal('show');
			} else if (response.successResponse) {
				if($('#source').val() == "checkout"){
					var estimatedTotal = $('.checkout-payment-estimatedTotal .amount').html()
					if(typeof estimatedTotal === 'string' && estimatedTotal.indexOf('0.00') != -1) window.location.reload();
				}
				sessionStorage.setItem('CartItems', JSON.stringify(response));
				$('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", false);
				$('#rewards-enabled-section').find('#coupon-certificate-error').html(couponRemovedText);
				$('#rewards-disabled-section').find('#coupon-certificate-error').html(couponRemovedText);
				$('#coupon-discount').hide();
				$('#coupon-apply-section').show();
				$('#togo-rewards').removeClass('hidden');
				/* Hide coupon enhancement :: BEGIN */
				$('.enter-coupon-txt').removeClass('rm-coupon-sec');
				$('.hide-coupon-section').addClass('rm-coupon-sec');
				var isEnableCouponLink = $("#enableCouponLink").val();
				var ischannelTypeValue = $("#channel").val();
				if (isEnableCouponLink === "true") {
					if (ischannelTypeValue != "MOBILE")	{
						if (window.location.href.indexOf("/commerce/checkout") > -1) {
							document.getElementById('coupon_no').checked = true;
						}
					}
					if (window.location.href.indexOf("/commerce/checkout") > -1 || window.location.href.indexOf("/cart") > -1) {
						if ($('#isLoyaltyEnabledLocation').val() === 'true') {
							$("#rewards-enabled-section").addClass("rm-coupon-sec");
						} else {
							$("#rewards-disabled-section").addClass("rm-coupon-sec");
						}
					}
				}
				/* Hide coupon enhancement :: END */
				$('.deleteXicon span').hide();
				if($('.checkout-payment-coupon .amount').length){
					$('.checkout-payment-coupon .amount').html(response.successResponse.order.couponDiscount);
				}
				if($('.checkout-payment-estimatedTotal').length){
					$('.checkout-payment-estimatedTotal .amount').html(response.successResponse.order.priceInfo.total);   
					$('.checkout-payment-tax .amount').html(response.successResponse.order.priceInfo.tax);
				}
				getOrderDetails(response);
			}
		}, null);
}

function applyRewards() {
	$('#togo-rewards .togo-btn').prop('disabled', true);
	var rewardId = $('#renderedRewardList').children(":selected").attr("id");
	var rewardVal = $('#renderedRewardList option:selected').val();
	var rewardsCode = $('#renderedRewardList option:selected').text();	
	if (rewardId === 'voucher') {
		applyCoupon(rewardVal , true);
	} else if (rewardVal != 'Select Rewards') {		
		$('#drawer-panel,.item-list-mycart').prepend('<div class="togo-loader" id="cartLoader" style="display: block;"></div>');
		var data = {
			"rewardTypeSelected": rewardId,
			"rewardItemCode": rewardVal,
			"postCheckout": false
		}
		if($('#source').val() == "checkout"){
			var data = {
			"rewardTypeSelected": rewardId,
			"rewardItemCode": rewardVal,
			"postCheckout": true
			}
		}
		apiCall('/web-api/order/applyreward', 'POST', data, function (response) {
			$('#togo-rewards .togo-btn').removeAttr('disabled');
			if (response.errorResponse) {
				var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;				
				if(expResponse == 'sessionExpired'){
					$("#sessionExpired").modal('show');
				}else{	
				$('#rewards-error').removeClass('hidden');
				$('#rewards-error').html(response.errorResponse.fault.faultDescription);
				$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
				}
			} else {
				if(response.successResponse){
				if($('#source').val() == "checkout"){
					var estimatedTotal = response.successResponse && response.successResponse.orderPriceInfo && response.successResponse.orderPriceInfo.amount;
					if(!estimatedTotal) window.location.reload();
				}
				sessionStorage.setItem('CartItems', JSON.stringify(response));
				$('#coupon-success').html('<span>'+rewardText+' '+ response.rewardDescription + '</span> <a href="javascript:void(0)" class="coupon-cancel-btn" onClick="removeRewards(\'' + rewardId + ',' + rewardVal + '\')">X</a>');
				$('#togo-rewards').addClass('hidden');
				$('.checkout-payment-coupon .amount').html(response.successResponse.order.couponDiscount);
				$('#rewards-error').addClass('hidden');
				$('#coupon-discount').show();
				$('#coupon-apply-section').hide();
				$('.enter-coupon-txt').addClass('rm-coupon-sec');
				if($('.checkout-payment-estimatedTotal').length){
    			    $('.checkout-payment-estimatedTotal .amount').html(response.successResponse.order.priceInfo.total);   
    			    $('.checkout-payment-tax .amount').html(response.successResponse.order.priceInfo.tax);
    			}
				getOrderDetails(response);
				}else{
					$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
				}
			}
		}, null);
	}
	if (rewardVal == 'Select Rewards') {	
		$('#togo-rewards .togo-btn').removeAttr('disabled');
	}
}

function removeRewards(id, rewardsCode) {
	$('#drawer-panel,.item-list-mycart').prepend('<div class="togo-loader" id="cartLoader" style="display: block;"></div>');
	var data = {
		"rewardTypeSelected": id,
		"rewardItemCode": rewardsCode,
		"postCheckout": false

	}
	if($('#source').val() == "checkout"){
		var data = {
		"rewardTypeSelected": id,
		"rewardItemCode": rewardsCode,
		"postCheckout": true
	    }
	}
	apiCall('/web-api/order/removereward', 'POST', data, function (response) {
		$('#drawer-panel,.item-list-mycart').find('#cartLoader').remove();
		var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;				
		if(expResponse == 'sessionExpired'){
			$("#sessionExpired").modal('show');
		}else{
		if (response.successResponse) {
			if($('#source').val() == "checkout"){
				var estimatedTotal = $('.checkout-payment-estimatedTotal .amount').html()
				if(typeof estimatedTotal === 'string' && estimatedTotal.indexOf('0.00') != -1) window.location.reload();
			}
			sessionStorage.setItem('CartItems', JSON.stringify(response));
			$('#rewards-success').html('Rewards Removed').fadeOut(1000);
			$('#togo-rewards').removeClass('hidden');
			$('#coupon-discount').hide();
			$('#coupon-apply-section').show();
			/* Hide coupon enhancement :: BEGIN */
			$('.enter-coupon-txt').removeClass('rm-coupon-sec');
			$('.hide-coupon-section').addClass('rm-coupon-sec');
			var isEnableCouponLink = $("#enableCouponLink").val();
			var ischannelTypeValue = $("#channel").val();
			if (isEnableCouponLink === "true") {
				if (ischannelTypeValue != "MOBILE")	{
					if (window.location.href.indexOf("/commerce/checkout") > -1) {
						document.getElementById('coupon_no').checked = true;
					}
				}
				if (window.location.href.indexOf("/commerce/checkout") > -1 || window.location.href.indexOf("/cart") > -1) {
					if ($('#isLoyaltyEnabledLocation').val() === 'true') {
						$("#rewards-enabled-section").addClass("rm-coupon-sec");
						} else {
						 $("#rewards-disabled-section").addClass("rm-coupon-sec");
					}
				}
			}
			/* Hide coupon enhancement :: END */
			if($('.checkout-payment-coupon .amount').length){
					$('.checkout-payment-coupon .amount').html(response.successResponse.order.couponDiscount);
				}
			if($('.checkout-payment-estimatedTotal').length){
			    $('.checkout-payment-estimatedTotal .amount').html(response.successResponse.order.priceInfo.total);  
			    $('.checkout-payment-tax .amount').html(response.successResponse.order.priceInfo.tax);
			}
			getOrderDetails(response);
		}
		}	
	}, null);
}

function rightRailCartCheckOut() {
	if (giftCardOrderExists()) {
		validateGiftCardOrder();
	} else if (($('#orderType-input').val() !== undefined && $('#orderType-input').val() !== '2') || $('#orderType').val() !== '2') {
		rightrailcheckout();
	} else {
		if ($('#cateringTotal').val() > minDeliveryAmtThreshold) {
			rightrailcheckout();
		} else {
			handleCateringItems();
		}
	}
}

function giftCardOrderExists() {
	var orderType = $("#orderTypeValue").val();
	var count = $("#itemCount").val();
	return (orderType == "1" && count > 0);
}

function validateGiftCardOrder() {
	var orderType = $("#orderTypeValue").val();
	var count = $("#itemCount").val();
	if (orderType == "1" && count > 0) {
		$("#createNewOrderModal-GC").modal('show');
	}
}

function rightrailcheckout() {
	var uri = '/web-api/order/moveToPurchase';
	var data = {
		togoNewFlow: true
	};
	apiCall(uri, 'POST', data, function (response) {
		if (response.successResponse) {
			sessionStorage.removeItem('CartItems');
			if ($('#rightRailCartDirectCheckoutEnabled').val() !== 'true') {
				window.location.href = URLPrefixLocale('/cart');
			} else {
				window.location.href = URLPrefixLocale('/commerce/checkout');
			}
		} else {
			populateErrorInfo(response);
		}

	}, null);
}

function commerceCheckOut(CartCheckOut) {
    $("#frmusercrosssell").append('<div class="togo-loader" id="crossSellLoader">Loader...</div>');
	if(!CartCheckOut){
		$('#crossSellLoader').show();
	}
	var uri = '/web-api/order/moveToPurchase';
	var data = {
		togoNewFlow: true
	};
	apiCall(uri, 'POST', data, function (response) {
	    if($(".perspective-btn .login-btn").length > 0){
	        if($(".perspective-btn .login-btn").hasClass("btn-img-loader")){
	            $(".perspective-btn .login-btn").removeClass("btn-img-loader");     
	        }  
	    }
	    if($(".drawer-check-btn").length > 0){
	         if($(".drawer-check-btn").hasClass("btn-img-loader")){
	          $(".drawer-check-btn").removeClass("btn-img-loader");   
	         }
	    }
		if (response.successResponse) {
			sessionStorage.removeItem('CartItems');
			$('#cross-sell-modal-popup').hide();
			$('#crossSellLoader').hide();
			if($('.modal-backdrop').length){
				$('.modal-backdrop').removeClass("in fade modal-backdrop");
			}
			if ($('#cartSliderDirectCheckoutEnabled').val() !== 'true') {
				window.location.href = URLPrefixLocale('/cart');
			} else {
				window.history.replaceState(null, '', window.location.origin + window.location.pathname + '?cartOpen=true')
				window.location.href = URLPrefixLocale('/commerce/checkout');
			}
		} else {
			populateErrorInfo(response);
			$('#crossSellLoader').hide();
			$('#crossSellLoader').remove();
		}

	}, null);
	$("#isCrossSellOpened").val("true");
}

function checkoutCall() {
	if ($('#cartSuggestionsEnabled').val() === 'true' && $('#cartSliderCrossSellEnabled').val() !== 'true' && $('#isCrossSellOpened').val() !== 'true') {
		closeCartSlider();
		cart_slider_modal_related_products();
		$("#isCrossSellOpened").val("true");
	} else {
		commerceCheckOut();
	}
}

function sliderCheckOut() {
	//For catering delivery crosssell popup not applicable, 
	//Check done if popup already opened using sessioncontext.
	if(sessionStorage){
		sessionStorage.removeItem("chkSelTime");
		sessionStorage.removeItem("chkSelDate");
	}
	$(".drawer-check-btn").addClass("btn-img-loader");	
	var LoggedInUserPastDateVal =  sessionStorage.getItem('cateringLoggedInUserPastDate');
	if(LoggedInUserPastDateVal != undefined && LoggedInUserPastDateVal === 'true'){
		var delivery_url = $('#pickup-to-deliverycontinue').attr("data-link");		
		window.location = delivery_url;
	}else if (giftCardOrderExists()) {
		validateGiftCardOrder();
	} else if ($('#orderType-input').val() !== undefined && $('#orderType-input').val() !== '2') {
		checkoutCall();
	} else {
		if ($('#cateringTotal').val() > minDeliveryAmtThreshold) {
			checkoutCall();
		} else {
			handleCateringItems();
		}
	} 		
}

function handleCateringItems() {
	$('#switch-pickup-msg').html($('#minInfoMessage').val());
	if ($('#cateringTotal').val() > 0) {
		$('#switch-pickup-msg2').html(cateringPickupInfoText1);
		$('#switch-to-pickup').html(switchCateringPickup1);
	} else {
		$('#switch-pickup-msg2').html(cateringPickupInfoText2);
		$('#switch-to-pickup').html(switchCateringPickup2);
	}	
	 $(".drawer-check-btn").removeClass("btn-img-loader");
	 if($(".perspective-btn .login-btn").hasClass("btn-img-loader")){
		$(".perspective-btn .login-btn").removeClass("btn-img-loader");     
	}
	$('#myModalSwitchPickup').modal('show');
	closeCartSlider();
}

function checkoutCallMobile() {
	if ($('#cartSuggestionsEnabled').val() === 'true' && $('#cartSliderCrossSellEnabled').val() !== 'true' && $('#isCrossSellOpened').val() !== 'true') {
		closeCartSlider();
		$("#isCrossSellOpened").val("true");
		cart_slider_mobile_related_products();
	} else {
		var uri = '/web-api/order/moveToPurchase';
		var data = {
			togoNewFlow: true
		};
		apiCall(uri, 'POST', data, function (response) {
			if (response.successResponse) {
				sessionStorage.removeItem('CartItems');
				window.history.replaceState(null, '', window.location.origin + window.location.pathname + '?cartOpen=true')
				window.location.href = URLPrefixLocale('/commerce/checkout');
			} else {
				populateErrorInfo(response);
			}

		}, null);
	}
}

function populateErrorInfo(response) {
	var asapErrorCode = response && response.errorResponse && response.errorResponse.fault && response.errorResponse.fault.faultCode;				
	var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;				
	if(expResponse == 'sessionExpired'){
		$("#sessionExpired").modal('show');
	}else if(asapErrorCode == 'asap_not_available'){
		asapInitialErrorDatetime();
		$('#cross-sell-modal-popup').modal('hide');
		$('#checkoutErrorMsg').removeClass('hidden');
		$('#asapEnabledErrortext').html(response.errorResponse.fault.faultDescription);
		$('#asapEnabled-Errormodal').modal('show');					
	}else if(asapErrorCode == 'OrderService-601'){		
		datetimeErrorHandler(response)
	}else{	
		$('#cross-sell-modal-popup').modal('hide');
		$('#moveToPurchaseErrorModal').modal('show');
		$('#checkoutErrorMsg').removeClass('hidden');
		$('#checkoutErrorMsg').html(response.errorResponse.fault.faultDescription);		
	}	
}

function checkOutMobile() {
	if(sessionStorage){
		sessionStorage.removeItem("chkSelTime");
		sessionStorage.removeItem("chkSelDate");
	}
	$(".drawer-check-btn").addClass("btn-img-loader");
	var LoggedInUserPastDateVal =  sessionStorage.getItem('cateringLoggedInUserPastDate');
	if(LoggedInUserPastDateVal != undefined && LoggedInUserPastDateVal === 'true'){
		var delivery_url = $('#pickup-to-deliverycontinue').attr("data-link");		
		window.location = delivery_url;
	}else if (giftCardOrderExists()) {
		validateGiftCardOrder();
	} else if (($('#orderType-input').val() !== undefined && $('#orderType-input').val() !== '2') || $('#orderType').val() !== '2') {
		checkoutCallMobile();		
	} else {
		if ($('#cateringTotal').val() > minDeliveryAmtThreshold) {
			checkoutCallMobile();
		} else {
			handleCateringItems();
		}
	}
	$(".drawer-check-btn").removeClass("btn-img-loader");
}

$('#dedicatedGobackbtn').click(function () {
	if ($('#orderTypeValue').val() == 2){
 		window.location.href = URLPrefixLocale('/menu-listing/catering');
	}else{
		window.location.href = URLPrefixLocale('/menu-listing');
	}
});

function cartCheckOut() {	
    $(".perspective-btn .login-btn").addClass("btn-img-loader");
	var LoggedInUserPastDateVal =  sessionStorage.getItem('cateringLoggedInUserPastDate');
	if(LoggedInUserPastDateVal != undefined && LoggedInUserPastDateVal === 'true'){
		var delivery_url = $('#pickup-to-deliverycontinue').attr("data-link");		
		window.location = delivery_url;
	}else if (giftCardOrderExists()) {
		validateGiftCardOrder();
	} else if ($('#orderTypeValue').val() !== undefined && $('#orderTypeValue').val() !== '2') {
		commerceCheckOut(true);
	} else {
		if ($('#cateringTotal').val() > minDeliveryAmtThreshold) {
			commerceCheckOut(true);
		} else {
			handleCateringItems();
		}
	}
}

function getRewardsList(rewardsList) {
	var data = rewardsList.successResponse;
	if (!($('#isProfileTransient').val() === 'true')) {
		var isLoyaltyenabled = $('#isLoyaltyEnabledLocation').val() === 'true';
		if (isLoyaltyenabled && rewardsList && rewardsList.successResponse && rewardsList.successResponse.memberRewardPointsBalance) {
			$('#coupon-tab').show();
			$('#coupon-apply-section .tab-content').removeClass('removeborder');
			$('#rewards-enabled-section').show();
			$('#rewards-disabled-section').hide();
			if($('#rewardsList-template').length){
				var rewardsListSource = document.getElementById("rewardsList-template").innerHTML;
				var rewardsListResultTemplate = Handlebars.compile(rewardsListSource);
				$("#renderedRewardList").html(rewardsListResultTemplate(data));
			}
			var points = rewardsList.successResponse.memberRewardPointsBalance;
			if (points && points > 0) {
				$('#earned-points').html(earnedInfotext1+' '+ points + ' '+pointsText);
				$('#earned-points').show();
			} else {
				$('#earned-points').html(earnedInfotext2);
				$('#togo-rewards').find('.rewards-option').hide();
				$('#earned-points').show();
			}
		} else {
			$('#coupon-apply-section .tab-content').addClass('removeborder');
			$('#coupon-tab').hide();
			if ($('#iscouponDisplayEnabled').val() !== 'true') {
				$('#rewards-enabled-section').hide();
				$('#rewards-disabled-section').show();
			} else {
				$('#rewards-enabled-section').show();
				$('#rewards-disabled-section').hide();
				$('#rewards-tab').remove();
				$('#coupon-tab').addClass('single-promotion');
			}
		}
	}
}

function editCart(prodName, prodId, commerceId, catId) {
	if (typeof (Storage) !== "undefined") {
		var stored_cartItems = JSON.parse(sessionStorage.getItem('CartItems'));
		var itemsMovedToCart = stored_cartItems['successResponse'] && stored_cartItems['successResponse']['order'] && stored_cartItems['successResponse']['order']['commerceItems'];
		if (itemsMovedToCart) {
			for (var index = 0; index < itemsMovedToCart.length; index++) {
				if (itemsMovedToCart[index]['id'] == commerceId) {
					sessionStorage.setItem('editedCartItemQuantity', itemsMovedToCart[index]['quantity']);
					break;
				}
			}
		}
	}
	var productName = prodName.toLowerCase().replace(/[\. ,&:-]+/g, "-");
	var url = '/menu/' + productName + '/' + prodId + '?commerceItemId=' + commerceId + '&parentCatalogRefId=' + catId + '&editFlag=cart';
	window.location.href = URLPrefixLocale(url);
}

/******* API calls ******/
function apiCall(url, type, data, successCallback, errorCallback) {
	if (data) {
		addSiteCodes(data);
	}
	var reqObj = {};
	if (data !== null) {
		reqObj['url'] = url,
			reqObj['type'] = type,
			reqObj['data'] = data
	} else {
		reqObj['url'] = url,
			reqObj['type'] = type
	}
	// making request non cachable -- as we faced issue in safari 
	reqObj['cache'] = false;
	reqObj['async'] = true; // For mobile browser got an issue where ajax by default act as synchronous.ALM #37058
	$.ajax(reqObj).done(function (response) {
		successCallback !== null ? successCallback(response) : console.log("response", response);
	})
		.fail(function (error) {
			errorCallback !== null ? errorCallback(error) : console.log("error", error.responseText);
		});
}

//UPdate order Details Service
function updateOrderAPI(itemCount, id) {
	$('#drawer-panel,.item-list-mycart').prepend('<div class="togo-loader" id="cartLoader" style="display: block;"></div>');
	// added for DTM START
	var skuId;
	var productId;
	var orderId; 
	if(id && id.indexOf("quantityText-") != -1){
	orderId= id.replace("quantityText-","");	
		if(($("#"+orderId)) && ($("#"+orderId)).find("#skuId") && ($("#"+orderId)).find("#productId")){
			skuId = ($("#"+orderId)).find("#skuId").val();
			productId =($("#"+orderId)).find("#productId").val();
		}
	}
	// added for DTM END
	var itemId = id.split('-');
	var quantityAndId = itemId[1] + "=" + itemCount;
	var payload = {
		'commerceIds': itemId[1],
		"isQuantityUpdated": true,
		"skuId": skuId,
		"productId": productId,
		"optType": optType
	};
	addSiteCodes(payload);
	$.ajax({
		url: '/web-api/order/update?' + quantityAndId,
		type: "POST",
		data: payload,
		async: true
	}).done(function (response) {
		var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;				
		if(expResponse == 'sessionExpired'){
			$("#sessionExpired").modal('show');
		}else{		
		if (response.successResponse) {
			// update data layer
			if(response.successResponse.dataLayerJSON){
			window.digitalData= JSON.parse(response.successResponse.dataLayerJSON);
			}
			$('.drawer-check-btn').prop("disabled", false);
			sessionStorage.setItem('CartItems', JSON.stringify(response));
			$('.warning-exceeded').addClass('hidden');
			cartSliderInnerscroll();
			getOrderDetails(response);
		} else if (response.formExceptions.length > 0) {
			if(response.formExceptions[0].errorCode === 'cart_TimeConflicts') {
				closeCartSlider();	
				$('#timeConflictOk').attr({
					increaseQty: true, 
					itemCount: itemCount,
					itemId: id
				});
                $('#timeConflictMessage').html(response.formExceptions[0].localizedMessage);
                $('#timeConflict').modal('show');
			}else{
				$('.warning-exceeded').html(response.formExceptions[0].localizedMessage);
				$('.warning-exceeded').removeClass('hidden');
				cartSliderInnerscroll();
				$('.drawer-check-btn').prop("disabled", true);
				callOrderDetail();
			}
		}
		}	
	});
}

function deleteAction(id) {
	$('#' + id).addClass('active');
}

function cart_slider_modal_related_products() {
	if ($('.cross-item-list li').length == 2) {
		$('#cross-sell-modal-popup').addClass('twoitems');
	}
	if ($('.cross-item-list li').length == 1) {
		$('.cross-item-list li').addClass("list-center");
		$('#cross-sell-modal-popup').addClass("oneitems");
	}
	$('#cross-sell-modal-popup').modal('show');
	$.ajax({
		url: $('#togoCartSuggestionAjax').val() + '?crossellPage=1',
		type: 'GET'
	}).done(function (response) {
		var crossSellModalResponse = (response.substring(response.indexOf('<div id="cross-sell-modal"'), response.indexOf('id="cross-sell-modal-end"')));
		$("#crossSellModalWrapper").append(crossSellModalResponse);
		if (crossSellModalResponse) {
			$('#cross-sell-modal-popup').modal('show');
			disableAlcoholItem();   //online alochol sale change
			if($(".drawer-check-btn").length > 0){
    	         if($(".drawer-check-btn").hasClass("btn-img-loader")){
    	          $(".drawer-check-btn").removeClass("btn-img-loader");   
    	         }
    	    }
			dtmCrossUpSellModal();
		}else{
			commerceCheckOut();
		}
	});
}

function cart_page_related_products() {
	$.ajax({
		url: $('#togoCartSuggestionAjax').val() + '?crossellPage=2',
		type: 'GET'
	}).done(function (response) {
		var crossSellModalResponse = (response.substring(response.indexOf('<div id="cart-cross-sell-modal"'), response.indexOf('id="cart-cross-sell-modal-end"')));
		$("#crossSellModalWrapperCart").html(crossSellModalResponse);
		if (crossSellModalResponse) {
			$('#cart-cross-sell-modal').show();			
			dtmCrossUpSellModal();
		}
	});
}

function cart_slider_related_products() {
	$.ajax({
		url: $('#togoCartSuggestionAjax').val() + '?crossellPage=3',
		type: 'GET'
	}).done(function (response) {
		var crossSellModalResponse = (response.substring(response.indexOf('<div id="cart-slider-cross-sell-modal"'), response.indexOf('id="cart-slider-cross-sell-modal-end"')));
		$("#crossSellWrapperCartSlider").html(crossSellModalResponse);
		if (crossSellModalResponse) {
			$('#cart-slider-cross-sell-modal').show();
			dtmCrossUpSellModal();
		}
		$("#myCarousel.cross-sell-carousel").on("slid.bs.carousel", "", carousel_checkitem);
	    carousel_checkitem();
	});
}

function cart_slider_mobile_related_products() {
	if ($('.cross-item-list li').length == 2) {
		$('#cross-sell-modal-popup').addClass('twoitems');
	}
	if ($('.cross-item-list li').length == 1) {
		$('.cross-item-list li').addClass("list-center");
		$('#cross-sell-modal-popup').addClass("oneitems");
	}
	$('#cross-sell-modal-popup').modal('show');
	$.ajax({
		url: $('#mobileTogoCartSuggestionAjax').val() + '?crossellPage=4',
		type: 'GET'
	}).done(function (response) {
		var crossSellModalResponse = (response.substring(response.indexOf('<div id="cross-sell-modal"'), response.indexOf('id="cross-sell-modal-end"')));
		$("#crossSellModalWrapper").append(crossSellModalResponse);
		if (crossSellModalResponse) {
			$('#cross-sell-modal-popup').modal('show');
			disableAlcoholItem();   //online alochol sale change
			dtmCrossUpSellModal();
			$('#frmusercrosssell').find('#myCarousel').on('slid.bs.carousel', checkitem);

			function checkitem()                        // check function
			{
				var $this = $('#myCarousel');
				if ($('.carousel-inner .item:first').hasClass('active')) {
					$this.children('.left.carousel-control').hide();
					$this.children('.right.carousel-control').show();
				} else if ($('.carousel-inner .item:last').hasClass('active')) {
					$this.children('.left.carousel-control').show();
					$this.children('.right.carousel-control').hide();
				} else {
					$this.children('.carousel-control').show();

				}
			}
		}else{
			checkoutCallMobile();
		}
		if ($('.carousel-inner .item').length == "1") {
			$('.carousel-control.left,.carousel-control.right').hide();
		} else {
			$('.left.carousel-control').hide();
		}
	});
}

function submitClearCartForm(form) {
	var formId = form.id;
	form.action = form.action.replace(/^https:/, 'https:');
	document.getElementById(formId).submit();
}



function checkoutPageCouponValidation(response){
	var checkoutCouponText = $('#coupon-hidden').val();
	var checkoutRewardText = $('#reward-hidden').val();
	var successRes = response && response.successResponse;
	if(successRes){
	var offerType =  response && response.successResponse && response.successResponse.order && response.successResponse.order.offerType;
	var discountAmount = response && response.successResponse && response.successResponse.order && response.successResponse.order.priceInfo && response.successResponse.order.priceInfo.discountAmount;
	var discountVal = discountAmount.toFixed(2);
	if(offerType){
		$('.checkout-payment-coupon').show();
	}else if(discountVal == 0){
		$('.checkout-payment-coupon').hide();
	}else{	
		$('.checkout-payment-coupon').hide();
	}
	if(offerType == "COUPON"){
		$('.checkout-payment-coupon #coupon-success').html(checkoutCouponText + response.successResponse.order.couponDescription);
	}else{
			var rewardDescription = response.successResponse.order.rewardDescription != null ? response.successResponse.order.rewardDescription : response.successResponse.order.couponDescription ;
		$('.checkout-payment-coupon #coupon-success').html(checkoutRewardText + rewardDescription);
	}
	}
}

function dtmCrossUpSellModal(){
	// dtm cross/up sell pop up START
	if($("#dtmenabled").val()=="true"){
		var primaryCategory = "togo";
		if ($("#orderTypeValue") && $("#orderTypeValue").val() === '2' ){
			primaryCategory = "delivery";
		}
		var productDet  = [];
		if($("div#sugestedItemDetails")){
			var index = 0;
			$("div#sugestedItemDetails").each (function(){
				var prodId="";
				var skuId = "";
				var prodName = "";
				var prodPrice = "";
				if($("#suggestedProductId"+index)){
					prodId = $("#suggestedProductId"+index).val();
				}
				if($("#suggestedSkuId"+index)){
					skuId = $("#suggestedSkuId"+index).val();
				}
				if($("#suggestedProductName"+index)){
					prodName = $("#suggestedProductName"+index).val();
				}
				if($("#suggestedProductPrice"+index)){
					prodPrice = $("#suggestedProductPrice"+index).val();
				}
				var product = {
					"category": {
		            "primaryCategory": primaryCategory,
		            "subCategory1": "upsell",
		            "subCategory2": ""
		        	},
		        	"price": {
			            "basePrice": prodPrice,
			            "currency": "USD"
			        },
			        "productInfo": {
			            "productID": prodId,
			            "productName": prodName,
			            "sku": skuId
			        }
				};
				productDet.push(product);
				index = index+1;
			});
		
		}
		
		var modalData = {
				"modalName": "upsell prompt",
			"modalIntent": "add upsell item",
			"modalContent": "static products",
				"product":productDet
				};		
		dtmModelEvents("DisplayModal",modalData);	
	}
	// dtm cross/up sell pop up END
}

function cartSliderInnerscroll(){
	var drawerbottom = $('.drawer-bottom-content').height(); // this is a bottom content height
	var $windowHeight = window.$height;
	var couponActions = $('.coupon-actions').height();
	var drawerlistheight = $windowHeight - drawerbottom - couponActions - 75; // header height
	if($windowHeight <= 760){
		$('.drawer-list').css({
			'max-height': 'inherit',
			'padding-bottom': '30px'
		});
	}else{
		$('.drawer-list').css({
			'max-height': drawerlistheight,
			'padding-bottom': '30px'
		});
	}
}
/*WO421114 changes start*/
$('#coupon-certificate-field1').on('change paste mouseup keyup', function () {
	$('#coupon-certificate1 #coupon-certificate-error').removeClass('invalid_coupon_error');
	$('#rewards-disabled-section').find('#coupon-certificate-error').html(couponErrorMessage);
});
/*WO421114 changes end*/