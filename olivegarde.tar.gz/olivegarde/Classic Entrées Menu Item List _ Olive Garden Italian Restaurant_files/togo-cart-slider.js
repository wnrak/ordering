var reorderedCount = 0;
var reordered = window.location.href.indexOf('reordered=true') >= 0;
$(document).on('triggerReadyFunction', function(event) {
	
	var opnSldr = getParameterByName("opnSldr");
	if(opnSldr && opnSldr ==="true"){		
		openCartSlider();
	}
	
	$('.item-list-mycart').stickySidebar({
		sidebarTopMargin: 20,
		footerThreshold: 100
	});
	
	$('.delivery-tooltip').click(function(){
	   $('.delivery-tooltip').toggleClass('open');
	}) 
	
	var certicoupan = document.getElementById('coupan');
	if(certicoupan) certicoupan.checked = true;
	$("#drawer-openmenu").attr("href", "javascript:void(0)");
	var notify = window.location.href.indexOf('notifyCart=true') >= 0;
	var showCart = window.location.href.indexOf('showCart=true') >= 0;
	var changeRestaurant = window.location.href.indexOf('changeCurrentRestaurant') >=0;
	var itemCount = $('#itemCount').val();
	var reorderException = $('#addReorderExceptions').val();
	if(reorderException) {
		reordered = false;
		updateURL();
		if($('#addReorderErrorCode').val() === 'cart_AmtThreshold') {
			$('#myModalOrderExceeds').modal('show');
			$('#exceeds-limit-section').html($('#togopickupexceedsThreshold').val());
		}
	}
	if (reordered) {
		if (typeof (Storage) !== "undefined") {
			var stored_cartItems = JSON.parse(sessionStorage.getItem('CartItems'));
			var oldItemCount = stored_cartItems && stored_cartItems['successResponse'] && stored_cartItems['successResponse']['order'] && stored_cartItems['successResponse']['order']['commerceItems'].length;
			if (oldItemCount != 'undefined') reorderedCount = +itemCount - oldItemCount;
		}
		reorderedCartNotify();
	}
	if (notify) {
		notifyCart();
	}
	if(itemCount > 0) {
		$('#drawer-openmenu').find('span').remove();
		$('#drawer-openmenu').append('<span class="order_num">' + itemCount + '</span>')
		$('#order-item-count').html(itemCount);
		$('#order-item-count').css({"display": "inline-block"});
	} else {
	  $('.order_num').remove();	
	  $('#order-item-count').hide();
	}
	if($('#isRightRailCartEnabled').val() === 'true') {
		var itemCount = $('#itemCount').val();
		 if(itemCount == 0) {
			 $("#drawer-openmenu").attr("href", "javascript:void(0)");
		 } else {
			 $("#drawer-openmenu").attr("href", URLPrefixLocale("/cart"));
		 }
	}

	/*Drawer slider Js Start*/
	var userAgent = window.navigator.userAgent;
	if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i ||  userAgent.match(/android/i))) {
		$(document).on('mouseover','.tg-info', function (event) {
			$( this ).find('.fav-tooltip').show();	
		}).on('mouseout','.tg-info',  function(){
			$( this ).find('.fav-tooltip').hide(); 
		});
	}else {
		$(document).on('mouseenter','.tg-info', function (event) {
			$( this ).find('.fav-tooltip').show();
		}).on('mouseleave','.tg-info',  function(){
			$( this ).find('.fav-tooltip').hide(); 
		});
	}

	/*get Qty values == 1 and diabled attr*/
	 $(".js_num_only").each(function () {			
			if($(this).val()== 1){				
				 $(this).closest('.drawer-qty').children(".js_drawerminus").attr('disabled', true);
			}
	  });
		$height = $(window).height();	
		var headerheight = $('header').height();
		$('#drawer-openmenu').on('click', function(){
			$('#addCart-popup').hide();
			var itemCount = $('#itemCount').val();
			var cartOrderType = $("#orderTypeValue").val();			
			if(cartOrderType == "1" && itemCount > 0){
				var giftCardReviewPageUrl = $('#giftCardReviewPageUrl').val();
				if(giftCardReviewPageUrl){
					 window.location.href = giftCardReviewPageUrl;
				}				
			}else{			
			 if(itemCount == 0 || isNaN(itemCount)) {
				 $.ajax({
						url : $('#togoCartPopover').val(),
						success : function(response1) {
							$("#addCart-popup").html(response1);
							$("#addCart-popup").show();
							var conceptCode = $("#conceptCode-val").val();
							var isYH = (conceptCode=='YH');
							if($("#myPopoverContent") && $.cookie("DRIREST")){
								var locValues =$.cookie("DRIREST").split("@@");
								if( isYH && locValues && locValues[9]){
									if(locValues[9] !="true" && $("#orderOnlineId")){
										$("#orderOnlineId").remove();
									}
								}else if (isYH && !locValues){
									$("#orderOnlineId").remove();
								}
							}
							if(isYH && !$.cookie("DRIREST")){
								$("#orderOnlineId").remove();
							}
						}
					});
				 
			 } else{
				if($('#isRightRailCartEnabled').val() === 'true') {
					window.location.href='/cart';
				} else{
					openCartSlider();
				}
			 }
		}	 
		});
		
		$(document).on('click', '#drawer-closemenu,.drawerbody-overlay', function() {		
			closeCartSlider();			
		});
		cartSliderInnerscroll();	
			
		/*Coupon empty validation*/
		$('#rewards-enabled-section').find('#coupon-certificate-btn').click(function(){
			if($('#rewards-enabled-section').find('#coupon-certificate-field').val() == ''){			
				$('#rewards-enabled-section').find('#coupon-certificate-btn').prop("disabled", true);
				$('#rewards-enabled-section').find('#coupon-certificate-error').show();
				$('#rewards-enabled-section').find('#coupon-certificate-field').addClass("input_error");
			}
		})
		$('#rewards-disabled-section').find('#coupon-certificate-btn').click(function(){
			if($('#rewards-disabled-section').find('#coupon-certificate-field').val() == ''){			
				$('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", true);
				$('#rewards-disabled-section').find('#coupon-certificate-error').show();
				$('#rewards-disabled-section').find('#coupon-certificate-field').addClass("input_error");
			}
		})
		
		$('#rewards-enabled-section').find('#coupon-certificate-field').on('change keyup paste mouseup',function(){				
			if($('#rewards-enabled-section').find('#coupon-certificate-field').val() == ''){	
				$('#rewards-enabled-section').find('#coupon-certificate-btn').prop("disabled", true);
				$('#rewards-enabled-section').find('#coupon-certificate-field').addClass("input_error");	
				$('#rewards-enabled-section').find('.deleteXicon span').css('display','none');
			}else{
				$('#rewards-enabled-section').find('#coupon-certificate-btn').removeAttr('disabled');
				$('#rewards-enabled-section').find('#coupon-certificate-error').html($('#couponErrorMessage').val());
				$('#rewards-enabled-section').find('#coupon-certificate-field').removeClass("input_error");
				$('#rewards-enabled-section').find('.deleteXicon span').css('display','block');
			}
		});
		$('#rewards-disabled-section').find('#coupon-certificate-field').on('change keyup paste mouseup',function(){				
			if($('#rewards-disabled-section').find('#coupon-certificate-field').val() == ''){	
				$('#rewards-disabled-section').find('#coupon-certificate-btn').prop("disabled", true);
				$('#rewards-disabled-section').find('#coupon-certificate-field').addClass("input_error");	
				$('#rewards-disabled-section').find('.deleteXicon span').css('display','none');
			}else{
				$('#rewards-disabled-section').find('#coupon-certificate-btn').removeAttr('disabled');
				$('#rewards-disabled-section').find('#coupon-certificate-error').html($('#couponErrorMessage').val());
				$('#rewards-disabled-section').find('#coupon-certificate-field').removeClass("input_error");
				$('#rewards-disabled-section').find('.deleteXicon span').css('display','block');
			}
		});
		/*Coupon empty validation another one fileds*/
		if($.trim($('#drawer-coupon-field').val()) == ''){			
			$('#drawer-coupon-btn').prop("disabled", true);
			$('#drawer-coupon-error').show();
			$('#drawer-coupon-field').addClass("input_error");
		}
		$('#drawer-coupon-field').on('change keyup paste mouseup',function(){				
			if($.trim($('#drawer-coupon-field').val()) == ''){	
				$('#drawer-coupon-btn').prop("disabled", true);			
				$('#drawer-coupon-error').show();
				$('#drawer-coupon-field').addClass("input_error");	
			}else{
				$('#drawer-coupon-btn').removeAttr('disabled');
				$('#drawer-coupon-error').hide();
				$('#drawer-coupon-field').removeClass("input_error");
			}
		});	
	// fixes for signle tab rewards UI fixes
		if($('#rewards-tab').length == 0){
		  $('.tab-content').css('border','none');
		  $('#coupon-tab').css('display','none');
		  $(this).children('.nav-tabs').css('border','none');
		}else{
			$('.apply-coupon input').css('width','67%');
		}
});

function closeCartSlider(){
	$('#drawer-panel').removeClass('opendrawer-panel');			
	setTimeout(function(){
		$('.drawer-container,body').removeAttr("style");		
		$('body').removeClass('cart-slider-open');
		$('#body-overlay').hide();
	}, 500);
}

function openCartSlider(){
	var isToGoLocationConfirmed = $('#isToGoLocationConfirmed').val();
	var sessionOrderType = $("#sessionOrderType").val();
	var orderTypeValue = $('#orderTypeValue').val();
	if ((isToGoLocationConfirmed != undefined && isToGoLocationConfirmed === 'false') && (sessionOrderType!=undefined && sessionOrderType=="catering-delivery-order" || orderTypeValue === "2")) {		
		window.location = $('#pickup-to-deliverycontinue').attr("data-link");		
	}else{	
	$('#coupon-certificate-field,#coupon-certificate-field1').val('');
	var headerheight = $('header').height();
	$('#addCart-popup').hide();
	$('#drawer-panel').addClass('opendrawer-panel');
	$('#body-overlay').show();	
	$('.drawer-container').css({'top':'-'+headerheight+'px','height':'calc(100vh)'});
	$('body').addClass('cart-slider-open');
	callOrderDetail();
	if($('#cartSliderCrossSellEnabled').val()==='true') {
		cart_slider_related_products();
	}
	$('.warning-exceeded').addClass('hidden');
	}
	cartSliderInnerscroll();
}

function reorderedCartNotify(){
	var data = {};
	apiCall('/web-api/order/detailed', 'GET', data, function (response) {
		if(response.successResponse) {
			sessionStorage.setItem('CartItems', JSON.stringify(response));
			notifyReorderedCartItems(response);
			getOrderDetails(response);
		}	
		}, null);
}

function notifyReorderedCartItems(response) {
	var data = response.successResponse.order;
	var itemCount = 0;
	for(var i in data.commerceItems) 
	 {
		 itemCount += data.commerceItems[i].quantity;
	}
	$('.order_num').remove();	
	$('#itemCount').val(itemCount+'');
	if(itemCount > 0) {
		cartDetails(itemCount,true);
		$('.warning-exceeded').addClass('hidden');
	} 
	if($('#isRightRailCartEnabled').val() === 'true') {
		if(itemCount == 0) {
			 $("#drawer-openmenu").attr("href", "javascript:void(0)");
		}else {
			 $("#drawer-openmenu").attr("href", URLPrefixLocale("/cart"));
		}
	}
	$('#orderType').val(response.successResponse.order.orderType);
	infoMessage();
}

//Document ready end
function notifyCart(){
	var itemCount = $('#itemCount').val();
	$('.order_num').remove();
	$('.dar-cart-count').remove();
	if(itemCount > 0) {
		cartDetails(itemCount,false);
	} 
}

function cartSliderInnerscroll(){
	var drawerbottom = $('.drawer-bottom-content').height(); // this is a bottom content height
	var $windowHeight = window.$height;
	var couponActions = $('.coupon-actions').height();
	var drawerlistheight = $windowHeight - drawerbottom - couponActions - 75; // header height
	if($windowHeight <= 760){
		$('.drawer-list').css({'max-height':'inherit','padding-bottom':'30px'});
	}else{
		$('.drawer-list').css({'max-height':drawerlistheight,'padding-bottom':'30px'});
	}
}

/*sticky sidebar*/
(function ($) { 
$.fn.stickySidebar = function(options) { 
	var config = $.extend({
	headerSelector: 'header',
	navSelector: 'nav',
	contentSelector: 'main',
	footerSelector: 'footer',
	sidebarTopMargin: 20,
	footerThreshold: 40
	}, options); 
	var fixSidebr = function() { 
			var sidebarSelector = $(this);
			var viewportHeight = $(window).height();
			var viewportWidth = $(window).width();
			var documentHeight = $(document).height();
			var headerHeight = $(config.headerSelector).outerHeight();
			var navHeight = $(config.navSelector).outerHeight();
			var sidebarHeight = sidebarSelector.outerHeight();
			var contentHeight = $(config.contentSelector).outerHeight();
			var footerHeight = $(config.footerSelector).outerHeight();
			var scroll_top = $(window).scrollTop();
			var fixPosition = contentHeight - sidebarHeight;
			var breakingPoint1 = headerHeight + navHeight;
			var breakingPoint2 = documentHeight - (sidebarHeight + footerHeight + config.footerThreshold); 
			// calculate
			if ( (contentHeight > sidebarHeight) && (viewportHeight > sidebarHeight) ) {		 
					if (scroll_top < breakingPoint1) {				 
					sidebarSelector.removeClass('sticky');		 
			} else if ((scroll_top >= breakingPoint1) && (scroll_top < breakingPoint2)) {		 
					sidebarSelector.addClass('sticky').css('top', config.sidebarTopMargin);		 
			} else {		 
			var negative = breakingPoint2 - scroll_top;
			sidebarSelector.addClass('sticky').css('top',negative);		 
			} 
		}
	}; 
	return this.each( function() {
		$(window).on('scroll', $.proxy(fixSidebr, this));
		$(window).on('resize', $.proxy(fixSidebr, this))
		$.proxy(fixSidebr, this)();
	}); 
	}; 
}(jQuery));
$(document).ready(function() {
});

/* Method to read url parameters */ 	 
function getParameterByName(name, url) {
    if (!url) {
      url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

/* Hide coupon enhancement :: BEGIN */
$(document).on("click",".show-couponcode", function () {
	$(".hide-coupon-section").removeClass("rm-coupon-sec");
    $(".enter-coupon-txt").addClass("rm-coupon-sec");
	if (window.location.href.indexOf("/commerce/checkout") > -1 ||  window.location.href.indexOf("/cart") > -1) {
        if ($('#isLoyaltyEnabledLocation').val() === 'true') {
    		if($("#rewards-enabled-section").hasClass("rm-coupon-sec")) {
    			$("#rewards-enabled-section").removeClass("rm-coupon-sec");
    		}
    	}
    	else {	
    		if($("#rewards-disabled-section").hasClass("rm-coupon-sec")) {
    			$("#rewards-disabled-section").removeClass("rm-coupon-sec");
    		}
    	}
    }
});

$(document).ready(function() {
	var isEnableCouponLink = $("#enableCouponLink").val();
	if (isEnableCouponLink === "true") {
		if (window.location.href.indexOf("/commerce/checkout") > -1) {
			document.getElementById('coupon_no').checked = true;
		}
	}
});

$(document).on("click", "#coupon_yes", function() {
	if ($('#isLoyaltyEnabledLocation').val() === 'true') {
		if($("#rewards-enabled-section").hasClass("rm-coupon-sec")) {
			$("#rewards-enabled-section").removeClass("rm-coupon-sec");
		}
	}
	else {	
		if($("#rewards-disabled-section").hasClass("rm-coupon-sec")) {
			$("#rewards-disabled-section").removeClass("rm-coupon-sec");
		}
	}	
});
 
$(document).on("click", "#coupon_no", function() { 
	if ($('#isLoyaltyEnabledLocation').val() === 'true') {
		$("#rewards-enabled-section").addClass("rm-coupon-sec");
	}
	else {
		$("#rewards-disabled-section").addClass("rm-coupon-sec");
	}
});
/* Hide coupon enhancement :: END */