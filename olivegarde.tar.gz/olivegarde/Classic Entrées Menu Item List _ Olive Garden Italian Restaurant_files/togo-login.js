	//Login functionality script starts

	var cookieEmailID = $.cookie('EMAILID');
	
	$(document).ready(function () { 
		
		//Trigger login function key enter
		$('.login-modal-body').keypress(function(e){
			var key = 'which' in e ? e.which : e.keyCode;
			if(key == 13) {
				login(e);
			}
		});
		
		/*Remember me value set to inbutbox*/
		if(cookieEmailID){	
			$('#loginEmail').val(cookieEmailID);
			$("#login-modal").prop('checked', true);
		}
		
		// Disable Login button when email or password input is empty
		$('#loginEmail, #loginPassword').keyup(function(e){
			var email = $('#loginEmail').val();
			var password = $('#loginPassword').val();
			if(email != '' && password != '') {
				$('#userLogin').removeAttr('disabled');
			} else {
				$('#userLogin').attr('disabled', 'disabled');
			}
		});
		
		//Login modal  
		$('#checkout-login-btn,#loyatly-login-btn,.signIn').click(function () {
			$("#loginPassword").val("");
			$('#catering-login-modal').modal('show');
			$('#login-modal').prop('checked','checked');
		});
				
		//Trigger login function on button click
		$('#userLogin').click(function(e){
			login(e);
		});
		
		//Reset filed and error on cancel
		$('#loginCancel, #modalClose').click(function(e) {
			e.preventDefault();
			$('#loginEmail').val('');
			$('#loginPassword').val('');
			$('#emailError, #passwordError, #emailEmpty, #passwordEmpty').addClass('hidden');
			$('#catering-login-modal').modal('hide');
			$('#userLogin').attr('disabled', 'disabled');
		});
	
	});
	

	
	//This function used to validate and perform the login functionality.
	function login(e) {
		if($('#loginEmail').val()){
			var email = $('#loginEmail').val().toLowerCase();	
		}
		var password = $('#loginPassword').val();
		var saveCardToProfile = false;
		if($('#saveCardToProfile').length > 0){
			var saveCardToProfile = $('#saveCardToProfile').is(':checked');
		}
		if(email != '' && password != ''){
			$('#emailError, #passwordError, #emailEmpty, #passwordEmpty').addClass('hidden');
			if(!validateEmail(email)){
				$('#emailError').removeClass('hidden');
				e.preventDefault();
				return false;
			}
			$('#loader').css('display', 'block');
			e.preventDefault();
			
			var data = {
				"login": email,
				"password": password,
				"saveCardToProfile": saveCardToProfile
			};
			addSiteCodes(data);
			$.ajax({
				type: 'POST',
				url: '/web-api/profile/login',
				async: true,
				data: JSON.stringify(data),
				success: function (response) {
					$('#loader').css('display', 'none');
					var fromSlider = $('#fromSlider').val();
					if (response.hasOwnProperty('successResponse')) {
						var source = $('#source').val();
						var favoriteLocationSet = sessionStorage.getItem("favouriteLocation");
						if(favoriteLocationSet){
						    favouriteLocation(favoriteLocationSet);
						}
						if(fromSlider) {
							$('#catering-login-modal').modal('hide');
							$('body').removeClass('modal-open');								
							$('body').removeAttr('style');
							$('.modal-backdrop').remove();
							//window.location.href= window.location.href+"?showCart=true";
							location.reload();
						}else if(source && source === 'checkout') {
							$('#catering-login-modal').modal('hide');
							$('body').removeClass('modal-open');								
							$('body').removeAttr('style');
							if($('#login-modal').is(':checked')) {
								$.cookie("EMAILID", email, { path: '/' });
							}else{
								$.removeCookie('EMAILID', { path: '/' });
							};
							$('.modal-backdrop').remove();
							$.get($('#togoCheckoutLoginAjax').val(),  function(response) {
								$('#checkoutLoginSection').html($(response).find('#checkoutLoginSection'));
								$('#personalInfoGuest').html($(response).find('#personalInfoGuest'));
								$('#checkout-loyalty').html($(response).find('#checkout-loyalty'));
								$('#togoLoggedInDisplaySectionAjax').html($(response).find('#togoLoggedInDisplaySection'));
								$(document).on('focusout', '#phone-ctn-checkout,#phone-ctn', formatPhoneNumber);
								var responsePath = $('.custom-tooltip img').attr('src');
								var infoSitepath = $('#mediaRootSite').val();
								var newSitePath = infoSitepath + responsePath;
								$('.custom-tooltip img').attr('src',newSitePath);
                                if (($('#phone-ctn-checkout').length > 0) || ($('#phone-ctn').length > 0) ) {
                                    formatPhoneNumber();
                                }
							});
						} else {
							//Section to handle to login on togo favorites flow
							if(source && source != '') {
								$('#isProfileTransient').val('false');
								$('#'+source).click();
								$('#catering-login-modal').modal('hide');
								$('body').removeClass('modal-open');								
								$('body').removeAttr('style');
							}
							if($('#login-modal').is(':checked')) {
								$.cookie("EMAILID", email, { path: '/' });
							}else{
								$.removeCookie('EMAILID', { path: '/' });
							};
							//Popup for setting preferred location
							$('#catering-login-modal').modal('hide');
							$('.modal-backdrop').remove();
							// dtm loggedin and fav modal event alert START
							if($("#dtmenabled").val()=="true" && window.sessionStorage){
								sessionStorage.setItem("dtmEventAlert","loginAndFavEvent");
							}
							// dtm loggedin and fav modal event alert END
						}
						location.reload();	
					} else if (response.hasOwnProperty('errorResponse')) {
						$('#emailEmpty, #passwordEmpty').addClass('hidden');
						$('#emailError, #passwordError').removeClass('hidden');
						if(response.errorResponse['fault'] && response.errorResponse['fault']['faultCode'] && response.errorResponse['fault']['faultCode'] == 'invalidPassword'){	
							 $('#emailError').addClass('hidden');
							  $('#passwordError').removeClass('hidden');
						}
					}
					//$("#checkout").load("#checkout > *"); 
					//Reloading the page getting success for load all elements
					//location.reload();
				},
				error: function (xhr, text, err) {
					console.log("error");
				},
				dataType: 'json',
				contentType: 'application/json'
			});
		} else {
			$('#emailError, #passwordError, #emailEmpty, #passwordEmpty').addClass('hidden');
			if(email == '') {
				$('#emailEmpty').removeClass('hidden');
			}
			if(password == '') {
				$('#passwordEmpty').removeClass('hidden');
			}
			e.preventDefault();
		}
	}
	
	//Validate email structure
	function validateEmail(email) {
		var filter = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i;
		if(filter.test(email)) {
			return true;
		} else {
			return false;
		}
	}
	
	function formatPhoneNumber(input) {
        if($('#phone-ctn')[0]){
			var input = $('#phone-ctn');
		}else{
			var input = $('#phone-ctn-checkout');
		}
        var numsOnly = input.val().replace(/\D/g, '');
        if (numsOnly.length >= 10) {
            input.val(input.val().replace(/\D/g, ''));
        }
        input.val(input.val().replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3'));
        if (input.val().length > 14) {
            input.val(input.val().slice(0, 14));
        }
    }
	function favouriteLocation(restaurantId){
	    sessionStorage.setItem("LatLng",$('#latLong').val());
        sessionStorage.setItem("latLongSearchText",$('#autocomplete').val());
        sessionStorage.setItem("restaurantId",restaurantId);
        $('#userLogin').attr("data-restid",restaurantId);
        var data = {
            "restaurantId": restaurantId
          };
         $.ajax({
        type: 'POST',
        url: '/web-api/favorite/addfavorite-location',
        async: true,
        data: JSON.stringify(data),
        success: function (response) {
          $('#togofavLoader-${restaurantId}').hide();
          if (response.hasOwnProperty('successResponse')) {
            getAllFavoriteLocations();
            //inputObj.addClass("active");
            sessionStorage.getItem("favouriteLocation");
          } else if (response.hasOwnProperty('errorResponse')) {
            console.log('errorResponse', response);
          }
        },
        error: function (xhr, text, err) {
          $('#togofavLoader-${restaurantId}').hide();
          console.log('error', err);
        },
        dataType: 'json',
        contentType: 'application/json'
      });
	}
	
	
	//Login functionality script ends