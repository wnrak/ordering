function unselectHidden(matchingId) {
    if (matchingId != null) {
        var parentInputId = matchingId + 'Val';
        var parentId = document.getElementById(parentInputId);
        hideChildren(parentId);
    }
}
/**
 * Function to check whether a element is present or not
 * @param {string} elementId 
 */
function isElementPresent(elementId) {
    return document.getElementById(elementId) != null &&
        document.getElementById(elementId) != undefined;
}

/**
 * Function to check whether a property value is empty or not
 * @param {string} propertyValue 
 */
function isNotEmpty(propertyValue) {
    return propertyValue != null && propertyValue != '' &&
        propertyValue != undefined;
}

/**
 * This function handles the adding and removing of submenu items and all the selected item's text in the accordion heading,
 * updation of price and toggling of radio button
 * @param {string} id current selected item's input ID
 * @param {string} parentID parent ID of the selected input
 */
function toggleDropdown(id, parentID) {
    if (id != null) {
        // The following code handles the adding and removing of submenu of the selected option.
        // -- START of submenu addtion and removal -- 
        var drpId = id + 'radioinput';

        // If parent ID is available use it otherwise use the selectedSKUDiv ID.
        var selectedDiv = parentID || $('#selectedSkuDiv').val();
        var input = id + 'input';
        if ($("#" + input).prop('checked') === true)
            $("#" + input).attr("checked", "checked");
        else
            $("#" + input).removeAttr('checked')
        if (selectedDiv) {
            var parentDiv = '#' + selectedDiv;
            if ($(parentDiv).find('#' + drpId + ':checked').length == "0") {
                drpId = id + 'input';
            }
            $(parentDiv).find('#' + drpId).closest('ul').find("div").css({
                display: "none"
            });
            var selectedText = $(parentDiv).find('#' + drpId).find(":checked").text();
            $(parentDiv).find('#' + drpId).next('.holder').text(selectedText);
            var radioButton = $(parentDiv).find('#' + drpId + ':checked').attr("id");
            var fullId = radioButton + 'drp';
            var hasSubItems = $(parentDiv).find('#' + drpId).closest('li').find('.subItems').length;
            if (!hasSubItems) {
                $(parentDiv).find('#' + fullId + ' .subItems').add($('#' + fullId + ' .subItems').find('*').filter(':not(.addition-menu)')).show();
                $('#' + fullId + ' .subItems').find('*').filter('.addition-menu').removeAttr('style');
                $(parentDiv).find('#' + drpId).closest('li').append($(parentDiv).find('#' + fullId + " .subItems").filter(function(index, item) {
                    return $(item).children().length
                }).clone());
                $(parentDiv).find('#' + drpId).closest('li').find('.subItems').find('ul').each(function() {
                    $(this).children('div').css({
                        display: "none"
                    });
                });
                $(".radio-custext").removeAttr('style');
            } else {
                $(parentDiv).find('#' + drpId).closest('li').find('.subItems').find('*').filter(':not(.addition-menu)').show();
                $(parentDiv).find('#' + drpId).closest('li').find('.subItems').removeAttr('style');
                $(parentDiv).find('#' + drpId).closest('li').find('.subItems').find('a').each(function() {
                    if ($(this).attr('aria-expanded') == 'false') {
                        $($(this).attr('href')).removeAttr('style');
                    }
                })
                $(parentDiv).find('#' + drpId).closest('li').find('.subItems').find('ul').each(function() {
                    $(this).children('div').css({
                        display: "none"
                    });
                });
                $(parentDiv).find('#' + drpId).closest('li').find('.subItems').find('*').filter('.addition-menu').removeAttr('style');
                $(".radio-custext").removeAttr('style');
                // Selecting subitem radio button by default if there is a single choice.
                var subItemsList = $(parentDiv).find('#' + drpId).closest('li').find('.subItems').find('ul').find('li');
                if (subItemsList.length == 1 && subItemsList.find('input')[0].type == 'radio') {
                    subItemsList.find('input')[0].checked = true;
                }
            }
        }
        // -- END of submenu addtion and removal --

        // The following code handles the updation of price 
        // -- START of updation of price --
        if (isElementPresent(id + 'optprice') || isElementPresent(id + 'radioinputprice') || isElementPresent(id + 'inputprice')) {
            var price = getPrice(id);
            var selectedCost = $("#" + drpId).closest(".panel-collapse").prev().children().find('.selected-cost').text();
            if ($('#' + drpId).attr('type') === 'checkbox') {
                if ($('#' + drpId).prop('checked')) {
                    if (selectedCost !== '' && selectedCost !== undefined) {
                        if (price !== '' && price !== undefined) {
                            price = Number(price.substr(1, price.length - 1)) + Number(selectedCost.substr(1, selectedCost.length - 1));
                        } else {
                            price = Number(selectedCost.subString(1, selectedCost.length));
                        }
                        price = "$" + price.toFixed(2);
                    }
                } else {
                    if (selectedCost !== '' && selectedCost !== undefined) {
                        if (price !== '' && price !== undefined) {
                            price = Number(selectedCost.substr(1, selectedCost.length - 1)) - Number(price.substr(1, price.length - 1));
                        } else {
                            price = Number(selectedCost.subString(1, selectedCost.length));
                        }
                        price = Number(price) > 0 ? '$' + Number(price).toFixed(2) : '';
                    }
                }
            }
            $("#" + drpId).closest(".panel-collapse").prev().children().find('.selected-cost').html(price);
        }
        var addon = addOnPrice();
        var total = totalPrice(addon);
        updateCardPrice(total);
        updatePopupPrice(addon);
        // -- END of updation of price --

        // The following code handles the adding and removing of selected item name in the accordion heading
        // -- START of text addition and removal--
        var menuName = '';

        var cp = 'cp' + id.split('sku')[1].split('cp')[1];
        var sku = 'sku' + id.split('sku')[1].split('cp')[0];
        var accordionSubMenuId = 'acc-' + cp + sku;
        var subMenu = $("#" + drpId).closest('li');
        var subMenuUL = $("#" + drpId).closest('Ul');

        if ($('#' + drpId + 'text').val() != undefined && $('#' + drpId + 'text').length > 0) {
            menuName = $('#' + drpId + 'text').val();
        } else {
            // The following code unchecks the radio button other than the selected one
            // -- START of radio button toggling--
            if (isElementPresent(drpId) && $("#" + drpId + ":checkbox").length === 0) {
                $(subMenuUL).children('li').not(subMenu).each(function() {
                    $(this).find('input').prop('checked', false);
                });
            }
            // -- END of radio button toggling--

            $('#' + accordionSubMenuId + ' li').filter(function(index, item) {
                return !$(item).closest('.subitem-holder').length
            }).each(function(index) {
                if ($(this).find('input').is(':checked')) {
                    var txt = $(this).find('input').attr('id');

                    var label = '';
                    if ($(this).find("label[for='" + txt + "']").find("input[type='hidden']").length) {
                        label = $(this).find("label[for='" + txt + "']").find("input[type='hidden']").val();
                    } else {
                        label = $(this).find("label[for='" + txt + "']").text().replace(/\s\s+/g, ' ').trim();
                    }

                    menuName += label + ', ';
                }
            });
            menuName = menuName.substring(0, menuName.lastIndexOf(','));
        }

        $("#" + accordionSubMenuId).closest(".panel-collapse").prev().children().find('.selected-item').html(menuName);
        // -- END of text addition and removal--
    }
}

/**
 * Function to get the price of the selected item
 * @param {string} id 
 */
function getPrice(id) {
    var priceID = isElementPresent(id + 'optprice') ? id + 'optprice' : (isElementPresent(id + 'radioinputprice') ? id + 'radioinputprice' : id + 'inputprice');
    var price = $('#' + priceID).val();
    if (Number(price) < 0 || Number(price) == 0) {
        var splittedID = id.split('cp');
        if (splittedID.length > 2) {
            var newID = "";
            for (var x = 0; x < id.split('cp').length - 1; x++) {
                newID += id.split('cp')[x] + "cp";
            }
            newID = newID.substring(0, newID.lastIndexOf('cp'));
            getPrice(newID);
        } else {
            price = Number(price) > 0 ? '$' + Number(price).toFixed(2) : '';
            return price;
        }
    } else {
        price = Number(price) > 0 ? '$' + Number(price).toFixed(2) : '';
        return price;
    }
}

/**
 * Function to calculate the total addon price of the selected item
 */
function addOnPrice() {
    var total = 0;
    $('.selected-cost').each(function() {
        var val = $(this).html();
        if (val) {
            var price = parseFloat(val.replace('$', ''));
            total += price;
        }
    });
    return total;
}

/**
 * Function to get the total price of the item including the addon.
 * @param {number} addon 
 */
function totalPrice(addon) {
    if ($('#quantity').length > 0) {
        var cartAmount = parseFloat($('#menuItemPrice').val());
        var quantity = parseInt($('#quantity').val().match(/\d+$/)[0]);
        var total = (cartAmount + addon) * quantity
        return total.toFixed(2);
    }
    return 0;
}

function toggle(fullId, partId) {
    if (fullId != null && partId != null) {
        var divs = document.getElementsByTagName('div');
        var selectedDiv = $('#selectedSkuDiv').val();
        var selectedIds = '';
        if (isNotEmpty(selectedDiv)) {
            var pDiv = '#' + selectedDiv;
            $(pDiv).find('#' + fullId).css({
                display: "block"
            });
        } else {
            document.getElementById(fullId).style.display = '';
        }
    }
}

function hideChildren(parentId) {
    var matchingCheckBoxes = [];
    var matchingDropdowns = [];
    var matchingRadios = [];
    var matchingParents = [];
    if (parentId != null) {
        prntId = parentId.value;
        var parId = parentId.id;
        var parLength = parId.length;
        var parDivId = parId.substring(0, parLength - 3);
        inputs = document.getElementsByTagName('input');
        len = inputs.length;
        for (var i = 0; i < len; i++) {
            input = inputs[i];
            inputId = input.getAttribute("id");
            if (inputId != null && inputId.indexOf(prntId) != -1 &&
                inputId.indexOf('ParentId') != -1) {
                inputPart = inputId.split(":");
                if (inputPart[0].indexOf(prntId) != -1) {
                    matchingParents.push(inputId);
                }
            }
        }
        divlen = matchingParents.length;
        for (var i = 0; i < divlen; i++) {
            matchingId = matchingParents[i];
            value = document.getElementById(matchingId).value;
            if (value != null) {
                var parts = value.split(":");
                if (parts[0].indexOf('chkinput') != -1) {
                    if (document.getElementById(parts[0]).checked == true) {
                        var parentDiv = document.getElementById(parts[0]).parentNode;
                        parentDiv.setAttribute('class', 'checkbox_d_overlay');
                        document.getElementById(parts[0]).checked = false;
                    }
                }
                if (parts[0].indexOf('radioinput') != -1) {
                    if (document.getElementById(parts[0]).checked == true) {
                        document.getElementById(parts[0]).checked = false;
                    }
                }
                if (parts[0].indexOf('drpinput') != -1) {
                    if (document.getElementById(parts[0]).selectedIndex > 0) {
                        var matchingIdSplit = matchingId.split(":");
                        document.getElementById(parts[0]).selectedIndex = 0;
                        $('#' + parts[0]).next('.holder').text('Select');
                    }
                }
            }
        }
    }
}

/**
 * This function is called when we toggle from one portion size to another.
 * It handles the removes old portoins sub item and shows the new one
 * @param {string} fullId 
 * @param {string} partId 
 */
function toggleSku(fullId, partId) {
    if (fullId != null && partId != null) {
        var divs = document.getElementsByTagName('div');
        var matchingIds = [];
        var len = divs.length;
        for (var i = 0; i < len; i++) {
            div = divs[i];
            divId = div.getAttribute("id");
            if (divId && divId.indexOf(partId) == 0) {
                var inputId = divId + 'input';
                if (document.getElementById(inputId)) {
                    if (!document.getElementById(inputId).checked) {
                        matchingIds.push(divId);
                    }
                }
            }
        }
        var divlen = matchingIds.length;
        for (var i = 0; i < divlen; i++) {
            matchingId = matchingIds[i];
            document.getElementById(matchingId).style.display = 'none';
            unselectHidden(matchingId);
        }
        var elem = document.getElementById(fullId);
        if (elem)
            document.getElementById(fullId).style.display = '';
    }
}

/**
 * This function is called after toggling the sku
 * It handles
 * @param {string} skuId 
 */
function changeSku(skuId) {
    if (skuId != null) {
        var prodId = document.getElementById('prod').value;
        var divs = document.getElementsByTagName('div');
        var matchingIds = [];
        var len = divs.length;
        for (var i = 0; i < len; i++) {
            div = divs[i];
            divId = div.getAttribute("id");
            if (divId && divId.indexOf(prodId) != -1) {
                inputId = divId + 'input';
                if (document.getElementById(inputId)) {
                    if (!document.getElementById(inputId).checked) {
                        matchingIds.push(divId);
                    }
                }
            }
        }
        var divLen = matchingIds.length;
        for (var i = 0; i < divLen; i++) {
            var divId = '#' + matchingIds[i];
            $(divId).find("input:checked").each(function() {
                var inputId = $(this).attr('id');
                if (inputId.indexOf('radioinput') != -1) {
                    $(this).addClass("radio_checked");
                    var idLength = inputId.length;
                    var fullId = inputId.substring(0, idLength - 5);
                    $(divId).find('#' + fullId).css({
                        display: 'none'
                    });
                }
                if (inputId.indexOf('propertyinput') != -1) {
                    $(this).removeAttr("checked");
                    var idLength = inputId.length;
                    var fullId = inputId.substring(0, idLength - 5);
                    $(divId).find('#' + fullId).css({
                        display: 'none'
                    });
                    unselectHidden(fullId);
                }
                if (inputId.indexOf('chkinput') != -1) {
                    $(this).removeAttr("checked");
                    $(this).parent().removeClass('checkbox_checked');
                    var idLength = inputId.length;
                    var fullId = inputId.substring(0, idLength - 5);
                    $(divId).find('#' + fullId).css({
                        display: 'none'
                    });
                    unselectHidden(fullId);
                }
            });
            $(divId).find("select").each(function() {
                var selectId = $(this).attr('id');
                if (selectId.indexOf('drpinput') != -1 &&
                    $(this)[0].selectedIndex > 0) {
                    var selectedIndex = $(this)[0].selectedIndex;
                    var partId = document.getElementById(selectId).options[selectedIndex].id;
                    var fullId = partId + 'drp';
                    $(divId).find('#' + fullId).css({
                        display: 'none'
                    });
                    unselectHidden(fullId);
                    $(this)[0].selectedIndex = 0;
                    $(this).next('.holder').text('Select');
                }
            });
        }
        if ($("#quickAddPopup #selectedSkuDiv").val() != undefined || $("#quickAddPopup #selectedSkuDiv").val() != "") {
            $("#popupAddToCart").removeAttr("disabled");
            $("#addToCart").removeAttr("disabled");
        }
    }
}

/**
 * This function updates the price of the selected SKU
 * @param {string} skuId 
 * @param {string} prodId 
 */
function replaceSkuPrice(skuId, prodId) {
    if (isNotEmpty(skuId) && isNotEmpty(prodId)) {
        var skuPrice = 0.00;
        var quantity = getQuantity()
        quantity = quantity > 1 ? quantity - 1 : quantity;
        var priceText = $('#priceText').val();
        if (isElementPresent(skuId + priceText)) {
            skuPrice = parseFloat(document.getElementById(skuId + priceText).value);
        } else {
            skuPrice = $('#menuItemPrice').val();
        }
        $('#selectedSkuDiv').val(prodId + skuId + 'sku');
        $('#menuItemPrice').val(skuPrice);
        $('#listPrice').val(skuPrice);
        
        var addon = addOnPrice();
        var total = totalPrice(addon);
        updateCardPrice(total);
        updatePopupPrice(addon);
    }
}

/**
 * Function to get the quantity of the item selected
 * @returns quantity of the selected item
 */
function getQuantity() {
    var quantity = 1;
    // Upon clicking the edit button in the cart menu it redirects to PDP where the quantiy of the item 
    // is updated through the value stored in session.
    if (typeof(Storage) !== "undefined") {
        var qtyInCart = sessionStorage.getItem('editedCartItemQuantity');
        if (qtyInCart) {
            var cartQuantity = $("#cartQuantity").val();
            $("#quantity").val(cartQuantity + ' ' + parseInt(qtyInCart));
            sessionStorage.removeItem('editedCartItemQuantity');
        }
    }
    if ($("#quantity").length > 0) {
        quantity = $("#quantity").val().split(':')[1].trim();
    }
    return quantity;
}

function updateCardPrice(price) {
    if (price != "" && price != "undefined" && price != "null") {
        price = Number(price).toFixed(2);
        if (cartEdit) {
            var saveChanges = $('#saveChanges').val();
            $("#cartUpdate").html(saveChanges + " <span class=" + "price-tag" + ">($" + price + ")</span>");
        } else {
            var togoAddToCart = $('#togoAddToCart').val();
            if ($("#selectedSkuDiv").val() == "") {
                $("#addToCart").html(togoAddToCart);
            } else {
                $("#addToCart").html(togoAddToCart + " <span class=" + "price-tag" + ">($" + price + ")</span>");
            }
        }

    }
}

function updateInitialCardPrice() {
    var menuItemPrice = +$('#menuItemPrice').val();
    var quantity = getQuantity();
    var addonPrice = addOnPrice();
    if (addonPrice) {
        menuItemPrice += addonPrice;
    }
    if (quantity > 0) {
        price = menuItemPrice * quantity;
    }
    if (quantity == 1) {
        $('.decr-btn').attr('disabled', 'true');
    } else if (quantity == 100) {
        $('.incr-btn').attr('disabled', 'true');
    }
    updateCardPrice(price);
}

function updatePopupPrice(price) {
    var addToCart = $('#togoAddToCart').val();
    var menuItemPrice = $('#menuItemPrice').val();
    var itemPrice = price ? Number(menuItemPrice) + Number(price) : Number(menuItemPrice);
    itemPrice = itemPrice.toFixed(2);
    if (document.getElementById('popupAddToCart')) {
        if ($("#selectedSkuDiv").val() == '') {
            $("#popupAddToCart").html(addToCart);
        } else {
            $("#popupAddToCart").html(addToCart + "<span class=" + "price-tag" + ">($" + itemPrice + ")</span>");
        }
    }
}

/**
 * This function is called when quantity of the item is incremented or decremented
 * @param {object} jqEle current element
 * @param {string} action specifies whether item is incremented or decremented
 */
function onCounterClick(jqEle, action) {
    var $quantity;
    var qty = getQuantity();
    var prodId = $("#menuItemID").val();
    var skuId = "sku" + $("#selectedSkuDiv").val().split("sku")[1];
    var cartQuantity = $("#cartQuantity").val();
    switch (action) {
        case 'INC': {
            $quantity = jqEle.prevAll('input').first();
            if (qty < jqEle.data("max")) {
                $quantity.val(cartQuantity + ' ' + (parseInt(qty) + 1));
                if (qty === '1') {
                    $('.qty-minus').removeAttr('disabled');
                }
            }
            break;
        }
        case 'DEC':
        default: {
            $quantity = jqEle.nextAll('input').first();
            if (qty > jqEle.data("min")) {
                $quantity.val(cartQuantity + ' ' + (parseInt(qty) - 1));
                if (qty === '2') {
                    $('.qty-minus').attr('disabled', true);
                }
            }
            break;
        }
    }
    replaceSkuPrice(skuId, prodId);
}

var cartEdit = false;
var parentSkuId = "";
$(document).on('triggerReadyFunction', function(event) {
    $('#asapTodayDate').hide();
    // display the NEW flag 
    if ($("#new-item").length > 0) {
        $("#new-item-content").show();
    }

    var queryString = window.location.search;
    if (queryString) {
        cartEdit = true;
    }

    var vars = [], hash;
    var q = document.URL.split('?')[1];
    var editFlag = "";
    var commerceId = "";
    if (q != undefined) {
        q = q.split('&');
        for (var i = 0; i < q.length; i++) {
            hash = q[i].split('=');
            vars.push(hash[1]);
            vars[hash[0]] = hash[1];
        }
        editFlag = vars['editFlag'];
        commerceId = vars['commerceItemId'];
        parentSkuId = vars['parentCatalogRefId'];

    }
    var prodId = $('#menuItemID').val();
    if ($('#ajaxMenu_Options').length > 0) {
        $("#configOptionsAjax").addClass('configOptionsAjax');
        $("#configOptionsAjax").html("<div class='container-img-loader'></div>");
        showConfigOptions(prodId, true, editFlag, commerceId, parentSkuId);
    }

    function showConfigOptions(prodId, contentToGo, editFlag, commerceId, parentSkuId) {
        var menuOptionsURL = $('#ajaxMenu_Options').val();
        var queryString = "";
        var type = "get";
        if (editFlag != null && editFlag != '') {
            queryString = "&commerceItemId=" + commerceId + "&parentCatalogRefId=" + parentSkuId + "&editFlag=" + editFlag;
            type = "post";
            var selectedIDs = getCommerceItemDetails(commerceId);
            var selectedSkuDivValue = getselectedSkuDivValue(commerceId);
        }
        var request = $.ajax({
            url: menuOptionsURL,
            type: type,
            data: "menuItemID=" + prodId + "&contentToGo=" + contentToGo + queryString,
            cache: false
        });
        request.done(function(response, textStatus, jqXHR) {
            var template = Handlebars.compile(response);

            var menuItemAjax = $.ajax({
                url: "/web-api/menuitem/" + prodId,
                type: 'GET',
                data: "restaurantId=" + $("#pdRestId").val() + "&checkAvailability=false"
            });
            var sku86edAax = $.ajax({
                url: "/web-api/restaurant/86edSkus",
                type: 'GET',
                data: "restaurantId=" + $("#pdRestId").val()
            });
            $.when(menuItemAjax, sku86edAax).done(function (response1, response2) {
                var menuItemResponse = response1[0];
                var sku86edResponse = response2[0];
                decorateMenuItemSkuBeanWithStatus(menuItemResponse, sku86edResponse, selectedIDs);
                sortMenuItemPropertyBeansByMandatoryOptions(menuItemResponse);
                $("#configOptionsAjax").html(template(menuItemResponse));
			}).then(function() {

                if (selectedSkuDivValue) {
                    $('#selectedSkuDiv').val(selectedSkuDivValue);
                }
                    
                var currentCategory = $("#configOptionsAjax").find('#currentCategory').val();
                if (currentCategory && currentCategory.length) {
                    var currentCategoryStr = new Array();
                    currentCategoryStr = currentCategory.split(' ');
                    $.each(currentCategoryStr, function(index, item) {
                        currentCategoryStr[index] = item.toLowerCase();
                    });
                    var pdpsublinkUrl = sessionStorage.getItem("lastMenuUrl");
                    if (pdpsublinkUrl && pdpsublinkUrl != undefined) {
                        var lastItem = pdpsublinkUrl.split("/").pop(-1);
                        if (lastItem && lastItem != undefined) {
                            for (var i = 0; i <= 0; i++) {
                                if (lastItem == $(".sub-link" + lastItem).attr("data-id")) {
                                    $(".sub-link" + lastItem).children("span").children("a").addClass("active");
                                }
                            }
                        }
                    }
                }
                if ($("#configOptionsAjax #selectedSkuDiv").val() == undefined || $("#configOptionsAjax #selectedSkuDiv").val() == "") {
                    $("#addToCart").attr("disabled", "disabled");
                }
                if ($('#dineInOnly')[0]) {
                    $('[id^=textareaprod]').hide();
                }
                var fromEdit = sessionStorage.getItem('editedCartItemQuantity');
                $("#quantity").attr('readonly', true);
                $("#configOptionsAjax #addToCartErrors").removeClass("alert");
                $("#configOptionsAjax #addToCartErrors").removeClass("alert-danger");
                //check the radio button for default item
                $('#' + $("#selectedSkuDiv").val() + 'input').attr('checked', true);
                $('.overlay-left-radio , .tmi-right').click(function() {
                    $('.radio_new').removeClass('radio_checked');
                    $('input').removeAttr('checked');
                    $(this).parents('.options-click').find('.radio_new input').click();
                    $(this).parents('.options-click').find('.radio_new').addClass('radio_checked');
                    $(this).parents('.options-click').find('.radio_new input').attr('checked', 'checked');
                });
                jQuery(function() {
                    jQuery.support.placeholder = false;
                    test = document.createElement('input');
                    if ('placeholder' in test) {
                        jQuery.support.placeholder = true;
                    }
                });
                $(function() {
                    if (!$.support.placeholder) {
                        var active = document.activeElement;
                        $('input[type=text], textarea').focus(function() {
                            if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
                                $(this).val('').removeClass('hasPlaceholder');
                            }
                        }).blur(function() {
                            if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
                                $(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
                            }
                        });
                        $('input[type="text"], textarea').blur();
                        $(active).focus();
                        $('form').submit(function() {
                            $(this).find('.hasPlaceholder').each(function() {
                                $(this).val('');
                            });
                        });
                    }
                });
                if ($('.ogproduct-list li').length == 0) {
                    $("#product-recommendation").remove();
                }
                if ($("#product-recommendation").length != undefined && $("#product-recommendation").length > 0) {
                    $(".pdp-addtocart-btn-panel").after($("#product-recommendation"));
                }

                //Open accordian on load
                var hash = window.location.hash;
                $('#configOptionsAjax').find("input[type=radio]:checked").trigger("change");

                $("#configOptionsAjax").find(".pdp-accordion").each(function() {
                    var count = $(this).attr('data-count');
                    $(this).append($('#configOptionsAjax').find('#nutritionDataHidden').html());
                    $(this).find('.panel.panel-default:last').find('.panel-collapse').attr('id', $(this).find('.panel.panel-default:last').find('.panel-collapse').attr('id') + count);
                    $(this).find('.panel.panel-default:last').find('.panel-title').find('a').attr('href', '#' + $(this).find('.panel.panel-default:last').find('.panel-collapse').attr('id'));
                    $(this).find('.panel.panel-default:last').find('.panel-title').find('a').attr('data-parent', '#' + $(this).attr('id'));
                    $(this).find('.panel.panel-default:last').find('.panel-title').next().attr('data-parent', $(this).find('.panel.panel-default:last').parent().attr('id'));
                    if (hash) {
                        var anchor = $('a[href$="' + hash + count + '"]');
                        if (anchor.length > 0) {
                            anchor.click();
                            var subMenuId = hash + count
                            var el = $(subMenuId);
                            var elOffset = el.offset().top;
                            var elHeight = el.height();
                            var windowHeight = $(window).height();
                            var offset;
                            if (elHeight < windowHeight) {
                                offset = elOffset - ((windowHeight / 2) - (elHeight / 2));
                            } else {
                                offset = elOffset;
                            }
                            var speed = 700;
                            $('html, body').animate({
                                scrollTop: offset
                            }, speed);
                        }
                    }
                });
                if ($('.pdp-addtocart-btn-panel').length) {
                    $("#configOptionsAjax").find('label[for="entree"]').parent().css('padding', '0');
                    $("#configOptionsAjax").find('label[for="entree"]').parent().addClass('this-item-entree');
                }
                updateInitialCardPrice();
                if (!fromEdit && $('#selectedSkuDiv').val() != '' && $('#selectedSkuDiv').val() != undefined) {
                    portionSizeTimeHandler();
                }
                portionSizeHandler('configOptionsAjax');
                handleAccordionSelection('configOptionsAjax');
				// disable add to cart if rest not enable to alcohol online togo START
				if(location.pathname.indexOf("/menu/") != -1){
				disableAlcoholItem();
				}
				// disable add to cart if rest not enable to alcohol online togo END
			});
		});
        request.fail(function(jqXHR, textStatus, errorThrown) {
            // log the error to the console
            console.error("The following error occured: " + textStatus, errorThrown);
        });
    }

    $("#configOptionsAjax").delegate('.qty-plus', 'click', function() {
        onCounterClick($(this), 'INC');
    });
    $("#configOptionsAjax").delegate('.qty-minus', 'click', function() {
        onCounterClick($(this), 'DEC');
    });
    $("#configOptionsAjax").delegate("#addToCart", "click", function(e) {
        e.preventDefault();
        $("#configOptionsAjax #addToCartErrors").removeClass("alert");
        $("#configOptionsAjax #addToCartErrors").removeClass("alert-danger");
        $(this).attr("disabled", "disabled");
        var orderTypeValue = $('#orderTypeValue').val();
        var isToGoLocationConfirmed = $("#isToGoLocationConfirmed").val();
        var sessionOrderType = $("#sessionOrderType").val();
        if (isGiftCardOrderExists()) {
            checkGiftCardOrder();
            $(this).removeAttr("disabled");
        } else if (isToGoLocationConfirmed != undefined && isToGoLocationConfirmed === 'false') {
            if ((sessionOrderType != undefined && sessionOrderType == "catering-delivery-order") || orderTypeValue === "2") {
                window.location = $('#pickup-to-deliverycontinue').attr("data-link");
            } else {
                loadLocationConfirmationPopup();
                $(this).removeAttr("disabled");
            }
        } else {
            if (isWrongPortionSelected(false)) {
                $(this).removeAttr("disabled");
                return false;
            }
            $('#pdpAddToCartLoader').show();
            var data = {}
            data['restaurantId'] = $("#pdRestId").val();
            data['productID'] = $("#menuItemID").val();
            data['catalogRefIds'] = "sku" + $("#selectedSkuDiv").val().split("sku")[1];
            data['Quantity'] = $("#quantity").val().split(':')[1].trim();
            data['fromPage'] = location.pathname;
            if ($("#entree").length > 0) {
                data['guestName'] = $("#entree").val();
            }
            if ($(".spl-instructions").length > 0) {
                data['itemInstructions'] = $(".spl-instructions").val();
            }
            var selectedIds = '';
            $("#" + $("#selectedSkuDiv").val()).find("input[type='radio']:checked, input[type='checkbox']:checked").filter(function(index, item) {
                return !$(item).closest('.subitem-holder').length
            }).each(function() {
                selectedIds += $(this).val() + ",";
            });
            data['selectedIds'] = selectedIds.substr(0, selectedIds.length - 1);
            data['ConfigQuantity'] = 1;
            addSiteCodes(data);
            var addItemUrl = "/web-api/order/add";
            $.ajax({
                type: 'POST',
                url: addItemUrl,
                async: false,
                data: JSON.stringify(data),
                success: function(response) {
                    // dtm add to cart event capture product detail page START
                    if ($("#dtmenabled").val() == "true" && response.hasOwnProperty('successResponse') && response.successResponse.dataLayerJSON) {
                        window.digitalData = JSON.parse(response.successResponse.dataLayerJSON);
                        if (window.digitalData && window.digitalData.event && window.digitalData.event.length > 0) {
                            $(window.digitalData.event).each(function(index, item) {
                                if (item.eventInfo && item.eventInfo.eventName && item.eventInfo.eventName === "addToCart") {
                                    if (window.sessionStorage) {
                                        sessionStorage.setItem("dtmAddtoCartEvent", "true");
                                        sessionStorage.setItem("addToCartEventObj", JSON.stringify(item));
                                    }
                                }
                            });
                        }

                    }
                    // dtm add to cart event capture END
                    if (response.hasOwnProperty('successResponse')) {
                        sessionStorage.setItem('CartItems', JSON.stringify(response));
                        var successRedirectionUrl = sessionStorage.getItem("lastMenuUrl");
                        if (successRedirectionUrl == undefined || successRedirectionUrl == '') {
                            successRedirectionUrl = "/menu-listing";
                        }
                        if (sessionStorage.getItem('listView') == 'true') {
                            successRedirectionUrl = successRedirectionUrl + "&notifyCart=true";
                        } else {
                            successRedirectionUrl = successRedirectionUrl + "?notifyCart=true";
                        }
                        window.location.href = successRedirectionUrl;
                        sessionStorage.removeItem('listView');
                        if(!$('.rest-pickupdate-drop').is(":visible")) {
                            $('.rest-pickupdate-drop').show();
                            $('#pickup-asapdate').show();
                        }

                    } else if (response.hasOwnProperty('errorResponse')) {
                        $("#configOptionsAjax #addToCartErrors").html('');
                        var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;
                        if (expResponse == 'sessionExpired') {
                            $("#sessionExpired").modal('show');
                        } else if (response.errorResponse.fault[0].faultCode === 'cart_AmtThreshold' ||
                            response.errorResponse.fault[0].faultCode === 'subtext-choose-items-cart-qualify-exceeds') {
                            orderExceedLimit();
                        } else if (response.errorResponse.fault[0].faultCode === 'itemMenuPeriodSwitch') {
                            menuPeriodSwitch();
                        } else if (response.errorResponse.fault[0].faultCode === 'cart_TimeConflicts') {
                            $('#timeConflictMessage').html(response.errorResponse.fault[0].faultDescription);
                            $('#timeConflict').modal('show');
                        } else if (response.errorResponse.fault[0].faultCode === 'cart_qtyThreshold') {
                            quantityExceedsLimit();
                        } else if (response.errorResponse.fault[0].faultCode === 'asap_not_available_add_item') {
                            asapInitialDatetime();
                            $('#asapNotAvailableAddItem').html(response.errorResponse.fault[0].faultDescription);
                            $('#quickaddasap-Errormodal').modal('show');
                        } else {
                            if (response.errorResponse.fault && response.errorResponse.fault[0].faultCode === 'itemNotAvailable') {
                                appendLocal86edValues($("#menuItemID").val());
                                process86edItemsData(generate86edResponseFromLocalValues(getLocal86edValues()));
                            }
                            if (response.errorResponse.fault.length > 0) {
                                $.each(response.errorResponse.fault, function(index, exception) {
                                    $("#configOptionsAjax #addToCartErrors").append(exception.faultDescription);
                                    if (response.errorResponse.fault.length > 0) {
                                        $("#configOptionsAjax #addToCartErrors").append('<br/>');
                                    }
                                });
                            } else {
                                $("#configOptionsAjax #addToCartErrors").append(response.errorResponse.fault.faultDescription);
                            }
                            $("#configOptionsAjax #addToCartErrors").addClass("alert alert-danger");
                            var errorPosition = $('#configOptionsAjax #addToCartErrors').offset().top;
                            var productPosition = $('.pdp-bigimageandtext').offset().top;
                            $(window).scrollTop(errorPosition - productPosition);
                        }
                        $('#pdpAddToCartLoader').hide();
                        sessionStorage.setItem('disableOrderSettings', "false");
                    }
                    $("#addToCart").removeAttr("disabled");
                },
                error: function(xhr, text, err) {
                    console.log("error");
                },
                dataType: 'json',
                contentType: 'application/json'
            });
        }
    });

    $("#configOptionsAjax").delegate("#cartUpdate", "click", function(e) {
        e.preventDefault();
        if (isWrongPortionSelected(false)) return false;
		//Commenting as part of Mandatory check in edit flow
        /*setTimeout(function() {
            $('#pdpAddToCartLoader').show();
        }, 0); */
        $("#configOptionsAjax #addToCartErrors").removeClass("alert");
        $("#configOptionsAjax #addToCartErrors").removeClass("alert-danger");
        $(this).attr("disabled", "disabled");
        var data = {}
        data['productID'] = $("#menuItemID").val();
        data['catalogRefIds'] = "sku" + $("#selectedSkuDiv").val().split("sku")[1];
        data['Quantity'] = $("#quantity").val().split(':')[1].trim();
        if ($("#entree").length > 0) {
            data['guestName'] = $("#entree").val();
        }
        if ($(".spl-instructions").length > 0) {
            data['itemInstructions'] = $(".spl-instructions").val();
        }
        var selectedIds = '';
        $("#" + $("#selectedSkuDiv").val()).find("input[type='radio']:checked, input[type='checkbox']:checked").filter(function(index, item) {
            return !$(item).closest('.subitem-holder').length
        }).each(function() {
            selectedIds += $(this).val() + ",";
        });
        data['selectedIds'] = selectedIds.substr(0, selectedIds.length - 1);
        data['ConfigQuantity'] = 1;
        var commerceId = $(this).attr('data-commerceid');
        data['commerceIds'] = commerceId;
        var quantity = $("#quantity").val().split(':')[1].trim();
        var updateItemUrl = "/web-api/order/update?" + commerceId + "=" + quantity;
        $.ajax({
            type: 'POST',
            url: updateItemUrl,
            async: false,
            data: JSON.stringify(data),
            success: function(response) {
                $('#pdpAddToCartLoader').hide();
                if (response.hasOwnProperty('successResponse')) {
                    sessionStorage.setItem('CartItems', JSON.stringify(response));
                    var successRedirectionUrl = sessionStorage.getItem("lastMenuUrl");
                    if (successRedirectionUrl == undefined || successRedirectionUrl == '') {
                        successRedirectionUrl = "/menu-listing";
                    }
                    if (sessionStorage.getItem('listView') == 'true') {
                        successRedirectionUrl = successRedirectionUrl + "&cartOpen=true";
                    } else {
                        successRedirectionUrl = successRedirectionUrl + "?cartOpen=true";
                    }
                    window.location.href = successRedirectionUrl;
                    sessionStorage.removeItem('listView');

                } else if (response.hasOwnProperty('errorResponse')) {
                    $("#configOptionsAjax #addToCartErrors").html('');
                    var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;
                    if (expResponse == 'sessionExpired') {
                        $("#sessionExpired").modal('show');
                    } else if (response.errorResponse.fault[0].faultCode === 'cart_AmtThreshold' ||
                        response.errorResponse.fault[0].faultCode === 'subtext-choose-items-cart-qualify-exceeds') {
                        orderExceedLimit();
                    } else if (response.errorResponse.fault[0].faultCode === 'itemMenuPeriodSwitch') {
                        menuPeriodSwitch();
                    } else if (response.errorResponse.fault[0].faultCode === 'cart_TimeConflicts') {
                        $('#timeConflictMessage').html(response.errorResponse.fault[0].faultDescription);
                        $('#timeConflict').modal('show');
                    } else if (response.errorResponse.fault[0].faultCode === 'cart_qtyThreshold') {
                        quantityExceedsLimit();
                    } else if (response.errorResponse.fault[0].faultCode === 'asap_not_available_add_item') {
                        asapInitialDatetime();
                        $('#asapNotAvailableAddItem').html(response.errorResponse.fault[0].faultDescription);
                        $('#quickaddasap-Errormodal').modal('show');
                    } else {
                        if (response.errorResponse.fault.length > 0) {
                            $.each(response.errorResponse.fault, function(index, exception) {
                                $("#configOptionsAjax #addToCartErrors").append(exception.faultDescription);
                                if (response.errorResponse.fault.length > 0) {
                                    $("#configOptionsAjax #addToCartErrors").append('<br/>');
                                }
                            });
                        } else {
                            $("#configOptionsAjax #addToCartErrors").append(response.errorResponse.fault.faultDescription);
                        }
                        $("#configOptionsAjax #addToCartErrors").addClass("alert alert-danger");
                        var errorPosition = $('#configOptionsAjax #addToCartErrors').offset().top;
                        var productPosition = $('.pdp-bigimageandtext').offset().top;
                        $(window).scrollTop(errorPosition - productPosition);
                    }
                } else if (response.formExceptions[0].errorCode === 'cart_AmtThreshold' ||
                    response.formExceptions[0].errorCode == 'subtext-choose-items-cart-qualify-exceeds' || response.formExceptions[0].errorCode == 'cart_qtyThreshold') {
                    orderExceedLimit();
                    if (response.formExceptions[0].errorCode == 'cart_qtyThreshold') {
                        quantityExceedsLimit();
                    }
                } else if (response.formExceptions[0].errorCode == 'cart_TimeConflicts') {
                    $('#timeConflictMessage').html(response.formExceptions[0].localizedMessage);
                    $('#timeConflict').modal('show');
                }
                $("#cartUpdate").removeAttr("disabled");
            },
            error: function(xhr, text, err) {
                console.log("error");
            },
            dataType: 'json',
            contentType: 'application/json'
        });
    });

    $('#show-change-time').on('click', function() {
        $('#myModalTimeConflicts').modal('hide');
        $('#modalacc-pickup').attr('style', '');
        $('#modalacc-pickup').attr('aria-expanded', 'true');
        $('#modalacc-pickup').addClass('in');
        window.location.reload();
    });

    $('#close-order-exceeds,#close-order-exceeds1').on('click', function() {
        $('#myModalOrderExceeds').modal('hide');
        if ($('.modal-backdrop').hasClass('in')) {
            $('.modal-backdrop').hide();
        }
    });

    $('#close-order-timeconflict,#close-order-timeconflict1').on('click', function() {
        $('#myModalTimeConflicts').modal('hide');
        if ($('.modal-backdrop').hasClass('in')) {
            $('.modal-backdrop').hide();
        }
        window.location.reload();
    });

    $('#quickaddasap-continue').on('click', function() {
        var asapSelectedId = $('input[name="asapDateTime"]:checked').attr('id');
        if (asapSelectedId == 'removeItemAsap') {
            window.location.reload();
        }
        if (asapSelectedId == 'chooseFutureDateTime') {
            var selectedTime = $('#asap-timelist').val();
            var selectedDate = moment($('#asap-datetimepicker').val()).format('MM/DD/YYYY');
            var reqBody = {
                "validateCartItems": true,
                "requestedPickupDate": selectedDate,
                "requestedPickupTime": selectedTime,
                'asapSelected': false
            };
            setPickupTimeApi(reqBody, asapSetPickupTimeSuccess, asapSetPickupTimeError);
            //window.location.reload();	
        }
    });

    $('#removeItemAsap').on('click', function() {
        $('#asapSpecificDateTime').hide();
    });

    $('#chooseFutureDateTime').on('click', function() {
        $('#asapSpecificDateTime').show();
    });
});

function isGiftCardOrderExists() {
    var orderType = $("#orderTypeValue").val();
    var count = $("#itemCount").val();
    return (orderType == "1" && count > 0);
}

function checkGiftCardOrder() {
    var orderType = $("#orderTypeValue").val();
    var count = $("#itemCount").val();
    if (orderType == "1" && count > 0) {
        $("#createNewOrderModal-GC").modal('show');
    }
}

function orderExceedLimit() {
    $('#myModalOrderExceeds').modal('show');
    if (($('#orderTypeValue').val() !== undefined && $('#orderTypeValue').val() === '0')) {
        $('#exceeds-limit-section').html($('#togopickupexceedsThreshold').val());
    }
    if (($('#orderTypeValue').val() !== undefined && $('#orderTypeValue').val() === '2')) {
        $('#exceeds-limit-section').html($('#cateringExceedsThreshold').val());
    }
    if (($('#orderTypeValue').val() !== undefined && $('#orderTypeValue').val() === '3')) {
        $('#exceeds-limit-section').html($('#catpickupexceedsThreshold').val());
    }
}

function quantityExceedsLimit() {
    $('#myModalOrderExceeds').modal('show');
    $('#exceeds-limit-section').html($('#exceedsQuantityThreshold').val());
}

/**
 * This function displays the time conflict modal.
 * When the selected item is not available for the current time, this function is called.
 */
function menuPeriodSwitch() {
    $('#fromTimeConflict').val(true);
    //update actual pickup date and picup time
    $('#actualPickupTime').html($('#default_jsontime').val());
    $('#actualPickupDate').html($('#default_jsondate').val());

    $('#myModalTimeConflicts').modal('show')
    var actualpickupTime = $('#pickup-timelist').val();
    var lunchEndTime = $('#lunchEndTime').html();
    var selectedPriceText = $('#selectedPriceText').val();
    var outsideLunchHoursText = $('#outsideLunchHoursText').val();
    var lunchItemsText = $('#lunchItemsText').val();
    var lunchOnlyItem = $('#lunchOnlyItemText').val()
    var errorMsg = '<p>' + lunchOnlyItem + '</p>';
    $('#error-section').html(errorMsg);
}

/**
 * Function to handle if selected portion size is not available for the current time 
 * @param {boolean} isQuickAdd specifes whether item is added to cart from quick add or not
 */
function isWrongPortionSelected(isQuickAdd) {
    if ($('.portion-size-panel').length && isElementPresent('lunchEndingTime')) {
        var selectedPickuptime = moment($('#default_jsontime').val(), 'hh:mm A').format('HH:mm').split(':');
        var lunchEndingtime = moment($('#lunchEndingTime').val(), 'hh:mm A').format('HH:mm').split(':');
        var selectedPortionValue = $('.portion-size-inner').children('ul').find('input[type="radio"]:checked').closest("li").find("[id*='portionSize']").val();
        if (selectedPortionValue == '1' && (Number(selectedPickuptime[0]) > Number(lunchEndingtime[0]) || (Number(selectedPickuptime[0]) == Number(lunchEndingtime[0]) && Number(selectedPickuptime[1]) > Number(lunchEndingtime[1])))) {
            if (isQuickAdd) $('#item-list-modal').modal('toggle');
            menuPeriodSwitch();
            return true;
        }
    }
    return false;
}

/**
 * Function to select the portion size of the item by default based on the current time.
 */
function portionSizeTimeHandler() {
    if ($('.portion-size-panel').length && isElementPresent('lunchEndingTime')) {
        var selectedPickuptime = moment($('#default_jsontime').val(), 'hh:mm A').format('HH:mm').split(':');
        var lunchEndingtime = moment($('#lunchEndingTime').val(), 'hh:mm A').format('HH:mm').split(':');
        var lunchItemSelected = false;
        if (Number(selectedPickuptime[0]) < Number(lunchEndingtime[0]) || (Number(selectedPickuptime[0]) == Number(lunchEndingtime[0]) && Number(selectedPickuptime[1]) < Number(lunchEndingtime[1]))) {
            lunchItemSelected = true;
        }
        $("[id*='portionSize']").each(function() {
            if ((lunchItemSelected && $(this).val() == '1') || (!lunchItemSelected && $(this).val() == '2') || $(this).val() == '3') {
                $('#' + $(this)[0].id.replace('portionSize', '') + 'skuinput').attr('checked', true);
            }
        })
    }
}

/**
 * This function is called to handle the portion size change, that is changed based on time.
 * @param {string} elID element ID to differentiate the quick add and the item added from PDP
 */
function portionSizeHandler(elID) {
    if ($('.portion-size-panel').length) {
        var id = $('#' + elID).find('input[type="radio"]:checked').attr('id');
        var name = $('#' + elID).find('input[type="radio"]:checked').attr('name');
        var value = $('#' + elID).find('input[type="radio"]:checked').attr('value');
        if (id && name && value) {
            id = id.replace('input', '');
            toggleSku(id, name);
            changeSku(value);
            var prodId = $('#menuItemID').val();
            if (parentSkuId) {
                $('#selectedSkuDiv').val(prodId + parentSkuId + 'sku');
            }
            replaceSkuPrice(value, name);
        }
    }
}

/**
 * This function handles all the selected menu under the selected accordion.
 * @param {string} elID element ID to differentiate the quick add and the item added from PDP
 */
function handleAccordionSelection(elID) {
    $('#' + elID).find('div[id*=' + $('#togoMenuItem').val() + ']').each(function() {
        var selectedId = $(this).attr('id');
        $("#" + selectedId + ' .panel-default').each(function() {
            $(this).find('li').filter(function(index, item) {
                return !$(item).closest('.subitem-holder').length
            }).each(function() {
                // Handling for radio button
                var radioBtnId = $(this).find('input[type="radio"]:checked').attr('id');
                if (radioBtnId) {
                    radioBtnId = radioBtnId.replace('radioinput', '');
                    toggleDropdown(radioBtnId, selectedId);
                }
                // Handling for checkbox
                var chkBoxId = $(this).find('input[type="checkbox"]:checked').attr('id');
                if (chkBoxId) {
                    chkBoxId = chkBoxId.replace('chkinput', '');
                    toggleDropdown(chkBoxId, selectedId);
                }
            });
        });
    });
}

/**
 * This event is triggered when change time button is clicked in time conflict modal
 */
function successAddItemToCart(response, form, inputObj) {
    if (!(response.indexOf("errorExists") >= 0)) {
        var data = {};
        apiCall('/web-api/order/detailed', 'GET', data, function(response) {
            if (response.successResponse) {
                sessionStorage.setItem('CartItems', JSON.stringify(response));
                notifyCartItems(response);
                getOrderDetails(response);
            }
        }, null);
    }
}

/**
 * Function to shows a notification when a item is added to cart.
 * @param {object} response 
 */
function notifyCartItems(response) {
    var data = response.successResponse.order;
    var itemCount = 0;
    for (var i in data.commerceItems) {
        itemCount += data.commerceItems[i].quantity;
    }
    $('.order_num').remove();
    $('#itemCount').val(itemCount + '');
    if (itemCount > 0) {
        cartDetails(itemCount, true);
        $('.warning-exceeded').addClass('hidden');
    }
    if ($('#isRightRailCartEnabled').val() === 'true') {
        if (itemCount == 0) {
            $("#drawer-openmenu").attr("href", "javascript:void(0)");
        } else {
            $("#drawer-openmenu").attr("href", URLPrefixLocale("/cart"));
        }
    }
    $('#orderType').val(response.successResponse.order.orderType);
    infoMessage();
}

/**
 * This event is Triggered when the quick add button is clicked in the listing page.
 */
$(document).on("click", ".plpquick-viewicon", function(event) {
    event.stopPropagation();
    sessionStorage.setItem('disableOrderSettings', "false");
    var inputObj = $(this);
    var prodID = inputObj.data('prodid');
    $('a#favoriteitem-indicator-' + prodID).closest("li").append('<div class="togo-loader" id="favoriteitem_loader-' + prodID + '">Loader...</div>');
    $('#favoriteitem_loader-' + prodID).show();
    var currentLinkId = $(this).attr("id");
    var url = $('#togoQuickAddAjax').val() + "?menuItemID=" + $(this).attr("data-prodId");
    var isToGoLocationConfirmed = $("#isToGoLocationConfirmed").val();
    var sessionOrderType = $("#sessionOrderType").val();
    var orderTypeValue = $('#orderTypeValue').val();
    var isSimpleProduct =  $(inputObj).closest("li").find('.isSimpleProduct').val();
	var isProSku =  $(inputObj).closest("li").find('.skuItemID').val();
    // Check gift card order exists if not then check is location confirmed if not show location conformation popup
    // orelse show the quick add popup
    $("#quickaddasap-continue,#timeConflictOk").attr("data-element", $(this).attr("id"));
    if (isGiftCardOrderExists()) {
        checkGiftCardOrder();
        $('#favoriteitem_loader-' + prodID).hide();
    } else if (isToGoLocationConfirmed != undefined && isToGoLocationConfirmed === 'false') {
        if ((sessionOrderType != undefined && sessionOrderType == "catering-delivery-order") || orderTypeValue === "2") {
            window.location = $('#pickup-to-deliverycontinue').attr("data-link");
        } else {
            loadLocationConfirmationPopup();
            $("#isToGoLocationConfirmed").val('true');
            $("#confirm-location-btn").attr("data-element", $(this).attr("id"));
        }
    } else {
        // Service call to show the qiuck add popup
        var orderType = $('#orderTypeValue').val();
        var restaurantId = $('#selected-Resid').val();
        var pickupDate = $('#default_jsondate').val();
        var reqBody1 = {
            "restaurantId": restaurantId,
            "pickupdate": pickupDate,
            "orderType": orderType
        };
        if(isSimpleProduct && isSimpleProduct === 'true'){  
                $('#favoriteitem_loader-' + prodID).remove();
                $('#cross-sell-modal-popup').hide();               
                if ($('.modal-backdrop').hasClass('in')) {
                    $('.modal-backdrop').hide();
                }          
                // If subcategory options are not available, item is directly added to cart
                if (isWrongPortionSelected(true)) return false;
                var data = {}
                data['productID'] = prodID;
                data['catalogRefIds'] = isProSku;
                data['Quantity'] = 1;
                data['ConfigQuantity'] = 1;
                data['fromPage'] = location.pathname;
                addSiteCodes(data);
                var addItemUrl = "/web-api/order/add";
                // Service call to add the item to cart
                $.ajax({
                    type: 'POST',
                    url: addItemUrl,
                    async: false,
                    cache: false,
                    data: JSON.stringify(data),
                    success: function(response) {
                        if (response && response.successResponse && response.successResponse.order && response.successResponse.order.orderType) {
                            reqBody1['orderType'] = response.successResponse.order.orderType;
                        }
                        if (response.hasOwnProperty('successResponse')) {
                            // data layer update
                            var digitalDataRes = response && response.successResponse && response.successResponse.dataLayerJSON;
                            if (digitalDataRes) {
                                window.digitalData = JSON.parse(digitalDataRes);
                                if (window.digitalData && window.digitalData.event && window.digitalData.event.length > 0) {
                                    $(window.digitalData.event).each(function(index, item) {

                                        var productDet = {};
                                        productDet = item.product;
                                        if (productDet) {
                                            var modalData = {
                                                "eventName": "add-to-cart",
                                                "eventStatus": "success",
                                                "product": [productDet]
                                            }
                                            dtmModelEvents("CartEvent", modalData);
                                        }
                                    });
                                }
                            }
                            sessionStorage.setItem('CartItems', JSON.stringify(response));
                            notifyCartItems(response);
                            getOrderDetails(response);
                            if (response.successResponse.leadTime != undefined) {
                                var response = response.successResponse;
                                asapLoadTimeCalc(response, reqBody1, true);
                            }
                            if ($("#confirm-location-btn").attr('data-refresh')) {
                                var changedResId = $('#selected-Resid').val();
                                var currentResId = getCookie('DRIREST', 0);
                                if (currentResId != changedResId) {
                                    location.reload();
                                }
                                $("#confirm-location-btn").removeAttr('data-refresh');
                            }
                            if(!$('.rest-pickupdate-drop').is(":visible")) {
                                $('.rest-pickupdate-drop').show();
                                $('#pickup-asapdate').show();
                            }
                        } else if (response.hasOwnProperty('errorResponse')) {
                            var expResponse = response && response.errorResponse && response.errorResponse.fault && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;
                            var formExceptions = response && response.errorResponse && response && response.errorResponse.formExceptions;
                            var faultDes = response && response.errorResponse && response.errorResponse.fault && response.errorResponse.fault[0].faultDescription
                            var frmDes = formExceptions && formExceptions.localizedMessage;
                            if (expResponse == 'sessionExpired') {
                                $("#sessionExpired").modal('show');
                            } else if (response.errorResponse.fault && response.errorResponse.fault[0].faultCode === 'cart_TimeConflicts') {
                                $('#timeConflictMessage').html(response.errorResponse.fault[0].faultDescription);
                                $('#timeConflict').modal('show');
                                $("#timeConflictOk").attr("data-element", currentLinkId);
                                var reqBody = {
                                    "orderType": orderTypeValue
                                };
                                var updatedTime;
                                var availableSlots = "";
                                var maxTime = sessionStorage.getItem('dinnerEndTime');
                                //var maxTime = "10:00 PM";
                                addRestaurantDate(reqBody, $("#pdRestId").val(), $('#default_jsondate').val());
                                getCapacityTimeslots(reqBody).done(function(responseCapacity) {
                                    if (responseCapacity && responseCapacity.successResponse && responseCapacity.successResponse.capacitySlots) {
                                        availableSlots = responseCapacity.successResponse.capacitySlots.availableSlots;
                                        if (availableSlots && availableSlots.length > 0) {
                                            var timeInterval = sessionStorage.getItem('timeInterval');
                                            var currentTime = sessionStorage.getItem('currentTime');
                                            if (currentTime)
                                                currentTime = Number(currentTime);
                                            updatedTime = findUpdatedTimeSlot($('#tcToTime').html().trim(), availableSlots, maxTime, timeInterval, currentTime);
                                            $('#tcToTime').html(updatedTime);
                                        }
                                    }
                                });
                            } else if (response.errorResponse.fault && response.errorResponse.fault[0].faultCode === 'itemMenuPeriodSwitch') {
                                $('#item-list-modal').modal('toggle');
                                menuPeriodSwitch();
                            } else if (response.errorResponse.fault && (response.errorResponse.fault[0].faultCode === 'cart_AmtThreshold' ||
                                    response.errorResponse.fault[0].faultCode === 'subtext-choose-items-cart-qualify-exceeds')) {
                                orderExceedLimit();
                            } else if (response.errorResponse.fault && response.errorResponse.fault[0].faultCode === 'cart_qtyThreshold') {
                                quantityExceedsLimit();
                            } else if (response.errorResponse.fault && response.errorResponse.fault[0].faultCode === 'asap_not_available_add_item') {
                                $('#item-list-modal').modal('toggle');
                                asapInitialDatetime();
                                $('#asapNotAvailableAddItem').html(response.errorResponse.fault[0].faultDescription);
                                $('#quickaddasap-Errormodal').modal('show');
                            } else {
                                if (response.errorResponse.fault && response.errorResponse.fault[0].faultCode === 'itemNotAvailable') {
                                    appendLocal86edValues(prodID);
                                    process86edItemsData(generate86edResponseFromLocalValues(getLocal86edValues()));
                                }
                                if (frmDes) {
                                    faultDes = frmDes;
                                }
                                $('#simpleItemErrorMsg #errorMessage').html(faultDes);
                                $('#simpleItemErrorModel').modal('show');
                            }
                            sessionStorage.setItem('disableOrderSettings', "false");
                        }
                    },
                    error: function(xhr, text, err) {
                        console.log("error");
                    },
                    dataType: 'json',
                    contentType: 'application/json'
                });
        }else{
        var request = $.ajax({
            url: url,
            type: "get",
            cache: false,
            async: false
        });

        request.done(function(response, textStatus, jqXHR) {
            $('#favoriteitem_loader-' + prodID).remove();
            $('#cross-sell-modal-popup').hide();
            var fromEdit = sessionStorage.getItem('editedCartItemQuantity');
            if ($('.modal-backdrop').hasClass('in')) {
                $('.modal-backdrop').hide();
            }
            
            var template = Handlebars.compile(response);

            var menuItemAjax = $.ajax({
                url: "/web-api/menuitem/" + prodID,
                type: 'GET',
                data: "restaurantId=" + $("#pdRestId").val() + "&checkAvailability=false"
            });
            var sku86edAax = $.ajax({
                url: "/web-api/restaurant/86edSkus",
                type: 'GET',
                data: "restaurantId=" + $("#pdRestId").val()
            });
            $.when(menuItemAjax, sku86edAax).done(function (response1, response2) {
                var menuItemResponse = response1[0];
                var sku86edResponse = response2[0];
                decorateMenuItemSkuBeanWithStatus(menuItemResponse, sku86edResponse, null);
                sortMenuItemPropertyBeansByMandatoryOptions(menuItemResponse);
                $("#quickAddPopup").html(template(menuItemResponse));
            }).then(function() {

                // Data layer product details modal event START
                if ($("#dtmenabled").val() == "true" && $("#selectedSkuDiv") && $("#selectedSkuDiv").val()) {

                    var primaryCategory = "togo";
                    if ($("#orderTypeValue") && $("#orderTypeValue").val() === 2) {
                        primaryCategory = "delivery";
                    }
                    var subCategory1 = "";
                    if ($("#currentCategory")) {
                        subCategory1 = $("#currentCategory").val();
                    }
                    var subCategory2 = "";
                    if ($(".menuCat.active")) {
                        $(".menuCat.active").each(function() {
                            if ($(this).attr("href")) {
                                var subCatName = $(this).attr("href");
                                subCatName = subCatName.replace("/menu-listing/", "");
                                if (subCatName.length > 0) {
                                    subCatName = subCatName.charAt(0).toUpperCase() + subCatName.slice(1);
                                }
                                subCategory2 = subCategory2 + subCatName + "|";
                            }
                        })
                        subCategory2 = subCategory2 + "Menu";
                    }
                    var basePrice = "";
                    if ($(".prod-price") && $(".prod-price").text()) {
                        basePrice = $(".prod-price").text().trim();
                    }
                    var productId = "";
                    var skuId = "";
                    if ($("#menuItemID")) {
                        productId = $("#menuItemID").val();
                        if (productId) {
                            skuId = $("#selectedSkuDiv").val().replace(productId, "");
                        }
                    }
                    var productName = "";
                    if ($("#myModalLabel") && $("#myModalLabel").text()) {
                        productName = $("#myModalLabel").text().trim()
                    }
                    var modalData = {
                        "modalName": "togo quick add",
                        "modalIntent": "add togo item",
                        "modalContent": "product item details",
                        "product": [{
                            "category": {
                                "primaryCategory": primaryCategory,
                                "subCategory1": subCategory1,
                                "subCategory2": subCategory2
                            },
                            "price": {
                                "basePrice": basePrice,
                                "currency": "USD"
                            },
                            "productInfo": {
                                "productID": productId,
                                "productName": productName,
                                "sku": skuId
                            }
                        }]
                    };

                    dtmModelEvents("ProductDetailsModal", modalData);
                }
                // Data layer product details modal event END          

                $('.modal-body').find('input[type=radio]:checked').trigger('change');
                var isDisabled = $(response).hasClass('plpnoquick-view');
                if (!isDisabled) {
                    if (isLocationPopupOpened) {
                        loadQuickAddModal = true;
                    } else {
                        $('#item-list-modal').modal('show');
						$('textarea.spl-instructions').attr("maxlength",'50');
                        if (!fromEdit && $('#selectedSkuDiv').val() != '' && $('#selectedSkuDiv').val() != undefined) {
                            portionSizeTimeHandler();
                        }
                        portionSizeHandler('quickAddPopup');
                        handleAccordionSelection('quickAddPopup');
                        var addon = addOnPrice();
                        updatePopupPrice(addon);
                    }
                }
                // disable view more option from quick add pop up START
                if ($("div.view-more")) {
                    $("div.view-more").hide();
                }
                // disable view more option from quick add pop up END
                if ($("#popupAddToCart").length > 0) {
                    if ($("#quickAddPopup #selectedSkuDiv").val() == undefined || $("#quickAddPopup #selectedSkuDiv").val() == "") {
                        $("#popupAddToCart").attr("disabled", "disabled");
                    }
                    // If subcategory options are available, item is added only after clicking add to cart button.
                    $("#popupAddToCart").click(function(e) {
                        $('#item-list-modal .modal-dialog').prepend('<div class="togo-loader" id="AddToCartLoader" style="display: block;"></div>');
                        e.preventDefault();
                        if (isWrongPortionSelected(true)) return false;
                        $(this).attr("disabled", "disabled");
                        var isToGoLocationConfirmed = $("#isToGoLocationConfirmed").val();
                        $("#quickAddPopup #addToCartErrors").removeAttr("class");
                        var data = {}
                        data['restaurantId'] = $("#pdRestId").val();
                        data['productID'] = $("#quickAddPopup #menuItemID").val();

                        data['catalogRefIds'] = "sku" + $("#quickAddPopup #selectedSkuDiv").val().split("sku")[1];
                        var selectedIds = '';
                        $("#" + $("#quickAddPopup #selectedSkuDiv").val()).find("input[type='radio']:checked, input[type='checkbox']:checked").filter(function(index, item) {
                            return !$(item).closest('.subitem-holder').length
                        }).each(function() {
                            selectedIds += $(this).val() + ",";
                        });
                        data['selectedIds'] = selectedIds.substr(0, selectedIds.length - 1);
                        data['Quantity'] = 1;
                        data['fromPage'] = location.pathname;
                        data['ConfigQuantity'] = 1;
                        addSiteCodes(data);
                        var addItemUrl = "/web-api/order/add";
                        // Service call to add the item to cart
                        setTimeout(function() {
                            $.ajax({
                                type: 'POST',
                                url: addItemUrl,
                                async: false,
                                cache: false,
                                data: JSON.stringify(data),
                                success: function(response) {
                                    if (response && response.successResponse && response.successResponse.order && response.successResponse.order.orderType) {
                                        reqBody1['orderType'] = response.successResponse.order.orderType;
                                    }
                                    $('#favoriteitem_loader-' + prodID).remove();
                                    if (response.hasOwnProperty('successResponse')) {
                                        // data layer update
                                        if (response.successResponse.dataLayerJSON) {
                                            window.digitalData = JSON.parse(response.successResponse.dataLayerJSON);
                                            if (window.digitalData && window.digitalData.event && window.digitalData.event.length > 0) {
                                                $(window.digitalData.event).each(function(index, item) {
                                                    var productDet = {};
                                                    productDet = item.product;
                                                    if (productDet) {
                                                        var modalData = {
                                                            "eventName": "add-to-cart",
                                                            "eventStatus": "success",
                                                            "product": [productDet]
                                                        }
                                                        dtmModelEvents("CartEvent", modalData);
                                                    }
                                                });
                                            }
                                        }
                                        if (!$('#timeConflictOk').attr('data')) {
                                            $('#item-list-modal').modal('hide');
                                        }
                                        $('#timeConflictOk').removeAttr('data');
                                        sessionStorage.setItem('CartItems', JSON.stringify(response));
                                        notifyCartItems(response);
                                        if (response.successResponse.leadTime != undefined) {
                                            var response = response.successResponse;
                                            asapLoadTimeCalc(response, reqBody1, true);
                                        }
                                        if ($("#confirm-location-btn").attr('data-refresh')) {
                                            var changedResId = $('#selected-Resid').val();
                                            var currentResId = getCookie('DRIREST', 0);
                                            if (currentResId != changedResId) {
                                                location.reload();
                                            }
                                            $("#confirm-location-btn").removeAttr('data-refresh');
                                        }
                                        $('#AddToCartLoader').remove();
                                        if(!$('.rest-pickupdate-drop').is(":visible")) {
                                            $('.rest-pickupdate-drop').show();
                                        $('#pickup-asapdate').show();
                                        }
                                    } else if (response.hasOwnProperty('errorResponse')) {
                                        var expResponse = response && response.errorResponse && response.errorResponse.fault[0] && response.errorResponse.fault[0].faultCode;
                                        if (expResponse == 'sessionExpired') {
                                            $("#sessionExpired").modal('show');
                                        } else if (response.errorResponse.fault[0].faultCode === 'itemMenuPeriodSwitch') {
                                            $('#item-list-modal').modal('toggle');
                                            menuPeriodSwitch();
                                        } else if (response.errorResponse.fault[0].faultCode === 'cart_TimeConflicts') {
                                            $('#item-list-modal').modal('toggle');
                                            $('#timeConflictMessage').html(response.errorResponse.fault[0].faultDescription);
                                            $('#timeConflict').modal('show');
                                            $("#timeConflictOk").attr("data-element", currentLinkId);
                                        } else if (response.errorResponse.fault[0].faultCode === 'cart_AmtThreshold' ||
                                            response.errorResponse.fault[0].faultCode === 'subtext-choose-items-cart-qualify-exceeds') {
                                            $('#item-list-modal').modal('toggle');
                                            orderExceedLimit();
                                        } else if (response.errorResponse.fault[0].faultCode === 'cart_qtyThreshold') {
                                            $('#item-list-modal').modal('toggle');
                                            quantityExceedsLimit();
                                        } else if (response.errorResponse.fault[0].faultCode === 'asap_not_available_add_item') {
                                            $('#item-list-modal').modal('toggle');
                                            asapInitialDatetime();
                                            $('#asapNotAvailableAddItem').html(response.errorResponse.fault[0].faultDescription);
                                            $('#quickaddasap-Errormodal').modal('show');
                                        } else {
                                            if (response.errorResponse.fault && response.errorResponse.fault[0].faultCode === 'itemNotAvailable') {
                                                appendLocal86edValues($("#quickAddPopup #menuItemID").val());
                                                process86edItemsData(generate86edResponseFromLocalValues(getLocal86edValues()));
                                            }
                                            $("#quickAddPopup #addToCartErrors").html('');
                                            $.each(response.errorResponse.fault, function(index, exception) {
                                                $("#quickAddPopup #addToCartErrors").append(exception.faultDescription);
                                                if (response.errorResponse.fault.length > 0) {
                                                    $("#quickAddPopup #addToCartErrors").append('<br/>');
                                                }
                                            });
                                            $("#quickAddPopup #addToCartErrors").addClass("alert alert-danger");
                                        }
                                        $('#AddToCartLoader').remove();
                                        sessionStorage.setItem('disableOrderSettings', "false");
                                    }
                                    $("#popupAddToCart").removeAttr("disabled");
                                    sessionStorage.removeItem('listView');
                                },
                                error: function(xhr, text, err) {
                                    console.log("error");
                                },
                                dataType: 'json',
                                contentType: 'application/json'
                            });
                        }, 500);
                    });           
                }
            });
        });
    }
            // DTM confirm modal event START
            if ($("#dtmenabled").val() == "true" && window.sessionStorage &&
                sessionStorage.getItem("dtmTimeCnfrmModel") === "true") {
                var selectedASAP = "notDefine";
                var pickupTime = "notDefine";
                var pickupDate = "notDefine";

                if (sessionStorage.getItem("selectedASAP") && sessionStorage.getItem("selectedASAP") === "true") {
                    selectedASAP = true;
                } else {
                    selectedASAP = false;
                }
                if (sessionStorage.getItem("pickupDate")) {
                    pickupDate = sessionStorage.getItem("pickupDate");
                    pickupDate = pickupDate.replace(/\"/g, "");
                    pickupDate = pickupDate.replace(/%22/g, "");
                }
                if (sessionStorage.getItem("pickupTime")) {
                    pickupTime = sessionStorage.getItem("pickupTime");
                    pickupTime = pickupTime.replace(/\"/g, "");
                    pickupTime = pickupTime.replace(/%22/g, "");
                    pickupTime = pickupTime.replace(/%20/g, " ");
                }

                var modalData = {
                    "selectedASAP": selectedASAP,
                    "puTime": pickupTime,
                    "puDate": pickupDate
                };
                dtmModelEvents("ConfirmModal", modalData);
                sessionStorage.removeItem("dtmTimeCnfrmModel");
                sessionStorage.removeItem("selectedASAP");
            }
            // DTM confirm modal event END	        
    }
    $("body").removeAttr("style");
});

/*Aspa Quick add function*/
function asapInitialDatetime() {
    $('#removeItemAsap').prop('checked', true);
    $('#asapSpecificDateTime').hide();
    var today_MMMDD = moment().format('MMM DD');
    $('#asapCurrentDate').html(today_MMMDD);
    var restaurantId = $('#selected-Resid').val()
    var asapTodayDate = moment(new Date()).add(1, 'days').format("MM/DD/YYYY");
    var disabledDates = sessionStorage.getItem('disabledDates');
    if (disabledDates) {
        var closedDays = disabledDates.split(',');
        while (closedDays.indexOf(asapTodayDate) != -1) {
            var newDate = moment(asapTodayDate, "MM/DD/YYYY").add('days', 1);
            asapTodayDate = newDate.format('MM/DD/YYYY')
        }
    }
    var asapTodayTimeDate = moment().format("MM/DD/YYYY");
    var reqPickupBody = {
        'restaurantId': restaurantId,
        'pickupDate': asapTodayDate,
        'orderType': $('#orderTypeValue').val()
    };

    getPickupTimeApi(reqPickupBody).done(function(response) {
        asapUpdateTimeslots(response, 'asap-timelist');
    });
    var reqBody = {
        'orderType': $('#orderTypeValue').val(),
        'nextAvailableSlot': 'true'
    };
    var asapmindate = true;
    datePicker('asap-datetimepicker', [], asapDateTimeChangeHandler, asapTodayDate, asapmindate, reqBody);
}

function asapDateTimeChangeHandler(val) {
    var restaurantId = $('#selected-Resid').val();
    var asapcurrentdate = moment(val.date._d).format('MM/DD/YYYY');
    var reqBody = {
        'asapSelected': false,
        'restaurantId': restaurantId,
        'pickupDate': asapcurrentdate,
        'orderType': $('#orderTypeValue').val()
    };

    getPickupTimeApi(reqBody).done(function(response) {
        asapUpdateTimeslots(response, 'asap-timelist');
    });
}

function asapSetPickupTimeSuccess(response) {
    if ($("#quickaddasap-continue").attr("data-element") != undefined && $("#quickaddasap-continue").attr("data-element").length > 0) {
        $('#timeConflictOk').removeAttr('data-element');
        $('#timeConflictOk').removeAttr('data');
        $("#" + $("#quickaddasap-continue").attr("data-element")).trigger("click");
    } else {
        $("#addToCart").trigger("click");
    }
    $('#quickaddasap-Errormodal').modal('hide');
    $('.modal').on("hidden.bs.modal", function(e) { //fire on closing modal box
        if ($('.modal:visible').length) { // check whether parent modal is opend after child modal close
            $('body').addClass('modal-open'); // if open mean length is 1 then add a bootstrap css class to body of the page
        }
    });
    getOrderSettingApi(null, init);
}

function asapSetPickupTimeError(response) {
    console.log("response==>", response);
}

/*Aspa Quick add function end*/