'use strict';
var autocomplete = {},
    map, infowindow, formattedAddress;
var today = moment();
var markerArr = [];
var milesText, comingSoonText, selectText;
var locMatchSearch = $('#locMatchSearch').val();
var franchiselocText = "PLEASE CALL TO PLACE A TO GO ORDER";
var orderTypeValue = $('#orderTypeValue').val();
// TODO: Comment the below code as map initialisation is done in togo-webapi-location.js . Do it after confirming.

/** @description Function to initialize the map
 */
function initMap() {
    initAutocomplete('restaurant-location-autocomplete', 'restaurant');
    initAutocomplete('ordertype-autocomplete', 'orderType');
}

/** @description autocomplete callback function
 * 
 */

/*WO377557*/
function initAutocomplete(id, key) {
    autocomplete[key] = new google.maps.places.Autocomplete(
        (document.getElementById(id)), {
            types: ['geocode'],
            fields: ["name", "address_component", "formatted_address", "geometry.location"]
        });
    autocomplete[key].setComponentRestrictions({
        'country': ['us', 'ca']
    });
    google.maps.event.addListener(autocomplete[key], 'place_changed', function() {
        locationFillAddress(id, autocomplete[key]);
    });
}

/** @description callback function for change the location in autocomplete dropdown
 * 
 */
function locationFillAddress(id, autocomplete) {
    var place = autocomplete.getPlace();
    var latLongEleId = getLatLongEleId(id);
    if (place && place.geometry) {
        formattedAddress = place.formatted_address;
        var lat = place.geometry.location.lat();
        var lng = place.geometry.location.lng();
        $('#' + latLongEleId).val(lat + ',' + lng);
        locationRestaurantcheckResults(id, autocomplete); //to do location search on selecting value from suggestions
    }
}

/**
 * Function to check the input given in location search box is valid or not.
 * And display corresponding messages to user.
 */
function orderSettingsEnterResults() {
    var searchText;
    searchText = $("#ordertype-autocomplete").val();
    if (searchText != '' || searchText == $("#ordertype-autocomplete").val()) {
        getGeoCode(searchText, function(latLong) {
            if ('NO_LAT_LONG' != latLong) {
                $('#ordertype-latLong').val(latLong);
                //call to populate results and map on location search page
                getSearchResults('ordertype-autocomplete');
            } else {
                var errorMessage = $('#ordertype-autocompleteValidation').text().split("'")[0];
                errorMessage = errorMessage.substr(0, 19);
                $('#ordertype-autocompleteValidation').show();
                $('#ordertype-autocompleteValidation').text(locMatchSearch);
            }
        });
    }
}

/**
 * Function to check the input given in location search box is valid or not.
 * And display corresponding messages to user.
 */
function confirmLocationEnterResults() {
    var searchText;
    searchText = $("#restaurant-location-autocomplete").val();
    if (searchText != '' || searchText == $("#ordertype-autocomplete").val()) {
        getGeoCode(searchText, function(latLong) {
            if ('NO_LAT_LONG' != latLong) {
                $('#location-latLong').val(latLong);
                //call to populate results and map on location search page
                getSearchResults('restaurant-location-autocomplete');
            } else {
                var errorMessage = $('#autocompleteValidation').text().split("'")[0];
                errorMessage = errorMessage.substr(0, 16);
                $('#autocompleteValidation').show();
                $('#autocompleteValidation').text(locMatchSearch);
            }
        });
    }
}

/** @description Function to check the location results based on lat and long
 */
$(document).on('triggerReadyFunction', function(event) {
    var locNoResults = $('#locNoResults').val();
    $('#autocompleteValidation,#ordertype-autocompleteValidation').hide();
    $('#restaurant-location-autocomplete').keydown(function(e) {
        if (e.keyCode == 13) {
            e.preventDefault();
            if ($.trim($('#restaurant-location-autocomplete').val()) == '' || $.trim($('#restaurant-location-autocomplete').val()) == undefined || $.trim($('#restaurant-location-autocomplete').val()) == null) {
                $('#autocompleteValidation').html(locNoResults);
                $('#autocompleteValidation').show();
            } else {
                $('#autocompleteValidation').hide();
            }
        }
    });
    $('#ordertype-autocomplete').keydown(function(e) {
        if (e.keyCode == 13) {
            e.preventDefault();
            if ($.trim($('#ordertype-autocomplete').val()) == '' || $.trim($('#ordertype-autocomplete').val()) == undefined || $.trim($('#ordertype-autocomplete').val()) == null) {
                $('#ordertype-autocompleteValidation').html(locNoResults);
                $('#ordertype-autocompleteValidation').show();
            } else {
                $('#ordertype-autocompleteValidation').hide();
                orderSettingsEnterResults();
            }
        }
    });

    $('#ordertype-orderingform .search-btn').on('click', function() {
        orderSettingsEnterResults();
    });

    $('#ordertype-orderingform > a').on('click', function() {
        $('#ordertype-autocompleteValidation').hide();
        $('#ordertype-autocomplete').val('');
        var listResultCount = $("ul#item-list-loc-results li").length;
        var latLong = getCookie("DRIREST", 2);
        $('#ordertype-latLong').val(latLong);
        getSearchResults('ordertype-autocomplete');
    });
    $('#clearerrormsg').on('click', function() {
        $('#autocompleteValidation').hide();
        $('#restaurant-location-autocomplete').val('');
        var locatonListCount = $("ul#restaurant-list li").length;
        var latLong = getCookie("DRIREST", 2);
        $('#location-latLong').val(latLong);
        getSearchResults('restaurant-location-autocomplete');

    });
    $('.res-search .search-btn').on('click', function() {
        if ($.trim($('#ordertype-autocomplete').val()) == '' || $.trim($('#ordertype-autocomplete').val()) == undefined || $.trim($('#ordertype-autocomplete').val()) == null) {
            $('#ordertype-autocompleteValidation').html(locNoResults);
            $('#ordertype-autocompleteValidation').css('display', 'block');
        } else {
            $('#ordertype-autocompleteValidation').hide();
        }
    });
    $('.plp-search .search-btn').on('click', function() {
        if ($.trim($('#restaurant-location-autocomplete').val()) == '' || $.trim($('#restaurant-location-autocomplete').val()) == undefined || $.trim($('#restaurant-location-autocomplete').val()) == null) {
            $('#autocompleteValidation').html(locNoResults);
            $('#autocompleteValidation').show();
        } else {
            $('#autocompleteValidation').hide();
            confirmLocationEnterResults();
        }
    });

    $('#restaurant-location-autocomplete').keydown(function(e) {
        if (e.keyCode == 13) {
            if ($.trim($('#restaurant-location-autocomplete').val()) == '' || $.trim($('#restaurant-location-autocomplete').val()) == undefined || $.trim($('#restaurant-location-autocomplete').val()) == null) {
                $('#autocompleteValidation').html(locNoResults);
                $('#autocompleteValidation').show();
            } else {
                $('#autocompleteValidation').hide();
                confirmLocationEnterResults();
            }
        }
    });
});

function locationRestaurantcheckResults(id, autocomplete) {
    var searchText = $("#" + id).val();
    var latLongEleId = getLatLongEleId(id);
    if (!autocomplete.getPlace()) { //for zip code search
        getGeoCode(searchText, function(latLong) {
            if ('NO_LAT_LONG' !== latLong) {
                $('#' + latLongEleId).val(latLong);
                //call to populate results and map on location search page
                getSearchResults(id);
            }
        });
        return;
    }
    getSearchResults(id);
}

/** @description Function to create the markers in google map
 * @param {object} position
 * @param {object} locationDetails
 * @param {number} index
 */
function createMarker(position, locationDetails, index) {
    milesText = $('#milesText').val();
    var resName = locationDetails['restaurantName'] ? locationDetails['restaurantName'] : '';
    var mediaPath = $('#mediaRoot_site').val();
    var marker = new google.maps.Marker({
        map: map,
        icon: mediaPath + '/geo.png',
        position: position
    });
    markerArr.push(marker);
    if (index === 1) {
        map.setCenter(position);
    }
    google.maps.event.addListener(marker, 'click', function() {
        infowindow.setContent(resName + '<div class="map1" style="color: #1E1E1E; font-family:Lato; text-align: center;">' + Number(locationDetails.miles).toFixed(2) + '&nbsp;' + milesText + '</div>');
        infowindow.open(map, this);
        offsetCenter(position, -160, 50);
    });
}

/** @description calculate the center point of selected lat and lang
 * @param {string} latlng
 * @param {number} offsetx
 * @param {number} offsety
 */
function offsetCenter(latlng, offsetx, offsety) {
    var scale = Math.pow(2, map.getZoom());
    var worldCoordinateCenter = map.getProjection().fromLatLngToPoint(latlng);
    var pixelOffset = new google.maps.Point((offsetx / scale) || 0, (offsety / scale) || 0);
    var worldCoordinateNewCenter = new google.maps.Point(
        worldCoordinateCenter.x - pixelOffset.x,
        worldCoordinateCenter.y + pixelOffset.y
    );
    var newCenter = map.getProjection().fromPointToLatLng(worldCoordinateNewCenter);
    map.setCenter(newCenter);
}

/** @description Function to render the search results
 * @param {string} id
 */
function getSearchResults(id) {
    var locMatchSearch = $('#locMatchSearch').val();
    var resultCount;
    var loaderId = getLoaderId(id);
    var latLongEleId = getLatLongEleId(id);
    var latLong = $("#" + latLongEleId).val();
    $('#' + loaderId).show();
    var jlocation = null;
    if (sessionStorage.getItem('locationResults' + latLong)) {
        var jlocation1 = JSON.parse(sessionStorage.getItem('locationResults' + latLong));
        jlocation = jlocation1.successResponse.locationSearchResult.Location;
        var cnt = jlocation1.successResponse.locationSearchResult.resultsCount;
        mandatoryFieldCheck(jlocation);
        confirmLocationResults(id, jlocation, formattedAddress);
        $('#' + loaderId).hide();
        $('#ordertype-autocompleteValidation, #autocompleteValidation').hide();
        if (cnt === 0) {
            $('#ordertype-autocompleteValidation,#autocompleteValidation').show();
            $('#ordertype-autocompleteValidation,#autocompleteValidation').html(locMatchSearch);

        } else {
            $('#ordertype-autocompleteValidation,#autocompleteValidation').hide();
        }
    } else {
        for (var x = 0; x < sessionStorage.length; x++) {
            if (sessionStorage.key(x).indexOf('locationResults') != -1) {
                sessionStorage.removeItem(sessionStorage.key(x));
            }
        }
        getSearchResultsApi(latLong).done(function(response) {
            sessionStorage.setItem('locationResults' + latLong, JSON.stringify(response));
            jlocation = response.successResponse.locationSearchResult.Location;
            resultCount = response && response.successResponse && response.successResponse.locationSearchResult && response.successResponse.locationSearchResult.resultsCount;
            mandatoryFieldCheck(jlocation);
            confirmLocationResults(id, jlocation, formattedAddress);
            $('#' + loaderId).hide();
            $('#ordertype-autocompleteValidation,#autocompleteValidation').hide();
            if (resultCount === 0) {
                $('#ordertype-autocompleteValidation,#autocompleteValidation').html(locMatchSearch);
                $('#ordertype-autocompleteValidation,#autocompleteValidation').show();
            }
        });
    }
}

/** @description Function to get loader element id based on parent
 * @param {string} id
 */
function getLoaderId(id) {
    if (id === 'ordertype-autocomplete') {
        return 'ordertype-loader';
    }
    return 'location-loader';
}

/** @description Function to get lat lang element id based on parent
 * @param {string} id
 */
function getLatLongEleId(id) {
    if (id === 'ordertype-autocomplete') {
        return 'ordertype-latLong';
    }
    return 'location-latLong';
}

/** @description Function to get lat lang element id based on parent
 * @param {string} id
 */
function getLocationResultId(id) {
    if (id === 'restaurant-location-autocomplete') {
        return 'restaurant-list';
    }
    if (id === 'ordertype-autocomplete') {
        return 'item-list-loc-results';
    }
    return 'restaurant-list, #item-list-loc-results';
}

/** @description Function to render the restuarant informtion
 * @param {object} jlocation
 * @param {string} address
 */
function confirmLocationResults(id, jlocation, address) {
    milesText = $('#milesText').val();
    comingSoonText = $('#comingSoonText').val();
    selectText = $('#selectText').val();
    if (!$('#selected-Resid').val()) {
        var restaurantId = getCookie("DRIREST", 0);
        $('#selected-Resid').val(restaurantId);
    }
    var locationResultId = getLocationResultId(id);
    var locId = locationResultId.replace('#', '').split(', ');
    var prefixURL = '/locations/';
    if ($('#currentLocale').val() === 'es_US') {
        prefixURL = '/es/locations/';
    }
    for (var id = 0; id < locId.length; id++) {
        var htmlText = "";
        if (jlocation) {
            for (var i = 0; i < jlocation.length; i++) {
                var resName = jlocation[i]['restaurantName'] ? jlocation[i]['restaurantName'] : '';
                var generateLocDetailURL = function() {
                    if (jlocation[i].restaurantName != null && jlocation[i].restaurantName != undefined && jlocation[i].state != null && jlocation[i].state != undefined && jlocation[i].city != null && jlocation[i].city != undefined) {
                        var restaurantName = function() {
                            var restaurantNameChunks = resName.toLowerCase().split(' ');
                            restaurantNameChunks = restaurantNameChunks.filter(function(restName) {
                                if (restName !== '-') {
                                    return true;
                                }
                                return false;
                            });
                            return restaurantNameChunks.join('-');
                        }
                        var directionURL = prefixURL + jlocation[i].state.toLowerCase() + '/' + jlocation[i].city.toLowerCase() + '/' + restaurantName() + '/' + jlocation[i].restaurantNumber + '#DirectionContainer';
                        return directionURL;
                    }
                };

                if (jlocation[i]) {
                    var selectbtn = "";
                    if (locId[id] === 'restaurant-location-autocomplete' || locId[id] === 'restaurant-list') {

                        if (jlocation[i].isComingSoon && jlocation[i].isComingSoon === true) {
                            selectbtn = "<a title='" + comingSoonText + "' data-link-info='" + comingSoonText + "' class='select-rest'>" + comingSoonText + "</a>";
                            htmlText += "<li class='clearfix'><input type='hidden' class='selected-location-array' value='" + i + "' /><div class='res-address-left'><h4>" + resName + "</h4><p class='restaurant-address'>" + jlocation[i].AddressOne + "</p><p class='restaurant-city'>" + jlocation[i].city + ", " + jlocation[i].state + " " + formatZipCode(jlocation[i].zip, jlocation[i].country) + "</p><p class='restaurant-phone'>" + jlocation[i].phoneNumber + "</p></div><div class='res-address-right'><h5>" + Math.round(jlocation[i].miles) + '&nbsp;' + milesText + "</h5>" + selectbtn + "<input type='hidden' id='restaurantId_" + i + "' value='" + jlocation[i].restaurantId + "' /></div></li>";
                        } else if (jlocation[i].onlineTogo === true) {
                            selectbtn = "<a data-toggle='collapse' data-parent='#accordion-3' data-target='#modalacc-orlando' aria-expanded='true' title='" + selectText + "' data-link-info='" + selectText + "' class='select-rest' onclick='restaurantSelectHandler(event, " + JSON.stringify(jlocation[i]).replace(/'/g, "&apos") + ")'>" + selectText + "</a>";
                            htmlText += "<li class='clearfix'><input type='hidden' class='selected-location-array' value='" + i + "' /><div class='res-address-left'><h4>" + resName + "</h4><p class='restaurant-address'>" + jlocation[i].AddressOne + "</p><p class='restaurant-city'>" + jlocation[i].city + ", " + jlocation[i].state + " " + formatZipCode(jlocation[i].zip, jlocation[i].country) + "</p><p class='restaurant-phone'>" + jlocation[i].phoneNumber + "</p></div><div class='res-address-right'><h5>" + Math.round(jlocation[i].miles) + '&nbsp;' + milesText + "</h5>" + selectbtn + "<input type='hidden' id='restaurantId_" + i + "' value='" + jlocation[i].restaurantId + "' /></div></li>";
                        }
                    } else {
                        if (jlocation[i].isComingSoon && jlocation[i].isComingSoon === true) {
                            selectbtn = "<a title='" + comingSoonText + "' data-link-info='" + comingSoonText + "' class='select-rest'>" + comingSoonText + "</a>";
                            htmlText += "<li class='clearfix'><input type='hidden' class='selected-location-array' value='" + i + "' /><div class='res-address-left'><h4>" + resName + "</h4><p class='restaurant-address'>" + jlocation[i].AddressOne + "</p><p class='restaurant-city'>" + jlocation[i].city + ", " + jlocation[i].state + " " + formatZipCode(jlocation[i].zip, jlocation[i].country) + "</p><p class='restaurant-phone'>" + jlocation[i].phoneNumber + "</p></div><div class='res-address-right'><h5>" + Math.round(jlocation[i].miles) + '&nbsp;' + milesText + "</h5>" + selectbtn + "<input type='hidden' id='restaurantId_" + i + "' value='" + jlocation[i].restaurantId + "' /></div></li>";

                        } else if (jlocation[i].onlineTogo === true) {
                            selectbtn = "<a title='" + selectText + "' data-link-info='" + selectText + "' class='ordertype-selected-rest'>" + selectText + "</a>";
                            htmlText += "<li class='clearfix'><input type='hidden' class='selected-location-array' value='" + i + "' /><div class='res-address-left'><h4>" + resName + "</h4><p class='restaurant-address'>" + jlocation[i].AddressOne + "</p><p class='restaurant-city'>" + jlocation[i].city + ", " + jlocation[i].state + " " + formatZipCode(jlocation[i].zip, jlocation[i].country) + "</p><p class='restaurant-phone'>" + jlocation[i].phoneNumber + "</p></div><div class='res-address-right'><h5>" + Math.round(jlocation[i].miles) + '&nbsp;' + milesText + "</h5>" + selectbtn + "<input type='hidden' id='restaurantId_" + i + "' value='" + jlocation[i].restaurantId + "' /></div></li>";

                        }
                    }
                }
            }
        } else {
            var template = "<li class='clearfix'>" + $('#location_search_no_results').val() + "</li>";
            htmlText += template;
        }
        $('#' + locId[id]).html(htmlText);
        $('#' + locId[id]).show();
    }
};

/** @description callback function for select restaurant
 * @param {object} event
 * @param {object} location
 */
function restaurantSelectHandler(event, location) {
    var unavailableSlots;
    var asapEnabled = $('#asapEnabled').val();
    var isAsapId = $('input[name="location-pickupdate"]:checked').attr('id');
    var isAsapSelected = false;
    var isSwitchRestaurant = true;
    if (isAsapId == 'location-asap') {
        isAsapSelected = true;
    }
    var newDate = sessionStorage.getItem('newDate');
    var pickupDate;
    if (newDate) {
        sessionStorage.removeItem('newDate');
        pickupDate = newDate;
    } else {
        // On changing restaurant set initial date to current date instead of already selecteddate, 
        // so that the current day will be disabled if it is closed.
        pickupDate = moment().format("MM/DD/YYYY");
    }
    var reqCapacityBody = {
        "orderType": orderTypeValue,
        "restaurantId": location.restaurantId,
        "pickupdate": pickupDate,
        "asapSelected": isAsapSelected
    };
    var reqBody1 = {
        'orderType': orderTypeValue
    };
    getPickupTimeApi(reqCapacityBody).done(function(response) {
        var initialDate = pickupDate;
        var unavailableSlots = "";
        var availableSlots = "";
        var formattedClosedDates = formatClosedDates(response.restaurantHolidays);
        var restaurantClosed, lunch, dinner, interval, leadTime, asapCutOffTime, asapSelected;

        if (response) {
            restaurantClosed = response.restaurantClosed;
            lunch = response.times && response.times.lunch;
            dinner = response.times && response.times.dinner;
            interval = response.interval;
            leadTime = response.successResponse && response.successResponse.leadTime;
            asapCutOffTime = response.successResponse && response.successResponse.asapCutoffTime;
            asapSelected = response.successResponse && response.successResponse.asapSelected;
            setPickupInfoToSession(lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime);
        }

        if (restaurantClosed && restaurantClosed == 'true' || (lunch === false && dinner === false)) {
            do {
                var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
                initialDate = newDate.format('MM/DD/YYYY')
            } while (formattedClosedDates.indexOf(initialDate) != -1);
        } else {
            while (formattedClosedDates.indexOf(initialDate) != -1) {
                var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
                initialDate = newDate.format('MM/DD/YYYY')
            }
        }
        if (initialDate != pickupDate) {
            // updating this variable on restaurant change
            sessionStorage.setItem('restaurantTimeOver', 'true');
            sessionStorage.setItem('newDate', initialDate);
            sessionStorage.setItem('isTodayClosed', 'true');
            restaurantSelectHandler(event, location);
        } else {
            if (response && response.successResponse && response.successResponse.capacitySlots) {
                unavailableSlots = response.successResponse.capacitySlots.unavailableSlots;
                availableSlots = response.successResponse.capacitySlots.availableSlots;
            }
            sessionStorage.removeItem('restaurantTimeOver');
            updateTimeslots(response, unavailableSlots);
            setLocationDateTime(initialDate, response, availableSlots, unavailableSlots);
            datePickerToggle(initialDate);
            createDatePicker('datetimepicker-location', initialDate, location.closedDays, dateChangeHandler, reqBody1);
            var reqBody = {
                "validateCartItems": true,
                "restaurantId": location.restaurantId,
                "togoNewFlow": true,
                "asapSelected": isAsapSelected
            };
            var reqCapacityBody1 = {
                "orderType": orderTypeValue,
                "restaurantId": location.restaurantId,
                "pickupdate": initialDate,
                "asapSelected": isAsapSelected
            };
            updateRestaurantApi(reqBody, locationRestaurantErrorHandler, locationRestaurantErrorHandler, isSwitchRestaurant, response, reqCapacityBody1);
            restaurantSelectHandlerChild(event, location);
        }

        var selectTime = $('#select-locationtime-list').val();
        $('#locselected-time').html(selectTime);
    });
}

function restaurantSelectHandlerChild(event, location) {
    $('#selected_resname,#selected_address_city').empty();
    $('#selected_resname').append(location.restaurantName);
    $('#selected_address_city').append(location.AddressOne, ', ', location.city, ', ', location.state, ' ', formatZipCode(location.zip, location.country));
    if ($("#confirm-location-googleMap").length) {
        /*mapmarker*/
        map.setZoom(Number($('#googleMapZoom').val()));
        var geometryLocation = new google.maps.LatLng(parseFloat(location.latitude), parseFloat(location.longitude));
        clearPreviousMarkers();
        createMarker(geometryLocation, location, 1);
        /*mapmarker end*/
    }
    if ($("#google-staticmap-img-url").length || $("#google-staticmap-err-msg").length) {
        fetchStaticMap(location);
    }
    $('#selected_res_id').val(location.restaurantId);
    $('.suggestion-location-list li').removeClass('selected_item');
    $(event.target).closest('li').addClass('selected_item');
}

/** @description Function to locationRestaurantErrorHandler unavailable Item on location change 
 * @param {data} - response
 */
function locationRestaurantErrorHandler(response) {
    var asapError = response && response.fault && response.fault.faultCode;
    var asapErrorDes = response && response.fault && response.fault.faultDescription;
    var restaurantId = $('#selected-Resid').val();
    if (asapError == 'asap_not_available_pickup') {
        $('#errorMsg').html(asapErrorDes);
        $('#errorMsg').show();
        var reqBody = {
            "validateCartItems": true,
            "restaurantId": restaurantId,
            "togoNewFlow": true,
            "asapSelected": false
        };
        updateRestaurantApi(reqBody, locationRestaurantErrorHandler1, locationRestaurantErrorHandler1);
        $('#location-asapElement').hide();
        $("#location-specificdate").prop("checked", true).trigger("click");
    }
}

function locationRestaurantErrorHandler1(response) {
    console.log('Restaurant Updated');
}

function clearPreviousMarkers() {
    if (markerArr && markerArr.length) {
        for (var x = 0; x < markerArr.length; x++) {
            markerArr[x].setMap(null);
        }
        markerArr = [];
    }
}

/** @description Function to update restaurant information from cookie
 */
function updateRestaurantInfo() {
    $('#selected_address_city').empty();
    var restaurantInfo = getCookie("DRIREST");
    $('#selected_res_id').val(restaurantInfo.restaurantId);
    $('#selected_resname').text(restaurantInfo.restaurantName);
    $('#selected_address_city').append(restaurantInfo.addressCity);
}

/** @description Function to get the local storage value
 * @param {string} key
 */
function getLocalStorage(key) {
    var item = localStorage.getItem(key);
    return item || '';
}

/** @description Function to remove the local storage value
 * @param {string} key
 */
function removeLocalStorage(key) {
    localStorage.removeItem(key);
}

/** @description Function to remove the local storage value
 * @param {string} key
 */
function setLocalStorage(key, value) {
    localStorage.setItem(key, value);
}

/** @description Function to make the api call for restaurant details
 * @param {string} latLong
 */
function getSearchResultsApi(latLong) {
    var reqBody = {
        "geoCode": latLong,
        "resultsPerPage": "20",
        "resultsOffset": "0",
        "pdEnabled": "",
        "reservationEnabled": "",
        "isToGo": "",
        "privateDiningEnabled": "",
        "isNew": "",
        "displayDistance": "false"
    };
    addSiteCodes(reqBody);
    return $.ajax({
        url: '/web-api/restaurants',
        data: reqBody,
        type: "post",
        async: true
    });
}

function mandatoryFieldCheck(result) {
    if (result) {
        for (var i = 0; i < result.length; i++) {
            if (!result[i].hasOwnProperty('AddressOne')) result[i]['AddressOne'] = '';
            if (!result[i].hasOwnProperty('AddressTwo')) result[i]['AddressTwo'] = '';
            if (!result[i].hasOwnProperty('city')) result[i]['city'] = '';
            if (!result[i].hasOwnProperty('state')) result[i]['state'] = '';
            if (!result[i].hasOwnProperty('zip')) result[i]['zip'] = '';
            if (!result[i].hasOwnProperty('phoneNumber')) result[i]['phoneNumber'] = '';
            if (!result[i].hasOwnProperty('miles')) result[i]['miles'] = '';
            if (!result[i].hasOwnProperty('restaurantId')) result[i]['restaurantId'] = '';
            if (!result[i].hasOwnProperty('restaurantNumber')) result[i]['restaurantNumber'] = '';
        }
    }
}