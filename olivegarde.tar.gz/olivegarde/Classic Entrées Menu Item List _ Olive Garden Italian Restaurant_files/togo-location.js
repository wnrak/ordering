var locationCookie = $.cookie("DRIREST");
var locationDetectedAlreadyCookie = $.cookie("DRILOCATIONDETECTEDCOOKIE");
var latlong=$("#autoDetectedLatLong").val();
var markerGlobalCallback;
$(window).on('load',function () {
	welcome();
	//geo location
	getLocation();
	function welcome() {
		// restID##restaurantName##latLong##address1##city##state##zipCode##phoneNumber##operationalHrs##onlineTogo##isNearest
		
		var locationCookie = $.cookie("DRIREST");
		if (locationCookie) {
			locationCookie = locationCookie.replace(/\*/g, ',');
			var locValues = locationCookie.split("@@");
			$('#selected-location').hide();
			$('#findRestaurantLink').show();
			if (locValues.length > 0) {

				if ($('#locationURL').val() == "") {
					$('#locationURL').val("/locations");
				}

				// /state/city/restname/restNum
				var locURL = $('#locationURL').val() + "/" + locValues[5] + "/" + locValues[4] + "/" + locValues[1] + "/" + locValues[11];
				locURL = locURL.replace(/[^a-zA-Z0-9/]/g, '-');
				locURL = locURL.toLowerCase();
				/*Changes made for Multiple Hyphens Issue -Sai Priyanka */
				locURL = locURL.replace(/-{2,}/g, '-');

				// add links to location details
				$('#popRestNameLink').attr("href", locURL);
				$('#popRestHrsLink').attr("href", locURL);
				$('#popDirIconLink').attr("href", locURL);
				$('#popDirLink').attr("href", locURL);
				$('#popMapLink').attr("href", locURL);

				// set Rest_ID from cookie for SMS and Email
				$('#sms-current').attr("data-id", locValues[0]);
				$('#email-current').attr("data-id", locValues[0]);


				var mapImg = "//media.olivegarden.com/en_us/images/marketing/italian-family-restaurant-olive-garden-g6-r1x1.jpg";

				$("#mapImg").attr("src", mapImg);

				$('#latLong_header').val(locValues[2]);
				// rest name
				$('#headRestName').text(locValues[1]);
				$('#popRestName').text(locValues[1]);
				$('#overlayRestName').text(locValues[1]);
				$('#headRestName').text(locValues[1]);
				// rest phone number
				$('#headRestPhone').text(locValues[7]);
				$('#popRestPhone').text(locValues[7]);
				// rest address
				$('#popRestAdd1').text(locValues[3]);
				$('#popRestCity').text(locValues[4]);
				$('#popRestState').text(locValues[5]);
				$('#popRestZip').text(locValues[6]);
				// rest Op hours
				$('#popRestHrs').html(locValues[8]);
				//webahead change start
				if (locValues.length > 16) {
					var lowEstimatedWaitTime = locValues[14];
					var highEstimatedWaitTime = locValues[15];

					var exactEstimatedWaitTime = locValues[16];

					if(exactEstimatedWaitTime == "~")
		            		exactEstimatedWaitTime=exactEstimatedWaitTime.replace("~","") ;
		            if(lowEstimatedWaitTime == "~")
		            		lowEstimatedWaitTime=lowEstimatedWaitTime.replace("~","") ;
		            if(highEstimatedWaitTime == "~")
		            		highEstimatedWaitTime=highEstimatedWaitTime.replace("~","") ;


					if ("false" == locValues[12]) {
						if (exactEstimatedWaitTime != "" && lowEstimatedWaitTime != "" && highEstimatedWaitTime != "") {
							var waitingListMin = $('#waitingListMin').val();
							if ($('#enterWaitListOnLoad').text() == "")
								$('#enterWaitListOnLoad').text("JOIN WAITLIST");

							$('#enterWaitListOnLoad').attr("data-url", "/locations/webahead/join-wait-list?restID=" + locValues[0]);
							estimatedWaitTimePrefixStr = "Current Wait: ";
							estimatedWaitTimeStr = "";

							if ("false" == locValues[13]) {
								estimatedWaitTimeStr = estimatedWaitTimePrefixStr + exactEstimatedWaitTime + " "+waitingListMin;

								if ($('#estimatedWaitTimeLabelOnLoad').text() == "")
									$('#estimatedWaitTimeLabelOnLoad').text(estimatedWaitTimeStr);
							}
							else {

								estimatedWaitTimeStr = estimatedWaitTimePrefixStr + lowEstimatedWaitTime + "-" + highEstimatedWaitTime + waitingListMin;
								$('estimatedWaitTimeLabelOnLoad').text(estimatedWaitTimeStr);
							}

							$("#joinWaitListButtonOnLoad").attr("style", "visibility: visible");

						}
						else {
							$("#joinWaitListButtonOnLoad").width(0);

						}
					}
				}
				if (locValues.length > 12) {
					if ("true" == locValues[12]) {

						$("#waitlistlabelspanonLoad").attr("style", "visibility: visible");

						if ($('#waitlistLabel').text() == "")
							$('#waitlistLabel').text("ON WAITLIST");
					}
					else {
						$('#waitlistLabel').width(0);
					}
				}
				//webahead change end
				$('#findRestaurantLink').hide();
				$('#selected-location').show();
				var welcomeConfigValue = $('#welcomeConfigValue').val();
				var pageURL = window.location + "";
				if ((pageURL.indexOf('/home') > -1 || pageURL.indexOf('/pagina-de-inicio') > -1) && locValues[10] == 'auto') {
					$("#pop-up").show();
					setTimeout('$("#pop-up").hide()', parseInt(welcomeConfigValue));
					var oldCookieVal = $.cookie("DRIREST");
					oldCookieVal = oldCookieVal.replace(/(auto)/g, '~');
					$.cookie("DRIREST", oldCookieVal, { expires: 365, path: "/" });
				}

				//var restId=locValues[0];	
				//showCateringInHeader(restId);
				//showJoinWaitListDetails();


			}
		}
	}
})

$(window).on('load', function () {

	// Change for Enhancement : Location update from sitemap - starts here [xsdamm1]
	var isLocationDetailsPage = $('#isLocationDetails').val();
	if ($("#locationWaitlistDetails").length > 0) {
		//loadMaps();
	}
	if (!(isLocationDetailsPage != undefined && isLocationDetailsPage != null && isLocationDetailsPage == 'true')) {
		if ($("#locationWaitlistDetails").length <= 0) {
			//loadMaps();
		}

		var url = $("#popRestNameLink").attr('href');
		if (url == '#') {
			var locationCookie = $.cookie("DRIREST");
			if (locationCookie) {
				locationCookie = locationCookie.replace(/\*/g, ',');
				var locValues = locationCookie.split("@@");
				if (locValues.length > 0) {
					// /state/city/restname/restnum
					var locURL = $('#locationURL').val() + "/" + locValues[5] + "/" + locValues[4] + "/" + locValues[1] + "/" + locValues[11];
					locURL = locURL.replace(/[^a-zA-Z0-9/]/g, '-');
					locURL = locURL.toLowerCase();
					/*Changes made for Multiple Hyphens Issue -Sai Priyanka */
					locURL = locURL.replace(/-{2,}/g, '-');

					// add links to location details
					$('#popRestNameLink').attr("href", locURL);
					$('#popRestHrsLink').attr("href", locURL);
					$('#popDirIconLink').attr("href", locURL);
					$('#popDirLink').attr("href", locURL);
					$('#popMapLink').attr("href", locURL);

					// set Rest_ID from cookie for SMS and Email
					$('#sms-current').attr("data-id", locValues[0]);
					$('#email-current').attr("data-id", locValues[0]);

					// lat_long
					var mapImg = "//media.olivegarden.com/en_us/images/marketing/italian-family-restaurant-olive-garden-g6-r1x1.jpg";
					$("#mapImg").attr("src", mapImg);

					$('#latLong_header').val(locValues[2]);
					// rest name
					$('#headRestName').text(locValues[1]);
					$('#popRestName').text(locValues[1]);
					$('#overlayRestName').text(locValues[1]);
					$('#headRestName').text(locValues[1]);
					// rest phone number
					$('#headRestPhone').text(locValues[7]);
					$('#popRestPhone').text(locValues[7]);
					// rest address
					$('#popRestAdd1').text(locValues[3]);
					$('#popRestCity').text(locValues[4]);
					$('#popRestState').text(locValues[5]);
					$('#popRestZip').text(locValues[6]);
					// rest Op hours
					$('#popRestHrs').html(locValues[8]);
					// link to nutrition page
					// $('#popNutritionIconLink').attr("href", "/nutrition");
					// $('#popNutritionLink').attr("href", "/nutrition");
					$('#findRestaurantLink').hide();
					$('#selected-location').show();
					var welcomeConfigValue = $('#welcomeConfigValue').val();
					var pageURL = window.location + "";
					if ((pageURL.indexOf('/home') > -1 || pageURL.indexOf('/pagina-de-inicio') > -1) && locValues[10] == 'auto') {
						$("#pop-up").show();
						setTimeout('$("#pop-up").hide()', parseInt(welcomeConfigValue));
						var oldCookieVal = $.cookie("DRIREST");
						oldCookieVal = oldCookieVal.replace(/(auto)/g, '~');
						$.cookie("DRIREST", oldCookieVal, { expires: 365, path: "/" });
					}
					showJoinWaitListDetails();
				}
			}
		}
		// Change for Enhancement : Location update from sitemap - ends here [xsdamm1]
	}

	//changes done by smitha for webahead
	//duplicate method: merged in the bewlo funtion 
	

	//added by vara for webahead changes
	function showLocationWaitlistDetails() {
		var isLocDetails = $("#isLocationDetails").val();
		var dataPageURL = location.pathname;
		var splitUrl = dataPageURL.split("/");
		if ("es" == splitUrl[1])
			var url = "/es/customer-service/includes/location-webahead-info.jsp";
		else
			var url = "/customer-service/includes/location-webahead-info.jsp";
		var join_wait_list_details = '';
		var data = {};
		var restID = '';
		var locDetailsReqURI = '';
		var location_wait_list_details = '';

		if ($("#joinWaitListDetails").length > 0) {
			join_wait_list_details = $("#joinWaitListDetails");
			data.dataPageURL = dataPageURL;
		}

		if (isLocDetails == "true") {
			restID = $("#locationWaitlistDetails").attr('data-rest-id');
			locDetailsReqURI = $("#locationWaitlistDetails").attr('base-url');
			data.restID = restID;
			data.locDetailsReqURI = locDetailsReqURI;
			if ($("#locationWaitlistDetails").length <= 0) {
				loadMaps();
			}

		}
		if (window.location.protocol == "https:") {
			url = $("#ajaxServletURL").val();
			data.AJAX_FUNCTION = "locationWebaheadinfo";
		}
		$.ajaxSetup({
			cache: false
		});

		$.get(url, data, function (response) {
			if ($("#joinWaitListDetails").length > 0) {
				join_wait_list_details.html($(response).filter('#waitListInfo').html());
			}
			if ($("#locationWaitlistDetails").length > 0) {
				location_wait_list_details = $("#locationWaitlistDetails");
				location_wait_list_details.html($(response).filter('#location-webahead-info-reload').html());
				loadMaps();
			}

		});

	}


	$('#content_body').click(function () {
		$("#pop-up").hide();
	});
	$('.header').click(function (e) {
		if ($(e.target).closest('#pop-up').length == 1) {

		} else if ($(e.target).closest('#pop-up').length == 0) {
			$('#pop-up').hide();
		}
	});
	$('.footer').click(function () {
		$("#pop-up").hide();
	});

	/*Crime Index 33513 Fix
	$('.cd-display-rest-block .delivery-location-spinner').remove();*/

});


//locationDetection.js
$(document).on("click", "#find_near_me_button", function () {
	if (latlong == undefined && locationDetectedAlreadyCookie == "YES") {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(onSuccessGeoLocation, showError, {
				maximumAge: 60000
			});

		} else {
			//$.holdReady(false);
			// THE BROWSER DOES NOT SUPPORTS LOCATION DETECTION
			// MAKE THE AJAX CALL TO THE CURRENT R1 - AJAX CALL (Location detection
			// servlet)
			// Display the detected restaurant in the header
			//alert("Geolocation is not supported by this browser. Use latitude and Longitude from Akamai");


		}
	}
});
function onSuccessGeoLocation(position) {
	$.removeCookie('DRILOCATIONDETECTEDCOOKIE', { path: '/' });
	$.cookie("DRILOCATIONDETECTEDCOOKIE", "YES", { path: '/' });
	var latLong = position.coords.latitude + "," + position.coords.longitude;
	//var latLong = 29.47621000 + "," + -81.21322000;
	processGeoLocation(latLong);
	// window.location.reload(true);
}
function processGeoLocation(latLong) {
	var geocoder = null;
	var address = null;
	autoDetectLocation(latLong);
	$("#joinWaitListButtonOnLoad").hide();
	$("#waitlistlabelspanonLoad").hide();
	$.holdReady(false);

}
function autoDetectLocation(latLong) {
	var url = url;
	if (window.location.protocol == "https:") {
		url = "/DardenAjaxURLRedirectServlet";
	} else {
		//url = "/customer-service/includes/detectedMobileLocAjax.jsp"
		url = $("#locDetectionUrl").val();
	}



	if (locationCookie) {
		var locValues = locationCookie.split("##");
		if (locValues.length > 0) {

			var rest = locValues[0];
		}
	}

	var redirectUrl = $('#redirectMenuUrl').val();
	var isEmptyRedirectTomenu = true;
	if (($('#isEmptyRedirectTomenu').val() !== null) && ($('#isEmptyRedirectTomenu').val() !== '') && ($('#isEmptyRedirectTomenu').val() !== undefined) && ($('#isEmptyRedirectTomenu').val() == 'false')) {
		isEmptyRedirectTomenu = false;
	}


	var data = {
		AJAX_FUNCTION: "detectedMobileLocAjax",
		LAT_LONG: latLong,
		CURR_DEFAULT_REST: rest
	};
	// var data = { AJAX_FUNCTION : "detectedMobileLocAjax" , LAT_LONG :
	// "29.552549,-81.222639" , CURR_DEFAULT_REST : rest };


	request = $.ajax({
		url: url,
		type: "post",
		cache: false,
		data: data
	});

	request.done(function (response, textStatus, jqXHR) {

		var locationCookie = $.cookie("DRIREST");
		if (locationCookie) {
			if (redirectUrl && isEmptyRedirectTomenu) {
				location.href = redirectUrl;
			}
			else {
				locationCookie = locationCookie.replace(/\*/g, ',');
				var locValues = locationCookie.split("@@");
				if (locValues.length > 0) {
					// /state/city/restname/restnum
					var locURL = $('#locationURL').val() + "/" + locValues[5] + "/" + locValues[4] + "/" + locValues[1] + "/" + locValues[11];
					locURL = locURL.replace(/[^a-zA-Z0-9/]/g, '-');
					locURL = locURL.toLowerCase();
					/* Changes made for Multiple Hyphens Issue -Sai Priyanka */
					locURL = locURL.replace(/-{2,}/g, '-');

					// add links to location details
					$('#popRestNameLink').attr("href", locURL);
					$('#popRestHrsLink').attr("href", locURL);
					$('#popDirIconLink').attr("href", locURL);
					$('#popDirLink').attr("href", locURL);
					$('#popMapLink').attr("href", locURL);

					// set Rest_ID from cookie for SMS and Email
					$('#sms-current').attr("data-id", locValues[0]);
					$('#email-current').attr("data-id", locValues[0]);

					// lat_long
					var mapImg = "//media.olivegarden.com/en_us/images/marketing/italian-family-restaurant-olive-garden-g6-r1x1.jpg";
					$("#mapImg").attr("src", mapImg);

					$('#latLong_header').val(locValues[2]);
					// rest name
					$('#headRestName').text(locValues[1]);
					$('#popRestName').text(locValues[1]);
					$('#overlayRestName').text(locValues[1]);
					$('#headRestName').text(locValues[1]);
					// rest phone number
					$('#headRestPhone').text(locValues[7]);
					$('#popRestPhone').text(locValues[7]);
					// rest address
					$('#popRestAdd1').text(locValues[3]);
					$('#popRestCity').text(locValues[4]);
					$('#popRestState').text(locValues[5]);
					$('#popRestZip').text(locValues[6]);
					// rest Op hours
					$('#popRestHrs').html(locValues[8]);


					if (locValues.length > 16) {
						var lowEstimatedWaitTime = locValues[14];
						var highEstimatedWaitTime = locValues[15];

						var exactEstimatedWaitTime = locValues[16];

						if(exactEstimatedWaitTime == "~")
			            		exactEstimatedWaitTime=exactEstimatedWaitTime.replace("~","") ;
			            if(lowEstimatedWaitTime == "~")
			            		lowEstimatedWaitTime=lowEstimatedWaitTime.replace("~","") ;
			            if(highEstimatedWaitTime == "~")
			            		highEstimatedWaitTime=highEstimatedWaitTime.replace("~","") ;


						if ("false" == locValues[12]) {
							if (exactEstimatedWaitTime != "" && lowEstimatedWaitTime != "" && highEstimatedWaitTime != "") {
								if ($('#enterWaitListOnLoad').text() == "")
									$('#enterWaitListOnLoad').text("JOIN WAITLIST");

								$('#enterWaitListOnLoad').attr("data-url", "/locations/webahead/join-wait-list?restID=" + locValues[0]);
								estimatedWaitTimePrefixStr = "Current Wait: ";
								estimatedWaitTimeStr = "";

								if ("false" == locValues[13]) {
									estimatedWaitTimeStr = estimatedWaitTimePrefixStr + exactEstimatedWaitTime + " min";

									if ($('#estimatedWaitTimeLabelOnLoad').text() == "")
										$('#estimatedWaitTimeLabelOnLoad').text(estimatedWaitTimeStr);
								}
								else {

									estimatedWaitTimeStr = estimatedWaitTimePrefixStr + lowEstimatedWaitTime + " - " + highEstimatedWaitTime + "min";
									$('estimatedWaitTimeLabelOnLoad').text(estimatedWaitTimeStr);
								}

								$("#joinWaitListButtonOnLoad").attr("style", "display: inline-block");

							}
							else {
								$("#joinWaitListButtonOnLoad").width(0);

							}
						}
					}
					if (locValues.length > 12) {
						if ("true" == locValues[12]) {

							$("#waitlistlabelspanonLoad").attr("style", "display: inline-block");

							if ($('#waitlistLabel').text() == "")
								$('#waitlistLabel').text("ON WAITLIST");
						}
						else {
							$('#waitlistLabel').width(0);
						}
					}
					// link to nutrition page
					// $('#popNutritionIconLink').attr("href", "/nutrition");
					// $('#popNutritionLink').attr("href", "/nutrition");
					$('#findRestaurantLink').hide();
					$('#selected-location').show();
					var welcomeConfigValue = $('#welcomeConfigValue').val();
					var pageURL = window.location + "";
					if ((pageURL.indexOf('/home') > -1 || pageURL.indexOf('/pagina-de-inicio') > -1) && locValues[10] == 'auto') {
						$("#pop-up").show();
						setTimeout('$("#pop-up").hide()', parseInt(welcomeConfigValue));
						var oldCookieVal = $.cookie("DRIREST");
						oldCookieVal = oldCookieVal.replace(/(auto)/g, '~');
						$.cookie("DRIREST", oldCookieVal, { expires: 365, path: "/" });
					}
					$('#find-locn-nearme-hidden-header').show();
					showJoinWaitListDetails();
				}
				location.reload();
				//Invoking Targeters on location auto detection
				invokeTargeters();
				/*   // reload page on location detection
				   if (location.pathname
					   .indexOf("/location-search") != -1) {
					   location.reload();
				   } */
			}
		}
	});
}

function getLocationSuccess(position) {
   var locationCookie = $.cookie('DRIREST');
   var directionCookie = $.cookie('DRILOCATIONDETECTEDCOOKIE');
   if (!locationCookie && !directionCookie) {	     
		   var data = {
				   AJAX_FUNCTION: "detectedMobileLocAjax",
				   LAT_LONG: position.coords.latitude+","+position.coords.longitude,
				   CURR_DEFAULT_REST: ''
			   };
		   getLocationApi(data).done(function (response) {			    
				$.removeCookie('DRILOCATIONDETECTEDCOOKIE', { path: '/' });
				$.cookie("DRILOCATIONDETECTEDCOOKIE", "YES", { path: '/' });
				window.location.reload();
		   });		
   }
}

function getLocationApi(data){	
        return $.ajax({
               url: "/DardenAjaxURLRedirectServlet",
               type: "post",
               data: data
           });  
}
function getLocationError(position) {
   console.log('Error in location change');
}


function getLocation() {
	if (!locationDetectedAlreadyCookie && !locationCookie) {
	$.holdReady(false);
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(onSuccessGeoLocation, showError, {
			maximumAge: 60000
		});

   } else {
    	$.holdReady(false);
    	// THE BROWSER DOES NOT SUPPORTS LOCATION DETECTION
        // MAKE THE AJAX CALL TO THE CURRENT R1 - AJAX CALL (Location detection
        // servlet)
        // Display the detected restaurant in the header
        //alert("Geolocation is not supported by this browser. Use latitude and Longitude from Akamai");
	}
  } else if (locationDetectedAlreadyCookie && locationDetectedAlreadyCookie == "YES") {
        $("#joinWaitListButtonOnLoad").hide() ;
		$("#waitlistlabelspanonLoad").hide() ;
        $.holdReady(false);
	}else{
		//location tracking blocked case
		$.holdReady(false);
	}
  /* if (navigator.geolocation) {
       navigator.geolocation.getCurrentPosition(getLocationSuccess, getLocationError);
   }*/
}
function showError(error) {
	$.holdReady(false);
    // THE USER DENIED LOCATION DETECTION
    // MAKE THE AJAX CALL TO THE CURRENT R1 - AJAX CALL (Location detection
    // servlet)
    // Display the detected restaurant in the header
    // Sangeetha - If User denies accessing the current location, will it
    // still be ok to default select a rest based on akamai lat long?
    // Sangeetha - If we do so, should we not show the user some message?
    // Sangeetha - If no default rest found with akamai as well, should we
    // redirect to Screen 1.7? Should we show any message to the user?
    switch (error.code) {
        case error.PERMISSION_DENIED:
            $.cookie("DRILOCATIONDETECTEDCOOKIE","NO");
			processGeoLocation($("#autoDetectedLatLong").val());
        	//Commenting out this code so that location detection happens in secure pages
            //$.cookie("DRILOCATIONDETECTEDCOOKIE", "NO",{path:'/'});
            //alert("User denied the request for Geolocation. location detected");
            // using akamai");
            break;
        case error.POSITION_UNAVAILABLE:
            // alert("Location information is unavailable.");
            break;
        case error.TIMEOUT:
            // alert("The request to get user location timed out.");
            break;
        case error.UNKNOWN_ERROR:
            // alert("An unknown error occurred.");
            break;
    }
}
$(document).ready(function () {
	$('#checkout-time-confirm-btn').on('click', function (e) {
			e.preventDefault();
			$('#checkoutdetails-step2').removeClass('hidden');
			$('#checkout-confirm-btn-section').addClass('hidden');
		});
					
		$('#myRestaurantModal_overlayCloseButton').click(function(){
		     $('#myRestaurantModal').hide();
		     
		})
		// Location suggestion from header drop down START
		if($('#searchText_header').length){
			//loadGoogleApi('initAutoCompleteSearchHeader');
			$("#searchText_header").val($('#searchText_header').attr('placeholder'));
		}
		$("#searchText_header").focus(function() {
			$("#searchText_header").val('');
		});
		
		// Find restaurant on header.
	$( "#locSearchIcon_header").click(function() {
		//loadGoogleApi('getGeoCodeHeader');
    	initAutoCompleteSearchHeader();
    	setTimeout(function () {
          	if(sessionStorage){
    		sessionStorage.setItem("searchText_header",$('#searchText_header').val());
    	}
    	getGeoCodeHeader();
        }, 500);
    	return false;
	});

		$('#searchText_header').keydown(function(e){
		if(e.keyCode == 13){
		//loadGoogleApi('getGeoCodeHeader');
		//getGeoCodeHeader();
		e.preventDefault();
		}
		});
		
		//Changes for Pillar1 Enhancements
		$(document).on("click", "#find_near_me_button,#find_near_me_link", function() {
		searchNearByLatLong();
		return false;
		});
		$('span#find-locn-nearme-hidden-header').on('click', function (e) {
			document.getElementById("searchText_header").value='';
			searchNearByLatLongFromHeader();
			return false;
		});
		//Changes for Pillar1 Enhancements	
		$(document).on("click", "#find-locn-nearme-header,#find-locn-nearme-hidden-header", function() {
		document.getElementById("searchText_header").value='';
		searchNearByLatLongFromHeader();
		return false;
		});		
		// Location suggestion from header drop down END
	});


	function hideEmailBlock(response, form) {
		$('#error_message_email').text('');
		$("#locEmail").modal('hide');
	}
	
	/* 	Commom Js moved from togoNew.js
		*******************************                 */

// for Header dropdown
var placeSearch, autocomplete;
var componentForm = {
street_number : 'short_name',
route : 'long_name',
locality : 'long_name',
administrative_area_level_1 : 'short_name',
country : 'short_name',
postal_code : 'short_name',
postal_code_suffix : 'short_name'
};
function initAutoCompleteSearch(searchText) {
	// Create the autocomplete object, restricting the search to geographical
	 // location types.
	 autocomplete = new google.maps.places.Autocomplete(
	 /** @type {!HTMLInputElement} */
	 (document.getElementById('searchText')), {
	     types : [ '(cities)' ],
		 fields: ["name", "address_component", "formatted_address", "geometry.location"]
	 });
	 google.maps.event.addListener(autocomplete,'place_changed', fillAddress);

}
var headerFlag = false;
function getGeoCodeHeader(){
   locZipCode = $('#searchText_header').val();
   var prefixURL;
   if ($('#currentLocale').val() === 'es_US') {
		prefixURL = '/es';
	}
   if(autocomplete.getPlace() == undefined){ //for zip code search
	   getGeoCode(locZipCode, function(latLong){
			if('NO_LAT_LONG' != latLong) {
				$('#latLong_header').val(latLong);	
				sessionStorage.setItem('searchlatLong', latLong);
				var formUrl = $('#headerLocationForm').attr('action');
				$('#headerLocationForm').attr('action', formUrl+'?searchText='+locZipCode).submit();
				headerFlag = true	
			}
	   }); 
	 }else{	
		$('#headerLocationForm').submit();
	 }
}

function initAutoCompleteSearchHeader() {
	// Create the autocomplete object, restricting the search to geographical
	// location types.
	autocomplete = new google.maps.places.Autocomplete(
	(document.getElementById('searchText_header')), {
	 types : [ '(cities)' ],
	 fields: ["name", "address_component", "formatted_address", "geometry.location"]
	});
	google.maps.event.addListener(autocomplete,'place_changed', fillHeaderAddress);

	}
function loadGoogleApi(callbackFunc) {
	if(typeof(MarkerWithLabel) != 'function'){
		if(typeof(google) != 'object'){
		  var script = document.createElement('script');
		  script.type = 'text/javascript';
		  var googleApiJS = $('#googleApiJS').val();
		  //var googleApiJS = "https://maps.googleapis.com/maps/api/js?v=3&sensor=false&channel=OG&client=gme-dardenrestaurants&language=en";
		  /*if (window.location.protocol == "https:") {
			googleApiJS = "https://maps.googleapis.com/maps/api/js?v=3&sensor=false&channel=OG&client=gme-dardenrestaurants&language=en";
	  	  }*/
		  //script.src = googleApiJS + '&callback='+callbackFunc;
		  //script.src = googleApiJS + '&libraries=places'+ '&callback=loadMarkerApi';
		 // document.body.appendChild(script);
		  markerGlobalCallback = callbackFunc;
		}else{
			markerGlobalCallback = callbackFunc;
			loadMarkerApi();
		}
	}else{// if google API is already included, then directly call the
			// callbackFunc.
		// declare the function
		var fn = window[callbackFunc];
		// call the function directly.
		fn();
		markerGlobalCallback = '';
	}
}
function loadMarkerApi() {
	var scriptnew = document.createElement('script');
	var markerWithLabelJS = $('#googleMarkerWithLabelJS').val();
	//var markerWithLabelJS = "https://media.olivegarden.com/stage/stage1/js/4.4.1.rev3/markerwithlabelv1.js";
	/*if (window.location.protocol == "https:") {
			markerWithLabelJS = "https://media.olivegarden.com/stage/stage1/js/4.4.1.rev3/markerwithlabelv1.js";
	}*/
	scriptnew.src = markerWithLabelJS;
	document.body.appendChild(scriptnew);
}
function fillHeaderAddress(){
	var place = autocomplete.getPlace();
	var locZipCode = $('#searchText_header').val();
	var prefixURL;
	if ($('#currentLocale').val() === 'es_US') {
		prefixURL = '/es';
	}
	console.log(place);
	if(place != undefined && place.geometry != undefined){
		console.log(place.geometry.location);
		var lat = place.geometry.location.lat();
		var lng = place.geometry.location.lng();
		console.log(lat);
		console.log(lng);
		$('#latLong_header').val(''+lat+','+lng);		
		if(!headerFlag){
			sessionStorage.setItem('searchlatLong', lat+','+lng);
			var formUrl = $('#headerLocationForm').attr('action');
			$('#headerLocationForm').attr('action', formUrl+'?searchText='+locZipCode).submit();
		}
	}
}
// This function fetches the latLong using google API. Please note that this
// function should be called by passing a 'function' as a 'callback' argument.
// Once the latlong is fetched a callback will be done to the calling function.
// Please refer to how this is used in line 1019. - ALM #1757
function getGeoCode(searchText, callback){
	if(searchText){
		geocoder = new google.maps.Geocoder();
		geocoder.geocode({'address' : searchText}, function(results, status) {
			if (status == google.maps.GeocoderStatus.OK) {
				if(typeof results[0].partial_match == 'undefined'){
					var latLong = [results[0].geometry.location.lat(),results[0].geometry.location.lng()];
					callback(latLong.toString());
				}else{
					callback('NO_LAT_LONG'); 
				}
			}else if(status == google.maps.GeocoderStatus.ZERO_RESULTS){
				 callback('NO_LAT_LONG'); 
			}
		});
	}
}

function geoCode(searchText){
	if(searchText){
		geocoder = new google.maps.Geocoder();
		geocoder.geocode({'address' : searchText}, function(results, status) {
			if (status == google.maps.GeocoderStatus.OK) {
				if(results[0]){
					$('#latLong').val(results[0].geometry.location);
				}
			}
		});
	}
}
function searchNearByLatLongFromHeader() {
    if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(locationSearchNearMeFromHeader, showError, {
        maximumAge: 60000
    });

} else {
	$.holdReady(false);
	// THE BROWSER DOES NOT SUPPORTS LOCATION DETECTION
    // MAKE THE AJAX CALL TO THE CURRENT R1 - AJAX CALL (Location
    // detection servlet)
    // Display the detected restaurant in the header
    alert("Geolocation is not supported by this browser. Use latitude and Longitude from Akamai");
}
}
function locationSearchNearMeFromHeader(position) {
	var latLong = position.coords.latitude+","+position.coords.longitude;
	//var latLong = 29.19384500 + "," + -81.06602700;
	$('#latLong_header').val(latLong);
	$('#headerLocationForm').submit();
	
}