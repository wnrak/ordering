window.fbAsyncInit = function() {
	if($("#facebookAppId").length){
		var facebookAppId = document.getElementById("facebookAppId").value;    
		FB.init({
		  appId      : facebookAppId,
		  xfbml      : true,
		  version    : 'v2.10'
		});
	   $(document).trigger('FBSDKLoaded');
    }
  };

  (function(d, s, id){
	 var js, fjs = d.getElementsByTagName(s)[0];
	 if (d.getElementById(id)) {return;}
	 js = d.createElement(s); js.id = id;
	 js.src = "//connect.facebook.net/en_US/sdk.js";
	 fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
 
function checkLoginState() {
	FB.getLoginStatus(function(response) {
	  statusChangeCallback(response);
	});
 }
 
function statusChangeCallback(response) {
    if (typeof console == "undefined" || typeof console.log == "undefined")  {
		var console = { log: function() {} };
	}
	if (response.status === 'connected') {	
		console.log('In statusChangeCallback');
		FB.api('/me', {fields: 'id,first_name,last_name,email,gender,locale,timezone'}, function(response) {			 		
			 
			  var socialEmail = "";
			  var socialFirstName = "";
			  var socialLastName = "";
			  if(response.email) {
				  socialEmail=response.email;
			  }
			  var socialUID = response.id;
			  
			  if(response.first_name) {
				  socialFirstName=response.first_name;
			  }
			  if(response.last_name) {
				  socialLastName=response.last_name;
			  }
			  var socialGender = response.gender;						      
			  var socialLocale = response.locale;
			  var socialTimeZone = response.timezone;
			  console.log("socialEmail:"+socialEmail);
							
			  var socialHandlerUrl = $("#socialHandler").val();
			  console.log("The socialHandlerUrl:"+socialHandlerUrl);	
				
			  var sdata = {socialEmail : socialEmail, socialUID : socialUID , socialFirstName : socialFirstName, socialLastName : socialLastName, socialGender : socialGender, socialLocale : socialLocale, socialTimeZone : socialTimeZone};
				  
			   var request = $.ajax({
					  url : socialHandlerUrl,
					  data : sdata,
					  type: "post",
					  cache : false
					 });
			   
			   
			   request.done(function(response, textStatus, jqXHR) { 
					console.log("The response json status:"+response.status);	

					var socialLinkStatus = response.status;
					
					if(socialLinkStatus == 'socialNonLinked'){					
						 var socialLinkUrl = $("#socialLinker").val();
						 console.log("In socialNon Linked Status:"+socialLinkUrl);
							  
							  var request = $.ajax({
								  url  : socialLinkUrl,
								  data : sdata,
								  type : "post",
								  cache : false
								 });
							  
							  request.done(function(response, textStatus, jqXHR) {
								  console.log("In socialNon Linked Status Done method:");
								  var modalDiv = $($.parseHTML(response)).filter("#myRestaurantModal");
								  
								  var socialLinkForm = $('#socialLoginLinkConfirmation');
								  var fbUID = $('#socialUID').val();
								  
								  modalDiv.find(".styled-select select, .styled-select-red select").each(function(){
										$(this).wrap("<span class='select-wrapper'></span>");
										$(this).after("<span class='holder'></span>");
										$(this).next(".holder").text($(this).find("option:first").text());
									 });
																		
								  modalDiv.modal();
								});
					

								// callback handler that will be called on failure
								request.fail(function(jqXHR, textStatus, errorThrown) {
									  // log the error to the console
									  console.error("The following error occured: " + textStatus,
															 errorThrown);
								});
					
					} else if(socialLinkStatus == 'socialLinked'){						
						var socialLoginForm = document.getElementById("socialLoginForm");
						var sodata = {socialEmail : socialEmail , socialUID : socialUID };
						$("#socialLinkedEmail").val(socialEmail);
						document.getElementById('linkSocialUID').value = socialUID;
						document.getElementById('socialLinkedEmail').value = socialEmail;
						console.log("In socialLinked Status:"+document.getElementById('socialLinkedEmail').value+":its form:"+socialLoginForm);
											
						socialLoginForm.submit();
					} 
					// social Registration Page
					else {
				
				
						var pageURL = window.location+"";
						if((pageURL.indexOf('/purchase') > -1 )){
							var socialRegistrationForm = document.getElementById("gcsocialRegistrationForm");
							console.log("IN gcSoc Reg Form:"+socialRegistrationForm);
							document.getElementById('gcsocialUid').value = socialUID;
							document.getElementById('gcsocialEmailId').value = socialEmail;
							document.getElementById('gcsocialFirstName').value = socialFirstName;
							document.getElementById('gcsocialLastName').value = socialLastName;
							document.getElementById('gcsocialGender').value = socialGender;
							document.getElementById('gcsocialLocale').value = socialLocale;
							document.getElementById('gcsocialTimeZone').value = socialTimeZone;
					
							socialRegistrationForm.submit();
							
						} else {
						socialRegistrationForm = document.getElementById("socialRegistrationForm");						
						document.getElementById('socialUid').value = socialUID;
						document.getElementById('socialEmailId').value = socialEmail;
						document.getElementById('socialFirstName').value = socialFirstName;
						document.getElementById('socialLastName').value = socialLastName;
						document.getElementById('socialGender').value = socialGender;
						document.getElementById('socialLocale').value = socialLocale;
						document.getElementById('socialTimeZone').value = socialTimeZone;
				
						socialRegistrationForm.submit();
						}
					}
					  
			   });
			   

				// callback handler that will be called on failure
				request.fail(function(jqXHR, textStatus, errorThrown) {
					  // log the error to the console
					  console.error("The following error occured: " + textStatus,
											 errorThrown);
				});
			});	   
	   
	  } else if (response.status === 'not_authorized') {
		// The person is logged into Facebook, but not your app.
		document.getElementById('status').innerHTML = 'Please log ' +
		  'into this app.';
	  } else {
		   FB.login(function(response) {
				if(response.authResponse){
					FB.api('/me', {fields: 'id,first_name,last_name,email,gender,locale,timezone'}, function(response) {			 		
			 
						  var socialEmail = "";
						  var socialFirstName = "";
						  var socialLastName = "";
						  if(response.email) {
							  socialEmail=response.email;
						  }
						  var socialUID = response.id;
						  
						  if(response.first_name) {
							  socialFirstName=response.first_name;
						  }
						  if(response.last_name) {
							  socialLastName=response.last_name;
						  }
						  var socialGender = response.gender;						      
						  var socialLocale = response.locale;
						  var socialTimeZone = response.timezone;
						  console.log("socialEmail:"+socialEmail);
										
						  var socialHandlerUrl = $("#socialHandler").val();
						  console.log("The socialHandlerUrl:"+socialHandlerUrl);	
							
						  var sdata = {socialEmail : socialEmail, socialUID : socialUID , socialFirstName : socialFirstName, socialLastName : socialLastName, socialGender : socialGender, socialLocale : socialLocale, socialTimeZone : socialTimeZone};
							  
						   var request = $.ajax({
								  url : socialHandlerUrl,
								  data : sdata,
								  type: "post",
								  cache : false
								 });
						   
						   
						   request.done(function(response, textStatus, jqXHR) { 
								console.log("The response json status:"+response.status);	

								var socialLinkStatus = response.status;
								
								if(socialLinkStatus == 'socialNonLinked'){					
									 var socialLinkUrl = $("#socialLinker").val();
									 console.log("In socialNon Linked Status:"+socialLinkUrl);
										  
										  var request = $.ajax({
											  url  : socialLinkUrl,
											  data : sdata,
											  type : "post",
											  cache : false
											 });
										  
										  request.done(function(response, textStatus, jqXHR) {
											  console.log("In socialNon Linked Status Done method:");
											  var modalDiv = $($.parseHTML(response)).filter("#myRestaurantModal");
											  
											  var socialLinkForm = $('#socialLoginLinkConfirmation');
											  var fbUID = $('#socialUID').val();
											  
											  modalDiv.find(".styled-select select, .styled-select-red select").each(function(){
													$(this).wrap("<span class='select-wrapper'></span>");
													$(this).after("<span class='holder'></span>");
													$(this).next(".holder").text($(this).find("option:first").text());
												 });
																					
											  modalDiv.modal();
											});
								

											// callback handler that will be called on failure
											request.fail(function(jqXHR, textStatus, errorThrown) {
												  // log the error to the console
												  console.error("The following error occured: " + textStatus,
																		 errorThrown);
											});
								
								} else if(socialLinkStatus == 'socialLinked'){						
									var socialLoginForm = document.getElementById("socialLoginForm");
									var sodata = {socialEmail : socialEmail , socialUID : socialUID };
									$("#socialLinkedEmail").val(socialEmail);
									document.getElementById('linkSocialUID').value = socialUID;
									document.getElementById('socialLinkedEmail').value = socialEmail;
									console.log("In socialLinked Status:"+document.getElementById('socialLinkedEmail').value+":its form:"+socialLoginForm);
														
									socialLoginForm.submit();
								} 
								// social Registration Page
								else {
							
							
									var pageURL = window.location+"";
									if((pageURL.indexOf('/purchase') > -1 )){
										var socialRegistrationForm = document.getElementById("gcsocialRegistrationForm");
										console.log("IN gcSoc Reg Form:"+socialRegistrationForm);
										document.getElementById('gcsocialUid').value = socialUID;
										document.getElementById('gcsocialEmailId').value = socialEmail;
										document.getElementById('gcsocialFirstName').value = socialFirstName;
										document.getElementById('gcsocialLastName').value = socialLastName;
										document.getElementById('gcsocialGender').value = socialGender;
										document.getElementById('gcsocialLocale').value = socialLocale;
										document.getElementById('gcsocialTimeZone').value = socialTimeZone;
								
										socialRegistrationForm.submit();
										
									} else {
									socialRegistrationForm = document.getElementById("socialRegistrationForm");						
									document.getElementById('socialUid').value = socialUID;
									document.getElementById('socialEmailId').value = socialEmail;
									document.getElementById('socialFirstName').value = socialFirstName;
									document.getElementById('socialLastName').value = socialLastName;
									document.getElementById('socialGender').value = socialGender;
									document.getElementById('socialLocale').value = socialLocale;
									document.getElementById('socialTimeZone').value = socialTimeZone;
							
									socialRegistrationForm.submit();
									}
								}
								  
						   });
						   

							// callback handler that will be called on failure
							request.fail(function(jqXHR, textStatus, errorThrown) {
								  // log the error to the console
								  console.error("The following error occured: " + textStatus,
														 errorThrown);
							});
						});
				} else {
					console.log(' Not Logged in to FB');
				}
		   }, {scope: 'public_profile,email'});	   
	  }
	
}
	
	
function checkMobileLoginState() {
FB.getLoginStatus(function(response) {
  mobileStatusChangeCallback(response);
});
 }
 
function mobileStatusChangeCallback(response) {
	console.log('mobile statusChangeCallback');
	if (response.status === 'connected') {	
		
		FB.api('/me', {fields: 'id,first_name,last_name,email,gender,locale,timezone'}, function(response) {			 		
			  var socialEmail = response.email != null?response.email:"";
     		  var socialUID = response.id;
     		  var socialFirstName = response.first_name != null?response.first_name:"";
     		  var socialLastName = response.last_name != null?response.last_name:"";
			  var socialGender = response.gender;						      
			  var socialLocale = response.locale;
			  var socialTimeZone = response.timezone;
			  console.log("socialEmail in mobile:"+socialEmail);
							
			  var socialHandlerUrl = $("#socialHandler").val();
			  console.log("The socialHandlerUrl:"+socialHandlerUrl);	
				
			  var sdata = {socialEmail : socialEmail, socialUID : socialUID , socialFirstName : socialFirstName, socialLastName : socialLastName, socialGender : socialGender, socialLocale : socialLocale, socialTimeZone : socialTimeZone};
				 
			  if(socialEmail && socialEmail.length > 40){	
						
					var mobilefbMessageUrl = "/customer-service/includes/fbEmailMessage.jsp";
					
					$.get(mobilefbMessageUrl, function(overlayHTML) {
							var modalDiv = $(overlayHTML).filter("#myModalRestaurantChange");
							modalDiv.modal();
						});
			   }
			   else	
			   {						 
			   var request = $.ajax({
					  url : socialHandlerUrl,
					  data : sdata,
					  type: "post",
					  cache : false
					 });
			   
			   
			   request.done(function(response, textStatus, jqXHR) { 
					console.log("The response json status:"+response.status);	

					var socialLinkStatus = response.status;
					
					if(socialLinkStatus == 'socialNonLinked'){					
						var socialLoginLinkForm = document.getElementById("socialLoginLinkForm");						
						document.getElementById('linkSocialUid').value = socialUID;
						document.getElementById('linkSocialEmailId').value = socialEmail;
						document.getElementById('linkSocialFirstName').value = socialFirstName;
						document.getElementById('linkSocialLastName').value = socialLastName;
						document.getElementById('linkSocialGender').value = socialGender;
						document.getElementById('linkSocialLocale').value = socialLocale;
						document.getElementById('linkSocialTimeZone').value = socialTimeZone;				
						socialLoginLinkForm.submit();
					
					} else if(socialLinkStatus == 'socialLinked'){						
						var socialLoginForm = document.getElementById("socialLoginForm");
						var sodata = {socialEmail : socialEmail};
						$("#socialLinkedEmail").val(socialEmail);
						document.getElementById('socialUid').value = socialUID;
						document.getElementById('socialLinkedEmail').value = socialEmail;
						console.log("In socialLinked Status:"+document.getElementById('socialLinkedEmail').value+":its form:"+socialLoginForm);
											
						socialLoginForm.submit();
					} 
					// social Registration Page
					else {
				
						var socialRegistrationForm = document.getElementById("socialRegistrationForm");						
						document.getElementById('regSocialUID').value = socialUID;
						document.getElementById('regSocialEmailId').value = socialEmail;
						document.getElementById('regSocialFirstName').value = socialFirstName;
						document.getElementById('regSocialLastName').value = socialLastName;
						document.getElementById('regSocialGender').value = socialGender;
						document.getElementById('regSocialLocale').value = socialLocale;
						document.getElementById('regSocialTimeZone').value = socialTimeZone;
		
						socialRegistrationForm.submit();
					}
					  
			   });
			   

				// callback handler that will be called on failure
				request.fail(function(jqXHR, textStatus, errorThrown) {
					  // log the error to the console
					  console.error("The following error occured: " + textStatus,
											 errorThrown);
				});
			 }
			});	   
	   
	  } else if (response.status === 'not_authorized') {
		// The person is logged into Facebook, but not your app.
		document.getElementById('status').innerHTML = 'Please log ' +
		  'into this app.';
	  } else {
		  document.getElementById('status').innerHTML = 'Please logIn ';		  
	  }
	
}


//mobileFacebookLoginButton Click Event
$(document).off("click", "#mobileFacebookLoginButton").on("click", "#mobileFacebookLoginButton", function(e) {
	if (typeof console == "undefined" || typeof console.log == "undefined") {
		var console = { log: function() {} };
	}
	
	//ToGo Refactoring changes - start
	if($('.main-container').find("div[id='catering-login-modal']").length != 0) {
		$('#catering-login-modal').modal('hide');
	}
	//ToGo Refactoring changes - end
	
	FB.login(function(response) {
				if(response.authResponse){
					FB.api('/me', {fields: 'id,first_name,last_name,email,gender,locale,timezone'} , function(response) {			 		
					  var socialEmail = response.email != null?response.email:"";
					  var socialUID = response.id;
					  var socialFirstName = response.first_name != null?response.first_name:"";
					  var socialLastName = response.last_name != null?response.last_name:"";
					  var socialGender = response.gender;						      
					  var socialLocale = response.locale;
					  var socialTimeZone = response.timezone;
					  console.log("socialEmail:"+socialEmail);
									
					  var socialHandlerUrl = $("#socialHandler").val();
					  console.log("The socialHandlerUrl:"+socialHandlerUrl);	
						
					  var sdata = {socialEmail : socialEmail, socialUID : socialUID , socialFirstName : socialFirstName, socialLastName : socialLastName, socialGender : socialGender, socialLocale : socialLocale, socialTimeZone : socialTimeZone};
						
					  if(socialEmail && socialEmail.length > 40){	
								
							var mobilefbMessageUrl = "/customer-service/includes/fbEmailMessage.jsp";
							
							$.get(mobilefbMessageUrl, function(overlayHTML) {
									var modalDiv = $(overlayHTML).filter("#myModalRestaurantChange");
									modalDiv.modal();
								});
					   }
					   else	
					   {	
					   var request = $.ajax({
							  url : socialHandlerUrl,
							  data : sdata,
							  type: "post",
							  cache : false
							 });
					   
					   
					   request.done(function(response, textStatus, jqXHR) { 
							console.log("The response json status:"+response.status);	

							var socialLinkStatus = response.status;
							
							if(socialLinkStatus == 'socialNonLinked'){					
								var socialLoginLinkForm = document.getElementById("socialLoginLinkForm");						
								document.getElementById('linkSocialUid').value = socialUID;
								document.getElementById('linkSocialEmailId').value = socialEmail;
								document.getElementById('linkSocialFirstName').value = socialFirstName;
								document.getElementById('linkSocialLastName').value = socialLastName;
								document.getElementById('linkSocialGender').value = socialGender;
								document.getElementById('linkSocialLocale').value = socialLocale;
								document.getElementById('linkSocialTimeZone').value = socialTimeZone;				
								socialLoginLinkForm.submit();
							
							} else if(socialLinkStatus == 'socialLinked'){						
								var socialLoginForm = document.getElementById("socialLoginForm");
								var sodata = {socialEmail : socialEmail};
								$("#socialLinkedEmail").val(socialEmail);
								document.getElementById('socialUid').value = socialUID;
								document.getElementById('socialLinkedEmail').value = socialEmail;
								console.log("In socialLinked Status:"+document.getElementById('socialLinkedEmail').value+":its form:"+socialLoginForm);
													
								socialLoginForm.submit();
							} 
							// social Registration Page
							else {
						
								var socialRegistrationForm = document.getElementById("socialRegistrationForm");						
								document.getElementById('regSocialUID').value = socialUID;
								document.getElementById('regSocialEmailId').value = socialEmail;
								document.getElementById('regSocialFirstName').value = socialFirstName;
								document.getElementById('regSocialLastName').value = socialLastName;
								document.getElementById('regSocialGender').value = socialGender;
								document.getElementById('regSocialLocale').value = socialLocale;
								document.getElementById('regSocialTimeZone').value = socialTimeZone;
				
								socialRegistrationForm.submit();
							}
							  
					   });
					   

						// callback handler that will be called on failure
						request.fail(function(jqXHR, textStatus, errorThrown) {
							  // log the error to the console
							  console.error("The following error occured: " + textStatus,
													 errorThrown);
						});
						
					   }	
					});	 
				} else {
					console.log(' Not Logged in to FB');
				}
		   }, {scope: 'public_profile,email'});	
		   e.preventDefault();
});

//method to check given DP User and FB User are same and Link

function checkUserSocialLogin(dpuserEmail) {
	if (typeof console == "undefined" || typeof console.log == "undefined") {
		var console = { log: function() {} };
	} 

	FB.login(function(response) {
				if(response.authResponse){
					FB.api('/me', {fields: 'id,first_name,last_name,email,gender,locale,timezone'}, function(response) {	
						  console.log("In New Method");
						  var socialEmail = response.email != null?response.email:"";
						  var socialUID = response.id;
						  var socialFirstName = response.first_name != null?response.first_name:"";
						  var socialLastName = response.last_name != null?response.last_name:"";
						  var socialGender = response.gender;						      
						  var socialLocale = response.locale;
						  var socialTimeZone = response.timezone;
						  console.log("socialEmail:"+socialEmail);
						  
						  var dpUserForm = document.getElementById("dpUserForm");						
							document.getElementById('linkSocialUid').value = socialUID;
							document.getElementById('linkSocialEmailId').value = socialEmail;
							document.getElementById('linkSocialFirstName').value = socialFirstName;
							document.getElementById('linkSocialLastName').value = socialLastName;
							document.getElementById('linkSocialGender').value = socialGender;
							document.getElementById('linkSocialLocale').value = socialLocale;
							document.getElementById('linkSocialTimeZone').value = socialTimeZone;
			
					dpUserForm.submit();
					});
				} else {
					console.log(' Not Logged in to FB');
				}
	}, {scope: 'public_profile,email'});						
			 
}

//facebookLoginButton Click Event
$(document).off("click", "#facebookLoginButton").on("click", "#facebookLoginButton", function() {
	if (typeof console == "undefined" || typeof console.log == "undefined") {
		var console = { log: function() {} };
	}
	
	//ToGo Refactoring changes - start
	if($('.main-container').find("div[id='catering-login-modal']").length != 0) {
		$('#catering-login-modal').modal('hide');
	}
	//ToGo Refactoring changes - end

	FB.login(function(response) {
				if(response.authResponse){
					FB.api('/me', {fields: 'id,first_name,last_name,email,gender,locale,timezone'}, function(response) {			 		
			 
						  var socialEmail = "";
						  var socialFirstName = "";
						  var socialLastName = "";
						  if(response.email) {
							  socialEmail=response.email;
						  }
						  var socialUID = response.id;
						  
						  if(response.first_name) {
							  socialFirstName=response.first_name;
						  }
						  if(response.last_name) {
							  socialLastName=response.last_name;
						  }
						
						  var socialGender = response.gender;						      
						  var socialLocale = response.locale;
						  var socialTimeZone = response.timezone;
						  console.log("socialEmail:"+socialEmail);
										
						  var socialHandlerUrl = $("#socialHandler").val();
						  console.log("The socialHandlerUrl:"+socialHandlerUrl);	
							
						  var redirectURL =  $("#redirectURL").val();
						  
						  var sdata = {socialEmail : socialEmail, socialUID : socialUID , socialFirstName : socialFirstName, socialLastName : socialLastName, socialGender : socialGender, socialLocale : socialLocale, socialTimeZone : socialTimeZone, redirectURL : redirectURL};
							
						if(socialEmail && socialEmail.length > 40){	
						
							var fbMessageUrl = "/customer-service/includes/fbEmailMessage.jsp";
							var request = $.ajax({
										url: fbMessageUrl,
										type: "GET",
										cache : false
									});
							request.done(function (response, textStatus, jqXHR){
														
								var modalDiv = $($.parseHTML(response)).filter("#myRestaurantModal");	
								modalDiv.find(".styled-select select, .styled-select-red select").each(function(){
												$(this).wrap("<span class='select-wrapper'></span>");
												$(this).after("<span class='holder'></span>");
												$(this).next(".holder").text($(this).find("option:first").text());
											 });
								modalDiv.modal();
							});
								
							request.fail(function(jqXHR, textStatus, errorThrown) {
											  // log the error to the console
											  console.error("The following error occured: " + textStatus,
																	 errorThrown);
										});
					   }
					   else	
					   {							   
						   var request = $.ajax({
								  url : socialHandlerUrl,
								  data : sdata,
								  type: "post",
								  cache : false
								 });
						   
						   
						   request.done(function(response, textStatus, jqXHR) { 
								console.log("The response json status:"+response.status);	

								var socialLinkStatus = response.status;
								
								if(socialLinkStatus == 'socialNonLinked'){					
									 var socialLinkUrl = $("#socialLinker").val();
									 console.log("In socialNon Linked Status:"+socialLinkUrl);
										  
										  var request = $.ajax({
											  url  : socialLinkUrl,
											  data : sdata,
											  type : "post",
											  cache : false
											 });
										  
										  request.done(function(response, textStatus, jqXHR) {
											  console.log("In socialNon Linked Status Done method:");
											  var modalDiv = $($.parseHTML(response)).filter("#myRestaurantModal");
											  
											  var socialLinkForm = $('#socialLoginLinkConfirmation');
											  var fbUID = $('#socialUID').val();
											  
											  modalDiv.find(".styled-select select, .styled-select-red select").each(function(){
													$(this).wrap("<span class='select-wrapper'></span>");
													$(this).after("<span class='holder'></span>");
													$(this).next(".holder").text($(this).find("option:first").text());
												 });
																					
											  modalDiv.modal();
											});
								

											// callback handler that will be called on failure
											request.fail(function(jqXHR, textStatus, errorThrown) {
												  // log the error to the console
												  console.error("The following error occured: " + textStatus,
																		 errorThrown);
											});
								
								} else if(socialLinkStatus == 'socialLinked'){						
									var socialLoginForm = document.getElementById("socialLoginForm");
									var sodata = {socialEmail : socialEmail , socialUID : socialUID };
									$("#socialLinkedEmail").val(socialEmail);
									document.getElementById('linkSocialUID').value = socialUID;
									document.getElementById('socialLinkedEmail').value = socialEmail;
									console.log("In socialLinked Status:"+document.getElementById('socialLinkedEmail').value+":its form:"+socialLoginForm);
														
									socialLoginForm.submit();
								} 
								// social Registration Page
								else {
							
							
									var pageURL = window.location+"";
									if((pageURL.indexOf('/purchase') > -1 )){
										var socialRegistrationForm = document.getElementById("gcsocialRegistrationForm");
										console.log("IN gcSoc Reg Form:"+socialRegistrationForm);
										document.getElementById('gcsocialUid').value = socialUID;
										document.getElementById('gcsocialEmailId').value = socialEmail;
										document.getElementById('gcsocialFirstName').value = socialFirstName;
										document.getElementById('gcsocialLastName').value = socialLastName;
										document.getElementById('gcsocialGender').value = socialGender;
										document.getElementById('gcsocialLocale').value = socialLocale;
										document.getElementById('gcsocialTimeZone').value = socialTimeZone;
								
										socialRegistrationForm.submit();
										
									} else {
									var socialRegistrationForm = document.getElementById("socialRegistrationForm");						
									document.getElementById('socialUid').value = socialUID;
									document.getElementById('socialEmailId').value = socialEmail;
									document.getElementById('socialFirstName').value = socialFirstName;
									document.getElementById('socialLastName').value = socialLastName;
									document.getElementById('socialGender').value = socialGender;
									document.getElementById('socialLocale').value = socialLocale;
									document.getElementById('socialTimeZone').value = socialTimeZone;
							
									socialRegistrationForm.submit();
									}
								}
								  
						   });
						   

							// callback handler that will be called on failure
							request.fail(function(jqXHR, textStatus, errorThrown) {
								  // log the error to the console
								  console.error("The following error occured: " + textStatus,
														 errorThrown);
							});
						 }
						});
				} else {
					console.log(' Not Logged in to FB');
				}
		   }, {scope: 'public_profile,email'});	
});

// method used for Eclub Overlay Page
$(document).off("click", "#overlayfacebookLoginButton").on("click", "#overlayfacebookLoginButton", function() {
	if (typeof console == "undefined" || typeof console.log == "undefined") var console = { log: function() {} };
	var facebookAppId = document.getElementById("facebookAppId").value;
	FB.init({
	  appId      : facebookAppId,
	  xfbml      : true,
	  version    : 'v2.10'
	});
	
	(function(d, s, id){
	 var js, fjs = d.getElementsByTagName(s)[0];
	 if (d.getElementById(id)) {return;}
	 js = d.createElement(s); js.id = id;
	 js.src = "//connect.facebook.net/en_US/sdk.js";
	 fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
   
 
	FB.login(function(response) {
				if(response.authResponse){
					FB.api('/me', {fields: 'id,first_name,last_name,email,gender,locale,timezone'}, function(response) {			 		
			 
						  var socialEmail = response.email != null?response.email:"";
						  var socialUID = response.id;
						  var socialFirstName = response.first_name != null?response.first_name:"";
						  var socialLastName = response.last_name != null?response.last_name:"";
						  var socialGender = response.gender;						      
						  var socialLocale = response.locale;
						  var socialTimeZone = response.timezone;
						  console.log("socialEmail:"+socialEmail);
										
						  var socialHandlerUrl = $("#socialHandler").val();
						  console.log("The socialHandlerUrl:"+socialHandlerUrl);	
							
						  var sdata = {socialEmail : socialEmail, socialUID : socialUID , socialFirstName : socialFirstName, socialLastName : socialLastName, socialGender : socialGender, socialLocale : socialLocale, socialTimeZone : socialTimeZone};
							  
						   var request = $.ajax({
								  url : socialHandlerUrl,
								  data : sdata,
								  type: "post",
								  cache : false
								 });
						   
						   
						   request.done(function(response, textStatus, jqXHR) { 
								console.log("The response json status:"+response.status);	

								var socialLinkStatus = response.status;
								
								if(socialLinkStatus == 'socialNonLinked'){					
									 var socialLinkUrl = $("#socialLinker").val();
									 console.log("In socialNon Linked Status:"+socialLinkUrl);
										  
										  var request = $.ajax({
											  url  : socialLinkUrl,
											  data : sdata,
											  type : "post",
											  cache : false
											 });
										  
										  request.done(function(response, textStatus, jqXHR) {
											  console.log("In socialNon Linked Status Done method:");
											  var modalDiv = $($.parseHTML(response)).filter("#myRestaurantModal");
											  
											  var socialLinkForm = $('#socialLoginLinkConfirmation');
											  var fbUID = $('#socialUID').val();
											  
											  modalDiv.find(".styled-select select, .styled-select-red select").each(function(){
													$(this).wrap("<span class='select-wrapper'></span>");
													$(this).after("<span class='holder'></span>");
													$(this).next(".holder").text($(this).find("option:first").text());
												 });
																					
											  modalDiv.modal();
											});
								

											// callback handler that will be called on failure
											request.fail(function(jqXHR, textStatus, errorThrown) {
												  // log the error to the console
												  console.error("The following error occured: " + textStatus,
																		 errorThrown);
											});
								
								} else if(socialLinkStatus == 'socialLinked'){						
									var socialLoginForm = document.getElementById("socialLoginForm");
									var sodata = {socialEmail : socialEmail , socialUID : socialUID };
									$("#socialLinkedEmail").val(socialEmail);
									document.getElementById('linkSocialUID').value = socialUID;
									document.getElementById('socialLinkedEmail').value = socialEmail;
									console.log("In socialLinked Status:"+document.getElementById('socialLinkedEmail').value+":its form:"+socialLoginForm);
														
									socialLoginForm.submit();
								} 
								// social Registration Page
								else {
							
							
									var pageURL = window.location+"";
									if((pageURL.indexOf('/purchase') > -1 )){
										var socialRegistrationForm = document.getElementById("gcsocialRegistrationForm");
										console.log("IN gcSoc Reg Form:"+socialRegistrationForm);
										document.getElementById('gcsocialUid').value = socialUID;
										document.getElementById('gcsocialEmailId').value = socialEmail;
										document.getElementById('gcsocialFirstName').value = socialFirstName;
										document.getElementById('gcsocialLastName').value = socialLastName;
										document.getElementById('gcsocialGender').value = socialGender;
										document.getElementById('gcsocialLocale').value = socialLocale;
										document.getElementById('gcsocialTimeZone').value = socialTimeZone;
								
										socialRegistrationForm.submit();
										
									} else {
									var socialRegistrationForm = document.getElementById("socialRegistrationForm");						
									document.getElementById('socialUid').value = socialUID;
									document.getElementById('socialEmailId').value = socialEmail;
									document.getElementById('socialFirstName').value = socialFirstName;
									document.getElementById('socialLastName').value = socialLastName;
									document.getElementById('socialGender').value = socialGender;
									document.getElementById('socialLocale').value = socialLocale;
									document.getElementById('socialTimeZone').value = socialTimeZone;
							
									socialRegistrationForm.submit();
									}
								}
								  
						   });
						   

							// callback handler that will be called on failure
							request.fail(function(jqXHR, textStatus, errorThrown) {
								  // log the error to the console
								  console.error("The following error occured: " + textStatus,
														 errorThrown);
							});
						});
				} else {
					console.log(' Not Logged in to FB');
				}
		   }, {scope: 'public_profile,email'});	
});


$(document).ready(function(){
	    if (typeof console == "undefined" || typeof console.log == "undefined") {
			var console = { log: function() {} };
		}
		console.log("In Ready:");
	 $(document).bind('FBSDKLoaded', function() {
		console.log("This is it:");
    });	
});

/********** tab browsing changes ***********/
$(document).ready(function(){
var cartCount=$(".my_cart .order_num").html();
	if(cartCount>0) 
		{
				var txt2 = '<a href="#checkoutCont" id="skipMainCont">skip main content</a>';              
    
				$(".sub-menu-grid-bg.sub-menu-grid-123").before(txt2);
			
		}
	});

/********** tab browsing changes ends***********/