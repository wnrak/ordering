'use strict';
var today = moment();
var currentDate = moment().format("MM/DD/YYYY");
var isLocationPopupOpened = false;
var loadQuickAddModal = false;
$(document).on('triggerReadyFunction', function(event) {

    //Time Conflict Script start
    $("#timeConflict").delegate("#timeConflictOk", "click", function(e) {
        var restaurantId = getCookie("DRIREST", 0);
        var pickupDate = moment().format("MM/DD/YYYY");
        var pickupTime = $('#tcToTime').text();
        sessionStorage.setItem("updateCookTime", pickupTime);
        var isAsap = false;
        var selectedId = $('input[name="pickupdate-time"]:checked').attr('id');
        if (selectedId == "ordertype-asap") {
            isAsap = true;
        }
        locationTimeApi(restaurantId, pickupDate, pickupTime, true, isAsap).done(function(response) {
            if (response.status == 'success') {
                $('#timeConflict').modal('hide');
                if ($('#timeConflictOk').attr('increaseQty')) {
                    $('#drawer-openmenu').trigger("click");
                    updateOrderAPI($('#timeConflictOk').attr('itemCount'), $('#timeConflictOk').attr('itemId'))
                    $('#timeConflictOk').removeAttr('increaseQty');
                    $('#timeConflictOk').removeAttr('itemCount');
                    $('#timeConflictOk').removeAttr('itemId');
                } else {
                    if ($('#timeConflictOk').attr('remove-data')) {
                        deleteHandler($('#timeConflictOk').attr('remove-Id'), []);
                        $('#timeConflictOk').removeAttr('remove-Id');
                        $('#timeConflictOk').removeAttr('remove-data');
                    } else {
                        if ($("#popupAddToCart").length > 0) {
                            $('#timeConflictOk').attr('data', true);
                            $("#popupAddToCart").trigger("click");
                        } else if ($("#addToCart").length > 0) {
                            $("#addToCart").trigger("click");
                        } else if ($("#cartUpdate").length > 0) {
                            $("#cartUpdate").trigger("click");
                        } else {
                            $("#" + $("#timeConflictOk").attr("data-element")).trigger("click");
                        }
                    }
                }
                getOrderSettingApi(null, init);
            }
        });
    });

    //Time Conflict Script end
    $('#location-asap').on('click', function() {
        locationAsapEvent();
    });
    //Select date and time on page click
    $('#location-specificdate').on('click', function() {
        locationSpecificDateEvent();
    });

    $('#select-locationtime-list').on('change', function() {
        $('#locselected-time').html(this.value);
        $('#locselected-time-val').val(this.value);
        $('#errorMsg').hide();
    })

    $('#location-modal').on('hidden.bs.modal', function() {
        isLocationPopupOpened = false;
        if (loadQuickAddModal) {
            $('#item-list-modal').modal('show');
            if ($('#selectedSkuDiv').val() != '' && $('#selectedSkuDiv').val() != undefined) {
                portionSizeTimeHandler();
            }
            portionSizeHandler('quickAddPopup');
            handleAccordionSelection('quickAddPopup');
            var addon = addOnPrice();
            updatePopupPrice(addon);
        }
    });

    $('#location-modal').on('shown.bs.modal', function() {
        isLocationPopupOpened = true;
    });

})

/*Asap Location function*/
function locationAsapEvent() {
    $('#location-asapdate').empty();
    $('#location-asapdate').html($('#location-asap:checked').val());
    $('#location-asapdate #leadTime').html($('#location-asapElement #leadTime').html());
    $('#specific-locationdate-time').hide();
}

function locationSpecificDateEvent() {
    $('#location-asapdate').empty();
    $('#specific-locationdate-time').show();
    var date = $('#datetimepicker-location').val();
    var time = $('#select-locationtime-list').val();
    var formatedDate = moment(date).format('MMM DD');
    var isToday;
    var isTomorrow;

    var currentTime = sessionStorage.getItem('currentTime');
    if (currentTime)
        currentTime = Number(currentTime);
    if (currentTime) {
        isToday = moment(currentTime).format("MMM DD"); //moment(new Date()).format("MMM DD");	
        isTomorrow = moment(currentTime).add(1, 'days').format("MMM DD");
    }

    if (time != null)
        time = time.trim();
    if (time) {
        selectedTimeTxt = "&nbsp;at&nbsp;<span id='locselected-time'>" + time + "</span>";
    } else {
        selectedTimeTxt = unAvailableMsg;
    }
    if (isToday == formatedDate) {
        $('#location-asapdate').html("<span class='current-date-title' id='locationcurrent-date'>" + todaytxt + " (<span id='location_currentdate'>" + formatedDate + "</span>)</span>" + selectedTimeTxt);
    } else if (isTomorrow == formatedDate) {
        $('#location-asapdate').html("<span class='current-date-title' id='locationcurrent-date'>" + tomorrowtxt + " (<span id='location_currentdate'>" + formatedDate + "</span>)</span>" + selectedTimeTxt);
    } else {
        $('#location-asapdate').html("<span class='current-date-title' id='locationcurrent-date'><span id='location_currentdate'>" + formatedDate + "</span></span>" + selectedTimeTxt);
    }
}
/*Asap Location function end*/

function setPickupDateTimeonLoad(pickupDate, pickupTime, asapSelected) {
    if ($('#orderTypeValue').val() != '1') {
        var restaurantId = getCookie("DRIREST", 0);
        if ($('#orderTypeValue').val() != '2') {
            if (restaurantId != null && pickupDate != null && pickupTime != null) {
                var currentPickupTime = moment(pickupTime, 'h:mm').format('h:mm A');
                $('#delivery-timelist option:contains(' + currentPickupTime + ')').prop('selected', true);
                $('#pickup-timelist option:contains(' + currentPickupTime + ')').prop('selected', true);
                locationTimeApi(restaurantId, pickupDate, currentPickupTime, true, asapSelected).done(function(response) {
                    if (response.status == 'success') {
                        if ($('#process86edItems').length && $('#productRecords').length &&
                            $('#enable_86ed_calls').val() == "true") {
                            process86edItems($('#productRecords'));
                        }
                    }
                });
            }
        }
    }
}

function initMap() {
    var latLong = getCookie("DRIREST", 2);
    var mapEle = document.getElementById('confirm-location-googleMap');
    var mediaPath = $('#mediaRoot_site').val();
    if (latLong) {
        var value = latLong.split(',');
        var lattiute = value[0];
        var longitude = value[1];
        $('#location-latLong').val(latLong);
    }
    if ($('#confirm-location-googleMap').length) {
        var latlng = new google.maps.LatLng(lattiute, longitude);
        map = new google.maps.Map(mapEle, {
            center: latlng,
            zoomControlOptions: {
                position: google.maps.ControlPosition.LEFT_TOP
            },
            fullscreenControlOptions: {
                position: google.maps.ControlPosition.LEFT_BOTTOM
            },
            mapTypeControl: false,
            zoom: Number($('#googleMapZoom').val()),
            gestureHandling: 'cooperative'
        });
        var marker = new google.maps.Marker({
            position: latlng,
            map: map,
            icon: mediaPath + '/geo.png'
        });
        infowindow = new google.maps.InfoWindow();
        google.maps.event.addListener(map, "click", function(event) {
            infowindow.close();
        });
    }
    initAutocomplete('restaurant-location-autocomplete', 'restaurant');
    initAutocomplete('ordertype-autocomplete', 'orderType');
    //getSearchResults();
}

function loadLocationConfirmationPopup(initialDate, isTodayClosed) {
    //Bootstrap Accordion arrow change	 
    if (sessionStorage && sessionStorage.getItem("noPop") === "true") {
        sessionStorage.removeItem("noPop")
    } else {
        $('#location-modal').modal('show');
        updateRestaurantInfo();
    }

    var defaultDate = initialDate || $('#default_jsondate').val().trim() || $('#default_Delivery_jsondate').val().trim();
    if ($('#fromTimeConflict').val() == 'true' && $('#actualPickupDate').html().trim()) {
        defaultDate = moment($.trim($('#actualPickupDate').html()), "MM/DD/YYYY");
    }
    datePickerToggle(defaultDate);
    var reqBody = {
        'orderType': orderTypeValue
    };
    createDatePicker('datetimepicker-location', defaultDate, isTodayClosed, dateChangeHandler, reqBody, updatePickupTime)
}


/** @description Function to set date time for specified location
 */
function setLocationDateTime(date, response, availableSlots, unavailableSlots) {
    var restaurantClosed = response && response.restaurantClosed;
    var asapSelected;
    
    if ((disableOrderSettings && onlineTogoEnabled && (orderTypeValue == 0 || orderTypeValue == 3) && cartItemsCount == 0)) {
    	asapSelected = response && response.successResponse && response.successResponse.asapEnabled;
    } else {
    	asapSelected = response && response.successResponse && response.successResponse.asapSelected;
    }
    
    var asapEnabled = response && response.successResponse && response.successResponse.asapEnabled;
    var asapNotAvailable = response && response.successResponse && response.successResponse.asap_not_available;
    var leadTime = response && response.successResponse && response.successResponse.leadTime;
    var selectedTime = $('#select-locationtime-list').val();
    var selectedDate = moment(date).format("MM/DD/YYYY");

    var cutOffTime = parseInt(sessionStorage.getItem('cutOffTime'));
    if (!cutOffTime) {
        cutOffTime = response && response.successResponse && response.successResponse.asapCutoffTime;
        sessionStorage.setItem('cutOffTime', cutOffTime);
    }

    if ($('#fromTimeConflict').val() == 'true' && $('#actualPickupDate').html().trim()) {
        selectedDate = $.trim($('#actualPickupDate').html());
    }

    $('#location-asapdate').empty();
    $('#asapEnabled').val(asapEnabled);

    var lunch = response && response.times && response.times.lunch;
    var dinner = response && response.times && response.times.dinner;

    if (restaurantClosed && restaurantClosed == 'true') {
        locationNextAvailableDate(selectedDate, response);
        if (!selectedTime) {
            selectedTime = '';
        }
        $('#select-locationtime-list').empty();
        $('#location-asapElement').hide();
        if (asapNotAvailable && asapNotAvailable != undefined) {
            $('#errorMsg').html(asapNotAvailable);
            $('#errorMsg').show();
        }
        renderDateTempate(selectedDate, selectedTime);
        $('#todayErrorMsg').remove();
        $('#specific-locationdate-time .datetimepicker-panel').after($('<div id="todayErrorMsg" class="todayErrorMsg">' + closedText + '</div>'));
        $('#specific-locationdate-time .timelist-select,#atTime,#locselected-time').hide();

    } else if (lunch === false && dinner === false) {
        locationNextAvailableDate(selectedDate, response);
    } else {
        $('#todayErrorMsg').remove();
        if (asapEnabled) {
            asapLocLoadTimeCalc(response, availableSlots, unavailableSlots, true);

            if (!asapSelected) {
                $('#location-asapdate').empty();
                selectedTime = $('#select-locationtime-list').val();
                renderDateTempate(selectedDate, selectedTime);
            }
        } else {
            $('#location-asapElement').hide();
            if (asapNotAvailable && asapNotAvailable != undefined) {
                $('#errorMsg').html(asapNotAvailable);
                $('#errorMsg').show();
            }
            selectedTime = $('#select-locationtime-list').val();
            renderDateTempate(selectedDate, selectedTime);
        }
        $('#specific-locationdate-time .timelist-select, #atTime, #locselected-time').show();
    }
    $('#date_month_year').val(selectedDate);
}

function renderDateTempate(selectedDate, selectedTime) {
    selectedDate = moment(selectedDate).format("MMM DD");
    var template = renderLocationDateTemplate(selectedDate, selectedTime);
    $('#location-specificdate').prop('checked', true);
    $('#specific-locationdate-time').show();
    $('#location-asapdate').append(template);
}

/** @description Function to make the leadtime less then asapCutoffTime to display  
 * @param {string} response
 */
function leadTimeChangedToAsap_WebApi(response) {
    var asapSelected;
    
    if ((disableOrderSettings && onlineTogoEnabled && (orderTypeValue == 0 || orderTypeValue == 3) && cartItemsCount == 0)) {
    	asapSelected = response && response.successResponse.asapEnabled;
    } else {
    	asapSelected = response && response.successResponse.asapSelected;
    }
    
    if (!asapSelected) {
        asapSelected = response && response.successResponse.isAsapSelected;
    }
    $('#location-asapElement').show();
    if (asapSelected) {
        $("#location-asap").prop("checked", true);
        locationAsapEvent(true);
    } else {
        $('#select-locationtime-list').attr('specificFlow');
    }
}


/** @description Function to make the leadtime exit from asapCutoffTime  
 * @param {string} response
 */
function leadTimeChangedToSpecificDate_WebApi(response, unavailableSlots) {
    $('#location-asapElement').hide();
    $("#location-specificdate").prop("checked", true);

    var cutOffTime = parseInt(sessionStorage.getItem('cutOffTime'));
    var leadTime = response && response.leadTime;
    if (!leadTime) {
        leadTime = response && response.successResponse && response.successResponse.leadTime;
    }
    var asapSelected;
    
    if ((disableOrderSettings && onlineTogoEnabled && (orderTypeValue == 0 || orderTypeValue == 3) && cartItemsCount == 0)) {
    	asapSelected = response && response.successResponse && response.successResponse.asapEnabled;
    } else {
    	asapSelected = response && response.successResponse && response.successResponse.asapSelected;
    }
    
    if (asapSelected === undefined) {
        asapSelected = response && response.successResponse.asapSelected;
        if (asapSelected === undefined) {
            asapSelected = response && response.successResponse.isAsapSelected;
        }
    }
    if (asapSelected && asapSelected === true || asapSelected === false) {
        sessionStorage.setItem('leadasapSelected', asapSelected);
    }
    if ((leadTime && cutOffTime && leadTime > cutOffTime) && (asapSelected && asapSelected === true)) {
        genrateNewTimeSlot(response, true, 'pickup-timelist', 'select-locationtime-list', unavailableSlots);
    }

    if (!$('#select-locationtime-list').attr('asapFlow')) {
        orderTypeSpecificDateEvent_WebApi(true);
    }
}

function orderTypeSpecificDateEvent_WebApi(leadTimeUpdate) {
    $('#location-asapdate').empty();
    if (!leadTimeUpdate) {
        $('#asapRadio').val('');
        $('#spacificRadio').val('true');
    }
    $('#specific-locationdate-time').show();
    var selectedDate = moment($('#datetimepicker-location').val()).format('MMM DD');
    var selectedTime = $('#select-locationtime-list').val();
    var isToday = moment($('#datetimepicker-location').val()).isSame(moment(), 'd');
    if (isToday) {
        $('#locationcurrent-date1').show();
    } else {
        $('#locationcurrent-date1').hide();
    }
    var template = renderLocationDateTemplate(selectedDate, selectedTime);
    $('#location-asapdate').append(template);
    restaurantClosedValidation();
}


/** @description Function to update pickup time value
 */
function updatePickupTime(initialDate) {
    var unavailableSlots = "";
    var availableSlots = "";
    $('#locationDTLoader').show();
    var restaurantId = $('#selected_res_id').val();
    var date;
    date = initialDate || $('#default_jsondate').val().trim() || $('#default_Delivery_jsondate').val().trim();

    if (!date) {
        date = today.format("MM/DD/YYYY");
    }

    $("#date_month_year").val(date);
    datePickerToggle(date);
    // api call for update pickup time
    var reqBody = {
        'orderType': orderTypeValue,
        'restaurantId': restaurantId,
        'pickupDate': date
    };
    getPickupTimeApi(reqBody).done(function(response) {
        var lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime;
        if (response) {
            lunch = response.times && response.times.lunch;
            dinner = response.times && response.times.dinner;
            interval = response.interval;
            leadTime = response.successResponse && response.successResponse.leadTime;
            asapEnabled = response.successResponse && response.successResponse.asapEnabled;
            asapSelected = response.successResponse && response.successResponse.asapSelected;
            asapCutOffTime = response.successResponse && response.successResponse.asapCutoffTime;

            setPickupInfoToSession(lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime);
        }
        if (response && response.successResponse && response.successResponse.capacitySlots) {
            unavailableSlots = response.successResponse.capacitySlots.unavailableSlots;
            availableSlots = response.successResponse.capacitySlots.availableSlots;
        }
        updateTimeslots(response, unavailableSlots);
        setLocationDateTime(date, response, availableSlots, unavailableSlots);
        // DTM event for location model START
        if ($("#dtmenabled").val() == "true") {
            if ($("input[name='location-pickupdate']:checked") && $('#select-locationtime-list') && $('#datetimepicker-location')) {
                var selectedTime = $('#select-locationtime-list').val();
                var selectedDate = moment($('#datetimepicker-location').val()).format("MM/DD/YYYY");
                var asapSelectedVal = $("input[name='location-pickupdate']:checked").val();
                var selectedASAP = false;
                if (asapSelectedVal && asapSelectedVal.indexOf("ASAP") != -1) {
                    selectedASAP = true;
                }
                var modalData = {
                    "selectedASAP": selectedASAP,
                    "puTime": selectedTime,
                    "puDate": selectedDate
                };
                if (selectedTime && asapSelectedVal) {
                    dtmModelEvents("ShowModal", modalData);
                }
            }
        }
        // DTM event for location model END
        $('#locationDTLoader').hide();
    });
}

/** @description Function to create datepicker using bootstarp datepicker
 * @param {string} id
 * @param {string} defaultDate
 * @param {boolean} isTodayClosed
 * @param {function} callback
 */
function createDatePicker(id, defaultDate, isTodayClosed, callback, reqBody, updateSuccessCallback) {
    var isTodayClosed = sessionStorage.getItem('restaurantTimeOver') || isTodayClosed || sessionStorage.getItem('isTodayClosed')
    var formattedClosedDates = [];
    var disabledDates = sessionStorage.getItem('disabledDates');
    if (disabledDates) {
        var dateStr = disabledDates.split(',');
        formattedClosedDates = formattedClosedDates.concat(dateStr || []);
    }
    if (isTodayClosed && isTodayClosed.length) {
        sessionStorage.removeItem('isTodayClosed')
        formattedClosedDates.push(moment().format("MM/DD/YYYY"))
    }

    if (formattedClosedDates.length)
        sessionStorage.setItem('disabledDates', formattedClosedDates)
    var dateTimePicker = $('#' + id).data("DateTimePicker");
    if (dateTimePicker) {
        dateTimePicker.destroy();
        if ($._data($('#' + id)[0], 'events')) $('#' + id).off();
        $('#' + id).val('');
    }

    var futureDaysThreshold = $('#futureDaysThreshold').val();
    if (futureDaysThreshold) {
        futureDaysThreshold = parseInt($('#futureDaysThreshold').val() - 1);
    } else {
        futureDaysThreshold = 29;
    }

    $('#' + id).datetimepicker({
        format: "MM/DD/YYYY",
        extraFormats: ['MM/DD/YYYY'],
        debug: true,
        minDate: moment().format("MM/DD/YYYY"),
        maxDate: moment().add(futureDaysThreshold, "day").format("MM/DD/YYYY"),
        disabledDates: formattedClosedDates,
        defaultDate: defaultDate || moment(),
        ignoreReadonly: true //for accessing in readonly input field
    });
    $('#' + id).on('dp.change', function(val) {
        var restaurantId = $('#selected_res_id').val();
        if (!restaurantId) {
            restaurantId = getCookie("DRIREST", 0);
        }
        addRestaurantDate(reqBody, restaurantId, moment(val.date._d).format('MM/DD/YYYY'));
        reqBody['nextAvailableSlot'] = false;
        var availableSlots = "";
        var isShowModal = false;

        getCapacityTimeslots(reqBody).done(function(responseCapacity) {
            if (responseCapacity && responseCapacity.successResponse && responseCapacity.successResponse.capacitySlots) {
                availableSlots = responseCapacity.successResponse.capacitySlots.availableSlots;
                if (availableSlots && availableSlots.length <= 0) {
                    isShowModal = true;
                }
            }
            if (isShowModal == true) {
                var lastSelectedDate = $('#date_month_year').val();
                if (!lastSelectedDate)
                    lastSelectedDate = defaultDate;
                $('#' + id).val(lastSelectedDate);
                $('#ordertype-selected-day-errormodal').modal('show');
                $('#ordertype-selected-day-errormodal').attr("style", "width:100% !important");
            } else {
                callback(val, reqBody);
            }
        });
    });

    if (updateSuccessCallback)
        updateSuccessCallback(defaultDate);
}
/** @description Callback function for date change
 * @param {object} selectDate
 */
function dateChangeHandler(selectDate, reqBody) {
    var unavailableSlots = "";
    var availableSlots = "";

    $('#locationDTLoader').show();
    $('#errorMsg').hide();

    var date = moment(selectDate.date._d).format('MMM DD');
    var formatedDate = moment(selectDate.date._d).format('MM/DD/YYYY');
    var restaurantId = $('#selected_res_id').val();
    datePickerToggle(selectDate.date._d);
    $('#date_month_year').val(formatedDate);

    getPickupTimeApi(reqBody).done(function(response) {
        var lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime;
        if (response) {
            lunch = response.times && response.times.lunch;
            dinner = response.times && response.times.dinner;
            interval = response.interval;
            leadTime = response.successResponse && response.successResponse.leadTime;
            asapEnabled = response.successResponse && response.successResponse.asapEnabled;
            asapSelected = response.successResponse && response.successResponse.asapSelected;
            asapCutOffTime = response.successResponse && response.successResponse.asapCutoffTime;
        }
        setPickupInfoToSession(lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime);
        if (response && response.successResponse && response.successResponse.capacitySlots) {
            unavailableSlots = response.successResponse.capacitySlots.unavailableSlots;
            availableSlots = response.successResponse.capacitySlots.availableSlots;
        }
        updateTimeslots(response, unavailableSlots);
        setLocationDateTime(formatedDate, response, availableSlots, unavailableSlots);
        $('#locationDTLoader').hide();
    });
}

function cancelPickupTime() {
    $("#isToGoLocationConfirmed").val(false);
}
/** @description callback function for confirm button
 */
function confirmHandler() {
    $("#confirm-location-btn").addClass("btn-img-loader");
    var restaurantId = $('#selected_res_id').val();
    var pickupTime = $('#select-locationtime-list').val();
    var pickupDate = moment($('#datetimepicker-location').val()).format("MM/DD/YYYY");
    var pickUpdateSelectedId = $('input[name="location-pickupdate"]:checked').attr('id');
    var isAsapSelected = false;
    var interval = sessionStorage.getItem('timeInterval');

    if (pickUpdateSelectedId == 'location-asap') {
        isAsapSelected = true;
    } else if (validateIfAsapTime(pickupTime, interval)) {
        isAsapSelected = true;
    }
    locationTimeApi(restaurantId, pickupDate, pickupTime, false, isAsapSelected).done(function(response) {
        $("#confirm-location-btn").removeClass("btn-img-loader");
        if (response.status == 'success') {
            $('#location-modal').modal('hide');
            $("#isToGoLocationConfirmed").val(true);
            var locationInfo = getSessionStorage('locationCallback');
            removeSessionStorage('locationCallback');
            if (locationInfo === 'toGoReOrder') {
                $('#togo_reorder_addtocart' + $('#reOrderSource').val()).trigger("click");
                $('#reOrderSource').val('');
            } else if (locationInfo === 'toGoFavorites') {
                var navURL = getSessionStorage('locationNavURL');
                removeSessionStorage('locationNavURL');
                window.open(navURL, '_self')
            } else {
                if ($("#confirm-location-btn").attr("data-element") != undefined &&
                    $("#confirm-location-btn").attr("data-element").length > 0) {
                    $("#confirm-location-btn").attr('data-refresh', true);
                    $("#" + $("#confirm-location-btn").attr("data-element")).trigger("click");
                } else {
                    $("#confirm-location-btn").attr('data-refresh', true);
                    $("#addToCart").trigger("click");
                }
            }
            getOrderSettingApi(null, init);
        } else if (response.errorResponse != undefined) {
            $('#errorMsg').html(response.errorResponse.fault.faultDescription);
            $('#errorMsg').css('display', 'block');
        } else if (response.formExceptions != undefined) {
            $('#errorMsg').html(response.formExceptions.faultDescription);
            $('#errorMsg').css('display', 'block');
        }
    });
}

/** @description update timeslots based on selected date
 * make update time slot api
 * @param {object} response
 */
function updateTimeslots(response, unavailableSlots) {
    var interval = response.interval;
    $('#select-locationtime-list').empty();
    var selectedTime = $('#default_jsontime').val() || $('#default_Delivery_jsontime').val();
    var selectedonchangegval = $('#locselected-time-val').val();
    if (selectedonchangegval) {
        selectedTime = selectedonchangegval;
    }
    var slotAvaErr = false;
    var bLunchHour = false;
    // render lunch timing
    if (response.times.lunch && response.times.lunch != "false") {
        var startTime = response.times.lunch.startTime;
        var endTime = response.times.lunch.endTime;
        var template = renderTimeSlotOptions(startTime, endTime, interval, selectedTime, unavailableSlots);
        if (template) {
            $('#select-locationtime-list').append(template);
            bLunchHour = true;
        } else {
            slotAvaErr = true;
            $('#select-locationtime-list').append('<option value=" " >' + $('#noSlotAvaialbleMessage').val() + '</option>');
        }
    }
    // render dinner timing
    if (response.times.dinner && response.times.dinner != "false") {
        var dinnerStartTime = response.times.dinner.startTime;
        var dinnerEndTime = response.times.dinner.endTime;
        var template = renderTimeSlotOptions(dinnerStartTime, dinnerEndTime, interval, selectedTime, unavailableSlots);
        if (template) {
            if (slotAvaErr) {
                $('#select-locationtime-list').empty();
            }
            $('#select-locationtime-list').append(template);
        } else {
            if (!slotAvaErr && !bLunchHour) {
                $('#select-locationtime-list').append('<option value=" " >' + $('#noSlotAvaialbleMessage').val() + '</option>');
            }
        }
    }
};

/** @description Function to make the api call for location time
 * @param {string} restaurantId
 * @param {string} pickupDate
 * @param {string} pickupTime
 */
function locationTimeApi(restaurantId, pickupDate, pickupTime, togoMenuFlow, isAsapSelected) {
    var reqBody = {
        "restaurantId": restaurantId,
        "requestedPickupDate": pickupDate,
        "requestedPickupTime": pickupTime,
        "togoMenuFlow": togoMenuFlow,
        "asapSelected": isAsapSelected
    };
    var orderType = $('#sessionOrderType').val();
    if (orderType === undefined || orderType === '' || orderType === 'togo-pickup-order') {
        reqBody['orderFlow'] = 'togo-pickup-order';
    }
    addSiteCodes(reqBody);
    return $.ajax({
        url: '/web-api/order/pickup/location-time',
        data: reqBody,
        type: "POST"
    });
}

// DTM data update for location confirmation popup START
$(document).on("click", "#confirm-location-btn", function() {
    if ($("#dtmenabled").val() == "true") {
        var pickupTime = "notDefine";
        var pickupDate = "notDefine";
        var restaurantId = "notDefine";

        if ($('#select-locationtime-list')) {
            pickupTime = $('#select-locationtime-list').val();
        }

        if ($('#datetimepicker-location')) {
            pickupDate = moment($('#datetimepicker-location').val()).format("MM/DD/YYYY");
        }
        if ($("#selected_res_id")) {
            restaurantId = $("#selected_res_id").val();
        }
        var asapSelectedVal = $("input[name='location-pickupdate']:checked").val();
        var selectedASAP = false;
        if (asapSelectedVal && asapSelectedVal.indexOf("ASAP") != -1) {
            selectedASAP = true;
        }
        var data = {
            "pickupTime": pickupTime,
            "pickupDate": pickupDate,
            "restaurantId": restaurantId,
            "selectedASAP": selectedASAP
        };
        dtmStore(data);
        if (window.sessionStorage) {
            sessionStorage.setItem("dtmTimeCnfrmModel", true);
        }
    }
});


// DTM data update for location confirmation popup END

/** @description Function to make the time api call to find next available time
 * @param {string} selectedDate
 * @param {string} response
 */
function locationNextAvailableDate(selectedDate, response) {
    var locPickupDate;
    var unavailableSlots = "";
    var availableSlots = "";
    var locNewDate = sessionStorage.getItem('locNewDate');
    if (locNewDate) {
        sessionStorage.removeItem('locNewDate');
        locPickupDate = locNewDate;
    } else {
        locPickupDate = moment().format("MM/DD/YYYY");
    }
    var restaurantId = getCookie("DRIREST", 0);
    var timeReqBody = {
        'restaurantId': restaurantId,
        'pickupDate': locPickupDate,
        'orderType': $('#orderTypeValue').val()
    };
    getPickupTimeApi(timeReqBody).done(function(response) {
        if (response && response.successResponse && response.successResponse.capacitySlots) {
            unavailableSlots = response.successResponse.capacitySlots.unavailableSlots;
            availableSlots = response.successResponse.capacitySlots.availableSlots;
        }
        var initialDate = locPickupDate;
        var formattedClosedDates = formatClosedDates(response.restaurantHolidays);
        var restaurantClosed, lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime;
        if (response) {
            restaurantClosed = response.restaurantClosed;
            lunch = response.times && response.times.lunch;
            dinner = response.times && response.times.dinner;
            interval = response.interval;
            leadTime = response.successResponse && response.successResponse.leadTime;
            asapEnabled = response.successResponse && response.successResponse.asapEnabled;
            asapSelected = response.successResponse && response.successResponse.asapSelected;
            asapCutOffTime = response.successResponse && response.successResponse.asapCutoffTime;
        }

        setPickupInfoToSession(lunch, dinner, interval, leadTime, asapEnabled, asapSelected, asapCutOffTime);
        if (restaurantClosed && restaurantClosed == 'true' || (lunch === false && dinner === false)) {
            do {
                var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
                initialDate = newDate.format('MM/DD/YYYY')
            } while (formattedClosedDates.indexOf(initialDate) != -1);
        } else {
            while (formattedClosedDates.indexOf(initialDate) != -1) {
                var newDate = moment(initialDate, "MM/DD/YYYY").add('days', 1);
                initialDate = newDate.format('MM/DD/YYYY')
            }
        }
        if (initialDate != locPickupDate) {
            sessionStorage.setItem('locNewDate', initialDate);
            locationNextAvailableDate([], response)
        } else {
            $('#locationcurrent-date1,#pickup-dt-title-panel').hide();
            /*ordersettings bar data update*/
            var reqBody = {
                'orderType': $('#orderTypeValue').val(),
                'nextAvailableSlot': 'true'
            };
            $('#default_jsondate').val(initialDate)
            datePicker('ordertype-datetimepicker', [], orderDateTimeChangeHandler, initialDate, null, reqBody);
            orderTypeSelectHandler(response);
            timepicker_API(response, true);
            /*location modal data update*/
            createDatePicker('datetimepicker-location', initialDate, false, dateChangeHandler, reqBody);
            updateTimeslots(response, unavailableSlots);
            setLocationDateTime(initialDate, response, availableSlots, unavailableSlots);

        }
    });
}