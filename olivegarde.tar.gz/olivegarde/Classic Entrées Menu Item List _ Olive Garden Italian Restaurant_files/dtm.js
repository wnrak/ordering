/* Method to read url parameters */ 	 
function getParameterByName(name, url) {
    if (!url) {
      url = window.location.href;
    }
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

// common method to call DTM events from JS
function dtmEvent(name, type){
	if($("#dtmenabled").val() && $("#dtmenabled").val()=="true")
	{	
    	var ddlistEvent = {
				"eventInfo": {
					"eventName": name,
					"type": type,
					"timeStamp": new Date(),
					"processed": {
						"adobeAnalytics": false
					}
				}
			};

			if (window.digitalData != null) {
			delete digitalData.event;	
			digitalData.event = digitalData.event || [];	
			window.digitalData.event.push(ddlistEvent);
			sendCustomEvent(name);
			}
	}
	
}

// method to call on custom event and after ajax call
function sendCustomEvent(evt) {
	var event;
	if (typeof document.body === 'object' && document.body !== null) {
		if (document.createEvent && document.body.dispatchEvent) {
			event = document.createEvent('Event');
			event.initEvent(evt, true, true); // can bubble, and is
												// cancellable
			document.body.dispatchEvent(event);
		} else if (window.CustomEvent && document.body.dispatchEvent) {
			event = new CustomEvent(evt, {
				bubbles : true,
				cancelable : true
			});
			document.body.dispatchEvent(event);
		}
	}
}

// tmp soln for remove cart
$( document ).ready(function() { 
$(".dar-gc-rmvebtn").on("click", function(){
	if(window.sessionStorage && $(this).parent() &&  $(this).parent().parent() && jQuery($(this).parent()).find("p") && jQuery($(this).parent()).find("p").length > 1 && jQuery($(this).parent().parent()).find("figcaption")){
	var priceInNum = jQuery(jQuery($(this).parent()).find("p")[1]).text().trim().replace("$","");
	sessionStorage.setItem("rmvItemPrice",priceInNum);
	sessionStorage.setItem("rmvItemType",jQuery(jQuery($(this).parent().parent()).find("figcaption")).text().trim());
	}
});
$(".dar-gc-remove").on("click", function(){
	if(window.sessionStorage && $(this).parent() &&  $(this).parent().parent() && jQuery($(this).parent()).find("p") && jQuery($(this).parent()).find("p").length > 1 && jQuery($(this).parent().parent()).find("figcaption")){
	var priceInNum = jQuery(jQuery($(this).parent()).find("p")[1]).text().trim().replace("$","");
	sessionStorage.setItem("rmvItemPrice",priceInNum);
	sessionStorage.setItem("rmvItemType",jQuery(jQuery($(this).parent().parent()).find("figcaption")).text().trim());
	}	
});
$("#save-subscriptions").on("click", function(){
	if(window.sessionStorage) {
		if($("#subscriptionInfo_emailcheckbox").attr("checked")){
		sessionStorage.setItem("eclubChecked", "true");	
		}
	}		
});
// Added for mothers day dtm events by Jaydeep START
$("#SubmitOrder").on("click", function(){
		if(window.sessionStorage) {
			if($("#offers").attr("checked") || $("#radio-checkbox").attr("checked"))
			{
				sessionStorage.setItem("eclubChecked", "true");								
			}
			if($("#noOfGuests") && $("#noOfGuests").val()){
				sessionStorage.setItem("noOfGuests", $("#noOfGuests").val());
			}
			if($("#subTotal") && $("#subTotal").text()){
				var basePrice = $("#subTotal").text().replace("$","");
				sessionStorage.setItem("basePrice", basePrice);
			}
			if($("#estimatedTotal") && $("#estimatedTotal").text()){
				var priceTotal = $("#estimatedTotal").text().replace("$","");
				sessionStorage.setItem("priceTotal", priceTotal);
			}
		}		
		 	
});
// Added for mothers day dtm events END						
});	

/* function dtmModelEvents(name, intent, content, modelName){
	// on display of modal Added for welcome popup
	  var modalData = {
		 "modalName":name,
		 "modalIntent":intent,
		 "modalContent":content
	   }
		AU.dispatchEvent('AnalyticsEvent',modelName,modalData);
	// DTM eclub event END
} */
function dtmModelEvents(modelName,data){
	 if(!jQuery.isEmptyObject(data) && typeof window.AU !== "undefined"){
	 AU.dispatchEvent('AnalyticsEvent',modelName,data);
	 }	 
}

function dtmStore(data){
	if(!jQuery.isEmptyObject(data) && typeof window.AU !== "undefined"){
		Object.keys(data).forEach(function(key){
			var value = data[key];
			if(key && value){
				AU.store(key, value);
			}			
		});		
	}	
}

/**
 * Start of DFA FLOODLIGHT TAGGING for on click
 * Please don't remove this code. Moved from Custom JS to DTM
 */
